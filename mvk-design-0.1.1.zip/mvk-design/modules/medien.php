<?php
/**
 * MVK Design · Modul Medien
 * 1. Alt-Live-Sync: Alt-Text aus der Mediathek gewinnt beim Ausspielen (ersetzt Code Snippet 9, erkennt zusätzlich Bilder ohne wp-image-Klasse über den Dateinamen).
 * 2. REST GET  /mvk-design/v1/media/inventory  Inventar aller Bilder mit Verwendung (Inhalte, Metafelder, Optionen, CSS-Dateien).
 * 3. REST POST /mvk-design/v1/media/rename     Datei samt Größen und WebP/AVIF umbenennen, Verweise ersetzen, alte Adresse per 301 weiterleiten.
 * 4. 301 für umbenannte Dateien (Option mvkd_media_redirects).
 */

defined( 'ABSPATH' ) || exit;

/* ------------------------------------------------------------------ */
/* Hilfen                                                              */
/* ------------------------------------------------------------------ */
function mvkd_upload_base() {
	$u = wp_get_upload_dir();
	return array( 'dir' => trailingslashit( $u['basedir'] ), 'url' => trailingslashit( $u['baseurl'] ) );
}

/** Stamm eines Anhangs relativ zu uploads, ohne Endung und ohne -scaled, z. B. 2025/12/bolte-kueche-1 */
function mvkd_attachment_stem( $id ) {
	$rel = (string) get_post_meta( $id, '_wp_attached_file', true );
	if ( '' === $rel ) {
		return '';
	}
	$meta = wp_get_attachment_metadata( $id );
	if ( is_array( $meta ) && ! empty( $meta['original_image'] ) ) {
		$rel = trailingslashit( dirname( $rel ) ) . $meta['original_image'];
	}
	$stem = preg_replace( '/\.[a-z0-9]+$/i', '', $rel );
	return preg_replace( '/-scaled$/', '', $stem );
}

/** Endungsteil hinter dem Stamm: Größen, -scaled/-rotated, Editor-Suffix, Endung (WebP/AVIF-Anhängsel bleiben dahinter erhalten). */
function mvkd_suffix_pattern() {
	return '(?:-e\\d{10,})?(?:-\\d+x\\d+)?(?:-scaled|-rotated)?(?:-\\d+x\\d+)?\\.(?:jpe?g|png|gif|webp|avif)';
}

/** Regex auf einen Stamm (z. B. 2025/12/name). Gruppe 1 = Ordnerteil (auch mit \\/ aus JSON), danach der Dateiname. */
function mvkd_stem_regex( $stem ) {
	$parts = explode( '/', $stem );
	$name  = array_pop( $parts );
	$dir   = '';
	foreach ( $parts as $p ) {
		$dir .= preg_quote( $p, '~' ) . '\\\\?/';
	}
	$lead = '' === $dir ? '(/)' : '(' . $dir . ')';
	return '~' . $lead . preg_quote( $name, '~' ) . '(?=' . mvkd_suffix_pattern() . ')~i';
}

/** Sucht rekursiv in Arrays/Objekten/Strings und ersetzt per Regex. */
function mvkd_deep_replace( $value, $regex, $replacement, &$count ) {
	if ( is_string( $value ) ) {
		$new = preg_replace( $regex, $replacement, $value, -1, $n );
		$count += $n;
		return $new;
	}
	if ( is_array( $value ) ) {
		foreach ( $value as $k => $v ) {
			$value[ $k ] = mvkd_deep_replace( $v, $regex, $replacement, $count );
		}
		return $value;
	}
	if ( is_object( $value ) && ! ( $value instanceof __PHP_Incomplete_Class ) ) {
		foreach ( get_object_vars( $value ) as $k => $v ) {
			$value->$k = mvkd_deep_replace( $v, $regex, $replacement, $count );
		}
	}
	return $value;
}

/** CSS-Dateien in uploads (Essential Blocks, GenerateBlocks u. a.). */
function mvkd_css_files() {
	$base  = mvkd_upload_base()['dir'];
	$files = array();
	foreach ( array( 'eb-style', 'generateblocks', 'essential-blocks', 'eb-custom-css', 'generatepress' ) as $sub ) {
		if ( ! is_dir( $base . $sub ) ) {
			continue;
		}
		$it = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $base . $sub, FilesystemIterator::SKIP_DOTS ) );
		foreach ( $it as $f ) {
			if ( preg_match( '/\.css$/i', $f->getFilename() ) ) {
				$files[] = $f->getPathname();
			}
		}
	}
	return $files;
}

/* ------------------------------------------------------------------ */
/* 1. Alt-Live-Sync                                                    */
/* ------------------------------------------------------------------ */
function mvkd_file_map() {
	$map = get_transient( 'mvkd_file_map' );
	if ( is_array( $map ) ) {
		return $map;
	}
	global $wpdb;
	$map  = array();
	$rows = $wpdb->get_results( "SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_wp_attached_file'" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	foreach ( $rows as $r ) {
		$stem = preg_replace( '/(-scaled)?\.[a-z0-9]+$/i', '', basename( $r->meta_value ) );
		$map[ strtolower( $stem ) ] = (int) $r->post_id;
	}
	set_transient( 'mvkd_file_map', $map, DAY_IN_SECONDS );
	return $map;
}
add_action( 'add_attachment', function () { delete_transient( 'mvkd_file_map' ); } );
add_action( 'delete_attachment', function () { delete_transient( 'mvkd_file_map' ); } );

function mvkd_alt_live_sync( $content ) {
	if ( empty( $content ) || false === stripos( $content, '<img' ) ) {
		return $content;
	}
	return preg_replace_callback( '/<img\b[^>]*>/i', function ( $m ) {
		$img = $m[0];
		$id  = 0;
		if ( preg_match( '/wp-image-(\d+)/', $img, $mm ) ) {
			$id = (int) $mm[1];
		} elseif ( preg_match( '/\ssrc\s*=\s*["\']([^"\']+)["\']/i', $img, $mm ) && false !== strpos( $mm[1], '/wp-content/uploads/' ) ) {
			$stem = preg_replace( '/(-\d+x\d+)?(-scaled)?\.[a-z0-9]+$/i', '', basename( wp_parse_url( $mm[1], PHP_URL_PATH ) ) );
			$map  = mvkd_file_map();
			$id   = isset( $map[ strtolower( $stem ) ] ) ? $map[ strtolower( $stem ) ] : 0;
		}
		if ( ! $id ) {
			return $img;
		}
		$alt = get_post_meta( $id, '_wp_attachment_image_alt', true );
		if ( '' === $alt || null === $alt ) {
			return $img;
		}
		$attr = 'alt="' . esc_attr( $alt ) . '"';
		if ( preg_match( '/\salt\s*=\s*("[^"]*"|\'[^\']*\')/i', $img ) ) {
			return preg_replace( '/\salt\s*=\s*("[^"]*"|\'[^\']*\')/i', ' ' . $attr, $img, 1 );
		}
		return preg_replace( '/<img\b/i', '<img ' . $attr, $img, 1 );
	}, $content );
}
add_filter( 'the_content', 'mvkd_alt_live_sync', 99 );
add_filter( 'widget_block_content', 'mvkd_alt_live_sync', 99 );

/* ------------------------------------------------------------------ */
/* 2. Inventar                                                         */
/* ------------------------------------------------------------------ */
/** Lädt einmal alle Texte, in denen Bilddateien vorkommen können. */
function mvkd_corpus() {
	global $wpdb;
	$c = array( 'posts' => array(), 'meta' => array(), 'options' => array(), 'css' => array(), 'thumbs' => array() );
	foreach ( $wpdb->get_results( "SELECT ID, post_type, post_status, post_title, post_content, post_excerpt FROM {$wpdb->posts} WHERE post_type NOT IN ('revision','attachment','nav_menu_item','customize_changeset','oembed_cache') AND post_status NOT IN ('auto-draft','trash','inherit')" ) as $r ) { // phpcs:ignore
		$c['posts'][] = $r;
	}
	foreach ( $wpdb->get_results( "SELECT post_id, meta_key, meta_value FROM {$wpdb->postmeta} WHERE meta_key NOT IN ('_wp_attached_file','_wp_attachment_metadata','_wp_attachment_backup_sizes') AND meta_value LIKE '%uploads%'" ) as $r ) { // phpcs:ignore
		$c['meta'][] = $r;
	}
	foreach ( $wpdb->get_results( "SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_thumbnail_id'" ) as $r ) { // phpcs:ignore
		$c['thumbs'][ (int) $r->meta_value ][] = (int) $r->post_id;
	}
	foreach ( $wpdb->get_results( "SELECT option_name, option_value FROM {$wpdb->options} WHERE option_name NOT LIKE '\\_%transient%' AND option_name NOT LIKE 'mvkd\\_%' AND option_value LIKE '%uploads%'" ) as $r ) { // phpcs:ignore
		$c['options'][] = $r;
	}
	$base = mvkd_upload_base()['dir'];
	foreach ( mvkd_css_files() as $f ) {
		$c['css'][ substr( $f, strlen( $base ) ) ] = (string) file_get_contents( $f ); // phpcs:ignore
	}
	return $c;
}

function mvkd_usage( $id, $stem, $c ) {
	$regex = mvkd_stem_regex( $stem );
	$name  = basename( $stem );
	$u     = array( 'posts' => array(), 'meta' => array(), 'options' => array(), 'css' => array() );
	foreach ( $c['posts'] as $r ) {
		$hit = ( false !== stripos( $r->post_content, $name ) && preg_match( $regex, $r->post_content ) )
			|| preg_match( '/wp-image-' . (int) $id . '\b|"id":' . (int) $id . '\b/', $r->post_content );
		if ( $hit ) {
			$u['posts'][] = array( 'id' => (int) $r->ID, 'type' => $r->post_type, 'status' => $r->post_status, 'title' => $r->post_title );
		}
	}
	foreach ( $c['meta'] as $r ) {
		if ( (int) $r->post_id !== (int) $id && false !== stripos( $r->meta_value, $name ) && preg_match( $regex, $r->meta_value ) ) {
			$u['meta'][] = array( 'post_id' => (int) $r->post_id, 'key' => $r->meta_key );
		}
	}
	if ( isset( $c['thumbs'][ $id ] ) ) {
		foreach ( $c['thumbs'][ $id ] as $p ) {
			$u['meta'][] = array( 'post_id' => $p, 'key' => '_thumbnail_id' );
		}
	}
	foreach ( $c['options'] as $r ) {
		if ( false !== stripos( $r->option_value, $name ) && preg_match( $regex, $r->option_value ) ) {
			$u['options'][] = $r->option_name;
		}
	}
	foreach ( $c['css'] as $f => $css ) {
		if ( false !== stripos( $css, $name ) && preg_match( $regex, $css ) ) {
			$u['css'][] = $f;
		}
	}
	return $u;
}

function mvkd_inventory( WP_REST_Request $req ) {
	$base   = mvkd_upload_base();
	$usage  = (bool) $req->get_param( 'usage' );
	$offset = max( 0, (int) $req->get_param( 'offset' ) );
	$limit  = (int) $req->get_param( 'limit' );
	$short  = (bool) $req->get_param( 'short' );
	$ids    = get_posts( array( 'post_type' => 'attachment', 'post_status' => 'inherit', 'post_mime_type' => 'image', 'posts_per_page' => -1, 'fields' => 'ids', 'orderby' => 'ID', 'order' => 'ASC' ) );
	$total  = count( $ids );
	$ids    = array_slice( $ids, $offset, $limit > 0 ? $limit : null );
	$corpus = $usage ? mvkd_corpus() : null;
	$out    = array();
	foreach ( $ids as $id ) {
		$rel  = (string) get_post_meta( $id, '_wp_attached_file', true );
		$meta = wp_get_attachment_metadata( $id );
		$stem = mvkd_attachment_stem( $id );
		$path = $base['dir'] . $rel;
		$row  = array(
			'id'     => $id,
			'file'   => $rel,
			'w'      => is_array( $meta ) && isset( $meta['width'] ) ? (int) $meta['width'] : 0,
			'h'      => is_array( $meta ) && isset( $meta['height'] ) ? (int) $meta['height'] : 0,
			'kb'     => file_exists( $path ) ? (int) round( filesize( $path ) / 1024 ) : -1,
			'date'   => substr( get_post_field( 'post_date', $id ), 0, 10 ),
			'parent' => (int) get_post_field( 'post_parent', $id ),
			'alt'    => (string) get_post_meta( $id, '_wp_attachment_image_alt', true ),
			'title'  => get_post_field( 'post_title', $id ),
		);
		if ( ! $short ) {
			$row['caption']     = get_post_field( 'post_excerpt', $id );
			$row['description'] = get_post_field( 'post_content', $id );
			$row['sizes']       = is_array( $meta ) && ! empty( $meta['sizes'] ) ? count( $meta['sizes'] ) : 0;
			$row['webp']        = file_exists( $path . '.webp' ) || file_exists( preg_replace( '/\.[a-z0-9]+$/i', '.webp', $path ) );
		}
		if ( $usage && $stem ) {
			$row['usage'] = mvkd_usage( $id, $stem, $corpus );
		}
		$out[] = $row;
	}
	return array( 'version' => MVKD_VERSION, 'total' => $total, 'offset' => $offset, 'count' => count( $out ), 'items' => $out );
}

/* ------------------------------------------------------------------ */
/* 3. Umbenennen                                                       */
/* ------------------------------------------------------------------ */
function mvkd_rename( WP_REST_Request $req ) {
	global $wpdb;
	$id      = (int) $req->get_param( 'id' );
	$dry     = (bool) $req->get_param( 'dry_run' );
	$new_raw = (string) $req->get_param( 'new_stem' );
	if ( 'attachment' !== get_post_type( $id ) ) {
		return new WP_Error( 'mvkd_no_attachment', 'Kein Anhang.', array( 'status' => 404 ) );
	}
	$base     = mvkd_upload_base();
	$rel      = (string) get_post_meta( $id, '_wp_attached_file', true );
	$meta     = wp_get_attachment_metadata( $id );
	$old_stem = mvkd_attachment_stem( $id );
	$subdir   = dirname( $old_stem );
	$prefix   = ( '.' === $subdir || '' === $subdir ) ? '' : $subdir . '/';
	$old_name = basename( $old_stem );
	$new_name = sanitize_title( remove_accents( preg_replace( '/\.[a-z0-9]+$/i', '', basename( $new_raw ) ) ) );
	if ( '' === $new_name || $new_name === $old_name ) {
		return new WP_Error( 'mvkd_bad_name', 'Neuer Name fehlt oder ist gleich.', array( 'status' => 400 ) );
	}
	$dir   = $base['dir'] . $prefix;
	$final = $new_name;
	$i     = 2;
	while ( glob( $dir . $final . '.*' ) || glob( $dir . $final . '-*x*.*' ) || glob( $dir . $final . '-scaled.*' ) ) {
		$final = $new_name . '-' . $i++;
	}
	$new_stem = $prefix . $final;

	// Dateien: Original, Größen, -scaled, WebP/AVIF-Geschwister, Imagify-Sicherungen
	$regex_file = '~^' . preg_quote( $old_name, '~' ) . '(' . mvkd_suffix_pattern() . '(?:\.(?:webp|avif))?)$~i';
	$files      = array();
	foreach ( array( $dir, $base['dir'] . 'backup/' . $prefix ) as $d ) {
		foreach ( (array) glob( $d . $old_name . '*' ) as $f ) {
			if ( preg_match( $regex_file, basename( $f ), $mm ) ) {
				$files[ substr( $f, strlen( $base['dir'] ) ) ] = substr( $d, strlen( $base['dir'] ) ) . $final . $mm[1];
			}
		}
	}

	$regex  = mvkd_stem_regex( $old_stem );
	$repl   = '${1}' . $final;
	$like   = '%' . $wpdb->esc_like( $old_name ) . '%';
	$report = array( 'id' => $id, 'old' => $old_stem, 'new' => $new_stem, 'files' => $files, 'posts' => array(), 'meta' => array(), 'options' => array(), 'css' => array(), 'dry_run' => $dry );

	$rows = $wpdb->get_results( $wpdb->prepare( "SELECT ID, post_content, post_excerpt FROM {$wpdb->posts} WHERE post_type <> 'revision' AND (post_content LIKE %s OR post_excerpt LIKE %s)", $like, $like ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	foreach ( $rows as $r ) {
		$pc = preg_replace( $regex, $repl, $r->post_content, -1, $a );
		$pe = preg_replace( $regex, $repl, $r->post_excerpt, -1, $b );
		if ( $a + $b ) {
			$report['posts'][ $r->ID ] = $a + $b;
			if ( ! $dry ) {
				$wpdb->update( $wpdb->posts, array( 'post_content' => $pc, 'post_excerpt' => $pe ), array( 'ID' => $r->ID ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
				clean_post_cache( $r->ID );
			}
		}
	}
	$mrows = $wpdb->get_results( $wpdb->prepare( "SELECT meta_id, post_id, meta_key, meta_value FROM {$wpdb->postmeta} WHERE meta_key NOT IN ('_wp_attached_file','_wp_attachment_metadata') AND meta_value LIKE %s", $like ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	foreach ( $mrows as $r ) {
		$n   = 0;
		$new = mvkd_deep_replace( maybe_unserialize( $r->meta_value ), $regex, $repl, $n );
		if ( $n ) {
			$report['meta'][] = array( 'post_id' => (int) $r->post_id, 'key' => $r->meta_key, 'n' => $n );
			if ( ! $dry ) {
				$wpdb->update( $wpdb->postmeta, array( 'meta_value' => maybe_serialize( $new ) ), array( 'meta_id' => $r->meta_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
				wp_cache_delete( (int) $r->post_id, 'post_meta' );
			}
		}
	}
	$orows = $wpdb->get_results( $wpdb->prepare( "SELECT option_name, option_value FROM {$wpdb->options} WHERE option_name NOT LIKE %s AND option_name NOT LIKE %s AND option_value LIKE %s", '\_transient%', '\_site\_transient%', $like ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	foreach ( $orows as $r ) {
		if ( in_array( $r->option_name, array( 'mvkd_media_redirects', 'mvkd_media_renames', 'mvkd_media_meta_backup' ), true ) ) {
			continue;
		}
		$n   = 0;
		$new = mvkd_deep_replace( maybe_unserialize( $r->option_value ), $regex, $repl, $n );
		if ( $n ) {
			$report['options'][ $r->option_name ] = $n;
			if ( ! $dry ) {
				$wpdb->update( $wpdb->options, array( 'option_value' => maybe_serialize( $new ) ), array( 'option_name' => $r->option_name ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
				wp_cache_delete( $r->option_name, 'options' );
			}
		}
	}
	foreach ( mvkd_css_files() as $f ) {
		$c  = (string) file_get_contents( $f ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$nc = preg_replace( $regex, $repl, $c, -1, $n );
		if ( $n ) {
			$report['css'][ substr( $f, strlen( $base['dir'] ) ) ] = $n;
			if ( ! $dry ) {
				if ( ! file_exists( $f . '.mvkbak' ) ) {
					copy( $f, $f . '.mvkbak' );
				}
				file_put_contents( $f, $nc ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			}
		}
	}
	if ( $dry ) {
		return $report;
	}

	foreach ( $files as $old => $new ) {
		if ( ! @rename( $base['dir'] . $old, $base['dir'] . $new ) ) { // phpcs:ignore
			$report['errors'][] = 'Umbenennen fehlgeschlagen: ' . $old;
		}
	}
	$swap    = function ( $file ) use ( $old_name, $final ) {
		return preg_replace( '~^' . preg_quote( $old_name, '~' ) . '~', $final, $file );
	};
	$new_rel = $prefix . $swap( basename( $rel ) );
	update_post_meta( $id, '_wp_attached_file', $new_rel );
	if ( is_array( $meta ) ) {
		if ( ! empty( $meta['file'] ) ) {
			$meta['file'] = $new_rel;
		}
		if ( ! empty( $meta['original_image'] ) ) {
			$meta['original_image'] = $swap( $meta['original_image'] );
		}
		if ( ! empty( $meta['sizes'] ) ) {
			foreach ( $meta['sizes'] as $k => $sz ) {
				$meta['sizes'][ $k ]['file'] = $swap( $sz['file'] );
			}
		}
		wp_update_attachment_metadata( $id, $meta );
	}
	$slug = wp_unique_post_slug( $final, $id, 'inherit', 'attachment', (int) get_post_field( 'post_parent', $id ) );
	$guid = preg_replace( $regex, $repl, (string) get_post_field( 'guid', $id ) );
	$wpdb->update( $wpdb->posts, array( 'guid' => $guid, 'post_name' => $slug ), array( 'ID' => $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	clean_post_cache( $id );
	delete_transient( 'mvkd_file_map' );

	$redirects = get_option( 'mvkd_media_redirects', array() );
	unset( $redirects[ $new_stem ] );
	foreach ( $redirects as $from => $to ) {
		if ( $to === $old_stem ) {
			$redirects[ $from ] = $new_stem;
		}
	}
	$redirects[ $old_stem ] = $new_stem;
	update_option( 'mvkd_media_redirects', $redirects, false );
	$log   = get_option( 'mvkd_media_renames', array() );
	$log[] = array( 'time' => current_time( 'mysql' ), 'id' => $id, 'old' => $old_stem, 'new' => $new_stem, 'files' => count( $files ), 'posts' => count( $report['posts'] ), 'meta' => count( $report['meta'] ), 'options' => count( $report['options'] ), 'css' => count( $report['css'] ) );
	update_option( 'mvkd_media_renames', $log, false );
	wp_cache_flush();
	return $report;
}

/* ------------------------------------------------------------------ */
/* 3b. Bildtexte (Alt, Titel, Beschriftung, Beschreibung)              */
/* ------------------------------------------------------------------ */
function mvkd_meta( WP_REST_Request $req ) {
	$items  = (array) $req->get_param( 'items' );
	$dry    = (bool) $req->get_param( 'dry_run' );
	$backup = get_option( 'mvkd_media_meta_backup', array() );
	$out    = array();
	foreach ( $items as $it ) {
		$id = isset( $it['id'] ) ? (int) $it['id'] : 0;
		if ( 'attachment' !== get_post_type( $id ) ) {
			$out[] = array( 'id' => $id, 'error' => 'kein Anhang' );
			continue;
		}
		$before = array(
			'alt'         => (string) get_post_meta( $id, '_wp_attachment_image_alt', true ),
			'title'       => get_post_field( 'post_title', $id ),
			'caption'     => get_post_field( 'post_excerpt', $id ),
			'description' => get_post_field( 'post_content', $id ),
		);
		$after = $before;
		foreach ( array( 'alt', 'title', 'caption', 'description' ) as $k ) {
			if ( array_key_exists( $k, $it ) ) {
				$after[ $k ] = 'alt' === $k || 'title' === $k ? sanitize_text_field( $it[ $k ] ) : wp_kses_post( $it[ $k ] );
			}
		}
		$changed = array_keys( array_diff_assoc( $after, $before ) );
		$out[]   = array( 'id' => $id, 'changed' => $changed, 'after' => $after );
		if ( $dry || ! $changed ) {
			continue;
		}
		if ( ! isset( $backup[ $id ] ) ) {
			$backup[ $id ] = $before;
		}
		update_post_meta( $id, '_wp_attachment_image_alt', $after['alt'] );
		wp_update_post( array( 'ID' => $id, 'post_title' => $after['title'], 'post_excerpt' => $after['caption'], 'post_content' => $after['description'] ) );
	}
	if ( ! $dry ) {
		update_option( 'mvkd_media_meta_backup', $backup, false );
	}
	return array( 'dry_run' => $dry, 'count' => count( $out ), 'items' => $out );
}

/* ------------------------------------------------------------------ */
/* 4. Weiterleitung alter Dateiadressen                                */
/* ------------------------------------------------------------------ */
add_action( 'template_redirect', function () {
	if ( ! is_404() ) {
		return;
	}
	$path = (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$pos  = strpos( $path, '/wp-content/uploads/' );
	if ( false === $pos ) {
		return;
	}
	$rel       = rawurldecode( substr( $path, $pos + strlen( '/wp-content/uploads/' ) ) );
	$redirects = get_option( 'mvkd_media_redirects', array() );
	foreach ( $redirects as $from => $to ) {
		$re = '~^' . preg_quote( $from, '~' ) . '(' . mvkd_suffix_pattern() . '(?:\.(?:webp|avif))?)$~i';
		if ( preg_match( $re, $rel, $m ) ) {
			wp_safe_redirect( mvkd_upload_base()['url'] . $to . $m[1], 301, 'MVK Design' );
			exit;
		}
	}
}, 1 );

/* ------------------------------------------------------------------ */
/* REST                                                                */
/* ------------------------------------------------------------------ */
add_action( 'rest_api_init', function () {
	$admin = function () { return current_user_can( 'manage_options' ); };
	register_rest_route( 'mvk-design/v1', '/status', array(
		'methods' => 'GET', 'permission_callback' => $admin,
		'callback' => function () {
			return array( 'version' => MVKD_VERSION, 'redirects' => get_option( 'mvkd_media_redirects', array() ), 'renames' => get_option( 'mvkd_media_renames', array() ) );
		},
	) );
	register_rest_route( 'mvk-design/v1', '/media/inventory', array(
		'methods' => 'GET', 'permission_callback' => $admin, 'callback' => 'mvkd_inventory',
		'args' => array(
			'usage'  => array( 'type' => 'boolean', 'default' => true ),
			'offset' => array( 'type' => 'integer', 'default' => 0 ),
			'limit'  => array( 'type' => 'integer', 'default' => 0 ),
			'short'  => array( 'type' => 'boolean', 'default' => false ),
		),
	) );
	register_rest_route( 'mvk-design/v1', '/media/meta', array(
		'methods' => 'POST', 'permission_callback' => $admin, 'callback' => 'mvkd_meta',
		'args' => array(
			'items'   => array( 'type' => 'array', 'required' => true ),
			'dry_run' => array( 'type' => 'boolean', 'default' => true ),
		),
	) );
	register_rest_route( 'mvk-design/v1', '/media/rename', array(
		'methods' => 'POST', 'permission_callback' => $admin, 'callback' => 'mvkd_rename',
		'args' => array(
			'id'       => array( 'type' => 'integer', 'required' => true ),
			'new_stem' => array( 'type' => 'string', 'required' => true ),
			'dry_run'  => array( 'type' => 'boolean', 'default' => true ),
		),
	) );
} );
