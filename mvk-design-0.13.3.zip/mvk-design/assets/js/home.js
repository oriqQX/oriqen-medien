/* MVK Design 0.13.0 · Startseite: Einblenden der Kacheln und Karten, Tiefe der Bildebenen beim Scrollen. Ohne Abhängigkeiten. */
( function () {
	'use strict';
	var calm = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
	if ( calm ) { return; }
	function $$( sel ) { return Array.prototype.slice.call( document.querySelectorAll( sel ) ); }

	/* 1. Einblenden in Gruppen, leicht versetzt */
	if ( 'IntersectionObserver' in window ) {
		var groups = [ '.mvkh-mosaic > .mvkh-tile', '.mvkh-pgrid > .mvkh-pc', '.mvkh-revs > .mvkh-rev', '.mvkh-figs > li', '.mvkh-steps__list > li', '.mvkh-layer__media', '.mvkh-region__orte > div', '.mvkh-logos > li' ];
		var io = new IntersectionObserver( function ( entries ) {
			entries.forEach( function ( e ) {
				if ( e.isIntersecting ) { e.target.classList.add( 'is-in' ); io.unobserve( e.target ); }
			} );
		}, { rootMargin: '0px 0px -6% 0px', threshold: 0 } );
		groups.forEach( function ( sel ) {
			$$( sel ).forEach( function ( el, i ) {
				var r = el.getBoundingClientRect();
				if ( r.top < window.innerHeight && r.bottom > 0 ) { return; }
				el.style.setProperty( '--i', String( i % 6 ) );
				el.classList.add( 'mvkh-rv' );
				io.observe( el );
			} );
		} );
	}

	/* 2. Tiefe: das kleine Bild und die Ziffer wandern langsamer als die Seite (nur Desktop) */
	var deep = $$( '.mvkh-layer__media, .mvkh-about__media' );
	if ( ! deep.length || ! window.requestAnimationFrame ) { return; }
	var wide = window.matchMedia( '(min-width: 901px)' );
	var ticking = false;
	function update() {
		ticking = false;
		var vh = window.innerHeight;
		deep.forEach( function ( m ) {
			if ( ! wide.matches ) { m.style.removeProperty( '--py' ); return; }
			var r = m.getBoundingClientRect();
			if ( r.bottom < -200 || r.top > vh + 200 ) { return; }
			var p = ( ( r.top + r.height / 2 ) - vh / 2 ) / vh; /* -1 … 1 */
			var py = Math.max( -1, Math.min( 1, p ) ) * 46;
			m.style.setProperty( '--py', py.toFixed( 1 ) + 'px' );
			var b = m.querySelector( '.mvkh-layer__b, .mvkh-about__b' );
			var n = m.querySelector( '.mvkh-layer__num' );
			if ( b ) { b.style.setProperty( '--py', py.toFixed( 1 ) + 'px' ); }
			if ( n ) { n.style.setProperty( '--py', py.toFixed( 1 ) + 'px' ); }
		} );
	}
	function onScroll() { if ( ! ticking ) { ticking = true; window.requestAnimationFrame( update ); } }
	window.addEventListener( 'scroll', onScroll, { passive: true } );
	window.addEventListener( 'resize', onScroll );
	update();
} )();
