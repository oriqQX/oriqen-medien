<?php
/**
 * MVK Design · Modul Startseite (ab 0.13.0, 16.11.2026)
 *
 * - [mvk_aktion]: rechte Hälfte der Startbühne. Zeigt das Beitragsbild der aktuellen Aktion als großen Teaser.
 *   Auswahl: zuerst ein „oben gehaltener“ Beitrag (Sticky) der Kategorie „Aktuelles von MVK“, sonst der neueste Beitrag
 *   dieser Kategorie mit Beitragsbild. Neue Aktion veröffentlichen genügt, die Startseite zieht nach.
 * - Startseiten-CSS und -JS (home.css, home.js) nur auf der Startseite.
 */

defined( 'ABSPATH' ) || exit;

function mvkd_h_aktion_id() {
	static $id = null;
	if ( null !== $id ) {
		return $id;
	}
	$cat    = get_category_by_slug( 'aktuelles' );
	$base   = array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 1, 'fields' => 'ids', 'no_found_rows' => true,
		'meta_query' => array( array( 'key' => '_thumbnail_id', 'compare' => 'EXISTS' ) ) );
	if ( $cat ) {
		$base['cat'] = $cat->term_id;
	}
	$sticky = get_option( 'sticky_posts' );
	$ids    = array();
	if ( $sticky ) {
		$ids = get_posts( array_merge( $base, array( 'post__in' => $sticky, 'ignore_sticky_posts' => true ) ) );
	}
	if ( ! $ids ) {
		$ids = get_posts( array_merge( $base, array( 'ignore_sticky_posts' => true ) ) );
	}
	return $id = $ids ? (int) $ids[0] : 0;
}

add_shortcode( 'mvk_aktion', function () {
	$pid = mvkd_h_aktion_id();
	if ( ! $pid ) {
		return '';
	}
	$tid  = get_post_thumbnail_id( $pid );
	$meta = wp_get_attachment_metadata( $tid );
	$r    = ( ! empty( $meta['width'] ) && ! empty( $meta['height'] ) ) ? round( $meta['width'] / $meta['height'], 4 ) : 1.7778;
	$img  = wp_get_attachment_image( $tid, 'full', false, array(
		'loading'       => 'eager',
		'fetchpriority' => 'high',
		'decoding'      => 'async',
		'sizes'         => '(max-width: 768px) 100vw, 55vw',
		'class'         => 'mvkh-hero__img',
	) );
	$title = get_the_title( $pid );
	$o  = '<a class="mvkh-hero__part mvkh-hero__akt" href="' . esc_url( get_permalink( $pid ) ) . '" style="--r:' . esc_attr( $r ) . '" aria-label="' . esc_attr( 'Aktuelle Aktion: ' . wp_strip_all_tags( $title ) ) . '">';
	$o .= $img;
	$o .= '<span class="mvkh-hero__go" aria-hidden="true"><span>Aktuelle Aktion</span></span>';
	return $o . '</a>';
} );

/* Startseiten-Bausteine laden (nur Startseite, nur v2). */
function mvkd_h_on() {
	if ( ! mvkd_is_v2() ) {
		return false;
	}
	if ( is_front_page() ) {
		return true;
	}
	$p = is_singular( 'page' ) ? get_queried_object() : null; /* Entwurf und Vorschau der Startseite */
	return $p && isset( $p->post_content ) && false !== strpos( $p->post_content, 'mvkh-hero' );
}

add_action( 'wp_enqueue_scripts', function () {
	if ( ! mvkd_h_on() ) {
		return;
	}
	$css = MVKD_DIR . 'assets/css/home.css';
	$js  = MVKD_DIR . 'assets/js/home.js';
	wp_enqueue_style( 'mvk-home', MVKD_URL . 'assets/css/home.css', array( 'mvk-design' ), MVKD_VERSION . '.' . ( file_exists( $css ) ? filemtime( $css ) : 0 ) );
	wp_enqueue_script( 'mvk-home', MVKD_URL . 'assets/js/home.js', array(), MVKD_VERSION . '.' . ( file_exists( $js ) ? filemtime( $js ) : 0 ), array( 'in_footer' => true, 'strategy' => 'defer' ) );
}, 22 );
