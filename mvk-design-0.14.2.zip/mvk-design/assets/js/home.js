/* MVK Design 0.13.0 · Startseite: Einblenden der Kacheln und Karten, Tiefe der Bildebenen beim Scrollen. Ohne Abhängigkeiten. */
( function () {
	'use strict';
	var calm = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
	function $$( sel ) { return Array.prototype.slice.call( document.querySelectorAll( sel ) ); }

	/* 0. Bewertungen: Karten der Reihe nach in die jeweils kürzeste Spalte (gleichmäßig befüllt, Lesereihenfolge zeilenweise) */
	var revs = document.querySelector( '.mvkh-revs' );
	if ( revs ) {
		var cards = Array.prototype.slice.call( revs.children );
		var cur = -1;
		var lay = function ( force ) {
			var w = window.innerWidth;
			var n = w <= 768 ? 0 : ( w <= 1100 ? 2 : 3 );
			if ( n === cur && ! force ) { return; }
			cur = n;
			revs.innerHTML = '';
			if ( ! n ) { revs.classList.remove( 'is-cols' ); cards.forEach( function ( c ) { revs.appendChild( c ); } ); return; }
			revs.classList.add( 'is-cols' );
			var cols = [];
			for ( var i = 0; i < n; i++ ) { var d = document.createElement( 'div' ); d.className = 'mvkh-revs__col'; revs.appendChild( d ); cols.push( d ); }
			cards.forEach( function ( c ) {
				var low = cols[ 0 ];
				cols.forEach( function ( col ) { if ( col.offsetHeight < low.offsetHeight ) { low = col; } } );
				low.appendChild( c );
			} );
		};
		lay();
		var rt;
		window.addEventListener( 'resize', function () { clearTimeout( rt ); rt = setTimeout( function () { lay(); }, 150 ); } );
		window.addEventListener( 'load', function () { lay( true ); } );
		if ( document.fonts && document.fonts.ready ) { document.fonts.ready.then( function () { lay( true ); } ); }
	}

	if ( calm ) { return; }

	/* 1. Einblenden in Gruppen, leicht versetzt */
	if ( 'IntersectionObserver' in window ) {
		var groups = [ '.mvkh-mosaic > .mvkh-tile', '.mvkh-pgrid > .mvkh-pc', '.mvkh-revs .mvkh-rev', '.mvkh-layer__media', '.mvkh-region__orte > div', '.mvkh-logos > li' ];
		var io = new IntersectionObserver( function ( entries ) {
			entries.forEach( function ( e ) {
				if ( e.isIntersecting ) { e.target.classList.add( 'is-in' ); io.unobserve( e.target ); }
			} );
		}, { rootMargin: '0px 0px -6% 0px', threshold: 0 } );
		groups.forEach( function ( sel ) {
			$$( sel ).forEach( function ( el, i ) {
				var r = el.getBoundingClientRect();
				if ( r.top < window.innerHeight && r.bottom > 0 ) { return; }
				el.style.setProperty( '--i', String( i % 6 ) );
				el.classList.add( 'mvkh-rv' );
				io.observe( el );
			} );
		} );
	}

	/* 2. Tiefe: das kleine Bild wandert langsamer als die Seite (nur Desktop) */
	var deep = $$( '.mvkh-layer__media, .mvkh-about__media' );
	if ( ! deep.length || ! window.requestAnimationFrame ) { return; }
	var wide = window.matchMedia( '(min-width: 901px)' );
	var ticking = false;
	function update() {
		ticking = false;
		var vh = window.innerHeight;
		deep.forEach( function ( m ) {
			if ( ! wide.matches ) { m.style.removeProperty( '--py' ); return; }
			var r = m.getBoundingClientRect();
			if ( r.bottom < -200 || r.top > vh + 200 ) { return; }
			var p = ( ( r.top + r.height / 2 ) - vh / 2 ) / vh; /* -1 … 1 */
			var py = Math.max( -1, Math.min( 1, p ) ) * 46;
			m.style.setProperty( '--py', py.toFixed( 1 ) + 'px' );
			var b = m.querySelector( '.mvkh-layer__b, .mvkh-about__b' );
			if ( b ) { b.style.setProperty( '--py', py.toFixed( 1 ) + 'px' ); }
		} );
	}
	function onScroll() { if ( ! ticking ) { ticking = true; window.requestAnimationFrame( update ); } }
	window.addEventListener( 'scroll', onScroll, { passive: true } );
	window.addEventListener( 'resize', onScroll );
	update();
} )();
