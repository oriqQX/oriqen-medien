<?php
defined( 'ABSPATH' ) || exit;
return array(
	'title'   => 'MVK Brücke zum Nachbar-Segment',
	'content' => <<<'MVK'
<!-- wp:group {"className":"mvk-bridge"} -->
<div class="wp-block-group mvk-bridge"><!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="" alt=""/></figure>
<!-- /wp:image -->
<!-- wp:group {"className":"mvk-bridge__body"} -->
<div class="wp-block-group mvk-bridge__body"><!-- wp:paragraph {"className":"mvk-bridge__k"} -->
<p class="mvk-bridge__k">Glas &amp; Loft</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"mvk-bridge__t"} -->
<p class="mvk-bridge__t">Ein Satz, der zum Nachbar-Segment führt.</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"mvk-bridge__go"} -->
<p class="mvk-bridge__go"><a href="/glastueren-glastrennwaende/">Zum Segment</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
MVK
);
