<?php
defined( 'ABSPATH' ) || exit;
return array(
	'title'   => 'MVK Werkzeug Duschform (Reiter mit Schema)',
	'content' => <<<'MVK'
<!-- wp:group {"className":"mvk-viewer mvk-tool mvk-tool--dusche"} -->
<div class="wp-block-group mvk-viewer mvk-tool mvk-tool--dusche"><!-- wp:group {"className":"mvk-viewer__panel"} -->
<div class="wp-block-group mvk-viewer__panel"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:shortcode -->
[mvk_dusche form="nische"]
<!-- /wp:shortcode --></div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Nischendusche</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Text zur Bauform. Formen: nische, doppelfluegel, nische-oberteil, eck-nische, eckdusche, fuenfeck, fuenfeck-gross, walkin, u-dusche, badewanne, nische-schiebe.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
MVK
);
