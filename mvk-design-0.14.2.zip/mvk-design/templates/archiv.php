<?php
/**
 * MVK Design · Kategorie-Archiv im v2-Look (Modul Beiträge). Rahmen wie die Seitenvorlage von GeneratePress.
 */
defined( 'ABSPATH' ) || exit;
get_header();
$mvkd_term = get_queried_object();
?>
	<div class="content-area" id="primary">
		<main class="site-main" id="main">
			<article class="page type-page mvk-blogpage">
				<div class="inside-article">
					<div class="entry-content">
						<?php echo mvkd_b_archive_html( $mvkd_term ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
					</div>
				</div>
			</article>
		</main>
	</div>
<?php
get_footer();
