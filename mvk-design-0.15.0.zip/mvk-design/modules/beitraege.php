<?php
/**
 * MVK Design · Modul Beiträge (ab 0.12.0, 16.11.2026)
 *
 * - /aktuelles/ (Archiv der Kategorie „aktuelles“) zeigt ALLE Beiträge, nicht nur die Kategorie. Ratgeber brauchen die Kategorie
 *   „Aktuelles von MVK“ nicht mehr. „Aktuelles von MVK“ = Aktionen, Gewinnspiele, Neuigkeiten.
 * - Alle Kategorie-Archive im v2-Look: Kopf, Kategorie-Filter, Aufmacher, Raster mit ganzem Beitragsbild, „Mehr anzeigen“, Beratungsband.
 * - Shortcode [mvk_beitraege] für Teaser-Reihen (Startseite, Säulenseiten): kategorie, anzahl, titel, kicker, link, layout=reihe|raster.
 * - Ersetzt jedes Essential-Blocks-Beitragskarussell automatisch durch die Teaser-Reihe (in Beiträgen: passende Ratgeber zur Hauptkategorie).
 * Neue Beiträge erscheinen automatisch, eine Kategorie genügt. Keine externen Requests.
 */

defined( 'ABSPATH' ) || exit;

const MVKD_B_ORDER = array( 'kuechen-ratgeber', 'glasduschen-ratgeber', 'glastueren-glaswaende', 'innentueren-ratgeber', 'aktuelles' );

function mvkd_b_label( $term ) {
	$map = array(
		'aktuelles'             => 'Aktionen &amp; News',
		'kuechen-ratgeber'      => 'Küchen-Ratgeber',
		'glasduschen-ratgeber'  => 'Glasduschen-Ratgeber',
		'glastueren-glaswaende' => 'Glas &amp; Loft-Ratgeber',
		'innentueren-ratgeber'  => 'Innentüren-Ratgeber',
	);
	return isset( $map[ $term->slug ] ) ? $map[ $term->slug ] : esc_html( $term->name );
}

function mvkd_b_primary( $pid ) {
	$cats = get_the_category( $pid );
	$id   = (int) get_post_meta( $pid, 'rank_math_primary_category', true );
	foreach ( $cats as $c ) {
		if ( $c->term_id === $id ) {
			return $c;
		}
	}
	return $cats ? $cats[0] : null;
}

function mvkd_b_minutes( $pid ) {
	$t = wp_strip_all_tags( strip_shortcodes( (string) get_post_field( 'post_content', $pid ) ) );
	$n = count( preg_split( '/\s+/u', trim( $t ), -1, PREG_SPLIT_NO_EMPTY ) );
	return max( 1, (int) round( $n / 200 ) );
}

function mvkd_b_excerpt( $pid ) {
	$d = trim( (string) get_post_meta( $pid, 'rank_math_description', true ) );
	if ( '' === $d || false !== strpos( $d, '%' ) ) {
		$d = has_excerpt( $pid ) ? get_the_excerpt( $pid ) : wp_strip_all_tags( strip_shortcodes( (string) get_post_field( 'post_content', $pid ) ) );
	}
	$d = preg_replace( '/\s*✅\s*/u', ' ', $d );
	return wp_trim_words( $d, 26, ' …' );
}

function mvkd_b_card( $p, $hl = 3, $lead = false ) {
	$url   = get_permalink( $p );
	$c     = mvkd_b_primary( $p->ID );
	$slugs = wp_list_pluck( get_the_category( $p->ID ), 'slug' );
	$title = get_the_title( $p );
	$img   = has_post_thumbnail( $p ) ? get_the_post_thumbnail( $p, 'large', array( 'class' => 'mvk-post__img', 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => $lead ? '(max-width: 781px) 100vw, 60vw' : '(max-width: 781px) 100vw, 33vw' ) ) : '<span class="mvk-post__noimg"></span>';
	$o  = '<article class="mvk-post' . ( $lead ? ' mvk-post--lead' : '' ) . '" data-cats="' . esc_attr( implode( ' ', $slugs ) ) . '">';
	$o .= '<a class="mvk-post__media" href="' . esc_url( $url ) . '" tabindex="-1" aria-hidden="true">' . $img . '</a>';
	$o .= '<div class="mvk-post__body"><p class="mvk-post__meta">';
	if ( $c ) {
		$o .= '<span class="mvk-post__cat">' . mvkd_b_label( $c ) . '</span>';
	}
	$o .= '<time datetime="' . esc_attr( get_the_date( 'c', $p ) ) . '">' . esc_html( get_the_date( 'j. F Y', $p ) ) . '</time>';
	$o .= '<span class="mvk-post__min">' . mvkd_b_minutes( $p->ID ) . ' Min. Lesezeit</span></p>';
	$o .= sprintf( '<h%1$d class="mvk-post__title"><a href="%2$s">%3$s</a></h%1$d>', $hl, esc_url( $url ), esc_html( wp_strip_all_tags( $title ) ) );
	$o .= '<p class="mvk-post__text">' . esc_html( mvkd_b_excerpt( $p->ID ) ) . '</p>';
	$o .= '<p class="mvk-post__go"><a href="' . esc_url( $url ) . '" aria-label="' . esc_attr( 'Weiterlesen: ' . wp_strip_all_tags( $title ) ) . '">Weiterlesen <span aria-hidden="true">→</span></a></p>';
	$o .= '</div></article>';
	return $o;
}

function mvkd_b_query( $args ) {
	$q = array(
		'post_type'           => 'post',
		'post_status'         => 'publish',
		'posts_per_page'      => isset( $args['n'] ) ? (int) $args['n'] : 60,
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
		'orderby'             => 'date',
		'order'               => 'DESC',
	);
	if ( ! empty( $args['cat'] ) ) {
		$q['category_name'] = $args['cat'];
	}
	if ( ! empty( $args['not'] ) ) {
		$q['post__not_in'] = (array) $args['not'];
	}
	return get_posts( $q );
}

function mvkd_b_script() {
	static $done = false;
	if ( $done ) {
		return '';
	}
	$done = true;
	return "<script>(function(){document.querySelectorAll('.mvk-posts').forEach(function(w){var items=[].slice.call(w.querySelectorAll('.mvk-posts__grid > .mvk-post')),more=w.querySelector('.mvk-posts__more'),step=+(w.getAttribute('data-step')||9),shown=step,f='alle';"
		. "function apply(){var n=0;items.forEach(function(a){var ok=f==='alle'||(' '+a.getAttribute('data-cats')+' ').indexOf(' '+f+' ')>-1;if(ok){n++;}a.hidden=!ok||n>shown;});if(more){more.hidden=n<=shown;}var e=w.querySelector('.mvk-posts__empty');if(e){e.hidden=n>0;}}"
		. "w.querySelectorAll('.mvk-chips a[data-f]').forEach(function(c){c.addEventListener('click',function(ev){if(!w.querySelector('.mvk-posts__grid')){return;}ev.preventDefault();f=c.getAttribute('data-f');shown=step;w.querySelectorAll('.mvk-chips a').forEach(function(x){x.removeAttribute('aria-current');});c.setAttribute('aria-current','true');apply();if(history.replaceState){history.replaceState(null,'',f==='alle'?location.pathname:'#'+f);}});});"
		. "if(more){more.querySelector('button').addEventListener('click',function(){shown+=step;apply();});}"
		. "var h=location.hash.slice(1);if(h){var c=w.querySelector('.mvk-chips a[data-f=\"'+h+'\"]');if(c){c.click();}}else{apply();}});"
		. "document.querySelectorAll('.mvk-reihe').forEach(function(r){var t=r.querySelector('.mvk-reihe__track');r.querySelectorAll('.mvk-reihe__nav button').forEach(function(b){b.addEventListener('click',function(){var c=t.querySelector('.mvk-post');var d=c?c.getBoundingClientRect().width+24:t.clientWidth;t.scrollBy({left:(b.getAttribute('data-d')==='prev'?-1:1)*d,behavior:'smooth'});});});});})();</script>";
}

/* ---------- Teaser-Reihe ---------- */
function mvkd_b_reihe( $posts, $kicker, $title, $link, $linktext ) {
	if ( ! $posts ) {
		return '';
	}
	$o  = '<section class="mvk-reihe" aria-label="' . esc_attr( wp_strip_all_tags( $title ) ) . '"><div class="mvk-reihe__head"><div>';
	$o .= $kicker ? '<p class="mvk-reihe__k">' . esc_html( $kicker ) . '</p>' : '';
	$o .= '<h2 class="mvk-reihe__t">' . esc_html( $title ) . '</h2></div><div class="mvk-reihe__side">';
	if ( $link ) {
		$o .= '<a class="mvk-reihe__all" href="' . esc_url( $link ) . '">' . esc_html( $linktext ) . ' <span aria-hidden="true">→</span></a>';
	}
	if ( count( $posts ) > 3 ) {
		$o .= '<div class="mvk-reihe__nav"><button type="button" data-d="prev" aria-label="Zurück">‹</button><button type="button" data-d="next" aria-label="Weiter">›</button></div>';
	}
	$o .= '</div></div><div class="mvk-reihe__track">';
	foreach ( $posts as $p ) {
		$o .= mvkd_b_card( $p, 3 );
	}
	return $o . '</div></section>' . mvkd_b_script();
}

add_shortcode( 'mvk_beitraege', function ( $atts ) {
	$a = shortcode_atts( array( 'kategorie' => '', 'anzahl' => 6, 'titel' => 'Ratgeber und Aktuelles', 'kicker' => 'Weiterlesen', 'link' => '/aktuelles/', 'linktext' => 'Alle Beiträge', 'aus' => '' ), $atts, 'mvk_beitraege' );
	$not   = array_filter( array_map( 'intval', explode( ',', $a['aus'] ) ) );
	if ( false !== strpos( $a['aus'], 'aktion' ) && function_exists( 'mvkd_h_aktion_id' ) && mvkd_h_aktion_id() ) {
		$not[] = mvkd_h_aktion_id(); /* Aktion steht schon in der Startbühne */
	}
	$posts = mvkd_b_query( array( 'cat' => sanitize_text_field( $a['kategorie'] ), 'n' => (int) $a['anzahl'], 'not' => $not ) );
	if ( count( $posts ) < 3 && $a['kategorie'] ) {
		$posts = array_merge( $posts, mvkd_b_query( array( 'n' => 3 - count( $posts ), 'not' => array_merge( $not, wp_list_pluck( $posts, 'ID' ) ) ) ) );
	}
	$link = $a['link'] && 0 === strpos( $a['link'], '/' ) ? home_url( $a['link'] ) : $a['link'];
	return mvkd_b_reihe( $posts, $a['kicker'], $a['titel'], $link, $a['linktext'] );
} );

/* Essential-Blocks-Beitragskarussell durch die Teaser-Reihe ersetzen. */
add_filter( 'render_block', function ( $html, $block ) {
	if ( empty( $block['blockName'] ) || 'essential-blocks/post-carousel' !== $block['blockName'] || is_admin() ) {
		return $html;
	}
	if ( is_singular( 'post' ) ) {
		$pid  = get_queried_object_id();
		$c    = mvkd_b_primary( $pid );
		$slug = $c && 'aktuelles' !== $c->slug ? $c->slug : '';
		$p    = mvkd_b_query( array( 'cat' => $slug, 'n' => 6, 'not' => array( $pid ) ) );
		if ( count( $p ) < 3 ) {
			$p = array_merge( $p, mvkd_b_query( array( 'n' => 6 - count( $p ), 'not' => array_merge( array( $pid ), wp_list_pluck( $p, 'ID' ) ) ) ) );
		}
		return mvkd_b_reihe( $p, 'Weiterlesen', 'Das könnte Sie auch interessieren', home_url( '/aktuelles/' ), 'Alle Beiträge' );
	}
	return mvkd_b_reihe( mvkd_b_query( array( 'n' => 6 ) ), 'Aktuelles · Ratgeber', 'Neues von MVK und Ratgeber', home_url( '/aktuelles/' ), 'Alle Beiträge' );
}, 10, 2 );

/* ---------- Kategorie-Archive im v2-Look ---------- */
function mvkd_b_intro( $term ) {
	$h = array(
		'aktuelles'             => array( 'Aktuelles · Ratgeber · Aktionen', 'Aktuelles und Ratgeber von MVK' ),
		'kuechen-ratgeber'      => array( 'Ratgeber · Küchen', 'Küchen-Ratgeber: Planung, Material und Geräte' ),
		'glasduschen-ratgeber'  => array( 'Ratgeber · Glasduschen', 'Glasduschen-Ratgeber: Glas, Pflege und Planung' ),
		'glastueren-glaswaende' => array( 'Ratgeber · Glastüren und Loft', 'Ratgeber Glastüren, Glastrennwände und Loft' ),
		'innentueren-ratgeber'  => array( 'Ratgeber · Innentüren', 'Innentüren-Ratgeber: Maße, Material und Montage' ),
	);
	return isset( $h[ $term->slug ] ) ? $h[ $term->slug ] : array( 'Ratgeber', $term->name );
}

function mvkd_b_archive_html( $term ) {
	$all   = 'aktuelles' === $term->slug;
	$posts = mvkd_b_query( array( 'cat' => $all ? '' : $term->slug ) );
	list( $kicker, $h1 ) = mvkd_b_intro( $term );
	$lead = $all
		? 'Aktionen, Gewinnspiele und Neuigkeiten aus unserem Küchenstudio in <strong>Rheda-Wiedenbrück</strong>, dazu Ratgeber zu Küchen, Glasduschen, Glastüren und Innentüren. Verständlich erklärt, aus der Praxis von Beratung, Planung und Montage.'
		: wp_kses_post( term_description( $term ) );

	$o  = '<section class="mvk-bloghead alignfull"><div class="mvk-wide">';
	$o .= '<p class="mvk-kicker">' . esc_html( $kicker ) . '</p><h1>' . esc_html( $h1 ) . '</h1>';
	$o .= '<div class="mvk-bloghead__lead">' . ( $all ? '<p>' . $lead . '</p>' : $lead ) . '</div>';

	$chips  = '<nav class="mvk-chips" aria-label="Kategorien"><a href="' . esc_url( home_url( '/aktuelles/' ) ) . '"' . ( $all ? ' data-f="alle" aria-current="true"' : '' ) . '>Alle <span>' . count( mvkd_b_query( array() ) ) . '</span></a>';
	foreach ( MVKD_B_ORDER as $slug ) {
		$t = get_category_by_slug( $slug );
		if ( ! $t || ! $t->count ) {
			continue;
		}
		$href   = 'aktuelles' === $slug ? home_url( '/aktuelles/#aktuelles' ) : get_category_link( $t );
		$cur    = ( ! $all && $t->term_id === $term->term_id ) ? ' aria-current="true"' : '';
		$chips .= '<a href="' . esc_url( $href ) . '"' . ( $all ? ' data-f="' . esc_attr( $slug ) . '"' : '' ) . $cur . '>' . mvkd_b_label( $t ) . ' <span>' . (int) $t->count . '</span></a>';
	}
	$chips .= '</nav>';
	$o     .= '</div></section>';

	$o .= '<section class="mvk-posts alignfull" data-step="9"><div class="mvk-wide">' . $chips;
	if ( $posts ) {
		$o .= '<div class="mvk-posts__grid">';
		foreach ( $posts as $i => $p ) {
			$o .= mvkd_b_card( $p, 2, 0 === $i );
		}
		$o .= '</div><p class="mvk-posts__empty" hidden>Zu diesem Thema gibt es noch keinen Beitrag.</p>';
		$o .= '<div class="mvk-posts__more" hidden><button type="button">Weitere Beiträge anzeigen</button></div>';
	} else {
		$o .= '<p class="mvk-posts__empty">Zu diesem Thema schreiben wir gerade. Bis dahin finden Sie alles Wichtige auf unseren Leistungsseiten oder fragen uns direkt.</p>';
	}
	$o .= '</div></section>';

	if ( function_exists( 'mvkd_instagram_html' ) ) {
		$o .= '<section class="mvk-insta-sec alignfull"><div class="mvk-wide">' . mvkd_instagram_html() . '</div></section>';
	}
	$o .= '<section class="mvk-blogcta alignfull"><div class="mvk-wide"><div><p class="mvk-kicker">Beratung · Planung · Montage</p><h2>Ihre Frage ist nicht dabei?</h2>'
		. '<p>Wir beraten Sie persönlich im Küchenstudio in Rheda-Wiedenbrück oder kommen zu Ihnen nach Hause, zu Küche, Glasdusche, Glastüren und Innentüren.</p></div>'
		. '<div class="wp-block-buttons"><div class="wp-block-button is-style-mvk-rot"><a class="wp-block-button__link wp-element-button" href="' . esc_url( home_url( '/kontakt/' ) ) . '">Anfrage starten</a></div>'
		. '<div class="wp-block-button is-style-mvk-linie"><a class="wp-block-button__link wp-element-button" href="' . esc_url( home_url( '/kontakt/kuechenplaner/' ) ) . '">Küchenplaner</a></div></div></div></section>';

	return $o . mvkd_b_script();
}

add_filter( 'template_include', function ( $tpl ) {
	if ( is_category() && ! is_paged() ) {
		$t = MVKD_DIR . 'templates/archiv.php';
		if ( file_exists( $t ) ) {
			return $t;
		}
	}
	return $tpl;
}, 99 );

add_filter( 'body_class', function ( $c ) {
	if ( is_category() ) {
		$c[] = 'mvk-blog';
		$c[] = 'full-width-content';
	}
	return $c;
} );
