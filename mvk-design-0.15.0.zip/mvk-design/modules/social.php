<?php
/**
 * MVK Design · Modul Social (ab 0.15.0, 16.11.2026)
 *
 * - [mvk_bewertungen auswahl="carina,kevin,regina" kicker="…" titel="… {rot} …" anker="stimmen"]: kompakter Google-Bewertungsblock
 *   mit farbigem Google-Zeichen, 5,0 und drei Bewertungen im Wortlaut (Quelle: Google-Profil, ausgewählt von Deen am 16.11.2026).
 * - Alte Bewertungsblöcke der Küchenseiten (Spalten „mvk-voices“) werden beim Ausspielen durch den neuen Block ersetzt, je Seite andere drei.
 * - [mvk_instagram]: schlanke Instagram-Leiste (nur Link, kein Embed, keine externen Requests). Auch im Archiv „Aktuelles“.
 */

defined( 'ABSPATH' ) || exit;

define( 'MVKD_GOOGLE', 'https://www.google.com/maps/place/MVK+K%C3%BCchen+%26+Raumdesign/@51.8329366,8.3650368,17z/data=!4m6!3m5!1s0x47ba4d3edfed40ff:0x8ca6de0d7e8e9754!8m2!3d51.8329366!4d8.3650368!16s%2Fg%2F11fn70pkvc' );
define( 'MVKD_INSTAGRAM', 'https://www.instagram.com/mvk_kuechen_und_raumdesign/' );

function mvkd_reviews() {
	return array(
		'carina'    => array( 'Carina Justus', '', 'Wir können die Beratung bei MVK-Küchen uneingeschränkt empfehlen. Positiv überrascht hat uns, dass schon vor dem ersten Gespräch bei uns vor Ort ein Aufmaß genommen wurde. Im Entwurf waren dann alle unsere Wünsche und Vorstellungen berücksichtigt. Gleichzeitig wurde kritisch nachgefragt und mitgedacht, wenn aus Sicht der Planer eine andere Lösung sinnvoller war, zum Beispiel bei den vorhandenen Abluftrohren für die Dunstabzugshaube. Alles wurde plausibel erklärt. Man hat gespürt, dass die beiden mit Herzblut dabei sind und sich viele Gedanken gemacht haben.' ),
		'kevin'     => array( 'Kevin Bairit', 'Local Guide', 'Ich bin absolut begeistert von MVK Küchen! Von der ersten Beratung bis zur finalen Montage lief alles reibungslos und professionell. Das Team hat sich viel Zeit genommen, um auf meine Wünsche einzugehen, und mir eine Küche geplant, die nicht nur optisch überzeugt, sondern auch funktional perfekt zu meinem Alltag passt.<br><br>Besonders positiv hervorheben möchte ich die ehrliche Beratung, die hochwertigen Materialien und die termingerechte Lieferung. Auch die Monteure haben sehr sauber und präzise gearbeitet. Man merkt, dass hier mit Leidenschaft und Erfahrung gearbeitet wird!<br><br>Wer eine individuelle, stilvolle und langlebige Küche sucht, ist bei MVK Küchen genau richtig. Absolute Empfehlung!' ),
		'anton'     => array( 'Anton Klippenstein', '', 'Wir waren lange Zeit auf der Suche nach schönen Küchen für unsere 2 Ferien-Appartements am schwarzen Meer in Bulgarien. Dazu haben wir sowohl Möbelfachgeschäfte in Paderborn, als auch in Burgas besucht. Gesehen haben wir viele Küchen, doch eine wirklich optimale Beratung blieb aus. Über Bekannte bin ich dann auf MVK Küchen aufmerksam gemacht worden und ich wurde nicht enttäuscht.<br><br>Trotz unserer sehr „speziellen“ Anfrage, erhielten wir eine professionelle Beratung und wirklich punktgenaue Lieferung zu absolut fairen Preisen. Hierbei ist noch zu erwähnen dass die Küchenplanung vollständig auf unserer „eigenen Vermessung“ beruhte. Vladimir konnte hier mit seiner Erfahrung glänzen und uns in allen kritischen Fragen zur Seite stehen. Hier spürt man Professionalität und Qualitätsanspruch!<br><br>Hat es sich für uns gelohnt, extra Küchen von Deutschland nach Bulgarien zu bringen? Absolut! Die Nolte Küche ist hochwertig und passt perfekt. Wir und unsere Gäste sind begeistert und empfehlen MVK Küchen mit 10 von 10 Punkten weiter!' ),
		'elena'     => array( 'Elena L.', '', 'Vom ersten Beratungsgespräch bis zur fertigen Montage war alles absolut professionell und reibungslos. Vladimir ist super freundlich, kompetent und ist auf all unsere Wünsche eingegangen. Die Qualität der Küche ist top und auch optisch genau so geworden, wie wir es uns vorgestellt haben. Besonders hervorheben möchte ich den Service: schnelle Rückmeldungen, transparente Planung und eine pünktliche Lieferung. Wir sind rundum zufrieden und können das Küchenstudio uneingeschränkt weiterempfehlen!' ),
		'snezhana'  => array( 'Snezhana Lang', '', 'Vor zwei Jahren sind wir umgezogen und brauchten daher eine neue Küche, da unsere alte zu klein war und nicht in unsere neue Wohnung passte. Wir haben alle Küchenläden durchforstet, wo die Qualität oft schrecklich war und die Preise einfach astronomisch waren, wenn die Qualität gut war. Als ich schon ganz verzweifelt war, wurde uns empfohlen, uns an MVK Küchen zu wenden. Das war ein echter Glücksgriff: persönliche, kostenlose und kompetente Beratung, schnelle Lieferung und Montage. Das Wichtigste ist die Qualität: Sie ist so hochwertig, dass sie bereits einen Umzug überstanden hat und in der anderen Wohnung ohne einen einzigen Kratzer wie neu aussieht. Am wichtigsten für mich war der Preis! Die Preise sind niedriger als überall! Ich bin Vladimir und seinem Team sehr dankbar.' ),
		'ilja'      => array( 'Ilja Klippenstein', '', 'Sehr kompetente und nette Beratung. Wir haben uns gut aufgehoben gefühlt und unsere Ideen wurden perfekt umgesetzt. Die Küche ist sehr hochwertig und sieht Klasse aus.<br><br>Hier merkt man bei der Planung dass Vladimir über sehr viel „know how“ verfügt!' ),
		'regina'    => array( 'Regina Bergen', '', 'Wir sind absolut begeistert von unserer neuen Küche und möchten der Firma ein großes Lob aussprechen! Von der ersten Beratung bis zur finalen Montage war alles hochprofessionell. Auf unsere Wünsche wurde nicht nur eingegangen, sondern wir wurden mit kreativen Ideen überrascht. Die Monteure waren pünktlich. Wir würden uns jederzeit wieder für euch entscheiden!' ),
		'sven'      => array( 'Sven Hindemith', '', 'Die beste Adresse, wenn es um Küche geht. Sehr nette und kompetente Beratung, kurze Lieferzeiten (kein Vergleich zu den Küchenstudios, die 12 Wochen lang auf sich warten lassen). Der Einbau ist auch reibungslos verlaufen, es hat alles gepasst und musste nichts nachbestellt werden. Super Team, das sein Handwerk versteht. Ich würde MVK Küchen ohne Bedenken weiterempfehlen. Vielen lieben Dank an der Stelle und LG.<br><br>Da uns alles gut gefallen hat, haben wir noch eine Küche in „klein“ bestellt. Auch diesmal wurden wir überzeugt, also wenn es um Küchen geht, dann ist das die beste Adresse! Es stimmt einfach alles, danke.' ),
		'alex'      => array( 'Alex S.', '', 'Der beste Mann für Ihre Küche. Egal ob Planung oder Aufbau, alles lief bei dieser Firma perfekt. Sehr freundlich und geduldig. Man kann jeden Wunsch äußern und er wird auch berücksichtigt. Wir sind mit den Leistungen mehr als zufrieden. Ich würde es jedem empfehlen, der vorhat, in Zukunft eine Küche zu kaufen. Das Preis-Leistungsverhältnis ist top!' ),
		'alexander' => array( 'Alexander Anhalt', '', 'Unkompliziert, kompetent und zuverlässig! Die Erfahrungen haben wir persönlich gemacht, daher eine klare 200%tige Weiterempfehlung. Wir sagen danke und falls wir eine neue Küche brauchen würden, nur hier!!!' ),
	);
}

/* Auswahl je Seite für die alten Bewertungsblöcke (je drei verschiedene, passend zum Thema der Seite). */
function mvkd_reviews_for( $post_id ) {
	$map = array(
		1233 => 'carina,kevin,regina',   /* Küchen und Küchenplanung */
		1345 => 'elena,sven,alex',       /* Ballerina Küchen */
		4481 => 'anton,snezhana,ilja',   /* Nolte Küchen: Anton nennt die Nolte Küche */
		1931 => 'kevin,elena,alexander', /* NEFF */
		1912 => 'regina,ilja,sven',      /* Miele */
	);
	return isset( $map[ $post_id ] ) ? $map[ $post_id ] : 'elena,regina,ilja';
}

function mvkd_g_svg( $cls = 'mvk-g' ) {
	return '<svg class="' . esc_attr( $cls ) . '" viewBox="0 0 48 48" aria-hidden="true" focusable="false"><path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9.1 3.6l6.8-6.8C35.8 2.4 30.3 0 24 0 14.6 0 6.6 5.4 2.6 13.3l7.9 6.1C12.4 13.7 17.7 9.5 24 9.5z"/><path fill="#4285F4" d="M46.1 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.4c-.5 2.9-2.2 5.3-4.6 6.9l7.4 5.7c4.3-4 6.9-9.9 6.9-17.1z"/><path fill="#FBBC05" d="M10.5 28.6c-.5-1.4-.8-3-.8-4.6s.3-3.2.8-4.6l-7.9-6.1C.9 16.6 0 20.2 0 24s.9 7.4 2.6 10.7l7.9-6.1z"/><path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.4-5.7c-2.1 1.4-4.8 2.2-8.5 2.2-6.3 0-11.6-4.2-13.5-10l-7.9 6.1C6.6 42.6 14.6 48 24 48z"/></svg>';
}

function mvkd_key_title( $t ) {
	$t = esc_html( $t );
	/* Rot markiert: {Wort} im Shortcode (eckige Klammern sind in Shortcode-Attributen nicht erlaubt) oder [[Wort]] intern. */
	return preg_replace( '/\{(.+?)\}|\[\[(.+?)\]\]/', '<mark style="background-color:rgba(0, 0, 0, 0);color:#d9010c" class="has-inline-color mvk-key">$1$2</mark>', $t );
}

function mvkd_bewertungen_html( $a ) {
	$all  = mvkd_reviews();
	$keys = array_slice( array_filter( array_map( 'trim', explode( ',', $a['auswahl'] ) ), function ( $k ) use ( $all ) { return isset( $all[ $k ] ); } ), 0, 3 );
	if ( ! $keys ) {
		return '';
	}
	$id = $a['anker'] ? ' id="' . esc_attr( $a['anker'] ) . '"' : '';
	$o  = '<div class="mvk-gr"><div class="mvk-gr__head"><div class="mvk-gr__titles">';
	$o .= '<p class="mvk-kicker">' . esc_html( $a['kicker'] ) . '</p><h2 class="wp-block-heading"' . $id . '>' . mvkd_key_title( $a['titel'] ) . '</h2></div>';
	$o .= '<a class="mvk-gbox mvk-plain" href="' . esc_url( MVKD_GOOGLE ) . '" target="_blank" rel="noopener">' . mvkd_g_svg( 'mvk-g mvk-g--l' )
		. '<span class="mvk-gbox__n">5,0</span><span class="mvk-gbox__r"><span class="mvk-stars" aria-hidden="true">★★★★★</span><span class="mvk-gbox__t">5,0 von 5 Sternen bei Google</span>'
		. '<span class="mvk-gbox__go">Alle Bewertungen ansehen</span></span></a></div>';
	$o .= '<div class="mvk-gr__cards">';
	foreach ( $keys as $k ) {
		list( $name, $badge, $text ) = $all[ $k ];
		$sub = ( $badge ? esc_html( $badge ) . ' · ' : '' ) . 'Rezension bei Google';
		$o  .= '<figure class="mvk-gr__card"><figcaption class="mvk-gr__who"><span class="mvk-gr__ini" aria-hidden="true">' . esc_html( mb_substr( $name, 0, 1 ) ) . '</span>'
			. '<span class="mvk-gr__name">' . esc_html( $name ) . '<span class="mvk-gr__sub">' . mvkd_g_svg( 'mvk-g mvk-g--s' ) . $sub . '</span></span></figcaption>'
			. '<p class="mvk-gr__stars" aria-label="5 von 5 Sternen">★★★★★</p>'
			. '<blockquote class="mvk-gr__text"><p>' . wp_kses( $text, array( 'br' => array() ) ) . '</p></blockquote>'
			. '<button type="button" class="mvk-gr__more" hidden>Weiterlesen</button></figure>';
	}
	$o .= '</div></div>';
	return $o . mvkd_gr_script();
}

function mvkd_gr_script() {
	static $done = false;
	if ( $done ) {
		return '';
	}
	$done = true;
	/* Lange Bewertungen auf 8 Zeilen kürzen, „Weiterlesen“ nur, wenn wirklich gekürzt. Text steht vollständig im HTML. */
	return "<script>(function(){function f(){document.querySelectorAll('.mvk-gr__card').forEach(function(c){var t=c.querySelector('.mvk-gr__text'),b=c.querySelector('.mvk-gr__more');if(!t||!b||c.classList.contains('is-open'))return;b.hidden=!(t.scrollHeight>t.clientHeight+4);if(!b.dataset.on){b.dataset.on=1;b.addEventListener('click',function(){var o=c.classList.toggle('is-open');b.textContent=o?'Weniger anzeigen':'Weiterlesen';});}});}if(document.readyState!=='loading'){f();}else{document.addEventListener('DOMContentLoaded',f);}window.addEventListener('load',f);})();</script>";
}

add_shortcode( 'mvk_bewertungen', function ( $atts ) {
	$a = shortcode_atts( array( 'auswahl' => 'elena,regina,ilja', 'kicker' => 'Kundenstimmen · Google', 'titel' => 'Was [[Kunden]] über ihre neue Küche sagen', 'anker' => 'stimmen' ), $atts, 'mvk_bewertungen' );
	return mvkd_bewertungen_html( $a );
} );

/* Alte Bewertungsblöcke (Spalten „mvk-voices“) beim Ausspielen ersetzen: Abschnitt bleibt, Inhalt wird der neue Block. */
add_filter( 'render_block', function ( $html, $block ) {
	if ( is_admin() || empty( $block['blockName'] ) || 'core/group' !== $block['blockName'] ) {
		return $html;
	}
	$cls = isset( $block['attrs']['className'] ) ? $block['attrs']['className'] : '';
	if ( false === strpos( $cls, 'mvk-wide' ) || false === strpos( $html, 'mvk-voices' ) ) {
		return $html;
	}
	$inner = mvkd_bewertungen_html( array( 'auswahl' => mvkd_reviews_for( get_the_ID() ), 'kicker' => 'Kundenstimmen · Google', 'titel' => 'Was [[Kunden]] über ihre neue Küche sagen', 'anker' => 'stimmen' ) );
	return $inner ? '<div class="wp-block-group mvk-wide">' . $inner . '</div>' : $html;
}, 10, 2 );

function mvkd_instagram_html() {
	$ig = '<svg class="mvk-ig" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><rect x="2.5" y="2.5" width="19" height="19" rx="5.5" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="12" r="4.3" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="17.6" cy="6.4" r="1.3" fill="currentColor"/></svg>';
	return '<div class="mvk-insta"><a class="mvk-insta__a mvk-plain" href="' . esc_url( MVKD_INSTAGRAM ) . '" target="_blank" rel="noopener">' . $ig
		. '<span class="mvk-insta__t"><span class="mvk-insta__k">MVK auf Instagram</span><span class="mvk-insta__h">@mvk_kuechen_und_raumdesign</span></span>'
		. '<span class="mvk-insta__x">Einblicke ins Küchenstudio, fertige Projekte und Aktionen</span><span class="mvk-insta__go">Folgen</span></a></div>';
}

add_shortcode( 'mvk_instagram', 'mvkd_instagram_html' );
