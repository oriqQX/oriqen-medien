# Changelog

## 0.18.0 (19.11.2026)
- Neues Modul Wartung (`modules/wartung.php`): kleine WordPress-Updates im selben Zweig (7.1.x) laufen automatisch. Setzt neben `automatic_updater_disabled` und `allow_minor_auto_core_updates` auch die letzte Schranke `auto_update_core` (nur gleicher Zweig, große Versionen bleiben manuell). Grund: Code Snippet 10 reichte nicht, 7.1.5 wurde nicht eingespielt.
- Diagnose `GET /mvk-design/v1/updates` (Version, Angebot, Sperren, Filter mit Herkunftsdatei, Must-Use-Plugins) und `POST /mvk-design/v1/updates/run {confirm:true}` (führt den automatischen Updater sofort aus).

## 0.17.1 (17.11.2026)
- Karriere und Initiativbewerbung nach Sichtprüfung: Fragen auf Weiß, Kontakt auf Nebelgrau, Zahlenband der Initiativbewerbung nach den Bereichen, Infozeile „Inhaber“ statt umbrochenem „Ansprechpartner“.

## 0.17.0 (17.11.2026)
- Karriere auf v2: Blueprint `karriere.html` (Seite 1454) mit Stellenanzeige Küchenplaner (m/w/d) im Wortlaut von Vladimir als Karte, Arbeitgeber, Arbeitsalltag mit vier Bereichen, Bewerbungsablauf, Fragen, Kontakt.
- Neue Unterseite Initiativbewerbung: Blueprint `initiativbewerbung.html` (Seite 6302, /karriere/initiativbewerbung/) mit acht gesuchten Bereichen, Ablauf, Kontakt und Fragen.
- Neue Bausteine: `.mvk-job` (Stellenanzeige mit Eckdaten-Chips, Haltung, Aufgaben und Profil, Angebots-Kacheln, Bewerbungsbox), `.mvk-areas`/`.mvk-area`, `.mvk-steps--col` (Schritte senkrecht), Linien-Icons team, pin, uhr, mail, glas, winkel, buch, vier.

## 0.16.1 (17.11.2026)
- Etikett „Aktuelle Aktion“ weiß auf Rot, oben rechts am Beitragsbild. Favicon: Bildmarke auf Nebelgrau (Mediathek 6301, vorher 1628).

## 0.16.0 (16.11.2026)
- Neue Kategorie „Aktion“ (zusätzlich zu „Aktuelles von MVK“, Adressen bleiben über die Hauptkategorie gleich). /aktuelles/: Platz 1 breit die neueste Aktion mit Etikett „Aktuelle Aktion“ und rotem Rahmen, Platz 2 breit der neueste übrige Beitrag, danach das Raster. Filter „Aktionen“.
- Etikett „Aktionen &amp; News“ heißt jetzt „Aktuelles von MVK“.
- Header (Logo und Hauptnavigation) in Nebelgrau #F4F4F5 wie das Footer-Band, Abstand unter dem Logo 16 px.

## 0.15.1 (16.11.2026)
- Google- und Instagram-Zeichen mit festen Maßen im HTML (bleiben klein, auch wenn eine alte CSS-Datei aus dem Cache kommt).

## 0.15.0 (16.11.2026)
- Neues Modul `modules/social.php`: `[mvk_bewertungen auswahl="…"]` als kompakter Google-Bewertungsblock (farbiges Google-Zeichen, 5,0, drei Bewertungen im Wortlaut, lange Texte mit „Weiterlesen“, mobil wischbar). Bewertungen zentral im Modul.
- Alte Bewertungsblöcke der Küchenseiten (Küchen, Ballerina, Nolte, NEFF, Miele) werden beim Ausspielen durch den neuen Block ersetzt, je Seite drei andere Bewertungen.
- `[mvk_instagram]`: Instagram-Leiste als Baustein (nur Link). Im Archiv „Aktuelles“ und allen Ratgeber-Archiven vor dem Beratungsband.

## 0.14.2 (16.11.2026)
- Startseite: Instagram-Leiste vor den Fragen (Link mit Instagram-Zeichen, kein Embed, keine externen Requests).

## 0.14.1 (16.11.2026)
- Startseite: Überschrift der Küchen-Kachel ohne Wortumbruch.

## 0.14.0 (16.11.2026)
- Startseite nach Deens Durchsicht: `[mvk_aktion beitrag="ID"]` zeigt fest gewählten Aktionsbeitrag (aktuell Küchen-Aktion 2026, ID 1981), nicht mehr automatisch den neuesten. Ohne Angabe nur ein Sticky-Beitrag.
- Gewerke-Mosaik als Bild-Banner: Foto im Vordergrund, darauf Kicker, Überschrift und roter Button, keine Beschreibungstexte mehr.
- Hohle Ziffern entfernt; Zahlen und Ablauf nutzen die bestehenden Bausteine `mvk-figures` und `mvk-steps`.
- Rote Buttons mit weißer Schrift (Vorrang vor der globalen Linkfarbe), Bild-Etiketten der gespiegelten Ebenen rechts statt über die ganze Breite, Bewertungen gleichmäßig auf die Spalten verteilt.

## 0.13.3 (16.11.2026)
- Startseite mobil: Gewerke-Kacheln als Karten mit Text unter dem Bild, Bild-Etiketten der Ebenen oben, kleinerer Kicker im roten Panel.

## 0.13.2 (16.11.2026)
- Startseite nach Sichtprüfung: Aktionshinweis oben rechts (verdeckt kein Logo im Aktionsbild), Ebenen oben ausgerichtet mit stehendem Bild, Etiketten unten, Mosaik höher, Google-Kasten mit großer 5,0, Links ohne Unterstreichung, NEFF und Miele ohne doppeltes Logo.

## 0.13.1 (16.11.2026)
- Startseiten-Stile auch in Entwurf und Vorschau der Startseite (Erkennung über den Baustein `mvkh-hero`).

## 0.13.0 (16.11.2026)
- Neues Modul `modules/home.php` mit `assets/css/home.css` und `assets/js/home.js` (nur Startseite, nur v2): Startseite als eigene Master-Seite.
- Shortcode `[mvk_aktion]`: rechte Hälfte der Startbühne mit dem Beitragsbild der aktuellen Aktion. Zuerst ein oben gehaltener Beitrag (Sticky) der Kategorie „Aktuelles von MVK“, sonst der neueste mit Beitragsbild. Beide Bühnenbilder gleich hoch und ganz sichtbar.
- `[mvk_beitraege aus="aktion"]` lässt die Aktion aus der Bühne in der Teaser-Reihe weg.
- Bausteine `mvkh-`: Einstieg mit rotem Stufenpanel, Gewerke-Mosaik (11 Kacheln, Hover hebt an), Ebenen je Gewerk mit Tiefe beim Scrollen, Über MVK mit Zahlen und Ablauf, Google-Bewertungen als Mauerwerk (mobil wischbar), Partnerbühne mit Logo-Leiste, Einsatzgebiet.

## 0.12.0 (16.11.2026)
- Neues Modul `modules/beitraege.php` mit Vorlage `templates/archiv.php`: Kategorie-Archive im v2-Look (Kopf, Kategorie-Chips mit Zahl, Aufmacher, Raster mit ganzem Beitragsbild, „Weitere Beiträge anzeigen“, Beratungsband). /aktuelles/ zeigt jetzt alle Beiträge, Ratgeber brauchen die Kategorie „Aktuelles von MVK“ nicht mehr. Filter auf /aktuelles/ ohne Neuladen (#kuechen-ratgeber usw.).
- Shortcode `[mvk_beitraege kategorie="kuechen-ratgeber" anzahl="6" titel="…" kicker="…" link="/kuechen-ratgeber/" linktext="…"]` als Teaser-Reihe mit Wischen und Pfeilen, füllt bei zu wenig Beiträgen mit den neuesten auf.
- Jedes Essential-Blocks-Beitragskarussell (Beiträge, Startseite) wird automatisch durch die Teaser-Reihe ersetzt; in Beiträgen mit passenden Beiträgen der Hauptkategorie.
- CSS: Karten `mvk-post`, `mvk-posts`, `mvk-chips`, `mvk-reihe`, `mvk-bloghead`, `mvk-blogcta` (global).

## 0.11.1 (16.11.2026)
- Header: Hauptnavigation passt auf eine Zeile (Abstände 8 px, Suche schmaler), Küchenplaner-Button unter 1180 px ausgeblendet, Ausklappmenü 280 px breit mit Pfeil in derselben Zeile.

## 0.11.0 (16.11.2026)
- Header v2 global: neues Stylesheet `assets/css/header.css`, auf allen Seiten geladen (auch v1 und Blog). Obere rote Leiste auf Containerbreite mit Schnellnavigation der Gewerke (Küchen-Welt, Glasduschen, Glastüren & Loft, Innentüren), weißes Ausklappmenü mit roter Marke, Telefon und Öffnungszeiten rechts, mobil eine wischbare Zeile ohne Ausklappmenü. Hauptnavigation in Montserrat mit roter Unterstreichung, Ausklappmenü weiß mit roter Oberkante, Hover Nebelgrau mit roter Marke, Küchenplaner als Linien-Button (Klasse `mvkh-cta`).
- Menüs: „Schnellnavigation v2“ (ID 10) und „Hauptmenü v2“ (ID 11) mit allen v2-Seiten (Nolte, Glas & Veredelung, Lofttüren, Türen austauschen, Grauthoff, Küchenplaner). Alte Menüs „Top“ und „Home“ bleiben als Ablage.

## 0.10.11 (16.11.2026)
- Kontakt und Küchenplaner nach Deens Feedback: Bühnenbilder getauscht (Kontakt Mitte Nolte 4138 statt 102; Küchenplaner Mitte und rechts Nolte 4125 und 4329 statt 131 und 171), Karten Montage mit 4410 und 4101 statt der mehrfach genutzten Projektküche.

## 0.10.10 (16.11.2026)
- CSS: Schritte über dem Formular (Kontakt, Küchenplaner) mobil als kompakte Leiste, damit das Formular früher im Blick ist.

## 0.10.9 (16.11.2026)
- Kontakt und Küchenplaner nach Sichtprüfung: keine Bilddoppelungen mehr (Bühne Kontakt 1869, 102, 1862; Karte Beratung 1873; Brücke 1870; Küchenplaner Studio-Abschnitt 1862, Karten 186 und 185).

## 0.10.8 (16.11.2026)
- Blueprints `kontakt.html` (58) und `kuechenplaner.html` (1975) im v2-System, Formulare im Fokus: Formularbühne `mvk-formstage` mit Karte `mvk-formcard`, Anfrage über `[mvk_formular name="anfrage"]`, Küchenplaner über Fluent Form 4 mit Bestands-Stilblock. Kontakt: Bühne, Leiste „Alles aus einer Hand“, Anfrage, direkte Wege mit Kontaktdaten (`mvk-nap`), Ansprechpartner, Öffnungszeiten und Anfahrt, Ablauf, Bereiche, Einsatzgebiet, 8 FAQ, Brücke Küchenplaner. Küchenplaner: Bühne, Leiste Küchen-Welt, Formular, Reiter „Was der Planer fragt“ mit sechs Themen, Online und im Studio, Ablauf nach dem Absenden, Bestand „Alles aus einer Hand“, 8 FAQ, Abschluss. Erzeuger `kontakt.py`, `planer.py`.
- CSS: `mvk-steps--3`, `mvk-formstage`, `mvk-formcard`, `mvk-nap`, `mvk-planercard`.

## 0.10.7 (16.11.2026)
- Service-Blueprint nach Deens Feedback: Reiter Küche mit echter Kundenküche (171), Reiter Glasdusche mit bodengleicher Erkelenz-Eckdusche (5277), Leistungskarte Glasduschen mit Walk-In (5258), Karte Neubau mit 598.

## 0.10.6 (16.11.2026)
- Service-Blueprint nach Sichtprüfung: kürzere H1, Einsatzgebiet-Überschrift ohne Ortspaar, Regionen mit größerer Überschrift und mitlaufendem Bild (`mvk-region`), Paderborn-Region gespiegelt, Abschlussband als Flex-Reihe, Bildwechsel im Reiter Küche (1877) und in der Leistungskarte Glas (553).

## 0.10.5 (16.11.2026)
- Blueprint `service.html` für „Service & Einsatzgebiet“ (57) im v2-System: Bühne Rohbau, 3D-Planung, Montage, Leiste „Alles aus einer Hand“, Kennzahlen, Planung im Rohbau, zwei Vergleichsregler (Rohbau zu 3D, 3D zu fertiger Küche), Reiter je Gewerk (Küche, Glasdusche, Glas und Loft, Innentüren), Projektarten, Ablauf in sechs Schritten, Einsatzgebiet mit zwei Regionen (Rheda-Wiedenbrück und Kreis Gütersloh, Paderborn und Kreis Paderborn) samt Orten nach Kreisen, Leistungen, Brücke Küchenstudio, 10 FAQ. Bestandstexte erhalten, „zweiter Standort Paderborn“ und „Festpreis“ korrigiert. Erzeuger `service.py`.
- CSS: `mvk-steps--6`, Ortslisten `mvk-orte`, Abschlussband `mvk-callband`.

## 0.10.4 (16.11.2026)
- Blueprint `kuechenstudio.html` für „Unser Küchenstudio in Rheda-Wiedenbrück“ (1857) im v2-System: Bühne, Kennzahlen, Leiste Küchen-Welt (Küchenstudio markiert), Ausstellung, zwei Ebenen, Stil-Reiter, Muster, Geräte, Beratung mit 3D-Planung, Besuch, Einsatzgebiet, Glas und Türen, Partner, 10 FAQ. Alle 21 Agenturfotos, Bestandstexte erhalten. Erzeuger `studio.py`.

## 0.10.3 (16.11.2026)
- Ballerina-, Nolte- und NEFF-Welt: Brückenlink „Küchen-Welt →“ am Ende der Leiste (18 Seiten), `silo.Silo` mit Parameter `ext`. Miele 1912 bekommt die Leiste „Küchen-Welt“.

## 0.10.2 (16.11.2026)
- Küchen-Hauptseiten 1233 und 781 bekommen die Leiste „Küchen-Welt“ unter der Bühne (Küchenplanung, Ausstattung, Ballerina Küchen, Nolte Küchen, NEFF Geräte, Miele Geräte, Brücke Küchenstudio), wie die Partner-Silos. Erzeuger `kuechen_welt.py`, eingebunden in `pilot_kuechen.py` und `ausstattung.py`.

## 0.10.1 (16.11.2026)
- CSS: Galerie `mvk-gallery--2` mit zwei gleich großen Bildern und Unterschrift an beiden (Vorher und Nachher).
- Innentüren-Blueprints nach Sichtprüfung: Katalogauszüge mit `auszug` (keine doppelten Anker), Oberflächenkatalog der Grauthoff-Seite mit eigenem Anker, Galerien als Reihe, Bauart-Reiter mit kurzen Titeln, Zargen-Reiter ohne Beschnitt, Formulierungen zu Furnieren und Kundenwünschen präzisiert.

## 0.10.0 (16.11.2026)
- Innentüren-Silo auf v2-Stand: Blueprints `innentueren.html` (1485, als Entwurfskopie), `innentueren-renovieren.html` (neu, /innentueren/tueren-renovieren/) und `innentueren-grauthoff.html` (neu, /innentueren/grauthoff-tueren/). Erzeugt mit `mvk-design-build/innen_tueren.py`, `innen_renovieren.py`, `innen_grauthoff.py`, gemeinsame Helfer in `innen_common.py` (Silo-Leiste „Innentüren“, korrigierte Alt-Texte für die Bestandsbilder 1556 bis 1585). Bestandstexte von 1485 nach Faktencheck vom 16.11.2026 korrigiert, LA 110 und LA 115 richtig zugeordnet.
- Vier Kataloge aus 547 Grauthoff-Bildern (Mediathek 5557 bis 6103): `grauthoff-tueren` (300, Filter Marke, Material, Bauart, Farbe), `grauthoff-modelle` (24 Modellfamilien mit Türfinder Raum, Stil, Farbe), `grauthoff-oberflaechen` (82 Muster, Filter Material, Linie, Farbe), `grauthoff-technik` (143 Detailbilder, Filter Thema). Erzeugt mit `grauthoff_*.py`.
- Katalog: Eintrag mit `frei: 1` zeigt das Bild ganz (Klasse `mvk-kat__sw--frei`, object-fit contain auf Nebelgrau), für Einzeltüren als Freisteller.
- CSS: Karte `mvk-card--frei` im Hochformat 4:5 mit ganzem Bild.
- Footer: „Türen austauschen“ und „Grauthoff Türen“ unter Innentüren, erscheinen erst nach Veröffentlichung.

## 0.9.6 (15.11.2026)
- Blueprints Lofttüren und Gewerbe: ungeprüfte Herstellerangabe zum Schallschutz von Trennwänden entfernt, nur noch STEEL|LINE Drehtür bis 25 dB laut Hersteller (Regel Designsystem 8j).

## 0.9.5 (15.11.2026)
- Footer: Link mit viertem Wert `true` erscheint erst, wenn die Seite veröffentlicht ist (`mvkd_page_live`). Gilt für „Lofttüren“, solange die Seite ein Entwurf ist.
- Blueprints G2 nach Sichtprüfung: Tabellen Glasarten (60) und Schallschutz (1145) in voller Breite, Partnertext auf 60 im Einleitungsband statt in der Brücke, Lofttüren mit Doppelweg vor dem Ablauf und kürzerer Kennzahl, Gewerbe-Katalogauszüge ohne doppelte Bilder.

## 0.9.4 (15.11.2026)
- Glas-Silo G2 „Glas & Loft-Welt“: Blueprints `glastueren.html` (60), `lofttueren.html` (neu, Elternseite 60), `gewerbe-buero.html` (1145), dazu `erkelenz-glas.html` (1384) angepasst. Erzeugt mit `mvk-design-build/glas_tueren.py`, `glas_lofttueren.py`, `glas_gewerbe.py`, gemeinsame Helfer in `loft_common.py` (Silo-Leiste „Glas & Loft-Welt“, genaue Alt-Texte für die Bestandsbilder vom März 2026).
- Katalog `erkelenz-glastueren`: 127 Ganzglastüren, Pendeltüren, Glasschiebetüren, Glaswände und Glasgarderoben, Filter Öffnung, Gestaltung, Raum. 84 Bilder neu in der Mediathek (5452 bis 5535), Ort in Dateiname und Alt-Text. Erzeugt mit `erkelenz_glastueren*.py`.
- Katalog `erkelenz-loft`: nur noch Rahmensysteme (102, STEEL|LINE, WOOD|LINE, UNIQUIN), die zehn Ganzglas-Anlagen stehen jetzt in `erkelenz-glastueren`.
- Erkelenz-Seite (1384): Loft-Katalog als Auszug mit Link, Maßtabelle, Farben und Lofttür-Fragen auf der Seite Lofttüren.
- Footer: „Lofttüren“ unter Glastüren & Glastrennwände.
- CSS: Kartenraster `mvk-grid--2` (zwei Spalten).

## 0.9.3 (15.11.2026)
- Katalog `erkelenz-loft`: 112 Lofttüren und Glaswände (STEEL|LINE 70, WOOD|LINE 26, UNIQUIN 6, Ganzglas mit Motiv 10), Filter Linie, Öffnung, Raum, Rahmen, Glas. Die ersten zwölf Karten zeigen die Bandbreite. 69 Bilder neu in der Mediathek (5381 bis 5449), Ort in Dateiname und Alt-Text. Erzeugt mit `mvk-design-build/erkelenz_loft*.py`.
- Blueprint `erkelenz-glas.html` (1384): Loft-Ausbau mit Systemvergleich in sieben Reitern (Drehtür, Pivottür, Schiebetür, Glaswand, WOOD|LINE, Renovierung mit BASIC|FRAME und STEEL|FRAME, UNIQUIN), Loft-Katalog, Planung mit Maßtabelle nach Höhe, RAL-Farben und Aufmaß, vier neue Fragen. Fakt „Lofttüren und Glaswände“ statt Programmzahl.

## 0.9.2 (15.11.2026)
- Footer: „Glas & Veredelung“ unter Glasduschen nach Maß (nach Duschkabinen Varianten). Glas-Silo G1 live.

## 0.9.1 (15.11.2026)
- Blueprints Glas-Silo G1: `glasduschen.html` (59), `glasduschen-varianten.html` (995), `glas-veredelung.html` (neu, Duschglas), `erkelenz-glas.html` (1384). Erzeugt mit `mvk-design-build/glas_*.py`, gemeinsame Helfer in `glas_common.py` (Silo-Leiste „Glasduschen-Welt“, Triptychon, Brücke, Werkzeug-Reiter).
- Silo-Leiste: Nachbar-Segment als abgesetzter Link `mvk-silonav__ext` (rechts, grau, roter Pfeil, mobil normal im Umbruch).
- Werkzeug Duschform: elf Reiter ab 782 px in zwei Zeilen statt seitlich scrollen.
- Doppelweg: Abschnitt mit Überschrift direkt davor ohne doppelten Abstand.
- Karten mit längerem Text `mvk-grid--text`: mobil einspaltig mit Querformat-Bild.

## 0.9.0 (15.11.2026)
- Duschform-Werkzeug `[mvk_dusche form="…"]`: Schema als SVG mit roten Aufmaß-Linien, Glas, Wand, Duschfläche und Schwenkbereich. Elf Formen: nische, doppelfluegel, nische-oberteil (Ansicht von vorn), eck-nische, eckdusche, fuenfeck, fuenfeck-gross, walkin, u-dusche, badewanne, nische-schiebe. Im Reiter-Viewer mit Klasse `mvk-tool--dusche` heißt die Reiterleiste „Duschform wählen“. Vorlage „MVK Werkzeug Duschform“.
- Brücke `mvk-bridge`: eigenes Foto mit Stufenkante, Kicker (`mvk-bridge__k`), ein Satz (`mvk-bridge__t`), Link (`mvk-bridge__go`); die rote Bemaßungslinie läuft aus der Seite hinaus und zeichnet sich beim Einblenden. Varianten `mvk-bridge--links` (gespiegelt) und `mvk-bridge-duo` (zwei Wege nebeneinander, Linien nach außen). Vorlage „MVK Brücke zum Nachbar-Segment“.
- Bühne als Triptychon `mvk-stage--tri`: `mvk-stage__img` als Gruppe mit drei Bildern, mittleres Bild mit Stufenkante.
- Kataloge `erkelenz-duschen` (63 Glasduschen, Filter Türsystem, Einbausituation, Motiv, Glasart, Beschlagfarbe), `erkelenz-veredelung` (69 Motive nach Verfahren und Element), `erkelenz-programm` (16 Duschmodelle ED100 bis ED1400 und 11 Produktlinien, Glasfinder mit drei Fragen). Katalog-Feld `daten_label` für die Überschrift der Datenzeilen.
- Medien: Fällt die PNG-Übergabe an GD aus (ImageMagick-Policy sperrt `png32`, Strato seit 15.11.2026), schreibt Imagick das WebP. Qualitätstest ohne Pseudo-Bildformat. `reconvert` nimmt mit `src_url` eine bessere Fassung direkt aus oriqen-medien und behält Name und Adresse des Anhangs.

## 0.8.2 (15.11.2026)
- `POST /media/meta` liest auf Wunsch ein Manifest aus oriqen-medien (`manifest`, `offset`, `limit` bis 400) und antwortet mit `kurz: true` nur mit Zählern und Fehlern. Für Massenläufe wie die Alt-Texte mit Ortsbezug (3.142 Bilder am 15.11.2026). Alte Werte weiter in Option `mvkd_media_meta_backup`.

## 0.8.1 (09.11.2026)
- Galerie-Variante `mvk-gallery--z`: nach dem Startblock Reihen mit Doppelbild links, dann rechts (Z-Rhythmus), mobil wie gewohnt zweispaltig.
- Küchenseite: Nolte-Galerie von 5 auf 11 Küchen erweitert (zwei Reihen im Z-Rhythmus), Button „Mehr über Nolte Küchen“ wie bei Ballerina.

## 0.8.0 (08.11.2026)
- NEFF-Silo als Entwurf: Hub /kuechen-kuechenplanung/neff-einbaugeraete/ (Umbau von 1931) und fünf Themenseiten (Backöfen und Dampfgarer, Kochfelder und Dunstabzug, Geschirrspüler und Kühlgeräte, NEFF Collection, Küchenideen), Leiste „NEFF-Welt“ wie bei Ballerina und Nolte.
- Sechs neue Kataloge: neff-geraete (68 Geräte, Karten mit Gerätefinder, Filter Geräteart, Werteklasse, Ausstattung, Breite), neff-backen, neff-kochen, neff-spuelen, neff-design, neff-kuechenideen.
- Miele-Seite neu aufgebaut ohne Herstellerbilder, Hinweis „Katalog in Entwicklung“ (neue Klasse .mvk-note).
- Küchenseite: Abschnitt Elektrogeräte mit Auszug aus dem NEFF Gerätekatalog, Markenleiste mit Link zu Nolte Küchen.

## 0.7.1 (08.11.2026)
- Nolte-Silo live (Hub 4481, Themenseiten 4483 bis 4487).
- Footer: „Nolte Küchen“ unter Maßküchen & Küchenplanung, nach Ballerina Küchen. Footer auf Deens Freigabe global eingeschaltet (Einstellung footer_global).

## 0.7.0 (08.11.2026)
- Nolte-Silo als Entwurf: Hub /kuechen-kuechenplanung/nolte-kuechen/ und fünf Themenseiten (Küchenfronten, Gestaltung, Innenausstattung, Neuheiten, Wohnideen), Leiste „Nolte-Welt“ und „Weiter in der Nolte-Welt“ wie bei Ballerina.
- Zehn neue Kataloge: nolte-programme (Karten mit Frontfinder), nolte-fronten, nolte-arbeitsplatten, nolte-korpusdekore, nolte-griffe, nolte-mattlackgriffe, nolte-nischen, nolte-ausstattung, nolte-wohnideen, nolte-neuheiten.
- Katalog: Text des Finder-Knopfs je Katalog einstellbar (`finder.knopf`), Standard bleibt „Passende Modelle ansehen“.

## 0.6.6 (08.11.2026)
- Handy: Leiste „Ballerina-Welt“ bricht um statt seitlich zu laufen, Themen-Kacheln kompakter (flacheres Bild, ohne Beschreibung).

## 0.6.5 (08.11.2026)
- Leiste „Ballerina-Welt“ ohne Listenstriche und Unterstreichung, Kacheln auf weißem Grund mit feiner Linie.

## 0.6.4 (08.11.2026)
- Partner-Silo: Leiste „Ballerina-Welt“ unter der Bühne auf Hub und allen Themenseiten (aktuelle Seite rot markiert, mobil seitlich wischbar).
- Abschnitt „Weiter in der Ballerina-Welt“ auf jeder Themenseite: Bild-Kacheln zur Übersicht und zu allen anderen Themen. Kacheln mit verlinktem Bild, Titel und „… ansehen“.

## 0.6.3 (08.11.2026)
- Ballerina-Seite: „Ein Blick in die Fronten“ zeigt 16 ausgewählte Fronten quer durch Farben und Materialien.

## 0.6.2 (08.11.2026)
- Ballerina-Seite (Hub): neuer Abschnitt „Ballerina-Welt“ mit den fünf Themenseiten und einem Blick in die Fronten, Querverweise bei Farben und Auszügen.
- Wohnideen: Multiroom-Bilder nebeneinander, Bild zur LAFER Gewürzbox aus der Schublade.
- Linktexte für Katalog-Auszüge (`auszug_link`) bei Fronten, Gestaltung, Ausstattung und Wohnideen.

## 0.6.1 (08.11.2026)
- Katalog „ballerina-wohnideen“: 96 Wohnideen in neun Räumen als Bildergalerie (ohne Personenbilder).
- Blueprint `ballerina-wohnideen.html`: acht Raumthemen, Multiroom, LAFER by Ballerina-Küchen, Partner, FAQ.
- Vergleichstabellen mit zwei Spalten (`mvk-vergleich--2`) ohne Wisch-Hinweis und ohne feste erste Spalte auf dem Handy. Wisch-Hinweis sonst allgemein formuliert.

## 0.6.0 (08.11.2026)
- Katalog „ballerina-messekuechen“: 132 Messeküchen von 2020/21 bis 2025/26 mit 141 Bildern, Filter nach Saison und Thema, je Karte die Neuheiten der Messeküche.
- Blueprint `ballerina-neuheiten.html`: Neuheiten 2026/27 (Stand ballerina.de 08.11.2026) als Tabelle, Trends je Jahrgang, Archiv, Begriffe, FAQ.
- Chronik mit Titelzeile (`mvk-chronik__t`).

## 0.5.9 (08.11.2026)
- Katalog „ballerina-ausstattung“: 242 Ausstattungsideen als Bildergalerie mit Filtern nach Ort (Unterschrank, Hochschrank, Eckschrank, Spüle und Abfall, Vitrine und Regal, Wohnen und Hauswirtschaft) und Zweck.
- Katalog-Format `foto` (quadratische Bildkacheln, 4/3/2 Spalten, größere Bildgröße), Lightbox-Text je Eintrag (`lb`), Bezeichnung der Vergrößerung je Datensatz (`lb_label`).
- Blueprint `ballerina-innenausstattung.html` für die Themenseite Innenausstattung.
- Korpusfarben: Schreibweise „Soft Perl“ vereinheitlicht.

## 0.5.8 (08.11.2026)
- Musternamen auf schmalen Handys etwas kleiner mit Silbentrennung (graphitschwarz).
- Sprungliste der Bühne auf schmalen Handys einspaltig (keine Silbentrennung mitten im Wort).
- Griffe ohne Gedankenstriche in den Beschreibungen, Rückwände mit Hinweis auf die Maßskala statt „Breite frei planbar“.

## 0.5.7 (08.11.2026)
- Kataloge „ballerina-arbeitsplatten“ (39), „ballerina-korpusfarben“ (46), „ballerina-griffe“ (107) und „ballerina-rueckwaende“ (11) als Musterkataloge mit Filtern.
- Blueprint `ballerina-gestaltung.html` für die Themenseite Gestaltung im Ballerina-Silo.

## 0.5.6 (08.11.2026)
- Import: Option `opt.flach_ok` für Farbmuster, die einfarbig sein dürfen (Korpusfarben).
- Katalog-Formate je Datensatz (`format`: quer, quadrat, band, panorama) für Griffe, Korpusfarben, Arbeitsplatten und Rückwände. Muster mit kurzer Beschreibung (`text`). Muster-Auszüge behalten das Musterraster.
- Kataloge ohne Filter laufen ohne Skriptfehler.

## 0.5.5 (08.11.2026)
- Blueprint anwenden blendet den Seitentitel des Themes aus (`_generate-disable-headline`), damit neue Seiten nur die H1 der Bühne tragen.
- Fakten-Band mit vier Zahlen: Zahlen etwas kleiner und ohne Umbruch (4.100).
- Küchenfronten-Blueprint: FLEXDESIGN mit drei Beispielen.

## 0.5.4 (08.11.2026)
- Katalog „ballerina-fronten“: 662 Ballerina-Fronten als Musterkatalog mit Filtern nach Farbton, Oberfläche und Glanzgrad (Linie 400xx ohne Türbild ausgelassen).
- Blueprint `ballerina-kuechenfronten.html` für die erste Themenseite des Ballerina-Silos.

## 0.5.3 (08.11.2026)
- Bildimport per Manifest: bis 40 Bilder je Aufruf, Kurzantwort `kurz: true` (nur IDs in Manifest-Reihenfolge und Fehler), damit große Kataloge ohne lange Antworten durchlaufen.

## 0.5.2 (08.11.2026)
- Vergleichstabelle ohne Gitterlinien der Core-Tabelle, mobil mit fester erster Spalte und Wisch-Hinweis.
- Fakten-Band mit vier Zahlen mobil als 2 × 2.
- Siegel-Leiste ohne doppelte Listenmarke. Ballerina-Blueprint: DirectLACK-Karte mit Frontdetail.

## 0.5.1 (08.11.2026)
- Katalog „ballerina-modelle“: 63 Modelle mit eigenen Texten, Filtern (Stil, Farbwelt, Griff, Form, Alltag) und 171 Bildern (153 neu importiert, IDs 2100 bis 2252). Stilfinder mit Hinweisen statt Sackgassen, Nachweis und Leertext je Katalog.
- Korpus im Schnitt mit eckigen Nummernmarken und Liste im HTML, mobil lesbar.
- Katalogkarten im Format 3:2, Detailangaben als `mvk-kat__spec` (kein Klassenkonflikt mehr mit „Mehr zeigen“).
- Neue Bausteine der Partnerseite: Rollen (`mvk-roles`), Chronik (`mvk-chronik`), Siegel-Leiste (`mvk-seals`), Bildnachweis-Zeile (`mvk-credit`).
- Blueprint `ballerina-kuechen.html` für die neue Ballerina-Seite.

## 0.5.0 (08.11.2026)
- Neues Modul Katalog: Herstellerkataloge als Datensätze im Plugin (`katalog/*.json`), Shortcode `[mvk_katalog set="…"]`. Text steht im HTML, ohne JavaScript sind alle Einträge sichtbar.
- Vollständiger Katalog: Filter-Chips je Merkmal mit Live-Zählern (UND zwischen Merkmalen, ODER innerhalb), Stilfinder mit drei Fragen und Hinweisen, „Mehr zeigen“ in Zwölferschritten, Bildansicht je Modell, teilbare Filter-Links (`#katalog=stil:landhaus;griff:grifflos`), Schema ItemList. Auszüge mit `auszug`, `ids`, `filter` und `link`.
- Neuer Shortcode `[mvk_korpus]`: Ballerina-Unterschrank im Schnitt mit Maßlinien, Nummernmarken und Liste im HTML.
- Bildimport `/mvk-design/v1/media/import` liest auf Wunsch ein Manifest aus oriqen-medien (`manifest`, `offset`, `limit`).
- Neue Leseroute `/mvk-design/v1/katalog` (Kataloge, Einträge, fehlende Bilder).

## 0.4.7 (08.11.2026)
- Footer: Einsatzgebiet bricht nie mit einem Punkt am Zeilenanfang um (geschütztes Leerzeichen vor dem Trenner).
- Kontaktleiste Desktop blendet aus, solange der Footer im Bild ist (dort stehen dieselben Kontaktwege im roten Panel). Mobil bleibt die Leiste unten.

## 0.4.6 (08.11.2026)
- Neuer Footer „Stufe“ (Konzept 5, Freigabe Deen): rotes Kontaktpanel links (Telefon groß, Öffnungszeiten, Termin, Route, Küche online planen) mit Kerbe oben rechts. Die rote Linie an der Oberkante des grauen Bandes läuft mittig in die Kerbe bis an deren Innenkante. Marke mit Leitsatz, Spalten Leistungen, Magazin, Studio. Einsatzgebiet an einer Bemaßung, Partner und Google 5,0 in einer Zeile, Rechtliches und oriqen-Verweis darunter. Altes Vertrauensband und die Stufenblöcke entfallen.

## 0.4.5 (08.11.2026)
- Footer-Stufenform nach Deens Vorlage: linker Balken doppelt so hoch (bis kurz vor „Glastüren & Glastrennwände“), linke Box ohne Obergrenze bis kurz vor das Logo. Rechte Form um 180 Grad gedreht: Balken (2,5-fach) auf Höhe der Öffnungszeiten vom rechten Rand bis an den Text, Box hängt darunter fast so hoch wie links. Überlauf jetzt am ganzen Footer abgeschnitten.
- Küchen-Blueprint: G-Küche mit gekennzeichneter Visualisierung (2095), Ballerina-Korpus „61 cm statt bisher 55,5 cm“.

## 0.4.4 (07.11.2026)
- Überschriften: lange Titel tragen zwei rote Blickanker (Schlüsselwort vorn, Nutzen hinten), kurze einen. Auch Abschnitts-H3 wie „Inspiration aus dem Ballerina-Programm“.
- Footer: Stufenform deutlich größer. Links Box im Seitenrand von Logo-Oberkante bis Balkenunterkante plus breiter Balken bis zum Spaltenende, rechts gespiegelt, kleiner und kürzer am Fuß der Studio-Spalte. Endstrich als Maßlinie. oriqen-Verweis ohne eigenes Band im selben Hellgrau wie der Footer.
- Bildband: Zielpunkt-Callouts (`mvk-pt` mit `mvk-x-NN mvk-y-NN`, Linienlänge `mvk-lead-N` in vw, `mvk-to-l` für Etikett links). Bildband mit `mvk-strip--pt` zeigt das Bild am Desktop ungeschnitten in 5:2, damit der Punkt exakt auf dem Objekt liegt. Mobil wie bisher als Etiketten unter dem Bild.
- Küchen-Blueprint: Nolte mit eigenem Magazin-Teaser (H3, Einleitung, Galerie mit fünf Küchen), Ballerina-Galerie mit 15 Küchen, Küchenformen mit Fotos für zweizeilig, U-Küche und Halbinsel.

## 0.4.3 (07.11.2026)
- Copyright der Bestandsseiten nur noch „© Jahr MVK Küchen & Raumdesign“ (Filter `generate_copyright`, Priorität 99). Der oriqen-Verweis steht einmal im neuen Band von oriqen Support 1.0.2. Snippet 5 wirkt damit nicht mehr und kann aus.

## 0.4.2 (07.11.2026)
- Bilder blenden weich ein (Deckkraft und leichter Zoom, 1,1 s) statt per Zuschnitt aufzuploppen, Auslöser etwas früher. Bilder in Reitern ohne zweite Einblendung. Bilder, die beim Start noch laden, blenden nach dem Laden weich ein (nicht Bühne).
- Akzente: Kicker in MVK-Rot, Schlüsselwörter in H2 rot markiert (Core-Textfarbe mit Klasse `mvk-key`, im Builder `[[Wort]]`).
- Footer: Spaltentitel, Leitsatz, Einsatzgebiet und Partner in Rot, Stufenbalken (Box und Balken) von links unter dem Leitsatz und kürzer von rechts unter dem Studio, Endstrich wie eine Maßlinie. oriqen-Verweis auf eigenem weißen Band.

## 0.4.1 (07.11.2026)
- Blueprints: Küchen-Pillar überarbeitet (Vorher-Nachher 3D gegen fertige Küche, Ballerina mit Fakten, Zahlenband und Galerie mit 12 Küchen, Nolte mit Fakten und Galerie, Stilwelten) und neu Küchenausstattung (Hotspot-Bild, drei Reiter-Viewer, Funktionsraster mit Filter, vier Galerien, Zahlenband, FAQ).
- Galerie: Bildunterschrift außerhalb des Rasters, Raster ohne Lücken bei 8, 12 und gerader Bildzahl mobil, Variante `mvk-gallery--row` (eine Reihe), Kachelunterschriften mobil und in Spalten nur am ersten Bild.
- Raster `mvk-grid--tall` (Bilder 4:5), `mvk-grid--funktion` zählt „Lösungen“. Sprungmarken-Liste `mvk-jump`. `mvk-split--solo`. Hotspot-Punkte mobil kleiner.

## 0.4.0 (07.11.2026)
- Bildimport `POST /mvk-design/v1/media/import` (nur aus oriqen-medien, höchstens 20 je Aufruf): WebP q92, lange Kante 2000 px, Zwischengrößen über GD, Alt-Text, Titel, Beschreibung, Quelle in `_mvkd_source`.
- Neue Bausteine: Galerie mit Lightbox (`mvk-gallery`, Einzelbild `mvk-zoom`), Vorher-Nachher-Schieber (`mvk-compare`), Hotspot-Bild (`mvk-hotspots` mit `mvk-x-NN mvk-y-NN`).

## 0.3.2 (07.11.2026)
- GeneratePress ohne theme.json legt in Gruppen `wp-block-group__inner-container` an: Container ohne eigene Box (display: contents), Kind-Selektoren und Skript berücksichtigen ihn.

## 0.3.1 (07.11.2026)
- Seiten-Blueprints: `POST /mvk-design/v1/content/apply` schreibt eine Seite aus `blueprints/pages/` in einen Entwurf (nie in veröffentlichte Seiten), setzt `_mvkd_v2` und GeneratePress „Volle Breite“. Erster Blueprint: Küchen-Pillar v2.

## 0.3.0 (07.11.2026)
- Modul Designsystem: Schriften lokal, Tokens, Bausteine (Bühne, Stufenpanel, Stufenband in drei Varianten, Text-Bild-Split, Zweispalter mit Randnotiz, Bildband mit Callouts, Nutzen-Leiste, Vergleichsraster mit Filter, Reiter-Viewer, Grundriss-Werkzeug, Zeitleiste, Zahlenband, Kundenstimmen, Marken-Leiste, Magazin-Teaser, FAQ, Abschluss), Blockstile für Buttons, 15 Blockvorlagen.
- Globaler Footer und Kontaktleiste aus dem Plugin, vorerst nur auf v2-Seiten.
- FAQPage-Schema aus `mvk-faq` ab drei Fragen.
- Medien: Aktion `purge` für eigene Zwischendateien.

## 0.2.7
- WebP über GD bei fehlerhafter Imagick-Qualität, lange Kante, ICC nach sRGB, keine Rückfallstufe auf q75.
