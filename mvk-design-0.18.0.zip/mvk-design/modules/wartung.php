<?php
/**
 * Wartung: kleine WordPress-Updates (gleicher Zweig, z. B. 7.1.4 auf 7.1.5) automatisch einspielen.
 *
 * Hintergrund (19.11.2026): Code Snippet 10 setzte nur automatic_updater_disabled und allow_minor_auto_core_updates.
 * Die letzte Schranke in WP_Automatic_Updater::should_update() ist aber der Filter auto_update_core, und den
 * belegt auf MVK das Must-Use-Plugin von Installatron (Strato). Dieses Modul setzt die Regel deshalb auch dort,
 * nur für Versionen im selben Zweig. Große Versionen (7.2, 8.0) bleiben manuell.
 *
 * Routen (nur Administratoren):
 *   GET  /mvk-design/v1/updates       Diagnose: Version, Angebot, Sperren, Filter mit Herkunft, Must-Use-Plugins
 *   POST /mvk-design/v1/updates/run   {confirm:true} führt den automatischen Updater jetzt aus (wie der Cron)
 */

defined( 'ABSPATH' ) || exit;

function mvkd_w_branch( $v ) {
	return implode( '.', array_slice( explode( '.', (string) $v ), 0, 2 ) );
}

function mvkd_w_core_minor( $update, $item ) {
	if ( ! is_object( $item ) || empty( $item->current ) ) {
		return $update;
	}
	$installiert = get_bloginfo( 'version' );
	if ( mvkd_w_branch( $installiert ) === mvkd_w_branch( $item->current ) && version_compare( $item->current, $installiert, '>' ) ) {
		return true;
	}
	return $update;
}

add_filter( 'automatic_updater_disabled', '__return_false', PHP_INT_MAX );
add_filter( 'allow_minor_auto_core_updates', '__return_true', PHP_INT_MAX );
add_filter( 'allow_major_auto_core_updates', '__return_false', PHP_INT_MAX );
add_filter( 'auto_update_core', 'mvkd_w_core_minor', PHP_INT_MAX, 2 );

// Falls ein anderes Plugin den Updater-Lauf vom Cron abhängt: vor jeder Versionsprüfung wieder anhängen.
add_action( 'wp_version_check', function () {
	if ( function_exists( 'wp_maybe_auto_update' ) && ! has_action( 'wp_maybe_auto_update', 'wp_maybe_auto_update' ) ) {
		add_action( 'wp_maybe_auto_update', 'wp_maybe_auto_update' );
	}
}, 1 );

function mvkd_w_callbacks( $hook ) {
	global $wp_filter;
	$out = array();
	if ( empty( $wp_filter[ $hook ] ) ) {
		return $out;
	}
	foreach ( $wp_filter[ $hook ]->callbacks as $prio => $cbs ) {
		foreach ( $cbs as $cb ) {
			$f    = $cb['function'];
			$name = is_string( $f ) ? $f : ( is_array( $f ) ? ( is_object( $f[0] ) ? get_class( $f[0] ) : $f[0] ) . '::' . $f[1] : 'Closure' );
			$file = '';
			try {
				$r    = is_array( $f ) ? new ReflectionMethod( $f[0], $f[1] ) : new ReflectionFunction( $f );
				$file = str_replace( ABSPATH, '', (string) $r->getFileName() ) . ':' . $r->getStartLine();
			} catch ( Throwable $e ) {
				$file = '?';
			}
			$out[] = array( 'prio' => $prio, 'callback' => $name, 'file' => $file );
		}
	}
	return $out;
}

function mvkd_w_diag() {
	require_once ABSPATH . 'wp-admin/includes/update.php';
	require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
	$u      = new WP_Automatic_Updater();
	$offers = array();
	foreach ( (array) get_core_updates( array( 'dismissed' => true ) ) as $o ) {
		if ( is_object( $o ) ) {
			$offers[] = array( 'response' => $o->response ?? '', 'current' => $o->current ?? '', 'locale' => $o->locale ?? '' );
		}
	}
	$auto   = find_core_auto_update();
	$should = $auto ? $u->should_update( 'core', $auto, ABSPATH ) : null;
	$hooks  = array();
	foreach ( array( 'auto_update_core', 'automatic_updater_disabled', 'allow_minor_auto_core_updates', 'allow_major_auto_core_updates', 'file_mod_allowed', 'automatic_updates_is_vcs_checkout', 'wp_maybe_auto_update', 'site_status_tests' ) as $h ) {
		$hooks[ $h ] = mvkd_w_callbacks( $h );
	}
	$mu = array();
	foreach ( (array) glob( WPMU_PLUGIN_DIR . '/*.php' ) as $f ) {
		$lines = array();
		foreach ( (array) @file( $f ) as $i => $l ) {
			if ( preg_match( '/add_filter|add_action|remove_action|remove_filter|define\s*\(|unset\(/i', $l ) ) {
				$l       = preg_replace( '/[A-Za-z0-9_\-]{32,}/', '[…]', trim( $l ) );
				$lines[] = ( $i + 1 ) . ': ' . substr( $l, 0, 220 );
			}
		}
		$mu[ basename( $f ) ] = array( 'bytes' => filesize( $f ), 'lines' => array_slice( $lines, 0, 60 ) );
	}
	$k = array();
	foreach ( array( 'AUTOMATIC_UPDATER_DISABLED', 'WP_AUTO_UPDATE_CORE', 'DISALLOW_FILE_MODS', 'DISABLE_WP_CRON' ) as $c ) {
		$k[ $c ] = defined( $c ) ? constant( $c ) : 'undefiniert';
	}
	return array(
		'version'           => get_bloginfo( 'version' ),
		'angebote'          => $offers,
		'auto_angebot'      => $auto ? ( $auto->current ?? '' ) : null,
		'updater_aus'       => $u->is_disabled(),
		'vcs_checkout'      => $u->is_vcs_checkout( ABSPATH ),
		'should_update'     => $should,
		'konstanten'        => $k,
		'optionen'          => array(
			'auto_core_update_failed'   => get_site_option( 'auto_core_update_failed' ),
			'auto_updater.lock'         => get_option( 'auto_updater.lock' ),
			'auto_core_update_notified' => get_site_option( 'auto_core_update_notified' ),
		),
		'naechste_pruefung' => wp_next_scheduled( 'wp_version_check' ) ? gmdate( 'c', wp_next_scheduled( 'wp_version_check' ) ) : null,
		'hooks'             => $hooks,
		'mu_plugins'        => $mu,
	);
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'mvk-design/v1', '/updates', array(
		'methods'             => 'GET',
		'permission_callback' => function () { return current_user_can( 'update_core' ); },
		'callback'            => function () { return rest_ensure_response( mvkd_w_diag() ); },
	) );
	register_rest_route( 'mvk-design/v1', '/updates/run', array(
		'methods'             => 'POST',
		'permission_callback' => function () { return current_user_can( 'update_core' ); },
		'callback'            => function ( WP_REST_Request $r ) {
			if ( true !== $r->get_param( 'confirm' ) ) {
				return new WP_Error( 'mvkd_confirm', 'confirm: true fehlt', array( 'status' => 400 ) );
			}
			$vorher = get_bloginfo( 'version' );
			@set_time_limit( 300 );
			wp_version_check( array(), true );
			require_once ABSPATH . 'wp-admin/includes/admin.php';
			require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
			$u = new WP_Automatic_Updater();
			$u->run();
			global $wp_version;
			include ABSPATH . WPINC . '/version.php';
			return rest_ensure_response( array(
				'vorher'  => $vorher,
				'nachher' => $wp_version,
				'fehler'  => get_site_option( 'auto_core_update_failed' ),
			) );
		},
	) );
} );
