<?php
/**
 * MVK Design · Modul Medien
 * 1. Alt-Live-Sync: Alt-Text aus der Mediathek gewinnt beim Ausspielen (ersetzt Code Snippet 9, erkennt zusätzlich Bilder ohne wp-image-Klasse über den Dateinamen).
 * 2. REST GET  /mvk-design/v1/media/inventory  Inventar aller Bilder mit Verwendung (Inhalte, Metafelder, Optionen, CSS-Dateien).
 * 3. REST POST /mvk-design/v1/media/rename     Datei samt Größen und WebP/AVIF umbenennen, Verweise ersetzen, alte Adresse per 301 weiterleiten.
 * 4. 301 für umbenannte Dateien (Option mvkd_media_redirects).
 */

defined( 'ABSPATH' ) || exit;

/* ------------------------------------------------------------------ */
/* Hilfen                                                              */
/* ------------------------------------------------------------------ */
function mvkd_upload_base() {
	$u = wp_get_upload_dir();
	return array( 'dir' => trailingslashit( $u['basedir'] ), 'url' => trailingslashit( $u['baseurl'] ) );
}

/** Stamm eines Anhangs relativ zu uploads, ohne Endung und ohne -scaled, z. B. 2025/12/bolte-kueche-1 */
function mvkd_attachment_stem( $id ) {
	$rel = (string) get_post_meta( $id, '_wp_attached_file', true );
	if ( '' === $rel ) {
		return '';
	}
	$meta = wp_get_attachment_metadata( $id );
	if ( is_array( $meta ) && ! empty( $meta['original_image'] ) ) {
		$rel = trailingslashit( dirname( $rel ) ) . $meta['original_image'];
	}
	$stem = preg_replace( '/\.[a-z0-9]+$/i', '', $rel );
	return preg_replace( '/-scaled$/', '', $stem );
}

/** Endungsteil hinter dem Stamm: Größen, -scaled/-rotated, Editor-Suffix, Endung (WebP/AVIF-Anhängsel bleiben dahinter erhalten). */
function mvkd_suffix_pattern() {
	return '(?:-e\\d{10,})?(?:-\\d+x\\d+)?(?:-scaled|-rotated)?(?:-\\d+x\\d+)?\\.(?:jpe?g|png|gif|webp|avif)';
}

/** Regex auf einen Stamm (z. B. 2025/12/name). Gruppe 1 = Ordnerteil (auch mit \\/ aus JSON), danach der Dateiname. */
function mvkd_stem_regex( $stem ) {
	$parts = explode( '/', $stem );
	$name  = array_pop( $parts );
	$dir   = '';
	foreach ( $parts as $p ) {
		$dir .= preg_quote( $p, '~' ) . '\\\\?/';
	}
	$lead = '' === $dir ? '(/)' : '(' . $dir . ')';
	return '~' . $lead . preg_quote( $name, '~' ) . '(?=' . mvkd_suffix_pattern() . ')~i';
}

/** Sucht rekursiv in Arrays/Objekten/Strings und ersetzt per Regex. */
function mvkd_deep_replace( $value, $regex, $replacement, &$count ) {
	if ( is_string( $value ) ) {
		$new = preg_replace( $regex, $replacement, $value, -1, $n );
		$count += $n;
		return $new;
	}
	if ( is_array( $value ) ) {
		foreach ( $value as $k => $v ) {
			$value[ $k ] = mvkd_deep_replace( $v, $regex, $replacement, $count );
		}
		return $value;
	}
	if ( is_object( $value ) && ! ( $value instanceof __PHP_Incomplete_Class ) ) {
		foreach ( get_object_vars( $value ) as $k => $v ) {
			$value->$k = mvkd_deep_replace( $v, $regex, $replacement, $count );
		}
	}
	return $value;
}

/** CSS-Dateien in uploads (Essential Blocks, GenerateBlocks u. a.). */
function mvkd_css_files() {
	$base  = mvkd_upload_base()['dir'];
	$files = array();
	foreach ( array( 'eb-style', 'generateblocks', 'essential-blocks', 'eb-custom-css', 'generatepress' ) as $sub ) {
		if ( ! is_dir( $base . $sub ) ) {
			continue;
		}
		$it = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $base . $sub, FilesystemIterator::SKIP_DOTS ) );
		foreach ( $it as $f ) {
			if ( preg_match( '/\.css$/i', $f->getFilename() ) ) {
				$files[] = $f->getPathname();
			}
		}
	}
	return $files;
}

/* ------------------------------------------------------------------ */
/* 1. Alt-Live-Sync                                                    */
/* ------------------------------------------------------------------ */
function mvkd_file_map() {
	$map = get_transient( 'mvkd_file_map' );
	if ( is_array( $map ) ) {
		return $map;
	}
	global $wpdb;
	$map  = array();
	$rows = $wpdb->get_results( "SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_wp_attached_file'" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	foreach ( $rows as $r ) {
		$stem = preg_replace( '/(-scaled)?\.[a-z0-9]+$/i', '', basename( $r->meta_value ) );
		$map[ strtolower( $stem ) ] = (int) $r->post_id;
	}
	set_transient( 'mvkd_file_map', $map, DAY_IN_SECONDS );
	return $map;
}
add_action( 'add_attachment', function () { delete_transient( 'mvkd_file_map' ); } );
add_action( 'delete_attachment', function () { delete_transient( 'mvkd_file_map' ); } );

function mvkd_alt_live_sync( $content ) {
	if ( empty( $content ) || false === stripos( $content, '<img' ) ) {
		return $content;
	}
	return preg_replace_callback( '/<img\b[^>]*>/i', function ( $m ) {
		$img = $m[0];
		$id  = 0;
		if ( preg_match( '/wp-image-(\d+)/', $img, $mm ) ) {
			$id = (int) $mm[1];
		} elseif ( preg_match( '/\ssrc\s*=\s*["\']([^"\']+)["\']/i', $img, $mm ) && false !== strpos( $mm[1], '/wp-content/uploads/' ) ) {
			$stem = preg_replace( '/(-\d+x\d+)?(-scaled)?\.[a-z0-9]+$/i', '', basename( wp_parse_url( $mm[1], PHP_URL_PATH ) ) );
			$map  = mvkd_file_map();
			$id   = isset( $map[ strtolower( $stem ) ] ) ? $map[ strtolower( $stem ) ] : 0;
		}
		if ( ! $id ) {
			return $img;
		}
		$alt = get_post_meta( $id, '_wp_attachment_image_alt', true );
		if ( '' === $alt || null === $alt ) {
			return $img;
		}
		$attr = 'alt="' . esc_attr( $alt ) . '"';
		if ( preg_match( '/\salt\s*=\s*("[^"]*"|\'[^\']*\')/i', $img ) ) {
			return preg_replace( '/\salt\s*=\s*("[^"]*"|\'[^\']*\')/i', ' ' . $attr, $img, 1 );
		}
		return preg_replace( '/<img\b/i', '<img ' . $attr, $img, 1 );
	}, $content );
}
add_filter( 'the_content', 'mvkd_alt_live_sync', 99 );
add_filter( 'widget_block_content', 'mvkd_alt_live_sync', 99 );

/* ------------------------------------------------------------------ */
/* 2. Inventar                                                         */
/* ------------------------------------------------------------------ */
/** Lädt einmal alle Texte, in denen Bilddateien vorkommen können. */
function mvkd_corpus() {
	global $wpdb;
	$c = array( 'posts' => array(), 'meta' => array(), 'options' => array(), 'css' => array(), 'thumbs' => array() );
	foreach ( $wpdb->get_results( "SELECT ID, post_type, post_status, post_title, post_content, post_excerpt FROM {$wpdb->posts} WHERE post_type NOT IN ('revision','attachment','nav_menu_item','customize_changeset','oembed_cache') AND post_status NOT IN ('auto-draft','trash','inherit')" ) as $r ) { // phpcs:ignore
		$c['posts'][] = $r;
	}
	foreach ( $wpdb->get_results( "SELECT post_id, meta_key, meta_value FROM {$wpdb->postmeta} WHERE meta_key NOT IN ('_wp_attached_file','_wp_attachment_metadata','_wp_attachment_backup_sizes') AND meta_value LIKE '%uploads%'" ) as $r ) { // phpcs:ignore
		$c['meta'][] = $r;
	}
	foreach ( $wpdb->get_results( "SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_thumbnail_id'" ) as $r ) { // phpcs:ignore
		$c['thumbs'][ (int) $r->meta_value ][] = (int) $r->post_id;
	}
	foreach ( $wpdb->get_results( "SELECT option_name, option_value FROM {$wpdb->options} WHERE option_name NOT LIKE '\\_%transient%' AND option_name NOT LIKE 'mvkd\\_%' AND option_value LIKE '%uploads%'" ) as $r ) { // phpcs:ignore
		$c['options'][] = $r;
	}
	$base = mvkd_upload_base()['dir'];
	foreach ( mvkd_css_files() as $f ) {
		$c['css'][ substr( $f, strlen( $base ) ) ] = (string) file_get_contents( $f ); // phpcs:ignore
	}
	return $c;
}

function mvkd_usage( $id, $stem, $c ) {
	$regex = mvkd_stem_regex( $stem );
	$name  = basename( $stem );
	$u     = array( 'posts' => array(), 'meta' => array(), 'options' => array(), 'css' => array() );
	foreach ( $c['posts'] as $r ) {
		$hit = ( false !== stripos( $r->post_content, $name ) && preg_match( $regex, $r->post_content ) )
			|| preg_match( '/wp-image-' . (int) $id . '\b|"id":' . (int) $id . '\b/', $r->post_content );
		if ( $hit ) {
			$u['posts'][] = array( 'id' => (int) $r->ID, 'type' => $r->post_type, 'status' => $r->post_status, 'title' => $r->post_title );
		}
	}
	foreach ( $c['meta'] as $r ) {
		if ( (int) $r->post_id !== (int) $id && false !== stripos( $r->meta_value, $name ) && preg_match( $regex, $r->meta_value ) ) {
			$u['meta'][] = array( 'post_id' => (int) $r->post_id, 'key' => $r->meta_key );
		}
	}
	if ( isset( $c['thumbs'][ $id ] ) ) {
		foreach ( $c['thumbs'][ $id ] as $p ) {
			$u['meta'][] = array( 'post_id' => $p, 'key' => '_thumbnail_id' );
		}
	}
	foreach ( $c['options'] as $r ) {
		if ( false !== stripos( $r->option_value, $name ) && preg_match( $regex, $r->option_value ) ) {
			$u['options'][] = $r->option_name;
		}
	}
	foreach ( $c['css'] as $f => $css ) {
		if ( false !== stripos( $css, $name ) && preg_match( $regex, $css ) ) {
			$u['css'][] = $f;
		}
	}
	return $u;
}

function mvkd_inventory( WP_REST_Request $req ) {
	$base   = mvkd_upload_base();
	$usage  = (bool) $req->get_param( 'usage' );
	$offset = max( 0, (int) $req->get_param( 'offset' ) );
	$limit  = (int) $req->get_param( 'limit' );
	$short  = (bool) $req->get_param( 'short' );
	$ids    = get_posts( array( 'post_type' => 'attachment', 'post_status' => 'inherit', 'post_mime_type' => 'image', 'posts_per_page' => -1, 'fields' => 'ids', 'orderby' => 'ID', 'order' => 'ASC' ) );
	$total  = count( $ids );
	$ids    = array_slice( $ids, $offset, $limit > 0 ? $limit : null );
	$corpus = $usage ? mvkd_corpus() : null;
	$out    = array();
	foreach ( $ids as $id ) {
		$rel  = (string) get_post_meta( $id, '_wp_attached_file', true );
		$meta = wp_get_attachment_metadata( $id );
		$stem = mvkd_attachment_stem( $id );
		$path = $base['dir'] . $rel;
		$row  = array(
			'id'     => $id,
			'file'   => $rel,
			'w'      => is_array( $meta ) && isset( $meta['width'] ) ? (int) $meta['width'] : 0,
			'h'      => is_array( $meta ) && isset( $meta['height'] ) ? (int) $meta['height'] : 0,
			'kb'     => file_exists( $path ) ? (int) round( filesize( $path ) / 1024 ) : -1,
			'date'   => substr( get_post_field( 'post_date', $id ), 0, 10 ),
			'parent' => (int) get_post_field( 'post_parent', $id ),
			'alt'    => (string) get_post_meta( $id, '_wp_attachment_image_alt', true ),
			'title'  => get_post_field( 'post_title', $id ),
		);
		if ( ! $short ) {
			$row['caption']     = get_post_field( 'post_excerpt', $id );
			$row['description'] = get_post_field( 'post_content', $id );
			$row['sizes']       = is_array( $meta ) && ! empty( $meta['sizes'] ) ? count( $meta['sizes'] ) : 0;
			$row['webp']        = file_exists( $path . '.webp' ) || file_exists( preg_replace( '/\.[a-z0-9]+$/i', '.webp', $path ) );
		}
		if ( $usage && $stem ) {
			$row['usage'] = mvkd_usage( $id, $stem, $corpus );
		}
		$out[] = $row;
	}
	return array( 'version' => MVKD_VERSION, 'total' => $total, 'offset' => $offset, 'count' => count( $out ), 'items' => $out );
}

/* ------------------------------------------------------------------ */
/* 3. Umbenennen, in WebP wandeln, tauschen                            */
/* ------------------------------------------------------------------ */

/** Alle Dateien eines Anhangs im Ordner (Original, Größen, -scaled, Editor-Varianten, WebP/AVIF-Geschwister) plus Imagify-Sicherungen. */
function mvkd_attachment_files( $id ) {
	$base   = mvkd_upload_base();
	$stem   = mvkd_attachment_stem( $id );
	$sub    = dirname( $stem );
	$prefix = ( '.' === $sub || '' === $sub ) ? '' : $sub . '/';
	$name   = basename( $stem );
	$re     = '~^' . preg_quote( $name, '~' ) . '(' . mvkd_suffix_pattern() . '(?:\.(?:webp|avif))?)$~i';
	$out    = array();
	foreach ( array( $prefix, 'backup/' . $prefix ) as $rel_dir ) {
		foreach ( (array) glob( $base['dir'] . $rel_dir . $name . '*' ) as $f ) {
			if ( preg_match( $re, basename( $f ), $m ) ) {
				$out[] = array( 'rel' => $rel_dir . basename( $f ), 'dir' => $rel_dir, 'suffix' => $m[1] );
			}
		}
	}
	return array( 'stem' => $stem, 'prefix' => $prefix, 'name' => $name, 'files' => $out );
}

/**
 * Ersetzt Verweise auf Dateien eines alten Stamms in Inhalten, Metafeldern, Optionen und CSS-Dateien.
 * $map: alter Dateiname (basename, klein) => neuer Pfad relativ zu uploads; '*' als Rückfall.
 * $ids: optional array( alt_id => neu_id ) für ID-Verweise in Beitragsinhalten mit Treffer.
 */
function mvkd_apply_map( $old_stem, $map, $dry, $ids = array() ) {
	global $wpdb;
	$base   = mvkd_upload_base();
	$parts  = explode( '/', $old_stem );
	$name   = array_pop( $parts );
	$dirpat = '';
	foreach ( $parts as $p ) {
		$dirpat .= preg_quote( $p, '~' ) . '\\\\?/';
	}
	// Gruppe 1: Pfad bis uploads/ (optional mit Domain), Gruppe 2: Dateiname
	$regex = '~((?:https?:\\\\?/\\\\?/[^"\'\s()<>]*?)?wp-content\\\\?/uploads\\\\?/)?' . $dirpat . '(' . preg_quote( $name, '~' ) . mvkd_suffix_pattern() . ')(\.(?:webp|avif))?(?![\w-])~i';
	$cb    = function ( $m ) use ( $map, $base ) {
		$key = strtolower( $m[2] );
		$new = isset( $map[ $key ] ) ? $map[ $key ] : $map['*'];
		$esc = false !== strpos( $m[0], '\\/' );
		return $m[1] . ( $esc ? str_replace( '/', '\\/', $new ) : $new );
	};
	$id_regex = array();
	foreach ( $ids as $old_id => $new_id ) {
		$id_regex[ '~(wp-image-|"(?:id|mediaId|imageId|imageID|ImageID|ImageId|backgroundImageID|bgImageID)":)' . (int) $old_id . '(?!\d)~' ] = '${1}' . (int) $new_id;
	}
	$like = '%' . $wpdb->esc_like( $name ) . '%';
	$rep  = array( 'posts' => array(), 'meta' => array(), 'options' => array(), 'css' => array() );

	foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT ID, post_content, post_excerpt FROM {$wpdb->posts} WHERE post_type <> 'revision' AND (post_content LIKE %s OR post_excerpt LIKE %s)", $like, $like ) ) as $r ) { // phpcs:ignore
		$pc = preg_replace_callback( $regex, $cb, $r->post_content, -1, $a );
		$pe = preg_replace_callback( $regex, $cb, $r->post_excerpt, -1, $b );
		if ( $a + $b ) {
			foreach ( $id_regex as $re => $to ) {
				$pc = preg_replace( $re, $to, $pc );
			}
			$rep['posts'][ $r->ID ] = $a + $b;
			if ( ! $dry ) {
				$wpdb->update( $wpdb->posts, array( 'post_content' => $pc, 'post_excerpt' => $pe ), array( 'ID' => $r->ID ) ); // phpcs:ignore
				clean_post_cache( $r->ID );
			}
		}
	}
	foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT meta_id, post_id, meta_key, meta_value FROM {$wpdb->postmeta} WHERE meta_key NOT IN ('_wp_attached_file','_wp_attachment_metadata','_wp_attachment_backup_sizes') AND meta_value LIKE %s", $like ) ) as $r ) { // phpcs:ignore
		$n   = 0;
		$new = mvkd_deep_replace_cb( maybe_unserialize( $r->meta_value ), $regex, $cb, $n );
		if ( $n ) {
			$rep['meta'][] = array( 'post_id' => (int) $r->post_id, 'key' => $r->meta_key, 'n' => $n );
			if ( ! $dry ) {
				$wpdb->update( $wpdb->postmeta, array( 'meta_value' => maybe_serialize( $new ) ), array( 'meta_id' => $r->meta_id ) ); // phpcs:ignore
				wp_cache_delete( (int) $r->post_id, 'post_meta' );
			}
		}
	}
	foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT option_name, option_value FROM {$wpdb->options} WHERE option_name NOT LIKE %s AND option_name NOT LIKE %s AND option_name NOT LIKE %s AND option_value LIKE %s", '\_transient%', '\_site\_transient%', 'mvkd\_%', $like ) ) as $r ) { // phpcs:ignore
		$n   = 0;
		$new = mvkd_deep_replace_cb( maybe_unserialize( $r->option_value ), $regex, $cb, $n );
		if ( $n ) {
			$rep['options'][ $r->option_name ] = $n;
			if ( ! $dry ) {
				$wpdb->update( $wpdb->options, array( 'option_value' => maybe_serialize( $new ) ), array( 'option_name' => $r->option_name ) ); // phpcs:ignore
				wp_cache_delete( $r->option_name, 'options' );
			}
		}
	}
	foreach ( mvkd_css_files() as $f ) {
		$c  = (string) file_get_contents( $f ); // phpcs:ignore
		$nc = preg_replace_callback( $regex, $cb, $c, -1, $n );
		if ( $n ) {
			$rep['css'][ substr( $f, strlen( $base['dir'] ) ) ] = $n;
			if ( ! $dry ) {
				if ( ! file_exists( $f . '.mvkbak' ) ) {
					copy( $f, $f . '.mvkbak' );
				}
				file_put_contents( $f, $nc ); // phpcs:ignore
			}
		}
	}
	return $rep;
}

function mvkd_deep_replace_cb( $value, $regex, $cb, &$count ) {
	if ( is_string( $value ) ) {
		$new = preg_replace_callback( $regex, $cb, $value, -1, $n );
		$count += $n;
		return $new;
	}
	if ( is_array( $value ) ) {
		foreach ( $value as $k => $v ) {
			$value[ $k ] = mvkd_deep_replace_cb( $v, $regex, $cb, $count );
		}
		return $value;
	}
	if ( is_object( $value ) && ! ( $value instanceof __PHP_Incomplete_Class ) ) {
		foreach ( get_object_vars( $value ) as $k => $v ) {
			$value->$k = mvkd_deep_replace_cb( $v, $regex, $cb, $count );
		}
	}
	return $value;
}

/** Weiterleitung alter Dateistamm => neues Ziel (relativ zu uploads; Ziel ohne Endung = gleiche Endung, mit Endung = feste Datei). */
function mvkd_add_redirect( $old_stem, $target ) {
	$r = get_option( 'mvkd_media_redirects', array() );
	foreach ( $r as $from => $to ) {
		if ( $to === $old_stem ) {
			$r[ $from ] = $target;
		}
	}
	unset( $r[ preg_replace( '/\.[a-z0-9]+$/i', '', $target ) ] );
	$r[ $old_stem ] = $target;
	update_option( 'mvkd_media_redirects', $r, false );
}

function mvkd_log( $entry ) {
	$log   = get_option( 'mvkd_media_renames', array() );
	$log[] = array_merge( array( 'time' => current_time( 'mysql' ) ), $entry );
	update_option( 'mvkd_media_renames', $log, false );
}

/**
 * Umbenennen (und optional in WebP wandeln) bei gleicher Anhang-ID.
 * $a: id, new_stem, webp (bool), max (int, längste Kante Breite), dry_run
 */
function mvkd_do_rename( $a ) {
	$id   = (int) $a['id'];
	$dry  = ! empty( $a['dry_run'] );
	$webp = ! empty( $a['webp'] );
	$max  = isset( $a['max'] ) ? (int) $a['max'] : 0;
	if ( 'attachment' !== get_post_type( $id ) ) {
		return new WP_Error( 'mvkd_no_attachment', 'Kein Anhang: ' . $id );
	}
	$base  = mvkd_upload_base();
	$info  = mvkd_attachment_files( $id );
	$meta  = wp_get_attachment_metadata( $id );
	$rel   = (string) get_post_meta( $id, '_wp_attached_file', true );
	$want  = sanitize_title( remove_accents( preg_replace( '/\.[a-z0-9]+$/i', '', basename( (string) $a['new_stem'] ) ) ) );
	if ( '' === $want ) {
		return new WP_Error( 'mvkd_bad_name', 'Neuer Name fehlt: ' . $id );
	}
	$is_webp = (bool) preg_match( '/\.webp$/i', $rel );
	if ( $want === $info['name'] && ( ! $webp || $is_webp ) ) {
		return array( 'id' => $id, 'skip' => 'Name unverändert' );
	}
	$dir   = $base['dir'] . $info['prefix'];
	$final = $want;
	$i     = 2;
	while ( $final !== $info['name'] && ( glob( $dir . $final . '.*' ) || glob( $dir . $final . '-*x*.*' ) || glob( $dir . $final . '-scaled.*' ) ) ) {
		$final = $want . '-' . $i++;
	}
	$new_stem = $info['prefix'] . $final;
	$report   = array( 'id' => $id, 'old' => $info['stem'], 'new' => $new_stem, 'webp' => $webp && ! $is_webp, 'files' => count( $info['files'] ), 'dry_run' => $dry );

	if ( ! $webp || $is_webp ) {
		// Reines Umbenennen: Dateiname je Größe gleich, nur Stamm neu
		$map = array();
		foreach ( $info['files'] as $f ) {
			$strip = '/(\.(?:jpe?g|png|gif))\.(?:webp|avif)$/i';
			$map[ strtolower( basename( preg_replace( $strip, '$1', $f['rel'] ) ) ) ] = $info['prefix'] . $final . preg_replace( $strip, '$1', $f['suffix'] );
		}
		$map['*'] = $info['prefix'] . $final . preg_replace( '/^.*?(\.[a-z0-9]+)$/i', '$1', basename( $rel ) );
		$report['refs'] = mvkd_apply_map( $info['stem'], $map, $dry );
		if ( $dry ) {
			return $report;
		}
		foreach ( $info['files'] as $f ) {
			$to = $f['dir'] . $final . $f['suffix'];
			if ( ! @rename( $base['dir'] . $f['rel'], $base['dir'] . $to ) ) { // phpcs:ignore
				$report['errors'][] = 'mv ' . $f['rel'];
			}
		}
		$swap    = function ( $file ) use ( $info, $final ) {
			return preg_replace( '~^' . preg_quote( $info['name'], '~' ) . '~', $final, $file );
		};
		$new_rel = $info['prefix'] . $swap( basename( $rel ) );
		update_post_meta( $id, '_wp_attached_file', $new_rel );
		if ( is_array( $meta ) ) {
			$meta['file'] = $new_rel;
			if ( ! empty( $meta['original_image'] ) ) {
				$meta['original_image'] = $swap( $meta['original_image'] );
			}
			if ( ! empty( $meta['sizes'] ) ) {
				foreach ( $meta['sizes'] as $k => $sz ) {
					$meta['sizes'][ $k ]['file'] = $swap( $sz['file'] );
				}
			}
			wp_update_attachment_metadata( $id, $meta );
		}
		mvkd_add_redirect( $info['stem'], $new_stem );
	} else {
		// In WebP wandeln: aus dem Original neu erzeugen, alte Dateien ins Archiv
		$src = $base['dir'] . $info['prefix'] . ( is_array( $meta ) && ! empty( $meta['original_image'] ) ? $meta['original_image'] : basename( $rel ) );
		if ( ! file_exists( $src ) ) {
			$src = $base['dir'] . $rel;
		}
		$old_sizes = is_array( $meta ) && ! empty( $meta['sizes'] ) ? $meta['sizes'] : array();
		$ow        = is_array( $meta ) && isset( $meta['width'] ) ? (int) $meta['width'] : 0;
		$report['src'] = basename( $src );
		$report['to']  = $final . '.webp' . ( $max && $ow > $max ? ' (' . $max . ' px)' : '' );
		if ( $dry ) {
			$report['refs'] = mvkd_apply_map( $info['stem'], array( '*' => $new_stem . '.webp' ), true );
			return $report;
		}
		$ed = wp_get_image_editor( $src );
		if ( is_wp_error( $ed ) ) {
			return $ed;
		}
		if ( $max ) {
			$sz = $ed->get_size();
			if ( $sz['width'] > $max ) {
				$ed->resize( $max, null, false );
			}
		}
		$ed->set_quality( 82 );
		$saved = $ed->save( $dir . $final . '.webp', 'image/webp' );
		if ( is_wp_error( $saved ) ) {
			return $saved;
		}
		// alte Dateien ins Archiv (nicht verlinkt, nichts gelöscht)
		$arch = $base['dir'] . '_mvk-archiv/' . $info['prefix'];
		wp_mkdir_p( $arch );
		foreach ( $info['files'] as $f ) {
			$to = $base['dir'] . '_mvk-archiv/' . $f['rel'];
			wp_mkdir_p( dirname( $to ) );
			if ( ! @rename( $base['dir'] . $f['rel'], $to ) ) { // phpcs:ignore
				$report['errors'][] = 'archiv ' . $f['rel'];
			}
		}
		$new_rel = $info['prefix'] . $final . '.webp';
		update_post_meta( $id, '_wp_attached_file', $new_rel );
		global $wpdb;
		$wpdb->update( $wpdb->posts, array( 'post_mime_type' => 'image/webp' ), array( 'ID' => $id ) ); // phpcs:ignore
		clean_post_cache( $id );
		if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) {
			require_once ABSPATH . 'wp-admin/includes/image.php';
		}
		$new_meta = wp_generate_attachment_metadata( $id, $dir . $final . '.webp' );
		wp_update_attachment_metadata( $id, $new_meta );
		// Zuordnung alte Größe => neue Größe über den Größennamen
		$map = array( '*' => $new_rel );
		$nw  = isset( $new_meta['sizes'] ) ? $new_meta['sizes'] : array();
		foreach ( $old_sizes as $k => $s ) {
			$key = strtolower( $s['file'] );
			$map[ $key ] = isset( $nw[ $k ] ) ? $info['prefix'] . $nw[ $k ]['file'] : $new_rel;
		}
		$report['refs'] = mvkd_apply_map( $info['stem'], $map, false );
		$report['size'] = array( $new_meta['width'] ?? 0, $new_meta['height'] ?? 0, file_exists( $dir . $final . '.webp' ) ? (int) round( filesize( $dir . $final . '.webp' ) / 1024 ) : 0 );
		mvkd_add_redirect( $info['stem'], $new_rel );
	}
	global $wpdb;
	$slug = wp_unique_post_slug( $final, $id, 'inherit', 'attachment', (int) get_post_field( 'post_parent', $id ) );
	$wpdb->update( $wpdb->posts, array( 'guid' => $base['url'] . get_post_meta( $id, '_wp_attached_file', true ), 'post_name' => $slug ), array( 'ID' => $id ) ); // phpcs:ignore
	clean_post_cache( $id );
	delete_transient( 'mvkd_file_map' );
	mvkd_log( array( 'action' => 'rename', 'id' => $id, 'old' => $info['stem'], 'new' => get_post_meta( $id, '_wp_attached_file', true ), 'posts' => count( $report['refs']['posts'] ), 'css' => count( $report['refs']['css'] ) ) );
	return $report;
}

/** Verweise auf Anhang A durch Anhang B ersetzen (z. B. altes Logo im Hintergrund). Anhang A bleibt unverändert in der Mediathek. */
function mvkd_do_swap( $a ) {
	$old = (int) $a['id'];
	$new = (int) $a['to'];
	$dry = ! empty( $a['dry_run'] );
	if ( 'attachment' !== get_post_type( $old ) || 'attachment' !== get_post_type( $new ) ) {
		return new WP_Error( 'mvkd_no_attachment', 'Anhang fehlt.' );
	}
	$info = mvkd_attachment_files( $old );
	$rep  = mvkd_apply_map( $info['stem'], array( '*' => get_post_meta( $new, '_wp_attached_file', true ) ), $dry, array( $old => $new ) );
	if ( ! $dry ) {
		mvkd_log( array( 'action' => 'swap', 'id' => $old, 'to' => $new, 'posts' => count( $rep['posts'] ), 'css' => count( $rep['css'] ) ) );
	}
	return array( 'id' => $old, 'to' => $new, 'dry_run' => $dry, 'refs' => $rep );
}

function mvkd_batch( WP_REST_Request $req ) {
	$dry = (bool) $req->get_param( 'dry_run' );
	$out = array();
	foreach ( (array) $req->get_param( 'ops' ) as $op ) {
		$op['dry_run'] = $dry;
		$res           = 'swap' === ( $op['action'] ?? 'rename' ) ? mvkd_do_swap( $op ) : mvkd_do_rename( $op );
		if ( is_wp_error( $res ) ) {
			$out[] = array( 'id' => $op['id'] ?? 0, 'error' => $res->get_error_message() );
			continue;
		}
		if ( isset( $res['refs'] ) ) {
			$res['refs'] = array( 'posts' => array_keys( $res['refs']['posts'] ), 'meta' => count( $res['refs']['meta'] ), 'options' => array_keys( $res['refs']['options'] ), 'css' => array_keys( $res['refs']['css'] ) );
		}
		$out[] = $res;
	}
	if ( ! $dry ) {
		wp_cache_flush();
	}
	return array( 'dry_run' => $dry, 'count' => count( $out ), 'items' => $out );
}

/* ------------------------------------------------------------------ */
/* 3b. Bildtexte (Alt, Titel, Beschriftung, Beschreibung)              */
/* ------------------------------------------------------------------ */
function mvkd_meta( WP_REST_Request $req ) {
	$items  = (array) $req->get_param( 'items' );
	$dry    = (bool) $req->get_param( 'dry_run' );
	$backup = get_option( 'mvkd_media_meta_backup', array() );
	$out    = array();
	foreach ( $items as $it ) {
		$id = isset( $it['id'] ) ? (int) $it['id'] : 0;
		if ( 'attachment' !== get_post_type( $id ) ) {
			$out[] = array( 'id' => $id, 'error' => 'kein Anhang' );
			continue;
		}
		$before = array(
			'alt'         => (string) get_post_meta( $id, '_wp_attachment_image_alt', true ),
			'title'       => get_post_field( 'post_title', $id ),
			'caption'     => get_post_field( 'post_excerpt', $id ),
			'description' => get_post_field( 'post_content', $id ),
		);
		$after = $before;
		foreach ( array( 'alt', 'title', 'caption', 'description' ) as $k ) {
			if ( array_key_exists( $k, $it ) ) {
				$after[ $k ] = 'alt' === $k || 'title' === $k ? sanitize_text_field( $it[ $k ] ) : wp_kses_post( $it[ $k ] );
			}
		}
		$changed = array_keys( array_diff_assoc( $after, $before ) );
		$out[]   = array( 'id' => $id, 'changed' => $changed, 'after' => $after );
		if ( $dry || ! $changed ) {
			continue;
		}
		if ( ! isset( $backup[ $id ] ) ) {
			$backup[ $id ] = $before;
		}
		update_post_meta( $id, '_wp_attachment_image_alt', $after['alt'] );
		wp_update_post( array( 'ID' => $id, 'post_title' => $after['title'], 'post_excerpt' => $after['caption'], 'post_content' => $after['description'] ) );
	}
	if ( ! $dry ) {
		update_option( 'mvkd_media_meta_backup', $backup, false );
	}
	return array( 'dry_run' => $dry, 'count' => count( $out ), 'items' => $out );
}

/* ------------------------------------------------------------------ */
/* 4. Weiterleitung alter Dateiadressen                                */
/* ------------------------------------------------------------------ */
add_action( 'template_redirect', function () {
	if ( ! is_404() ) {
		return;
	}
	$path = (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$pos  = strpos( $path, '/wp-content/uploads/' );
	if ( false === $pos ) {
		return;
	}
	$rel       = rawurldecode( substr( $path, $pos + strlen( '/wp-content/uploads/' ) ) );
	$redirects = get_option( 'mvkd_media_redirects', array() );
	foreach ( $redirects as $from => $to ) {
		$re = '~^' . preg_quote( $from, '~' ) . '(' . mvkd_suffix_pattern() . '(?:\\.(?:webp|avif))?)$~i';
		if ( preg_match( $re, $rel, $m ) ) {
			$target = preg_match( '/\\.(webp|jpe?g|png|gif|avif)$/i', $to ) ? $to : $to . $m[1];
			wp_safe_redirect( mvkd_upload_base()['url'] . $target, 301, 'MVK Design' );
			exit;
		}
	}
}, 1 );

/* ------------------------------------------------------------------ */
/* REST                                                                */
/* ------------------------------------------------------------------ */
add_action( 'rest_api_init', function () {
	$admin = function () { return current_user_can( 'manage_options' ); };
	register_rest_route( 'mvk-design/v1', '/status', array(
		'methods' => 'GET', 'permission_callback' => $admin,
		'callback' => function () {
			return array( 'version' => MVKD_VERSION, 'redirects' => get_option( 'mvkd_media_redirects', array() ), 'renames' => get_option( 'mvkd_media_renames', array() ) );
		},
	) );
	register_rest_route( 'mvk-design/v1', '/media/inventory', array(
		'methods' => 'GET', 'permission_callback' => $admin, 'callback' => 'mvkd_inventory',
		'args' => array(
			'usage'  => array( 'type' => 'boolean', 'default' => true ),
			'offset' => array( 'type' => 'integer', 'default' => 0 ),
			'limit'  => array( 'type' => 'integer', 'default' => 0 ),
			'short'  => array( 'type' => 'boolean', 'default' => false ),
		),
	) );
	register_rest_route( 'mvk-design/v1', '/media/meta', array(
		'methods' => 'POST', 'permission_callback' => $admin, 'callback' => 'mvkd_meta',
		'args' => array(
			'items'   => array( 'type' => 'array', 'required' => true ),
			'dry_run' => array( 'type' => 'boolean', 'default' => true ),
		),
	) );
	register_rest_route( 'mvk-design/v1', '/media/batch', array(
		'methods' => 'POST', 'permission_callback' => $admin, 'callback' => 'mvkd_batch',
		'args' => array(
			'ops'     => array( 'type' => 'array', 'required' => true ),
			'dry_run' => array( 'type' => 'boolean', 'default' => true ),
		),
	) );
} );
