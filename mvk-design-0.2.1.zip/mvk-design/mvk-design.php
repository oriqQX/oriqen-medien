<?php
/**
 * Plugin Name: MVK Design
 * Description: Fundament für MVK Redesign v2. Modul Medien: Alt-Text-Live-Sync aus der Mediathek, Medieninventar mit Verwendungsnachweis, sicheres Umbenennen von Bilddateien mit Verweis-Ersatz und 301-Weiterleitung. Weitere Module (Designsystem, Bausteine, Katalog, Footer) folgen.
 * Version: 0.2.1
 * Author: oriqen
 * Author URI: https://oriqen.de/
 * Requires PHP: 7.4
 * Text Domain: mvk-design
 */

defined( 'ABSPATH' ) || exit;

define( 'MVKD_VERSION', '0.2.1' );
define( 'MVKD_DIR', plugin_dir_path( __FILE__ ) );
define( 'MVKD_URL', plugin_dir_url( __FILE__ ) );

require_once MVKD_DIR . 'modules/medien.php';
