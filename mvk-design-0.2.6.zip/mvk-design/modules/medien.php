<?php
/**
 * MVK Design · Modul Medien
 * 1. Alt-Live-Sync: Alt-Text aus der Mediathek gewinnt beim Ausspielen (ersetzt Code Snippet 9, erkennt zusätzlich Bilder ohne wp-image-Klasse über den Dateinamen).
 * 2. REST GET  /mvk-design/v1/media/inventory  Inventar aller Bilder mit Verwendung (Inhalte, Metafelder, Optionen, CSS-Dateien).
 * 3. REST POST /mvk-design/v1/media/rename     Datei samt Größen und WebP/AVIF umbenennen, Verweise ersetzen, alte Adresse per 301 weiterleiten.
 * 4. 301 für umbenannte Dateien (Option mvkd_media_redirects).
 */

defined( 'ABSPATH' ) || exit;

/* ------------------------------------------------------------------ */
/* Hilfen                                                              */
/* ------------------------------------------------------------------ */
function mvkd_upload_base() {
	$u = wp_get_upload_dir();
	return array( 'dir' => trailingslashit( $u['basedir'] ), 'url' => trailingslashit( $u['baseurl'] ) );
}

/** Stamm eines Anhangs relativ zu uploads, ohne Endung und ohne -scaled/-rotated, z. B. 2025/12/kueche-1 (aus der angehängten Datei, nicht aus original_image). */
function mvkd_attachment_stem( $id ) {
	$rel = (string) get_post_meta( $id, '_wp_attached_file', true );
	if ( '' === $rel ) {
		return '';
	}
	return preg_replace( '/(-scaled|-rotated)?\.[a-z0-9]+$/i', '', $rel );
}

/** Endungsteil hinter dem Stamm: Größen, -scaled/-rotated, Editor-Suffix, Endung (WebP/AVIF-Anhängsel bleiben dahinter erhalten). */
function mvkd_suffix_pattern() {
	return '(?:-e\\d{10,})?(?:-\\d+x\\d+)?(?:-scaled|-rotated)?(?:-\\d+x\\d+)?\\.(?:jpe?g|png|gif|webp|avif)';
}

/** Regex auf einen Stamm (z. B. 2025/12/name). Gruppe 1 = Ordnerteil (auch mit \\/ aus JSON), danach der Dateiname. */
function mvkd_stem_regex( $stem ) {
	$parts = explode( '/', $stem );
	$name  = array_pop( $parts );
	$dir   = '';
	foreach ( $parts as $p ) {
		$dir .= preg_quote( $p, '~' ) . '\\\\?/';
	}
	$lead = '' === $dir ? '(/)' : '(' . $dir . ')';
	return '~' . $lead . preg_quote( $name, '~' ) . '(?=' . mvkd_suffix_pattern() . ')~i';
}

/** Sucht rekursiv in Arrays/Objekten/Strings und ersetzt per Regex. */
function mvkd_deep_replace( $value, $regex, $replacement, &$count ) {
	if ( is_string( $value ) ) {
		$new = preg_replace( $regex, $replacement, $value, -1, $n );
		$count += $n;
		return $new;
	}
	if ( is_array( $value ) ) {
		foreach ( $value as $k => $v ) {
			$value[ $k ] = mvkd_deep_replace( $v, $regex, $replacement, $count );
		}
		return $value;
	}
	if ( is_object( $value ) && ! ( $value instanceof __PHP_Incomplete_Class ) ) {
		foreach ( get_object_vars( $value ) as $k => $v ) {
			$value->$k = mvkd_deep_replace( $v, $regex, $replacement, $count );
		}
	}
	return $value;
}

/** CSS-Dateien in uploads (Essential Blocks, GenerateBlocks u. a.). */
function mvkd_css_files() {
	$base  = mvkd_upload_base()['dir'];
	$files = array();
	foreach ( array( 'eb-style', 'generateblocks', 'essential-blocks', 'eb-custom-css', 'generatepress' ) as $sub ) {
		if ( ! is_dir( $base . $sub ) ) {
			continue;
		}
		$it = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $base . $sub, FilesystemIterator::SKIP_DOTS ) );
		foreach ( $it as $f ) {
			if ( preg_match( '/\.css$/i', $f->getFilename() ) ) {
				$files[] = $f->getPathname();
			}
		}
	}
	return $files;
}

/* ------------------------------------------------------------------ */
/* 1. Alt-Live-Sync                                                    */
/* ------------------------------------------------------------------ */
function mvkd_file_map() {
	$map = get_transient( 'mvkd_file_map' );
	if ( is_array( $map ) ) {
		return $map;
	}
	global $wpdb;
	$map  = array();
	$norm = function ( $f ) {
		return strtolower( preg_replace( '/(-e\d{10,})?(-\d+x\d+)?(-scaled|-rotated)?(-e\d{10,})?\.[a-z0-9]+$/i', '', basename( $f ) ) );
	};
	foreach ( $wpdb->get_results( "SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_wp_attached_file'" ) as $r ) { // phpcs:ignore
		$map[ $norm( $r->meta_value ) ] = (int) $r->post_id;
	}
	foreach ( $wpdb->get_results( "SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_wp_attachment_metadata' AND meta_value LIKE '%original_image%'" ) as $r ) { // phpcs:ignore
		$m = maybe_unserialize( $r->meta_value );
		if ( is_array( $m ) && ! empty( $m['original_image'] ) && ! isset( $map[ $norm( $m['original_image'] ) ] ) ) {
			$map[ $norm( $m['original_image'] ) ] = (int) $r->post_id;
		}
	}
	set_transient( 'mvkd_file_map', $map, DAY_IN_SECONDS );
	return $map;
}
add_action( 'add_attachment', function () { delete_transient( 'mvkd_file_map' ); } );
add_action( 'delete_attachment', function () { delete_transient( 'mvkd_file_map' ); } );
add_filter( 'wp_update_attachment_metadata', function ( $d ) { delete_transient( 'mvkd_file_map' ); return $d; } );

function mvkd_alt_live_sync( $content ) {
	if ( empty( $content ) || false === stripos( $content, '<img' ) ) {
		return $content;
	}
	return preg_replace_callback( '/<img\b[^>]*>/i', function ( $m ) {
		$img = $m[0];
		$id  = 0;
		if ( preg_match( '/wp-image-(\d+)/', $img, $mm ) ) {
			$id = (int) $mm[1];
		} elseif ( preg_match( '/\ssrc\s*=\s*["\']([^"\']+)["\']/i', $img, $mm ) && false !== strpos( $mm[1], '/wp-content/uploads/' ) ) {
			$stem = preg_replace( '/(-e\d{10,})?(-\d+x\d+)?(-scaled|-rotated)?(-e\d{10,})?\.[a-z0-9]+$/i', '', basename( wp_parse_url( $mm[1], PHP_URL_PATH ) ) );
			$map  = mvkd_file_map();
			$id   = isset( $map[ strtolower( $stem ) ] ) ? $map[ strtolower( $stem ) ] : 0;
		}
		if ( ! $id ) {
			return $img;
		}
		$alt = get_post_meta( $id, '_wp_attachment_image_alt', true );
		if ( '' === $alt || null === $alt ) {
			return $img;
		}
		$attr = 'alt="' . esc_attr( $alt ) . '"';
		if ( preg_match( '/\salt\s*=\s*("[^"]*"|\'[^\']*\')/i', $img ) ) {
			return preg_replace( '/\salt\s*=\s*("[^"]*"|\'[^\']*\')/i', ' ' . $attr, $img, 1 );
		}
		return preg_replace( '/<img\b/i', '<img ' . $attr, $img, 1 );
	}, $content );
}
add_filter( 'the_content', 'mvkd_alt_live_sync', 99 );
add_filter( 'widget_block_content', 'mvkd_alt_live_sync', 99 );

/* ------------------------------------------------------------------ */
/* 2. Inventar                                                         */
/* ------------------------------------------------------------------ */
/** Lädt einmal alle Texte, in denen Bilddateien vorkommen können. */
function mvkd_corpus() {
	global $wpdb;
	$c = array( 'posts' => array(), 'meta' => array(), 'options' => array(), 'css' => array(), 'thumbs' => array() );
	foreach ( $wpdb->get_results( "SELECT ID, post_type, post_status, post_title, post_content, post_excerpt FROM {$wpdb->posts} WHERE post_type NOT IN ('revision','attachment','nav_menu_item','customize_changeset','oembed_cache') AND post_status NOT IN ('auto-draft','trash','inherit')" ) as $r ) { // phpcs:ignore
		$c['posts'][] = $r;
	}
	foreach ( $wpdb->get_results( "SELECT post_id, meta_key, meta_value FROM {$wpdb->postmeta} WHERE meta_key NOT IN ('_wp_attached_file','_wp_attachment_metadata','_wp_attachment_backup_sizes') AND meta_value LIKE '%uploads%'" ) as $r ) { // phpcs:ignore
		$c['meta'][] = $r;
	}
	foreach ( $wpdb->get_results( "SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_thumbnail_id'" ) as $r ) { // phpcs:ignore
		$c['thumbs'][ (int) $r->meta_value ][] = (int) $r->post_id;
	}
	foreach ( $wpdb->get_results( "SELECT option_name, option_value FROM {$wpdb->options} WHERE option_name NOT LIKE '\\_%transient%' AND option_name NOT LIKE 'mvkd\\_%' AND option_value LIKE '%uploads%'" ) as $r ) { // phpcs:ignore
		$c['options'][] = $r;
	}
	$base = mvkd_upload_base()['dir'];
	foreach ( mvkd_css_files() as $f ) {
		$c['css'][ substr( $f, strlen( $base ) ) ] = (string) file_get_contents( $f ); // phpcs:ignore
	}
	return $c;
}

function mvkd_usage( $id, $stem, $c ) {
	$regex = mvkd_stem_regex( $stem );
	$name  = basename( $stem );
	$u     = array( 'posts' => array(), 'meta' => array(), 'options' => array(), 'css' => array() );
	foreach ( $c['posts'] as $r ) {
		$hit = ( false !== stripos( $r->post_content, $name ) && preg_match( $regex, $r->post_content ) )
			|| preg_match( '/wp-image-' . (int) $id . '\b|"id":' . (int) $id . '\b/', $r->post_content );
		if ( $hit ) {
			$u['posts'][] = array( 'id' => (int) $r->ID, 'type' => $r->post_type, 'status' => $r->post_status, 'title' => $r->post_title );
		}
	}
	foreach ( $c['meta'] as $r ) {
		if ( (int) $r->post_id !== (int) $id && false !== stripos( $r->meta_value, $name ) && preg_match( $regex, $r->meta_value ) ) {
			$u['meta'][] = array( 'post_id' => (int) $r->post_id, 'key' => $r->meta_key );
		}
	}
	if ( isset( $c['thumbs'][ $id ] ) ) {
		foreach ( $c['thumbs'][ $id ] as $p ) {
			$u['meta'][] = array( 'post_id' => $p, 'key' => '_thumbnail_id' );
		}
	}
	foreach ( $c['options'] as $r ) {
		if ( false !== stripos( $r->option_value, $name ) && preg_match( $regex, $r->option_value ) ) {
			$u['options'][] = $r->option_name;
		}
	}
	foreach ( $c['css'] as $f => $css ) {
		if ( false !== stripos( $css, $name ) && preg_match( $regex, $css ) ) {
			$u['css'][] = $f;
		}
	}
	return $u;
}

function mvkd_inventory( WP_REST_Request $req ) {
	$base   = mvkd_upload_base();
	$usage  = (bool) $req->get_param( 'usage' );
	$offset = max( 0, (int) $req->get_param( 'offset' ) );
	$limit  = (int) $req->get_param( 'limit' );
	$short  = (bool) $req->get_param( 'short' );
	$ids    = get_posts( array( 'post_type' => 'attachment', 'post_status' => 'inherit', 'post_mime_type' => 'image', 'posts_per_page' => -1, 'fields' => 'ids', 'orderby' => 'ID', 'order' => 'ASC' ) );
	$total  = count( $ids );
	$ids    = array_slice( $ids, $offset, $limit > 0 ? $limit : null );
	$corpus = $usage ? mvkd_corpus() : null;
	$out    = array();
	foreach ( $ids as $id ) {
		$rel  = (string) get_post_meta( $id, '_wp_attached_file', true );
		$meta = wp_get_attachment_metadata( $id );
		$stem = mvkd_attachment_stem( $id );
		$path = $base['dir'] . $rel;
		$row  = array(
			'id'     => $id,
			'file'   => $rel,
			'w'      => is_array( $meta ) && isset( $meta['width'] ) ? (int) $meta['width'] : 0,
			'h'      => is_array( $meta ) && isset( $meta['height'] ) ? (int) $meta['height'] : 0,
			'kb'     => file_exists( $path ) ? (int) round( filesize( $path ) / 1024 ) : -1,
			'date'   => substr( get_post_field( 'post_date', $id ), 0, 10 ),
			'parent' => (int) get_post_field( 'post_parent', $id ),
			'alt'    => (string) get_post_meta( $id, '_wp_attachment_image_alt', true ),
			'title'  => get_post_field( 'post_title', $id ),
		);
		if ( is_array( $meta ) && ! empty( $meta['original_image'] ) && preg_replace( '/\\.[a-z0-9]+$/i', '', $meta['original_image'] ) !== basename( $stem ) ) {
			$row['orig'] = $meta['original_image'];
		}
		if ( ! $short ) {
			$row['caption']     = get_post_field( 'post_excerpt', $id );
			$row['description'] = get_post_field( 'post_content', $id );
			$row['sizes']       = is_array( $meta ) && ! empty( $meta['sizes'] ) ? count( $meta['sizes'] ) : 0;
			$row['webp']        = file_exists( $path . '.webp' ) || file_exists( preg_replace( '/\.[a-z0-9]+$/i', '.webp', $path ) );
		}
		if ( $usage && $stem ) {
			$row['usage'] = mvkd_usage( $id, $stem, $corpus );
		}
		$out[] = $row;
	}
	return array( 'version' => MVKD_VERSION, 'total' => $total, 'offset' => $offset, 'count' => count( $out ), 'items' => $out );
}

/* ------------------------------------------------------------------ */
/* 3. Umbenennen, in WebP wandeln, tauschen                            */
/* ------------------------------------------------------------------ */

/** Alle Dateien eines Anhangs: angehängte Datei, original_image, Größen, WebP/AVIF-Geschwister, Imagify-Sicherungen. Mehrere Stämme möglich (z. B. nach Umbenennen durch andere Plugins). */
function mvkd_attachment_files( $id ) {
	$base   = mvkd_upload_base();
	$rel    = (string) get_post_meta( $id, '_wp_attached_file', true );
	$meta   = wp_get_attachment_metadata( $id );
	$sub    = dirname( $rel );
	$prefix = ( '.' === $sub || '' === $sub ) ? '' : $sub . '/';
	$name   = preg_replace( '/(-scaled|-rotated)?\.[a-z0-9]+$/i', '', basename( $rel ) );
	$names  = array( $name );
	$list   = array( basename( $rel ) );
	if ( is_array( $meta ) ) {
		if ( ! empty( $meta['original_image'] ) ) {
			$list[] = $meta['original_image'];
			$on     = preg_replace( '/\.[a-z0-9]+$/i', '', $meta['original_image'] );
			if ( $on !== $name ) {
				$names[] = $on;
			}
		}
		foreach ( (array) ( $meta['sizes'] ?? array() ) as $sz ) {
			$list[] = $sz['file'];
		}
	}
	// Mit dem WordPress-Bildeditor bearbeitete Bilder: Name ohne -e123 und Sicherungsgrößen gehören dazu
	$edit_base = '';
	if ( preg_match( '/^(.+)-e\d{10,}$/', $name, $em ) ) {
		$names[]   = $em[1];
		$edit_base = $em[1];
	}
	foreach ( (array) get_post_meta( $id, '_wp_attachment_backup_sizes', true ) as $bs ) {
		if ( is_array( $bs ) && ! empty( $bs['file'] ) ) {
			$list[] = $bs['file'];
		}
	}
	$names = array_values( array_unique( $names ) );
	$set = array();
	foreach ( array( '', 'backup/' ) as $d ) {
		foreach ( $list as $n ) {
			foreach ( array( $n, $n . '.webp', $n . '.avif', preg_replace( '/\.[a-z0-9]+$/i', '.webp', $n ), preg_replace( '/\.[a-z0-9]+$/i', '.avif', $n ) ) as $c ) {
				if ( file_exists( $base['dir'] . $d . $prefix . $c ) ) {
					$set[ $d . $prefix . $c ] = $d . $prefix;
				}
			}
		}
		foreach ( $names as $nm ) {
			$re = '~^' . preg_quote( $nm, '~' ) . mvkd_suffix_pattern() . '(?:\.(?:webp|avif))?$~i';
			foreach ( (array) glob( $base['dir'] . $d . $prefix . $nm . '*' ) as $f ) {
				if ( preg_match( $re, basename( $f ) ) ) {
					$set[ $d . $prefix . basename( $f ) ] = $d . $prefix;
				}
			}
		}
	}
	usort( $names, function ( $x, $y ) { return strlen( $y ) - strlen( $x ); } );
	$files = array();
	foreach ( $set as $r => $d ) {
		$bn   = basename( $r );
		$stem = '';
		foreach ( $names as $nm ) {
			if ( 0 === stripos( $bn, $nm ) ) {
				$stem = $nm;
				break;
			}
		}
		$files[] = array( 'rel' => $r, 'dir' => $d, 'stem' => $stem, 'suffix' => substr( $bn, strlen( $stem ) ), 'tag' => ( '' !== $edit_base && $stem === $edit_base ) ? '-orig' : '' );
	}
	$stems = array();
	foreach ( $names as $nm ) {
		$stems[] = $prefix . $nm;
	}
	return array( 'stem' => $prefix . $name, 'prefix' => $prefix, 'name' => $name, 'stems' => $stems, 'files' => $files );
}

/**
 * Ersetzt Verweise auf Dateien eines alten Stamms in Inhalten, Metafeldern, Optionen und CSS-Dateien.
 * $map: alter Dateiname (basename, klein) => neuer Pfad relativ zu uploads; '*' als Rückfall.
 * $ids: optional array( alt_id => neu_id ) für ID-Verweise in Beitragsinhalten mit Treffer.
 */
function mvkd_apply_map( $old_stem, $map, $dry, $ids = array() ) {
	global $wpdb;
	$base   = mvkd_upload_base();
	$parts  = explode( '/', $old_stem );
	$name   = array_pop( $parts );
	$dirpat = '';
	foreach ( $parts as $p ) {
		$dirpat .= preg_quote( $p, '~' ) . '\\\\?/';
	}
	// Gruppe 1: Pfad bis uploads/ (optional mit Domain), Gruppe 2: Dateiname
	$regex = '~((?:https?:\\\\?/\\\\?/[^"\'\s()<>]*?)?wp-content\\\\?/uploads\\\\?/)?' . $dirpat . '(' . preg_quote( $name, '~' ) . mvkd_suffix_pattern() . ')(\.(?:webp|avif))?(?![\w-])~i';
	$cb    = function ( $m ) use ( $map, $base ) {
		$key = strtolower( $m[2] );
		$new = isset( $map[ $key ] ) ? $map[ $key ] : $map['*'];
		$esc = false !== strpos( $m[0], '\\/' );
		return $m[1] . ( $esc ? str_replace( '/', '\\/', $new ) : $new );
	};
	$id_regex = array();
	foreach ( $ids as $old_id => $new_id ) {
		$id_regex[ '~(wp-image-|"(?:id|mediaId|imageId|imageID|ImageID|ImageId|backgroundImageID|bgImageID)":)' . (int) $old_id . '(?!\d)~' ] = '${1}' . (int) $new_id;
	}
	$like = '%' . $wpdb->esc_like( $name ) . '%';
	$rep  = array( 'posts' => array(), 'meta' => array(), 'options' => array(), 'css' => array() );

	foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT ID, post_content, post_excerpt FROM {$wpdb->posts} WHERE post_type <> 'revision' AND (post_content LIKE %s OR post_excerpt LIKE %s)", $like, $like ) ) as $r ) { // phpcs:ignore
		$pc = preg_replace_callback( $regex, $cb, $r->post_content, -1, $a );
		$pe = preg_replace_callback( $regex, $cb, $r->post_excerpt, -1, $b );
		if ( $a + $b ) {
			foreach ( $id_regex as $re => $to ) {
				$pc = preg_replace( $re, $to, $pc );
			}
			$rep['posts'][ $r->ID ] = $a + $b;
			if ( ! $dry ) {
				$wpdb->update( $wpdb->posts, array( 'post_content' => $pc, 'post_excerpt' => $pe ), array( 'ID' => $r->ID ) ); // phpcs:ignore
				clean_post_cache( $r->ID );
			}
		}
	}
	foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT meta_id, post_id, meta_key, meta_value FROM {$wpdb->postmeta} WHERE meta_key NOT IN ('_wp_attached_file','_wp_attachment_metadata','_wp_attachment_backup_sizes') AND meta_value LIKE %s", $like ) ) as $r ) { // phpcs:ignore
		$n   = 0;
		$new = mvkd_deep_replace_cb( maybe_unserialize( $r->meta_value ), $regex, $cb, $n );
		if ( $n ) {
			$rep['meta'][] = array( 'post_id' => (int) $r->post_id, 'key' => $r->meta_key, 'n' => $n );
			if ( ! $dry ) {
				$wpdb->update( $wpdb->postmeta, array( 'meta_value' => maybe_serialize( $new ) ), array( 'meta_id' => $r->meta_id ) ); // phpcs:ignore
				wp_cache_delete( (int) $r->post_id, 'post_meta' );
			}
		}
	}
	foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT option_name, option_value FROM {$wpdb->options} WHERE option_name NOT LIKE %s AND option_name NOT LIKE %s AND option_name NOT LIKE %s AND option_value LIKE %s", '\_transient%', '\_site\_transient%', 'mvkd\_%', $like ) ) as $r ) { // phpcs:ignore
		$n   = 0;
		$new = mvkd_deep_replace_cb( maybe_unserialize( $r->option_value ), $regex, $cb, $n );
		if ( $n ) {
			$rep['options'][ $r->option_name ] = $n;
			if ( ! $dry ) {
				$wpdb->update( $wpdb->options, array( 'option_value' => maybe_serialize( $new ) ), array( 'option_name' => $r->option_name ) ); // phpcs:ignore
				wp_cache_delete( $r->option_name, 'options' );
			}
		}
	}
	foreach ( mvkd_css_files() as $f ) {
		$c  = (string) file_get_contents( $f ); // phpcs:ignore
		$nc = preg_replace_callback( $regex, $cb, $c, -1, $n );
		if ( $n ) {
			$rep['css'][ substr( $f, strlen( $base['dir'] ) ) ] = $n;
			if ( ! $dry ) {
				if ( ! file_exists( $f . '.mvkbak' ) ) {
					copy( $f, $f . '.mvkbak' );
				}
				file_put_contents( $f, $nc ); // phpcs:ignore
			}
		}
	}
	return $rep;
}

function mvkd_apply_map_all( $stems, $map, $dry, $ids = array() ) {
	$all = array( 'posts' => array(), 'meta' => array(), 'options' => array(), 'css' => array() );
	foreach ( $stems as $st ) {
		$r = mvkd_apply_map( $st, $map, $dry, $ids );
		foreach ( $r['posts'] as $k => $v ) {
			$all['posts'][ $k ] = ( $all['posts'][ $k ] ?? 0 ) + $v;
		}
		$all['meta']    = array_merge( $all['meta'], $r['meta'] );
		$all['options'] = array_merge( $all['options'], $r['options'] );
		$all['css']     = array_merge( $all['css'], $r['css'] );
	}
	return $all;
}

function mvkd_deep_replace_cb( $value, $regex, $cb, &$count ) {
	if ( is_string( $value ) ) {
		$new = preg_replace_callback( $regex, $cb, $value, -1, $n );
		$count += $n;
		return $new;
	}
	if ( is_array( $value ) ) {
		foreach ( $value as $k => $v ) {
			$value[ $k ] = mvkd_deep_replace_cb( $v, $regex, $cb, $count );
		}
		return $value;
	}
	if ( is_object( $value ) && ! ( $value instanceof __PHP_Incomplete_Class ) ) {
		foreach ( get_object_vars( $value ) as $k => $v ) {
			$value->$k = mvkd_deep_replace_cb( $v, $regex, $cb, $count );
		}
	}
	return $value;
}

/** Weiterleitung alter Dateistamm => neues Ziel (relativ zu uploads; Ziel ohne Endung = gleiche Endung, mit Endung = feste Datei). */
function mvkd_add_redirect( $old_stem, $target ) {
	$r = get_option( 'mvkd_media_redirects', array() );
	foreach ( $r as $from => $to ) {
		if ( $to === $old_stem ) {
			$r[ $from ] = $target;
		}
	}
	unset( $r[ preg_replace( '/\.[a-z0-9]+$/i', '', $target ) ] );
	$r[ $old_stem ] = $target;
	update_option( 'mvkd_media_redirects', $r, false );
}

function mvkd_log( $entry ) {
	$log   = get_option( 'mvkd_media_renames', array() );
	$log[] = array_merge( array( 'time' => current_time( 'mysql' ) ), $entry );
	update_option( 'mvkd_media_renames', $log, false );
}

/**
 * Umbenennen (und optional in WebP wandeln) bei gleicher Anhang-ID.
 * $a: id, new_stem, webp (bool), max (int, längste Kante Breite), dry_run
 */
function mvkd_do_rename( $a ) {
	$id   = (int) $a['id'];
	$dry  = ! empty( $a['dry_run'] );
	$webp = ! empty( $a['webp'] );
	$max  = isset( $a['max'] ) ? (int) $a['max'] : 0;
	if ( 'attachment' !== get_post_type( $id ) ) {
		return new WP_Error( 'mvkd_no_attachment', 'Kein Anhang: ' . $id );
	}
	$base  = mvkd_upload_base();
	$info  = mvkd_attachment_files( $id );
	$meta  = wp_get_attachment_metadata( $id );
	$rel   = (string) get_post_meta( $id, '_wp_attached_file', true );
	$want  = sanitize_title( remove_accents( preg_replace( '/\.[a-z0-9]+$/i', '', basename( (string) $a['new_stem'] ) ) ) );
	if ( '' === $want ) {
		return new WP_Error( 'mvkd_bad_name', 'Neuer Name fehlt: ' . $id );
	}
	$is_webp = (bool) preg_match( '/\.webp$/i', $rel );
	if ( $want === $info['name'] && ( ! $webp || $is_webp ) ) {
		return array( 'id' => $id, 'skip' => 'Name unverändert' );
	}
	$dir   = $base['dir'] . $info['prefix'];
	$final = $want;
	$i     = 2;
	while ( $final !== $info['name'] && ( glob( $dir . $final . '.*' ) || glob( $dir . $final . '-*x*.*' ) || glob( $dir . $final . '-scaled.*' ) ) ) {
		$final = $want . '-' . $i++;
	}
	$new_stem = $info['prefix'] . $final;
	$report   = array( 'id' => $id, 'old' => $info['stem'], 'new' => $new_stem, 'webp' => $webp && ! $is_webp, 'files' => count( $info['files'] ), 'dry_run' => $dry );

	if ( ! $webp || $is_webp ) {
		// Reines Umbenennen: Dateiname je Größe gleich, nur Stamm neu
		$map   = array();
		$strip = '/(\\.(?:jpe?g|png|gif))\\.(?:webp|avif)$/i';
		foreach ( $info['files'] as $f ) {
			if ( '' === $f['stem'] ) {
				continue;
			}
			$map[ strtolower( preg_replace( $strip, '$1', basename( $f['rel'] ) ) ) ] = $info['prefix'] . $final . $f['tag'] . preg_replace( $strip, '$1', $f['suffix'] );
		}
		$map['*'] = $info['prefix'] . $final . preg_replace( '/^.*?((-scaled|-rotated)?\\.[a-z0-9]+)$/i', '$1', basename( $rel ) );
		$report['refs'] = mvkd_apply_map_all( $info['stems'], $map, $dry );
		if ( $dry ) {
			return $report;
		}
		foreach ( $info['files'] as $f ) {
			if ( '' === $f['stem'] ) {
				continue;
			}
			$to = $f['dir'] . $final . $f['tag'] . $f['suffix'];
			if ( ! @rename( $base['dir'] . $f['rel'], $base['dir'] . $to ) ) { // phpcs:ignore
				$report['errors'][] = 'mv ' . $f['rel'];
			}
		}
		$swap    = function ( $file ) use ( $info, $final ) {
			foreach ( $info['stems'] as $st ) {
				$nm = basename( $st );
				if ( 0 === stripos( $file, $nm ) ) {
					return $final . substr( $file, strlen( $nm ) );
				}
			}
			return $file;
		};
		$new_rel = $info['prefix'] . $swap( basename( $rel ) );
		update_post_meta( $id, '_wp_attached_file', $new_rel );
		if ( is_array( $meta ) ) {
			$meta['file'] = $new_rel;
			if ( ! empty( $meta['original_image'] ) ) {
				$meta['original_image'] = $swap( $meta['original_image'] );
			}
			if ( ! empty( $meta['sizes'] ) ) {
				foreach ( $meta['sizes'] as $k => $sz ) {
					$meta['sizes'][ $k ]['file'] = $swap( $sz['file'] );
				}
			}
			wp_update_attachment_metadata( $id, $meta );
		}
		foreach ( $info['stems'] as $st ) {
			mvkd_add_redirect( $st, $new_stem );
		}
	} else {
		// In WebP wandeln: aus dem Original neu erzeugen, alte Dateien ins Archiv
		$edited = (bool) preg_match( '/-e\\d{10,}\\.[a-z0-9]+$/i', basename( $rel ) );
		$src    = $base['dir'] . $info['prefix'] . ( ! $edited && is_array( $meta ) && ! empty( $meta['original_image'] ) ? $meta['original_image'] : basename( $rel ) );
		if ( ! file_exists( $src ) ) {
			$src = $base['dir'] . $rel;
		}
		if ( ! empty( $a['src'] ) ) {
			$src = mvkd_safe_upload_path( $a['src'] );
			if ( ! $src ) {
				return new WP_Error( 'mvkd_src', 'Quelle nicht gefunden: ' . $a['src'] );
			}
		}
		$old_sizes = is_array( $meta ) && ! empty( $meta['sizes'] ) ? $meta['sizes'] : array();
		$ow        = is_array( $meta ) && isset( $meta['width'] ) ? (int) $meta['width'] : 0;
		$report['src'] = basename( $src );
		$report['to']  = $final . '.webp' . ( $max && $ow > $max ? ' (' . $max . ' px)' : '' );
		if ( $dry ) {
			$report['refs'] = mvkd_apply_map_all( $info['stems'], array( '*' => $new_stem . '.webp' ), true );
			return $report;
		}
		$q   = isset( $a['quality'] ) ? max( 60, min( 100, (int) $a['quality'] ) ) : 90; // Qualität vor Größe, Imagify fasst die WebP nicht verlustbehaftet an
		$tmp = $dir . $final . '-mvktmp.webp';
		$mk  = mvkd_make_webp( $src, $tmp, $max, $q );
		if ( is_wp_error( $mk ) ) {
			return $mk;
		}
		if ( ! @rename( $tmp, $dir . $final . '.webp' ) ) { // phpcs:ignore
			@unlink( $tmp ); // phpcs:ignore
			return new WP_Error( 'mvkd_mv', 'WebP konnte nicht abgelegt werden: ' . $id );
		}
		$report['engine'] = $mk['engine'];
		// alte Dateien ins Archiv (nicht verlinkt, nichts gelöscht)
		$arch = $base['dir'] . '_mvk-archiv/' . $info['prefix'];
		wp_mkdir_p( $arch );
		foreach ( $info['files'] as $f ) {
			$to = $base['dir'] . '_mvk-archiv/' . $f['rel'];
			wp_mkdir_p( dirname( $to ) );
			if ( ! @rename( $base['dir'] . $f['rel'], $to ) ) { // phpcs:ignore
				$report['errors'][] = 'archiv ' . $f['rel'];
			}
		}
		$new_rel = $info['prefix'] . $final . '.webp';
		update_post_meta( $id, '_wp_attached_file', $new_rel );
		global $wpdb;
		$wpdb->update( $wpdb->posts, array( 'post_mime_type' => 'image/webp' ), array( 'ID' => $id ) ); // phpcs:ignore
		clean_post_cache( $id );
		if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) {
			require_once ABSPATH . 'wp-admin/includes/image.php';
		}
		$qf = function () use ( $q ) { return $q; };
		add_filter( 'wp_editor_set_quality', $qf, 99 );
		mvkd_editor_hook( true, $q );
		$new_meta = wp_generate_attachment_metadata( $id, $dir . $final . '.webp' );
		mvkd_editor_hook( false, $q );
		remove_filter( 'wp_editor_set_quality', $qf, 99 );
		wp_update_attachment_metadata( $id, $new_meta );
		// Zuordnung alte Größe => neue Größe über den Größennamen
		$map = array( '*' => $new_rel );
		$nw  = isset( $new_meta['sizes'] ) ? $new_meta['sizes'] : array();
		foreach ( $old_sizes as $k => $s ) {
			$key = strtolower( $s['file'] );
			$map[ $key ] = isset( $nw[ $k ] ) ? $info['prefix'] . $nw[ $k ]['file'] : $new_rel;
		}
		$report['refs'] = mvkd_apply_map_all( $info['stems'], $map, false );
		$report['size'] = array( $new_meta['width'] ?? 0, $new_meta['height'] ?? 0, file_exists( $dir . $final . '.webp' ) ? (int) round( filesize( $dir . $final . '.webp' ) / 1024 ) : 0 );
		foreach ( $info['stems'] as $st ) {
			mvkd_add_redirect( $st, $new_rel );
		}
		$report['q'] = $q;
	}
	global $wpdb;
	$slug = wp_unique_post_slug( $final, $id, 'inherit', 'attachment', (int) get_post_field( 'post_parent', $id ) );
	$wpdb->update( $wpdb->posts, array( 'guid' => $base['url'] . get_post_meta( $id, '_wp_attached_file', true ), 'post_name' => $slug ), array( 'ID' => $id ) ); // phpcs:ignore
	clean_post_cache( $id );
	delete_transient( 'mvkd_file_map' );
	mvkd_log( array( 'action' => 'rename', 'id' => $id, 'old' => $info['stem'], 'new' => get_post_meta( $id, '_wp_attached_file', true ), 'posts' => count( $report['refs']['posts'] ), 'css' => count( $report['refs']['css'] ) ) );
	return $report;
}

/* ------------------------------------------------------------------ */
/* WebP sicher erzeugen (0.2.6)                                        */
/* Imagick zuerst: Farbraum (CMYK), EXIF-Drehung, Lanczos, ICC bleibt. */
/* Ergebnis wird geprüft: Breite, nicht einfarbig. Sonst Abbruch.      */
/* ------------------------------------------------------------------ */
function mvkd_safe_upload_path( $rel ) {
	$base = mvkd_upload_base();
	$rel  = ltrim( str_replace( '\\', '/', (string) $rel ), '/' );
	if ( '' === $rel || false !== strpos( $rel, '..' ) ) {
		return false;
	}
	$full = realpath( $base['dir'] . $rel );
	$root = realpath( $base['dir'] );
	return ( $full && $root && 0 === strpos( $full, $root ) && is_file( $full ) ) ? $full : false;
}

function mvkd_webp_defaults( $opt = array() ) {
	// Feinabstimmung gegen das Original gemessen (siehe Medienplan): Textur und Kanten bleiben
	$t = get_option( 'mvkd_webp_tuning', array() );
	return array_merge( array( 'filter' => 20, 'sns' => 50, 'sharp_yuv' => true, 'lossless' => false, 'near' => 0 ), is_array( $t ) ? $t : array(), (array) $opt );
}

/** Setzt die WebP-Encoder-Optionen auf ein Imagick-Objekt. */
function mvkd_webp_apply( $im, $q, $opt ) {
	$o = mvkd_webp_defaults( $opt );
	$im->setImageFormat( 'webp' );
	$im->setImageCompressionQuality( (int) $q );
	$im->setOption( 'webp:method', '6' );
	$im->setOption( 'webp:alpha-quality', '100' );
	if ( $o['lossless'] ) {
		$im->setOption( 'webp:lossless', 'true' );
		if ( $o['near'] ) {
			$im->setOption( 'webp:near-lossless', (string) (int) $o['near'] );
		}
		return;
	}
	$im->setOption( 'webp:lossless', 'false' );
	$im->setOption( 'webp:filter-strength', (string) (int) $o['filter'] );
	$im->setOption( 'webp:sns-strength', (string) (int) $o['sns'] );
	$im->setOption( 'webp:use-sharp-yuv', $o['sharp_yuv'] ? 'true' : 'false' );
}

function mvkd_make_webp( $src, $dest, $max, $q, $opt = array() ) {
	$engine  = '';
	$resized = false;
	$err     = '';
	$color   = '';
	if ( class_exists( 'Imagick' ) ) {
		try {
			$im   = new Imagick();
			$info = @getimagesize( $src ); // phpcs:ignore
			if ( $max && $info && 'image/jpeg' === $info['mime'] && max( $info[0], $info[1] ) > 2 * $max ) {
				// JPEG gleich verkleinert dekodieren: spart Speicher, bleibt deutlich über der Zielgröße
				$im->setOption( 'jpeg:size', ( 2 * $max ) . 'x' . ( 2 * $max ) );
			}
			$im->readImage( $src );
			$im->setIteratorIndex( 0 );
			switch ( $im->getImageOrientation() ) {
				case Imagick::ORIENTATION_TOPRIGHT: $im->flopImage(); break;
				case Imagick::ORIENTATION_BOTTOMRIGHT: $im->rotateImage( '#000', 180 ); break;
				case Imagick::ORIENTATION_BOTTOMLEFT: $im->flipImage(); break;
				case Imagick::ORIENTATION_LEFTTOP: $im->transposeImage(); break;
				case Imagick::ORIENTATION_RIGHTTOP: $im->rotateImage( '#000', 90 ); break;
				case Imagick::ORIENTATION_RIGHTBOTTOM: $im->transverseImage(); break;
				case Imagick::ORIENTATION_LEFTBOTTOM: $im->rotateImage( '#000', -90 ); break;
			}
			$im->setImageOrientation( Imagick::ORIENTATION_TOPLEFT );
			$icc = '';
			try {
				$icc = $im->getImageProfile( 'icc' );
			} catch ( Exception $e ) {
				$icc = '';
			}
			$srgb = (string) @file_get_contents( __DIR__ . '/srgb.icc' ); // phpcs:ignore
			if ( $icc && $srgb ) {
				// eingebettetes Profil (Display P3, Adobe RGB, CMYK ...) farbtreu nach sRGB umrechnen
				try {
					$im->profileImage( 'icc', $srgb );
					$color = 'icc>srgb';
				} catch ( Exception $e ) {
					$color = 'icc-fehler';
				}
			}
			if ( in_array( $im->getImageColorspace(), array( Imagick::COLORSPACE_CMYK, Imagick::COLORSPACE_GRAY ), true ) ) {
				$im->transformImageColorspace( Imagick::COLORSPACE_SRGB );
				$color = ( $color ? $color . '+' : '' ) . 'srgb';
			}
			$w = $im->getImageWidth();
			$h = $im->getImageHeight();
			if ( $max && $w > $max ) {
				$nh = (int) round( $h * $max / $w );
				$im->resizeImage( $max, $nh, Imagick::FILTER_LANCZOS, 1 );
				$im->unsharpMaskImage( 0.25, 0.25, 8, 0.065 ); // wie WordPress beim Verkleinern
				$resized = true;
			}
			$im->stripImage();
			$enc = mvkd_webp_encoder( $opt );
			if ( 'gd' === $enc ) {
				$gw = mvkd_gd_write( $im, $dest, $q );
				if ( is_wp_error( $gw ) ) {
					throw new Exception( $gw->get_error_message() );
				}
			} else {
				if ( $icc && $srgb ) {
					$im->profileImage( 'icc', $srgb );
				}
				mvkd_webp_apply( $im, $q, $opt );
				$im->writeImage( 'webp:' . $dest );
			}
			$im->clear();
			$engine = 'imagick>' . $enc;
		} catch ( Exception $e ) {
			$err = $e->getMessage();
			@unlink( $dest ); // phpcs:ignore
		}
	}
	if ( '' === $engine ) {
		$ed = wp_get_image_editor( $src );
		if ( is_wp_error( $ed ) ) {
			return new WP_Error( 'mvkd_editor', 'Kein Bildeditor: ' . $ed->get_error_message() . ( $err ? ' / ' . $err : '' ) );
		}
		$sz = $ed->get_size();
		if ( $max && $sz['width'] > $max ) {
			$r = $ed->resize( $max, null, false );
			if ( is_wp_error( $r ) ) {
				return new WP_Error( 'mvkd_resize', 'Verkleinern fehlgeschlagen: ' . $r->get_error_message() . ( $err ? ' / ' . $err : '' ) );
			}
			$resized = true;
		}
		$ed->set_quality( $q );
		$saved = $ed->save( $dest, 'image/webp' );
		if ( is_wp_error( $saved ) ) {
			return $saved;
		}
		$engine = 'wp:' . get_class( $ed );
	}
	$chk = mvkd_webp_check( $dest, $max );
	if ( is_wp_error( $chk ) ) {
		@unlink( $dest ); // phpcs:ignore
		return $chk;
	}
	$chk['engine']  = $engine . ( $color ? ' ' . $color : '' ) . ( $err ? ' (imagick: ' . $err . ')' : '' );
	$chk['resized'] = $resized;
	return $chk;
}

/** Hält Imagick die WebP-Qualität ein? Manche ImageMagick-6-Builds ignorieren sie und schreiben immer q75. */
function mvkd_imagick_q_ok() {
	static $ok = null;
	if ( null !== $ok ) {
		return $ok;
	}
	if ( ! class_exists( 'Imagick' ) ) {
		return $ok = false;
	}
	$key = 'mvkd_imq_' . md5( Imagick::getVersion()['versionString'] ?? '' );
	$c   = get_transient( $key );
	if ( false !== $c ) {
		return $ok = ( 'y' === $c );
	}
	try {
		$t = new Imagick();
		$t->newPseudoImage( 256, 256, 'plasma:fractal' );
		$t->setImageFormat( 'webp' );
		$t->setImageCompressionQuality( 30 );
		$a = strlen( $t->getImagesBlob() );
		$t->setImageCompressionQuality( 95 );
		$b = strlen( $t->getImagesBlob() );
		$t->clear();
		$ok = $b > $a * 1.3;
	} catch ( Exception $e ) {
		$ok = false;
	}
	set_transient( $key, $ok ? 'y' : 'n', DAY_IN_SECONDS );
	return $ok;
}

/** Welcher Encoder schreibt das WebP: Imagick (wenn Qualität greift) oder GD (hält die Qualität immer ein). */
function mvkd_webp_encoder( $opt = array() ) {
	if ( ! empty( $opt['enc'] ) && in_array( $opt['enc'], array( 'gd', 'imagick' ), true ) ) {
		return $opt['enc'];
	}
	if ( ! empty( $opt['lossless'] ) || ! function_exists( 'imagewebp' ) ) {
		return 'imagick';
	}
	return mvkd_imagick_q_ok() ? 'imagick' : 'gd';
}

/** Fertig bearbeitetes Imagick-Bild verlustfrei an GD übergeben und dort als WebP mit echter Qualität speichern. */
function mvkd_gd_write( $im, $dest, $q ) {
	if ( ! function_exists( 'imagewebp' ) ) {
		return new WP_Error( 'mvkd_gd', 'GD ohne WebP.' );
	}
	$c = clone $im;
	$c->stripImage();
	$c->setImageDepth( 8 );
	$c->setImageFormat( 'png32' );
	$blob = $c->getImageBlob();
	$c->clear();
	$g = @imagecreatefromstring( $blob ); // phpcs:ignore
	unset( $blob );
	if ( ! $g ) {
		return new WP_Error( 'mvkd_gd', 'GD konnte das Bild nicht übernehmen.' );
	}
	if ( ! imageistruecolor( $g ) ) {
		imagepalettetotruecolor( $g );
	}
	imagealphablending( $g, false );
	imagesavealpha( $g, true );
	$ok = imagewebp( $g, $dest, max( 1, min( 100, (int) $q ) ) );
	imagedestroy( $g );
	return $ok && file_exists( $dest ) ? true : new WP_Error( 'mvkd_gd', 'GD konnte das WebP nicht schreiben.' );
}

/** Prüft das Ergebnis: Datei da, Breite eingehalten, Bild nicht einfarbig (z. B. schwarz). */
function mvkd_webp_check( $file, $max ) {
	clearstatcache( true, $file );
	$info = @getimagesize( $file ); // phpcs:ignore
	if ( ! $info || 'image/webp' !== $info['mime'] ) {
		return new WP_Error( 'mvkd_check', 'Ergebnis ist kein gültiges WebP.' );
	}
	if ( $max && $info[0] > $max ) {
		return new WP_Error( 'mvkd_check', 'Ergebnis zu breit: ' . $info[0] . ' px.' );
	}
	$sd = null;
	if ( class_exists( 'Imagick' ) ) {
		try {
			$c = new Imagick( $file );
			$c->scaleImage( 64, 0 );
			$c->transformImageColorspace( Imagick::COLORSPACE_GRAY );
			$m  = $c->getImageChannelMean( Imagick::CHANNEL_GRAY );
			$qr = Imagick::getQuantumRange();
			$sd = $m['standardDeviation'] / max( 1, (float) $qr['quantumRangeLong'] );
			$c->clear();
		} catch ( Exception $e ) {
			$sd = null;
		}
	}
	if ( null === $sd && function_exists( 'imagecreatefromwebp' ) ) {
		$g = @imagecreatefromwebp( $file ); // phpcs:ignore
		if ( $g ) {
			$t = imagescale( $g, 32, 32 );
			$v = array();
			for ( $y = 0; $y < 32; $y++ ) {
				for ( $x = 0; $x < 32; $x++ ) {
					$rgb = imagecolorat( $t, $x, $y );
					$v[] = ( ( $rgb >> 16 ) & 255 ) * 0.299 + ( ( $rgb >> 8 ) & 255 ) * 0.587 + ( $rgb & 255 ) * 0.114;
				}
			}
			$mean = array_sum( $v ) / count( $v );
			$var  = 0;
			foreach ( $v as $p ) {
				$var += ( $p - $mean ) * ( $p - $mean );
			}
			$sd = sqrt( $var / count( $v ) ) / 255;
		}
	}
	if ( null !== $sd && $sd < 0.004 ) {
		return new WP_Error( 'mvkd_check', 'Ergebnis ist einfarbig (vermutlich defekt).' );
	}
	return array( 'w' => (int) $info[0], 'h' => (int) $info[1], 'kb' => (int) round( filesize( $file ) / 1024 ), 'sd' => null === $sd ? null : round( $sd, 4 ) );
}

/** Zwischengrößen (768, 1024, 1536 ...) mit denselben WebP-Einstellungen schreiben. */
function mvkd_editor_hook( $on, $q, $opt = array() ) {
	$GLOBALS['mvkd_webp_ctx'] = $on ? array( 'q' => (int) $q, 'opt' => $opt ) : null;
	$f = 'mvkd_editors_filter';
	if ( $on ) {
		add_filter( 'wp_image_editors', $f, 99 );
	} else {
		remove_filter( 'wp_image_editors', $f, 99 );
	}
}
function mvkd_editors_filter( $editors ) {
	if ( ! class_exists( 'MVKD_Image_Editor' ) && class_exists( 'WP_Image_Editor_Imagick' ) ) {
		require_once __DIR__ . '/editor.php';
	}
	if ( class_exists( 'MVKD_Image_Editor' ) ) {
		array_unshift( $editors, 'MVKD_Image_Editor' );
	}
	return $editors;
}

/** Testlauf: eine Quelle mit mehreren Einstellungen kodieren, Ergebnisse in _mvk-archiv/_probe/ (werden überschrieben). */
function mvkd_do_probe( $a ) {
	$src = mvkd_safe_upload_path( $a['src'] ?? '' );
	if ( ! $src ) {
		return new WP_Error( 'mvkd_src', 'Quelle nicht gefunden.' );
	}
	$base = mvkd_upload_base();
	$dir  = $base['dir'] . '_mvk-archiv/_probe/';
	wp_mkdir_p( $dir );
	$out = array( 'src' => $a['src'], 'variants' => array() );
	foreach ( (array) ( $a['variants'] ?? array() ) as $i => $v ) {
		$file = 'probe-' . ( (int) $i + 1 ) . '.webp';
		$t    = microtime( true );
		$r    = mvkd_make_webp( $src, $dir . $file, isset( $a['max'] ) ? (int) $a['max'] : 2000, (int) ( $v['q'] ?? 90 ), $v );
		$out['variants'][] = is_wp_error( $r ) ? array( 'v' => $v, 'error' => $r->get_error_message() ) : array( 'v' => $v, 'url' => $base['url'] . '_mvk-archiv/_probe/' . $file, 'kb' => $r['kb'], 'w' => $r['w'], 'h' => $r['h'], 's' => round( microtime( true ) - $t, 1 ) );
	}
	return $out;
}

/**
 * Bereits gewandeltes WebP neu erzeugen (falsche Größe, defekt). Name bleibt.
 * src: Pfad relativ zu uploads, meist die archivierte Originaldatei in _mvk-archiv/.
 * Die bisherigen Dateien wandern nach _mvk-archiv/_ersetzt/, nichts wird gelöscht.
 */
function mvkd_do_reconvert( $a ) {
	$id  = (int) $a['id'];
	$dry = ! empty( $a['dry_run'] );
	$max = isset( $a['max'] ) ? (int) $a['max'] : 2000;
	$q   = isset( $a['quality'] ) ? max( 60, min( 100, (int) $a['quality'] ) ) : 90;
	if ( 'attachment' !== get_post_type( $id ) ) {
		return new WP_Error( 'mvkd_no_attachment', 'Kein Anhang: ' . $id );
	}
	$src = mvkd_safe_upload_path( $a['src'] ?? '' );
	if ( ! $src ) {
		return new WP_Error( 'mvkd_src', 'Quelle nicht gefunden: ' . ( $a['src'] ?? '' ) );
	}
	$base  = mvkd_upload_base();
	$info  = mvkd_attachment_files( $id );
	$meta  = wp_get_attachment_metadata( $id );
	$final = $info['name'];
	$dir   = $base['dir'] . $info['prefix'];
	$rep   = array( 'id' => $id, 'name' => $final, 'src' => $a['src'], 'files' => count( $info['files'] ), 'dry_run' => $dry );
	if ( $dry ) {
		$rep['refs'] = mvkd_apply_map_all( $info['stems'], array( '*' => $info['prefix'] . $final . '.webp' ), true );
		return $rep;
	}
	$opt = isset( $a['opt'] ) ? (array) $a['opt'] : array();
	$tmp = $dir . $final . '-mvktmp.webp';
	$mk  = mvkd_make_webp( $src, $tmp, $max, $q, $opt );
	if ( is_wp_error( $mk ) ) {
		return $mk;
	}
	$old_sizes = is_array( $meta ) && ! empty( $meta['sizes'] ) ? $meta['sizes'] : array();
	$old_rel   = (string) get_post_meta( $id, '_wp_attached_file', true );
	foreach ( $info['files'] as $f ) {
		$to = $base['dir'] . '_mvk-archiv/_ersetzt/' . $f['rel'];
		wp_mkdir_p( dirname( $to ) );
		if ( file_exists( $to ) ) {
			$to = preg_replace( '/(\.[a-z0-9]+)$/i', '-' . time() . '$1', $to );
		}
		if ( ! @rename( $base['dir'] . $f['rel'], $to ) ) { // phpcs:ignore
			$rep['errors'][] = 'archiv ' . $f['rel'];
		}
	}
	if ( ! @rename( $tmp, $dir . $final . '.webp' ) ) { // phpcs:ignore
		return new WP_Error( 'mvkd_mv', 'WebP konnte nicht abgelegt werden: ' . $id );
	}
	$new_rel = $info['prefix'] . $final . '.webp';
	update_post_meta( $id, '_wp_attached_file', $new_rel );
	if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) {
		require_once ABSPATH . 'wp-admin/includes/image.php';
	}
	$qf = function () use ( $q ) { return $q; };
	add_filter( 'wp_editor_set_quality', $qf, 99 );
	mvkd_editor_hook( true, $q, $opt );
	$new_meta = wp_generate_attachment_metadata( $id, $dir . $final . '.webp' );
	mvkd_editor_hook( false, $q );
	remove_filter( 'wp_editor_set_quality', $qf, 99 );
	wp_update_attachment_metadata( $id, $new_meta );
	$map = array( '*' => $new_rel );
	$nw  = isset( $new_meta['sizes'] ) ? $new_meta['sizes'] : array();
	foreach ( $old_sizes as $k => $s ) {
		$map[ strtolower( $s['file'] ) ] = isset( $nw[ $k ] ) ? $info['prefix'] . $nw[ $k ]['file'] : $new_rel;
	}
	$rep['refs'] = mvkd_apply_map_all( $info['stems'], $map, false );
	global $wpdb;
	$wpdb->update( $wpdb->posts, array( 'guid' => $base['url'] . $new_rel ), array( 'ID' => $id ) ); // phpcs:ignore
	clean_post_cache( $id );
	delete_transient( 'mvkd_file_map' );
	if ( $old_rel !== $new_rel ) {
		mvkd_add_redirect( preg_replace( '/\.[a-z0-9]+$/i', '', $old_rel ), $new_rel );
	}
	$rep['size']   = array( $new_meta['width'] ?? 0, $new_meta['height'] ?? 0, $mk['kb'] );
	$rep['engine'] = $mk['engine'];
	$rep['sd']     = $mk['sd'];
	$rep['q']      = $q;
	mvkd_log( array( 'action' => 'reconvert', 'id' => $id, 'src' => $a['src'], 'new' => $new_rel, 'size' => $rep['size'] ) );
	return $rep;
}

/** Verweise auf Anhang A durch Anhang B ersetzen (z. B. altes Logo im Hintergrund). Anhang A bleibt unverändert in der Mediathek. */
function mvkd_do_swap( $a ) {
	$old = (int) $a['id'];
	$new = (int) $a['to'];
	$dry = ! empty( $a['dry_run'] );
	if ( 'attachment' !== get_post_type( $old ) || 'attachment' !== get_post_type( $new ) ) {
		return new WP_Error( 'mvkd_no_attachment', 'Anhang fehlt.' );
	}
	$info = mvkd_attachment_files( $old );
	$rep  = mvkd_apply_map_all( $info['stems'], array( '*' => get_post_meta( $new, '_wp_attached_file', true ) ), $dry, array( $old => $new ) );
	if ( ! $dry ) {
		mvkd_log( array( 'action' => 'swap', 'id' => $old, 'to' => $new, 'posts' => count( $rep['posts'] ), 'css' => count( $rep['css'] ) ) );
	}
	return array( 'id' => $old, 'to' => $new, 'dry_run' => $dry, 'refs' => $rep );
}


/* ------------------------------------------------------------------ */
/* Imagify: eine Komprimierung, keine doppelte                         */
/* ------------------------------------------------------------------ */
function mvkd_imagify_ready() {
	return function_exists( 'imagify_get_optimization_process' );
}

/** Alte Imagify-Daten verwerfen und die neue WebP-Datei einmal von Imagify komprimieren lassen. */
function mvkd_imagify_optimize( $id ) {
	if ( ! mvkd_imagify_ready() ) {
		return 'Imagify nicht aktiv';
	}
	try {
		$process = imagify_get_optimization_process( $id, 'wp' );
		if ( ! $process || ( method_exists( $process, 'is_valid' ) && ! $process->is_valid() ) ) {
			return 'Imagify: Medium ungültig';
		}
		if ( method_exists( $process, 'get_data' ) && method_exists( $process->get_data(), 'delete_imagify_data' ) ) {
			$process->get_data()->delete_imagify_data();
		}
		clean_post_cache( $id );
		wp_cache_delete( $id, 'post_meta' );
		$process = imagify_get_optimization_process( $id, 'wp' ); // frisch laden, sonst gilt der alte Stand als verarbeitet
		$r = method_exists( $process, 'optimize' ) ? $process->optimize() : new WP_Error( 'x', 'optimize fehlt' );
		return is_wp_error( $r ) ? 'Imagify: ' . $r->get_error_message() : 'Imagify gestartet';
	} catch ( Throwable $e ) {
		return 'Imagify Fehler: ' . $e->getMessage();
	}
}

/* ------------------------------------------------------------------ */
/* Archivieren: aus der Mediathek nehmen, Dateien und Datensatz bleiben */
/* ------------------------------------------------------------------ */
function mvkd_do_archive( $a ) {
	global $wpdb;
	$id  = (int) $a['id'];
	$dry = ! empty( $a['dry_run'] );
	if ( 'attachment' !== get_post_type( $id ) ) {
		return new WP_Error( 'mvkd_no_attachment', 'Kein Anhang: ' . $id );
	}
	$info = mvkd_attachment_files( $id );
	$use  = mvkd_usage( $id, $info['stem'], mvkd_corpus() );
	$used = count( $use['posts'] ) + count( $use['meta'] ) + count( $use['options'] ) + count( $use['css'] );
	$rep  = array( 'id' => $id, 'file' => get_post_meta( $id, '_wp_attached_file', true ), 'files' => count( $info['files'] ), 'used' => $used, 'dry_run' => $dry );
	if ( $used && empty( $a['force'] ) ) {
		$rep['error'] = 'noch in Verwendung, nicht archiviert';
		return $rep;
	}
	if ( $dry ) {
		return $rep;
	}
	$base    = mvkd_upload_base();
	$archive = get_option( 'mvkd_media_archive', array() );
	$archive[ $id ] = array(
		'time' => current_time( 'mysql' ),
		'post' => $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->posts} WHERE ID = %d", $id ), ARRAY_A ), // phpcs:ignore
		'meta' => $wpdb->get_results( $wpdb->prepare( "SELECT meta_key, meta_value FROM {$wpdb->postmeta} WHERE post_id = %d", $id ), ARRAY_A ), // phpcs:ignore
		'files' => wp_list_pluck( $info['files'], 'rel' ),
	);
	update_option( 'mvkd_media_archive', $archive, false );
	foreach ( $info['files'] as $f ) {
		$to = $base['dir'] . '_mvk-archiv/' . $f['rel'];
		wp_mkdir_p( dirname( $to ) );
		if ( ! @rename( $base['dir'] . $f['rel'], $to ) ) { // phpcs:ignore
			$rep['errors'][] = 'archiv ' . $f['rel'];
		}
	}
	if ( ! empty( $rep['errors'] ) ) {
		return $rep; // Datensatz bleibt, wenn Dateien nicht verschoben werden konnten
	}
	wp_delete_attachment( $id, true );
	delete_transient( 'mvkd_file_map' );
	mvkd_log( array( 'action' => 'archive', 'id' => $id, 'file' => $rep['file'] ) );
	$rep['archived'] = true;
	return $rep;
}

function mvkd_batch( WP_REST_Request $req ) {
	$dry = (bool) $req->get_param( 'dry_run' );
	$out = array();
	foreach ( (array) $req->get_param( 'ops' ) as $op ) {
		$op['dry_run'] = $dry;
		$act           = $op['action'] ?? 'rename';
		if ( 'imagify' === $act ) {
			$out[] = array( 'id' => (int) $op['id'], 'imagify' => $dry ? 'dry_run' : mvkd_imagify_optimize( (int) $op['id'] ) );
			continue;
		}
		if ( 'swap' === $act ) {
			$res = mvkd_do_swap( $op );
		} elseif ( 'archive' === $act ) {
			$res = mvkd_do_archive( $op );
		} elseif ( 'reconvert' === $act ) {
			$res = mvkd_do_reconvert( $op );
		} elseif ( 'probe' === $act ) {
			$res = mvkd_do_probe( $op );
		} elseif ( 'tuning' === $act ) {
			if ( ! $dry ) {
				update_option( 'mvkd_webp_tuning', array_intersect_key( (array) ( $op['opt'] ?? array() ), array_flip( array( 'filter', 'sns', 'sharp_yuv', 'q_photo', 'q_graphic' ) ) ), false );
			}
			$res = array( 'tuning' => get_option( 'mvkd_webp_tuning' ) );
		} else {
			$res = mvkd_do_rename( $op );
		}
		if ( is_wp_error( $res ) ) {
			$out[] = array( 'id' => $op['id'] ?? 0, 'error' => $res->get_error_message() );
			continue;
		}
		if ( isset( $res['refs'] ) ) {
			$res['refs'] = array( 'posts' => array_keys( $res['refs']['posts'] ), 'meta' => count( $res['refs']['meta'] ), 'options' => array_keys( $res['refs']['options'] ), 'css' => array_keys( $res['refs']['css'] ) );
		}
		$out[] = $res;
	}
	if ( ! $dry ) {
		wp_cache_flush();
	}
	return array( 'dry_run' => $dry, 'count' => count( $out ), 'items' => $out );
}

/* ------------------------------------------------------------------ */
/* 3b. Bildtexte (Alt, Titel, Beschriftung, Beschreibung)              */
/* ------------------------------------------------------------------ */
function mvkd_meta( WP_REST_Request $req ) {
	$items  = (array) $req->get_param( 'items' );
	$dry    = (bool) $req->get_param( 'dry_run' );
	$backup = get_option( 'mvkd_media_meta_backup', array() );
	$out    = array();
	foreach ( $items as $it ) {
		$id = isset( $it['id'] ) ? (int) $it['id'] : 0;
		if ( 'attachment' !== get_post_type( $id ) ) {
			$out[] = array( 'id' => $id, 'error' => 'kein Anhang' );
			continue;
		}
		$before = array(
			'alt'         => (string) get_post_meta( $id, '_wp_attachment_image_alt', true ),
			'title'       => get_post_field( 'post_title', $id ),
			'caption'     => get_post_field( 'post_excerpt', $id ),
			'description' => get_post_field( 'post_content', $id ),
		);
		$after = $before;
		if ( isset( $it['alt'] ) ) {
			$after['alt'] = sanitize_text_field( $it['alt'] );
		}
		foreach ( array( 'caption', 'description' ) as $k ) {
			if ( isset( $it[ $k ] ) && '@alt' === $it[ $k ] ) {
				$it[ $k ] = rtrim( $after['alt'], '.' ) . '.';
			}
		}
		foreach ( array( 'alt', 'title', 'caption', 'description' ) as $k ) {
			if ( array_key_exists( $k, $it ) ) {
				$after[ $k ] = 'alt' === $k || 'title' === $k ? sanitize_text_field( $it[ $k ] ) : wp_kses_post( $it[ $k ] );
			}
		}
		$changed = array_keys( array_diff_assoc( $after, $before ) );
		$out[]   = $req->get_param( 'verbose' ) ? array( 'id' => $id, 'changed' => $changed, 'after' => $after ) : array( 'id' => $id, 'changed' => $changed );
		if ( $dry || ! $changed ) {
			continue;
		}
		if ( ! isset( $backup[ $id ] ) ) {
			$backup[ $id ] = $before;
		}
		update_post_meta( $id, '_wp_attachment_image_alt', $after['alt'] );
		wp_update_post( array( 'ID' => $id, 'post_title' => $after['title'], 'post_excerpt' => $after['caption'], 'post_content' => $after['description'] ) );
	}
	if ( ! $dry ) {
		update_option( 'mvkd_media_meta_backup', $backup, false );
	}
	return array( 'dry_run' => $dry, 'count' => count( $out ), 'items' => $out );
}

/* ------------------------------------------------------------------ */
/* 4. Weiterleitung alter Dateiadressen                                */
/* ------------------------------------------------------------------ */
add_action( 'template_redirect', function () {
	if ( ! is_404() ) {
		return;
	}
	$path = (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$pos  = strpos( $path, '/wp-content/uploads/' );
	if ( false === $pos ) {
		return;
	}
	$rel       = rawurldecode( substr( $path, $pos + strlen( '/wp-content/uploads/' ) ) );
	$redirects = get_option( 'mvkd_media_redirects', array() );
	foreach ( $redirects as $from => $to ) {
		$re = '~^' . preg_quote( $from, '~' ) . '(' . mvkd_suffix_pattern() . '(?:\\.(?:webp|avif))?)$~i';
		if ( preg_match( $re, $rel, $m ) ) {
			$target = preg_match( '/\\.(webp|jpe?g|png|gif|avif)$/i', $to ) ? $to : $to . $m[1];
			wp_safe_redirect( mvkd_upload_base()['url'] . $target, 301, 'MVK Design' );
			exit;
		}
	}
}, 1 );

/* ------------------------------------------------------------------ */
/* REST                                                                */
/* ------------------------------------------------------------------ */
add_action( 'rest_api_init', function () {
	$admin = function () { return current_user_can( 'manage_options' ); };
	register_rest_route( 'mvk-design/v1', '/status', array(
		'methods' => 'GET', 'permission_callback' => $admin,
		'callback' => function () {
			$img = array( 'imagick' => class_exists( 'Imagick' ), 'editor' => _wp_image_editor_choose( array( 'mime_type' => 'image/webp' ) ), 'memory' => ini_get( 'memory_limit' ), 'gd_webp' => function_exists( 'imagewebp' ) );
			if ( class_exists( 'Imagick' ) ) {
				$img['imagick_version'] = Imagick::getVersion()['versionString'] ?? '';
				$img['webp_format']     = in_array( 'WEBP', Imagick::queryFormats( 'WEBP' ), true );
				$img['imagick_q_ok']    = mvkd_imagick_q_ok();
				$img['encoder']         = mvkd_webp_encoder();
				$img['lcms']            = method_exists( 'Imagick', 'getConfigureOptions' ) ? (bool) preg_match( '/lcms/i', implode( ' ', (array) Imagick::getConfigureOptions( 'DELEGATES' ) ) ) : null;
				$img['limits']          = array( 'memory' => Imagick::getResourceLimit( Imagick::RESOURCETYPE_MEMORY ), 'area' => Imagick::getResourceLimit( Imagick::RESOURCETYPE_AREA ) );
			}
			return array( 'version' => MVKD_VERSION, 'image' => $img, 'webp_tuning' => mvkd_webp_defaults(), 'redirects' => get_option( 'mvkd_media_redirects', array() ), 'renames' => get_option( 'mvkd_media_renames', array() ) );
		},
	) );
	register_rest_route( 'mvk-design/v1', '/media/inventory', array(
		'methods' => 'GET', 'permission_callback' => $admin, 'callback' => 'mvkd_inventory',
		'args' => array(
			'usage'  => array( 'type' => 'boolean', 'default' => true ),
			'offset' => array( 'type' => 'integer', 'default' => 0 ),
			'limit'  => array( 'type' => 'integer', 'default' => 0 ),
			'short'  => array( 'type' => 'boolean', 'default' => false ),
		),
	) );
	register_rest_route( 'mvk-design/v1', '/media/meta', array(
		'methods' => 'POST', 'permission_callback' => $admin, 'callback' => 'mvkd_meta',
		'args' => array(
			'items'   => array( 'type' => 'array', 'required' => true ),
			'dry_run' => array( 'type' => 'boolean', 'default' => true ),
			'verbose' => array( 'type' => 'boolean', 'default' => false ),
		),
	) );
	register_rest_route( 'mvk-design/v1', '/media/batch', array(
		'methods' => 'POST', 'permission_callback' => $admin, 'callback' => 'mvkd_batch',
		'args' => array(
			'ops'     => array( 'type' => 'array', 'required' => true ),
			'dry_run' => array( 'type' => 'boolean', 'default' => true ),
		),
	) );
} );
