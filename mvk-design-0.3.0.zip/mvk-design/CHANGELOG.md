# Changelog

## 0.3.0 (07.11.2026)
- Modul Designsystem: Schriften lokal, Tokens, Bausteine (Bühne, Stufenpanel, Stufenband in drei Varianten, Text-Bild-Split, Zweispalter mit Randnotiz, Bildband mit Callouts, Nutzen-Leiste, Vergleichsraster mit Filter, Reiter-Viewer, Grundriss-Werkzeug, Zeitleiste, Zahlenband, Kundenstimmen, Marken-Leiste, Magazin-Teaser, FAQ, Abschluss), Blockstile für Buttons, 15 Blockvorlagen.
- Globaler Footer und Kontaktleiste aus dem Plugin, vorerst nur auf v2-Seiten.
- FAQPage-Schema aus `mvk-faq` ab drei Fragen.
- Medien: Aktion `purge` für eigene Zwischendateien.

## 0.2.7
- WebP über GD bei fehlerhafter Imagick-Qualität, lange Kante, ICC nach sRGB, keine Rückfallstufe auf q75.
