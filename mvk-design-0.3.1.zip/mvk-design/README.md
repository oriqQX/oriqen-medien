# MVK Design

Plugin für mvk-kuechen-und-raumdesign.de (Redesign v2). Keine externen Requests, keine Einstellungsseite.

## Module
- **Medien** (`modules/medien.php`, `modules/editor.php`): Alt-Text-Live-Sync, Inventar, WebP-Erzeugung (Fotos q92, Grafiken q95, Logos verlustfrei), Umbenennen mit 301, Bildtausch, Archiv, Aufräumen (`purge` für `_mvk-archiv/_ersetzt` und `_probe`).
- **Designsystem** (`modules/design.php`, `assets/`): Schriften (Barlow Condensed, Montserrat, OFL, lokal), Tokens, Bausteine als `mvk-`-Klassen auf Core-Blöcken, Bühne, Stufenband, Footer, Kontaktleiste, Grundriss-Werkzeug `[mvk_grundriss form="zeile|zweizeilig|l|u|g|insel|halbinsel"]`, FAQ-Schema aus `mvk-faq`, Blockvorlagen unter „MVK Design“.

## Geltungsbereich
Das Designsystem lädt nur auf v2-Seiten: Metafeld `_mvkd_v2 = 1` oder ein Block mit der Markierungsklasse `mvk-page-v2` (Bestandsseiten nutzen eigene `mvk-`-Klassen, die nicht zählen). Footer und Kontaktleiste nur dort, bis `mvkd_design.footer_global` auf true steht.

## REST (nur Administratoren)
- `GET /mvk-design/v1/status`, `GET /mvk-design/v1/media/inventory`, `POST /mvk-design/v1/media/meta`, `POST /mvk-design/v1/media/batch` (Aktionen rename, swap, archive, reconvert, probe, tuning, purge)
- `GET|POST /mvk-design/v1/design` (Einstellungen: footer_global, rating, stars, google_url, route_url, phone, termin_url, logo_id)

## Bausteine
Siehe Projektdatei `MVK_Designsystem.md` (Designsystem v1.0) und die Muster in `patterns/`.
