/* MVK Design 0.3.0 · Bausteine: Einblenden, Reiter-Viewer, Raster-Filter, Zahlen. Ohne Abhängigkeiten. */
( function () {
	'use strict';
	var doc = document;
	var calm = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
	var uid = 0;

	function $$( sel, root ) { return Array.prototype.slice.call( ( root || doc ).querySelectorAll( sel ) ); }
	function txt( el ) { return ( el && el.textContent || '' ).replace( /\s+/g, ' ' ).trim(); }

	/* 1. Einblenden: Maßlinien, Stufen, Zuschnitt. */
	function reveal() {
		var els = $$( '.mvk-band, .mvk-stage__panel, .mvk-stage__track > .mvk-hero-card, .mvk-steps, .mvk-step, .mvk-cut, .mvk-strip .mvk-callout' );
		if ( calm || ! ( 'IntersectionObserver' in window ) ) { return; }
		var io = new IntersectionObserver( function ( entries ) {
			entries.forEach( function ( e ) {
				if ( e.isIntersecting ) { e.target.classList.add( 'is-in' ); io.unobserve( e.target ); }
			} );
		}, { rootMargin: '0px 0px -12% 0px', threshold: 0.08 } );
		els.forEach( function ( el ) {
			var r = el.getBoundingClientRect();
			if ( r.top < window.innerHeight && r.bottom > 0 ) { return; } /* schon sichtbar: kein Flackern */
			el.classList.add( 'mvk-rv' );
			io.observe( el );
		} );
	}

	/* 2. Reiter-Viewer und Werkzeug: Reiter aus der ersten H3 jedes Panels. */
	function viewers() {
		$$( '.mvk-viewer' ).forEach( function ( v ) {
			var panels = $$( ':scope > .mvk-viewer__panel', v );
			if ( panels.length < 2 ) { return; }
			var bar = doc.createElement( 'div' );
			bar.className = 'mvk-tabs';
			bar.setAttribute( 'role', 'tablist' );
			var label = v.getAttribute( 'aria-label' ) || ( v.classList.contains( 'mvk-tool' ) ? 'Küchenform wählen' : 'Variante wählen' );
			bar.setAttribute( 'aria-label', label );
			var tabs = panels.map( function ( p, i ) {
				var h = p.querySelector( 'h3, h4' );
				var id = 'mvk-v' + ( ++uid );
				var b = doc.createElement( 'button' );
				b.type = 'button';
				b.id = id + '-t';
				b.setAttribute( 'role', 'tab' );
				b.setAttribute( 'aria-controls', id );
				b.textContent = h ? txt( h ) : 'Variante ' + ( i + 1 );
				p.id = p.id || id;
				b.setAttribute( 'aria-controls', p.id );
				p.setAttribute( 'role', 'tabpanel' );
				p.setAttribute( 'aria-labelledby', b.id );
				p.setAttribute( 'tabindex', '-1' );
				bar.appendChild( b );
				return b;
			} );
			function show( n, focus ) {
				tabs.forEach( function ( t, i ) {
					var on = i === n;
					t.setAttribute( 'aria-selected', on ? 'true' : 'false' );
					t.tabIndex = on ? 0 : -1;
					if ( on ) { panels[ i ].removeAttribute( 'hidden' ); } else { panels[ i ].setAttribute( 'hidden', '' ); }
				} );
				if ( focus ) { tabs[ n ].focus(); }
			}
			tabs.forEach( function ( t, i ) {
				t.addEventListener( 'click', function () { show( i ); } );
				t.addEventListener( 'keydown', function ( e ) {
					var k = e.key, n = null;
					if ( k === 'ArrowRight' ) { n = ( i + 1 ) % tabs.length; }
					if ( k === 'ArrowLeft' ) { n = ( i - 1 + tabs.length ) % tabs.length; }
					if ( k === 'Home' ) { n = 0; }
					if ( k === 'End' ) { n = tabs.length - 1; }
					if ( n !== null ) { e.preventDefault(); show( n, true ); }
				} );
			} );
			v.insertBefore( bar, panels[ 0 ] );
			v.classList.add( 'is-ready' );
			show( 0 );
		} );
	}

	/* 3. Vergleichsraster: Filter aus den Tags der Karten. */
	function grids() {
		$$( '.mvk-grid:not(.mvk-grid--static)' ).forEach( function ( g ) {
			var cards = $$( ':scope > .mvk-card', g );
			var tags = [];
			cards.forEach( function ( c ) {
				var t = txt( c.querySelector( '.mvk-card__tag' ) );
				c.setAttribute( 'data-mvk-tag', t );
				if ( t && tags.indexOf( t ) < 0 ) { tags.push( t ); }
			} );
			if ( tags.length < 2 ) { return; }
			var bar = doc.createElement( 'div' );
			bar.className = 'mvk-filter';
			bar.setAttribute( 'role', 'group' );
			bar.setAttribute( 'aria-label', g.getAttribute( 'aria-label' ) || 'Filtern' );
			var lbl = doc.createElement( 'span' );
			lbl.className = 'mvk-filter__lbl';
			lbl.textContent = 'Filtern';
			lbl.setAttribute( 'aria-hidden', 'true' );
			bar.appendChild( lbl );
			var count = doc.createElement( 'span' );
			count.className = 'mvk-filter__count';
			count.setAttribute( 'aria-live', 'polite' );
			var noun = g.getAttribute( 'data-mvk-noun' ) || ( g.classList.contains( 'mvk-grid--plates' ) ? 'Arbeitsplatten' : 'Varianten' );
			var btns = [ 'Alle' ].concat( tags ).map( function ( t, i ) {
				var b = doc.createElement( 'button' );
				b.type = 'button';
				b.textContent = t;
				b.setAttribute( 'aria-pressed', i === 0 ? 'true' : 'false' );
				b.addEventListener( 'click', function () {
					btns.forEach( function ( x ) { x.setAttribute( 'aria-pressed', x === b ? 'true' : 'false' ); } );
					var n = 0;
					cards.forEach( function ( c ) {
						var on = i === 0 || c.getAttribute( 'data-mvk-tag' ) === t;
						if ( on ) { c.removeAttribute( 'hidden' ); n++; } else { c.setAttribute( 'hidden', '' ); }
					} );
					count.textContent = n + ' von ' + cards.length + ' gezeigt';
				} );
				bar.appendChild( b );
				return b;
			} );
			count.textContent = cards.length + ' ' + noun;
			bar.appendChild( count );
			g.parentNode.insertBefore( bar, g );
		} );
	}

	/* 4. Zahlenband: zählt einmal hoch. Startwert im HTML ist die echte Zahl. */
	function figures() {
		if ( calm || ! ( 'IntersectionObserver' in window ) ) { return; }
		var nums = $$( '.mvk-figure__num' );
		var io = new IntersectionObserver( function ( entries ) {
			entries.forEach( function ( e ) {
				if ( ! e.isIntersecting ) { return; }
				io.unobserve( e.target );
				var el = e.target, end = parseInt( el.getAttribute( 'data-mvk-end' ), 10 ), t0 = null;
				function step( ts ) {
					if ( ! t0 ) { t0 = ts; }
					var p = Math.min( 1, ( ts - t0 ) / 900 );
					el.textContent = String( Math.round( end * ( 1 - Math.pow( 1 - p, 3 ) ) ) );
					if ( p < 1 ) { requestAnimationFrame( step ); }
				}
				requestAnimationFrame( step );
			} );
		}, { threshold: 0.6 } );
		nums.forEach( function ( el ) {
			var n = parseInt( txt( el ), 10 );
			if ( isNaN( n ) || String( n ) !== txt( el ) ) { return; }
			el.setAttribute( 'data-mvk-end', n );
			io.observe( el );
		} );
	}

	function init() {
		viewers();
		grids();
		figures();
		reveal();
	}
	if ( doc.readyState === 'loading' ) { doc.addEventListener( 'DOMContentLoaded', init ); } else { init(); }
}() );
