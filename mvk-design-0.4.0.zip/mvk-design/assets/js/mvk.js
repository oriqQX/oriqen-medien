/* MVK Design 0.4.0 · Bausteine: Einblenden, Reiter-Viewer, Raster-Filter, Zahlen. Ohne Abhängigkeiten. */
( function () {
	'use strict';
	var doc = document;
	var calm = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
	var uid = 0;

	function $$( sel, root ) { return Array.prototype.slice.call( ( root || doc ).querySelectorAll( sel ) ); }
	function txt( el ) { return ( el && el.textContent || '' ).replace( /\s+/g, ' ' ).trim(); }

	/* 1. Einblenden: Maßlinien, Stufen, Zuschnitt. */
	function reveal() {
		var els = $$( '.mvk-band, .mvk-stage__panel, .mvk-hero-card, .mvk-steps, .mvk-step, .mvk-cut, .mvk-strip .mvk-callout' );
		if ( calm || ! ( 'IntersectionObserver' in window ) ) { return; }
		var io = new IntersectionObserver( function ( entries ) {
			entries.forEach( function ( e ) {
				if ( e.isIntersecting ) { e.target.classList.add( 'is-in' ); io.unobserve( e.target ); }
			} );
		}, { rootMargin: '0px 0px -12% 0px', threshold: 0.08 } );
		els.forEach( function ( el ) {
			var r = el.getBoundingClientRect();
			if ( r.top < window.innerHeight && r.bottom > 0 ) { return; } /* schon sichtbar: kein Flackern */
			el.classList.add( 'mvk-rv' );
			io.observe( el );
		} );
	}

	/* 2. Reiter-Viewer und Werkzeug: Reiter aus der ersten H3 jedes Panels. */
	function viewers() {
		$$( '.mvk-viewer' ).forEach( function ( v ) {
			var panels = $$( ':scope > .mvk-viewer__panel, :scope > .wp-block-group__inner-container > .mvk-viewer__panel', v );
			if ( panels.length < 2 ) { return; }
			var bar = doc.createElement( 'div' );
			bar.className = 'mvk-tabs';
			bar.setAttribute( 'role', 'tablist' );
			var label = v.getAttribute( 'aria-label' ) || ( v.classList.contains( 'mvk-tool' ) ? 'Küchenform wählen' : 'Variante wählen' );
			bar.setAttribute( 'aria-label', label );
			var tabs = panels.map( function ( p, i ) {
				var h = p.querySelector( 'h3, h4' );
				var id = 'mvk-v' + ( ++uid );
				var b = doc.createElement( 'button' );
				b.type = 'button';
				b.id = id + '-t';
				b.setAttribute( 'role', 'tab' );
				b.setAttribute( 'aria-controls', id );
				b.textContent = h ? txt( h ) : 'Variante ' + ( i + 1 );
				p.id = p.id || id;
				b.setAttribute( 'aria-controls', p.id );
				p.setAttribute( 'role', 'tabpanel' );
				p.setAttribute( 'aria-labelledby', b.id );
				p.setAttribute( 'tabindex', '-1' );
				bar.appendChild( b );
				return b;
			} );
			function show( n, focus ) {
				tabs.forEach( function ( t, i ) {
					var on = i === n;
					t.setAttribute( 'aria-selected', on ? 'true' : 'false' );
					t.tabIndex = on ? 0 : -1;
					if ( on ) { panels[ i ].removeAttribute( 'hidden' ); } else { panels[ i ].setAttribute( 'hidden', '' ); }
				} );
				if ( focus ) { tabs[ n ].focus(); }
			}
			tabs.forEach( function ( t, i ) {
				t.addEventListener( 'click', function () { show( i ); } );
				t.addEventListener( 'keydown', function ( e ) {
					var k = e.key, n = null;
					if ( k === 'ArrowRight' ) { n = ( i + 1 ) % tabs.length; }
					if ( k === 'ArrowLeft' ) { n = ( i - 1 + tabs.length ) % tabs.length; }
					if ( k === 'Home' ) { n = 0; }
					if ( k === 'End' ) { n = tabs.length - 1; }
					if ( n !== null ) { e.preventDefault(); show( n, true ); }
				} );
			} );
			panels[ 0 ].parentNode.insertBefore( bar, panels[ 0 ] );
			v.classList.add( 'is-ready' );
			show( 0 );
		} );
	}

	/* 3. Vergleichsraster: Filter aus den Tags der Karten. */
	function grids() {
		$$( '.mvk-grid:not(.mvk-grid--static)' ).forEach( function ( g ) {
			var cards = $$( ':scope > .mvk-card, :scope > .wp-block-group__inner-container > .mvk-card', g );
			var tags = [];
			cards.forEach( function ( c ) {
				var t = txt( c.querySelector( '.mvk-card__tag' ) );
				c.setAttribute( 'data-mvk-tag', t );
				if ( t && tags.indexOf( t ) < 0 ) { tags.push( t ); }
			} );
			if ( tags.length < 2 ) { return; }
			var bar = doc.createElement( 'div' );
			bar.className = 'mvk-filter';
			bar.setAttribute( 'role', 'group' );
			bar.setAttribute( 'aria-label', g.getAttribute( 'aria-label' ) || 'Filtern' );
			var lbl = doc.createElement( 'span' );
			lbl.className = 'mvk-filter__lbl';
			lbl.textContent = 'Filtern';
			lbl.setAttribute( 'aria-hidden', 'true' );
			bar.appendChild( lbl );
			var count = doc.createElement( 'span' );
			count.className = 'mvk-filter__count';
			count.setAttribute( 'aria-live', 'polite' );
			var noun = g.getAttribute( 'data-mvk-noun' ) || ( g.classList.contains( 'mvk-grid--plates' ) ? 'Arbeitsplatten' : 'Varianten' );
			var btns = [ 'Alle' ].concat( tags ).map( function ( t, i ) {
				var b = doc.createElement( 'button' );
				b.type = 'button';
				b.textContent = t;
				b.setAttribute( 'aria-pressed', i === 0 ? 'true' : 'false' );
				b.addEventListener( 'click', function () {
					btns.forEach( function ( x ) { x.setAttribute( 'aria-pressed', x === b ? 'true' : 'false' ); } );
					var n = 0;
					cards.forEach( function ( c ) {
						var on = i === 0 || c.getAttribute( 'data-mvk-tag' ) === t;
						if ( on ) { c.removeAttribute( 'hidden' ); n++; } else { c.setAttribute( 'hidden', '' ); }
					} );
					count.textContent = n + ' von ' + cards.length + ' gezeigt';
				} );
				bar.appendChild( b );
				return b;
			} );
			count.textContent = cards.length + ' ' + noun;
			bar.appendChild( count );
			g.parentNode.insertBefore( bar, g );
		} );
	}

	/* 4. Zahlenband: zählt einmal hoch. Startwert im HTML ist die echte Zahl. */
	function figures() {
		if ( calm || ! ( 'IntersectionObserver' in window ) ) { return; }
		var nums = $$( '.mvk-figure__num' );
		var io = new IntersectionObserver( function ( entries ) {
			entries.forEach( function ( e ) {
				if ( ! e.isIntersecting ) { return; }
				io.unobserve( e.target );
				var el = e.target, end = parseInt( el.getAttribute( 'data-mvk-end' ), 10 ), t0 = null;
				function step( ts ) {
					if ( ! t0 ) { t0 = ts; }
					var p = Math.min( 1, ( ts - t0 ) / 900 );
					el.textContent = String( Math.round( end * ( 1 - Math.pow( 1 - p, 3 ) ) ) );
					if ( p < 1 ) { requestAnimationFrame( step ); }
				}
				requestAnimationFrame( step );
			} );
		}, { threshold: 0.6 } );
		nums.forEach( function ( el ) {
			var n = parseInt( txt( el ), 10 );
			if ( isNaN( n ) || String( n ) !== txt( el ) || n >= 1000 ) { return; }
			el.setAttribute( 'data-mvk-end', n );
			io.observe( el );
		} );
	}


	/* 5. Lightbox für Galerien (.mvk-gallery) und einzelne Bilder (.mvk-zoom). */
	var ICO = {
		x: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 5l14 14M19 5L5 19"/></svg>',
		l: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M15 4l-8 8 8 8"/></svg>',
		r: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M9 4l8 8-8 8"/></svg>',
		lr: '<svg viewBox="0 0 26 26" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M9 7l-6 6 6 6M17 7l6 6-6 6"/></svg>'
	};
	function lightbox() {
		var groups = $$( '.mvk-gallery, .mvk-zoom' );
		if ( ! groups.length || typeof HTMLDialogElement === 'undefined' ) { return; }
		var dlg = doc.createElement( 'dialog' );
		dlg.className = 'mvk-lb';
		dlg.setAttribute( 'aria-label', 'Bildansicht' );
		dlg.innerHTML = '<div class="mvk-lb__stage"><img alt=""></div><div class="mvk-lb__bar"><span class="mvk-lb__count"></span><span class="mvk-lb__cap"></span></div>' +
			'<button type="button" class="mvk-lb__close" aria-label="Schließen">' + ICO.x + '</button>' +
			'<button type="button" class="mvk-lb__prev" aria-label="Vorheriges Bild">' + ICO.l + '</button>' +
			'<button type="button" class="mvk-lb__next" aria-label="Nächstes Bild">' + ICO.r + '</button>';
		doc.body.appendChild( dlg );
		var img = dlg.querySelector( 'img' ), cnt = dlg.querySelector( '.mvk-lb__count' ), cap = dlg.querySelector( '.mvk-lb__cap' );
		var list = [], idx = 0;
		function show( n ) {
			idx = ( n + list.length ) % list.length;
			var it = list[ idx ];
			img.src = it.src; img.alt = it.alt;
			cnt.textContent = ( idx + 1 ) + ' / ' + list.length;
			cap.textContent = it.cap || it.alt;
			var multi = list.length > 1;
			dlg.querySelector( '.mvk-lb__prev' ).hidden = ! multi;
			dlg.querySelector( '.mvk-lb__next' ).hidden = ! multi;
		}
		dlg.querySelector( '.mvk-lb__close' ).addEventListener( 'click', function () { dlg.close(); } );
		dlg.querySelector( '.mvk-lb__prev' ).addEventListener( 'click', function () { show( idx - 1 ); } );
		dlg.querySelector( '.mvk-lb__next' ).addEventListener( 'click', function () { show( idx + 1 ); } );
		dlg.addEventListener( 'click', function ( e ) { if ( e.target === dlg || e.target.classList.contains( 'mvk-lb__stage' ) ) { dlg.close(); } } );
		dlg.addEventListener( 'keydown', function ( e ) {
			if ( e.key === 'ArrowRight' ) { show( idx + 1 ); }
			if ( e.key === 'ArrowLeft' ) { show( idx - 1 ); }
		} );
		var x0 = null;
		dlg.addEventListener( 'touchstart', function ( e ) { x0 = e.touches[ 0 ].clientX; }, { passive: true } );
		dlg.addEventListener( 'touchend', function ( e ) {
			if ( x0 === null ) { return; }
			var dx = e.changedTouches[ 0 ].clientX - x0; x0 = null;
			if ( Math.abs( dx ) > 50 ) { show( idx + ( dx < 0 ? 1 : -1 ) ); }
		} );
		groups.forEach( function ( g ) {
			var figs = $$( 'figure.wp-block-image', g );
			if ( g.matches( 'figure.wp-block-image' ) ) { figs = [ g ]; }
			var items = figs.map( function ( f ) {
				var a = f.querySelector( 'a' ), im = f.querySelector( 'img' ), c = f.querySelector( 'figcaption' );
				var src = a && /\.(webp|jpe?g|png)(\?|$)/i.test( a.getAttribute( 'href' ) || '' ) ? a.href : ( im && ( im.currentSrc || im.src ) );
				return { src: src, alt: im ? im.alt : '', cap: c ? txt( c ) : '', el: a || im };
			} ).filter( function ( it ) { return it.src && it.el; } );
			items.forEach( function ( it, i ) {
				it.el.addEventListener( 'click', function ( e ) {
					e.preventDefault();
					list = items; show( i );
					dlg.showModal();
				} );
				if ( it.el.tagName === 'IMG' ) { it.el.style.cursor = 'zoom-in'; it.el.tabIndex = 0; it.el.addEventListener( 'keydown', function ( e ) { if ( e.key === 'Enter' ) { it.el.click(); } } ); }
			} );
		} );
	}

	/* 6. Vorher-Nachher: zwei Bilder in .mvk-compare, Schieber per Maus, Finger und Tastatur. */
	function compares() {
		$$( '.mvk-compare' ).forEach( function ( c ) {
			var figs = $$( 'figure.wp-block-image', c );
			if ( figs.length < 2 ) { return; }
			figs[ 0 ].classList.add( 'mvk-compare__before' );
			figs[ 1 ].classList.add( 'mvk-compare__after' );
			var holder = figs[ 0 ].parentNode;
			var range = doc.createElement( 'input' );
			range.type = 'range'; range.min = 0; range.max = 100; range.value = 50; range.className = 'mvk-compare__range';
			range.setAttribute( 'aria-label', 'Vergleich verschieben: ' + ( txt( figs[ 0 ].querySelector( 'figcaption' ) ) || 'vorher' ) + ' und ' + ( txt( figs[ 1 ].querySelector( 'figcaption' ) ) || 'nachher' ) );
			var handle = doc.createElement( 'span' );
			handle.className = 'mvk-compare__handle'; handle.setAttribute( 'aria-hidden', 'true' );
			handle.innerHTML = '<span class="mvk-compare__knob">' + ICO.lr + '</span>';
			holder.appendChild( range ); holder.appendChild( handle );
			function set( v ) { c.style.setProperty( '--pos', v + '%' ); }
			range.addEventListener( 'input', function () { set( range.value ); } );
			c.classList.add( 'is-ready' );
			set( 50 );
			if ( ! calm && 'IntersectionObserver' in window ) {
				var io = new IntersectionObserver( function ( en ) {
					if ( ! en[ 0 ].isIntersecting ) { return; }
					io.disconnect();
					var t0 = null;
					function step( ts ) {
						if ( ! t0 ) { t0 = ts; }
						var p = Math.min( 1, ( ts - t0 ) / 1600 );
						var v = 50 + Math.sin( p * Math.PI * 2 ) * 18 * ( 1 - p );
						set( v ); range.value = v;
						if ( p < 1 ) { requestAnimationFrame( step ); }
					}
					requestAnimationFrame( step );
				}, { threshold: 0.6 } );
				io.observe( c );
			}
		} );
	}

	/* 7. Hotspot-Bild: Liste mit Positionsklassen mvk-x-NN mvk-y-NN wird zu Punkten auf dem Bild. */
	function hotspots() {
		$$( '.mvk-hotspots' ).forEach( function ( h ) {
			var fig = h.querySelector( 'figure.wp-block-image' );
			var items = $$( '.wp-block-list > li', h ).filter( function ( li ) { return /mvk-x-\d+/.test( li.className ) && /mvk-y-\d+/.test( li.className ); } );
			if ( ! fig || ! items.length ) { return; }
			var card = doc.createElement( 'div' );
			card.className = 'mvk-hs-card'; card.hidden = true; card.id = 'mvk-hs' + ( ++uid );
			card.setAttribute( 'role', 'status' );
			fig.appendChild( card );
			var dots = items.map( function ( li, i ) {
				var x = +li.className.match( /mvk-x-(\d+)/ )[ 1 ], y = +li.className.match( /mvk-y-(\d+)/ )[ 1 ];
				var b = doc.createElement( 'button' );
				b.type = 'button'; b.className = 'mvk-hs-dot';
				b.textContent = ( i < 9 ? '0' : '' ) + ( i + 1 );
				b.style.left = x + '%'; b.style.top = y + '%';
				b.setAttribute( 'aria-expanded', 'false' ); b.setAttribute( 'aria-controls', card.id );
				var t = li.querySelector( 'strong' );
				b.setAttribute( 'aria-label', 'Detail ' + ( i + 1 ) + ': ' + ( t ? txt( t ) : txt( li ).slice( 0, 40 ) ) );
				b.addEventListener( 'click', function () {
					var open = b.getAttribute( 'aria-expanded' ) === 'true';
					dots.forEach( function ( d ) { d.setAttribute( 'aria-expanded', 'false' ); } );
					items.forEach( function ( l ) { l.classList.remove( 'mvk-hs-active' ); } );
					if ( open ) { card.hidden = true; return; }
					b.setAttribute( 'aria-expanded', 'true' ); li.classList.add( 'mvk-hs-active' );
					card.innerHTML = li.innerHTML;
					card.hidden = false;
					var fw = fig.clientWidth, fh = fig.clientHeight, cw = Math.min( 300, fw * 0.7 );
					var left = x / 100 * fw + 26, top = y / 100 * fh - 20;
					if ( left + cw > fw - 8 ) { left = x / 100 * fw - 26 - cw; }
					if ( left < 8 ) { left = 8; }
					top = Math.max( 8, Math.min( top, fh - card.offsetHeight - 8 ) );
					card.style.left = left + 'px'; card.style.top = top + 'px';
				} );
				fig.appendChild( b );
				return b;
			} );
			doc.addEventListener( 'keydown', function ( e ) { if ( e.key === 'Escape' && ! card.hidden ) { card.hidden = true; dots.forEach( function ( d ) { d.setAttribute( 'aria-expanded', 'false' ); } ); } } );
			h.classList.add( 'is-ready' );
		} );
	}

	function init() {
		viewers();
		lightbox();
		compares();
		hotspots();
		grids();
		figures();
		reveal();
	}
	if ( doc.readyState === 'loading' ) { doc.addEventListener( 'DOMContentLoaded', init ); } else { init(); }
}() );
