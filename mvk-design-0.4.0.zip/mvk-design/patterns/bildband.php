<?php
defined( 'ABSPATH' ) || exit;
return array(
	'title'   => 'MVK Bildband mit Callouts',
	'content' => <<<'MVK'
<!-- wp:group {"align":"full","className":"mvk-strip"} -->
<div class="wp-block-group alignfull mvk-strip"><!-- wp:image {"id":1867,"sizeSlug":"full","linkDestination":"none","className":"mvk-cut"} -->
<figure class="wp-block-image size-full mvk-cut"><img src="https://mvk-kuechen-und-raumdesign.de/wp-content/uploads/2026/09/mvk-grifflose-kueche-anthrazit-kochinsel-lippstadt.webp" alt="" class="wp-image-1867"/></figure>
<!-- /wp:image -->
<!-- wp:paragraph {"className":"mvk-callout mvk-at-ml"} -->
<p class="mvk-callout mvk-at-ml"><strong>Grifflos</strong></p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"mvk-callout mvk-at-bl"} -->
<p class="mvk-callout mvk-at-bl"><strong>Kochinsel</strong></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
MVK
);
