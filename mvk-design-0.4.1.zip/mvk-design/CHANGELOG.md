# Changelog

## 0.4.1 (07.11.2026)
- Blueprints: Küchen-Pillar überarbeitet (Vorher-Nachher 3D gegen fertige Küche, Ballerina mit Fakten, Zahlenband und Galerie mit 12 Küchen, Nolte mit Fakten und Galerie, Stilwelten) und neu Küchenausstattung (Hotspot-Bild, drei Reiter-Viewer, Funktionsraster mit Filter, vier Galerien, Zahlenband, FAQ).
- Galerie: Bildunterschrift außerhalb des Rasters, Raster ohne Lücken bei 8, 12 und gerader Bildzahl mobil, Variante `mvk-gallery--row` (eine Reihe), Kachelunterschriften mobil und in Spalten nur am ersten Bild.
- Raster `mvk-grid--tall` (Bilder 4:5), `mvk-grid--funktion` zählt „Lösungen“. Sprungmarken-Liste `mvk-jump`. `mvk-split--solo`. Hotspot-Punkte mobil kleiner.

## 0.4.0 (07.11.2026)
- Bildimport `POST /mvk-design/v1/media/import` (nur aus oriqen-medien, höchstens 20 je Aufruf): WebP q92, lange Kante 2000 px, Zwischengrößen über GD, Alt-Text, Titel, Beschreibung, Quelle in `_mvkd_source`.
- Neue Bausteine: Galerie mit Lightbox (`mvk-gallery`, Einzelbild `mvk-zoom`), Vorher-Nachher-Schieber (`mvk-compare`), Hotspot-Bild (`mvk-hotspots` mit `mvk-x-NN mvk-y-NN`).

## 0.3.2 (07.11.2026)
- GeneratePress ohne theme.json legt in Gruppen `wp-block-group__inner-container` an: Container ohne eigene Box (display: contents), Kind-Selektoren und Skript berücksichtigen ihn.

## 0.3.1 (07.11.2026)
- Seiten-Blueprints: `POST /mvk-design/v1/content/apply` schreibt eine Seite aus `blueprints/pages/` in einen Entwurf (nie in veröffentlichte Seiten), setzt `_mvkd_v2` und GeneratePress „Volle Breite“. Erster Blueprint: Küchen-Pillar v2.

## 0.3.0 (07.11.2026)
- Modul Designsystem: Schriften lokal, Tokens, Bausteine (Bühne, Stufenpanel, Stufenband in drei Varianten, Text-Bild-Split, Zweispalter mit Randnotiz, Bildband mit Callouts, Nutzen-Leiste, Vergleichsraster mit Filter, Reiter-Viewer, Grundriss-Werkzeug, Zeitleiste, Zahlenband, Kundenstimmen, Marken-Leiste, Magazin-Teaser, FAQ, Abschluss), Blockstile für Buttons, 15 Blockvorlagen.
- Globaler Footer und Kontaktleiste aus dem Plugin, vorerst nur auf v2-Seiten.
- FAQPage-Schema aus `mvk-faq` ab drei Fragen.
- Medien: Aktion `purge` für eigene Zwischendateien.

## 0.2.7
- WebP über GD bei fehlerhafter Imagick-Qualität, lange Kante, ICC nach sRGB, keine Rückfallstufe auf q75.
