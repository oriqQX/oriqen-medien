# Changelog

## 0.4.4 (07.11.2026)
- Überschriften: lange Titel tragen zwei rote Blickanker (Schlüsselwort vorn, Nutzen hinten), kurze einen. Auch Abschnitts-H3 wie „Inspiration aus dem Ballerina-Programm“.
- Footer: Stufenform deutlich größer. Links Box im Seitenrand von Logo-Oberkante bis Balkenunterkante plus breiter Balken bis zum Spaltenende, rechts gespiegelt, kleiner und kürzer am Fuß der Studio-Spalte. Endstrich als Maßlinie. oriqen-Verweis ohne eigenes Band im selben Hellgrau wie der Footer.
- Bildband: Zielpunkt-Callouts (`mvk-pt` mit `mvk-x-NN mvk-y-NN`, Linienlänge `mvk-lead-N` in vw, `mvk-to-l` für Etikett links). Bildband mit `mvk-strip--pt` zeigt das Bild am Desktop ungeschnitten in 5:2, damit der Punkt exakt auf dem Objekt liegt. Mobil wie bisher als Etiketten unter dem Bild.
- Küchen-Blueprint: Nolte mit eigenem Magazin-Teaser (H3, Einleitung, Galerie mit fünf Küchen), Ballerina-Galerie mit 15 Küchen, Küchenformen mit Fotos für zweizeilig, U-Küche und Halbinsel.

## 0.4.3 (07.11.2026)
- Copyright der Bestandsseiten nur noch „© Jahr MVK Küchen & Raumdesign“ (Filter `generate_copyright`, Priorität 99). Der oriqen-Verweis steht einmal im neuen Band von oriqen Support 1.0.2. Snippet 5 wirkt damit nicht mehr und kann aus.

## 0.4.2 (07.11.2026)
- Bilder blenden weich ein (Deckkraft und leichter Zoom, 1,1 s) statt per Zuschnitt aufzuploppen, Auslöser etwas früher. Bilder in Reitern ohne zweite Einblendung. Bilder, die beim Start noch laden, blenden nach dem Laden weich ein (nicht Bühne).
- Akzente: Kicker in MVK-Rot, Schlüsselwörter in H2 rot markiert (Core-Textfarbe mit Klasse `mvk-key`, im Builder `[[Wort]]`).
- Footer: Spaltentitel, Leitsatz, Einsatzgebiet und Partner in Rot, Stufenbalken (Box und Balken) von links unter dem Leitsatz und kürzer von rechts unter dem Studio, Endstrich wie eine Maßlinie. oriqen-Verweis auf eigenem weißen Band.

## 0.4.1 (07.11.2026)
- Blueprints: Küchen-Pillar überarbeitet (Vorher-Nachher 3D gegen fertige Küche, Ballerina mit Fakten, Zahlenband und Galerie mit 12 Küchen, Nolte mit Fakten und Galerie, Stilwelten) und neu Küchenausstattung (Hotspot-Bild, drei Reiter-Viewer, Funktionsraster mit Filter, vier Galerien, Zahlenband, FAQ).
- Galerie: Bildunterschrift außerhalb des Rasters, Raster ohne Lücken bei 8, 12 und gerader Bildzahl mobil, Variante `mvk-gallery--row` (eine Reihe), Kachelunterschriften mobil und in Spalten nur am ersten Bild.
- Raster `mvk-grid--tall` (Bilder 4:5), `mvk-grid--funktion` zählt „Lösungen“. Sprungmarken-Liste `mvk-jump`. `mvk-split--solo`. Hotspot-Punkte mobil kleiner.

## 0.4.0 (07.11.2026)
- Bildimport `POST /mvk-design/v1/media/import` (nur aus oriqen-medien, höchstens 20 je Aufruf): WebP q92, lange Kante 2000 px, Zwischengrößen über GD, Alt-Text, Titel, Beschreibung, Quelle in `_mvkd_source`.
- Neue Bausteine: Galerie mit Lightbox (`mvk-gallery`, Einzelbild `mvk-zoom`), Vorher-Nachher-Schieber (`mvk-compare`), Hotspot-Bild (`mvk-hotspots` mit `mvk-x-NN mvk-y-NN`).

## 0.3.2 (07.11.2026)
- GeneratePress ohne theme.json legt in Gruppen `wp-block-group__inner-container` an: Container ohne eigene Box (display: contents), Kind-Selektoren und Skript berücksichtigen ihn.

## 0.3.1 (07.11.2026)
- Seiten-Blueprints: `POST /mvk-design/v1/content/apply` schreibt eine Seite aus `blueprints/pages/` in einen Entwurf (nie in veröffentlichte Seiten), setzt `_mvkd_v2` und GeneratePress „Volle Breite“. Erster Blueprint: Küchen-Pillar v2.

## 0.3.0 (07.11.2026)
- Modul Designsystem: Schriften lokal, Tokens, Bausteine (Bühne, Stufenpanel, Stufenband in drei Varianten, Text-Bild-Split, Zweispalter mit Randnotiz, Bildband mit Callouts, Nutzen-Leiste, Vergleichsraster mit Filter, Reiter-Viewer, Grundriss-Werkzeug, Zeitleiste, Zahlenband, Kundenstimmen, Marken-Leiste, Magazin-Teaser, FAQ, Abschluss), Blockstile für Buttons, 15 Blockvorlagen.
- Globaler Footer und Kontaktleiste aus dem Plugin, vorerst nur auf v2-Seiten.
- FAQPage-Schema aus `mvk-faq` ab drei Fragen.
- Medien: Aktion `purge` für eigene Zwischendateien.

## 0.2.7
- WebP über GD bei fehlerhafter Imagick-Qualität, lange Kante, ICC nach sRGB, keine Rückfallstufe auf q75.
