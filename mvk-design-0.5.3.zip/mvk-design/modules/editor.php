<?php
/**
 * MVK Design: Imagick-Editor mit festen WebP-Einstellungen für Zwischengrößen.
 * Nur aktiv, während MVK Design selbst Bilder erzeugt (mvkd_editor_hook).
 * Hält Imagick die Qualität nicht ein, schreibt GD die Datei (Verkleinern bleibt bei Imagick).
 */
defined( 'ABSPATH' ) || exit;

class MVKD_Image_Editor extends WP_Image_Editor_Imagick {
	protected function _save( $image, $filename = null, $mime_type = null ) {
		$ctx = $GLOBALS['mvkd_webp_ctx'] ?? null;
		list( $fn, $ext, $mt ) = $this->get_output_format( $filename, $mime_type );
		if ( ! $ctx || 'image/webp' !== $mt || ! ( $image instanceof Imagick ) ) {
			return parent::_save( $image, $filename, $mime_type );
		}
		if ( 'gd' !== mvkd_webp_encoder( $ctx['opt'] ) ) {
			try {
				mvkd_webp_apply( $image, $ctx['q'], $ctx['opt'] );
			} catch ( Exception $e ) { // phpcs:ignore
			}
			return parent::_save( $image, $filename, $mime_type );
		}
		if ( ! $fn ) {
			$fn = $this->generate_filename( null, null, $ext );
		}
		wp_mkdir_p( dirname( $fn ) );
		$r = mvkd_gd_write( $image, $fn, $ctx['q'] );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		$stat = stat( dirname( $fn ) );
		chmod( $fn, $stat['mode'] & 0000666 );
		return array(
			'path'      => $fn,
			'file'      => wp_basename( apply_filters( 'image_make_intermediate_size', $fn ) ),
			'width'     => $this->size['width'],
			'height'    => $this->size['height'],
			'mime-type' => $mt,
			'filesize'  => wp_filesize( $fn ),
		);
	}
}
