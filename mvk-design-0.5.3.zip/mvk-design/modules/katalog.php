<?php
/**
 * MVK Design · Modul Katalog (ab 0.5.0)
 *
 * Herstellerkataloge als Datensätze im Plugin (katalog/*.json), ausgespielt per Shortcode.
 * Ein Katalog lebt vollständig auf genau einer Seite; andere Seiten zeigen Auszüge mit Filter-Link.
 *
 * [mvk_katalog set="ballerina-modelle"]                       vollständiger Katalog mit Filtern, Stilfinder, Schema
 * [mvk_katalog set="ballerina-modelle" auszug="6" ids="a,b"]   Auszug ohne Filter, mit Link zum Katalog
 * [mvk_katalog set="ballerina-modelle" auszug="6" filter="stil:landhaus" link="/…/#katalog=stil:landhaus"]
 * [mvk_korpus]                                                 Korpus im Schnitt (Ballerina) als SVG
 *
 * Text steht immer im HTML. Ohne JavaScript sind alle Einträge sichtbar, Filter und Stilfinder blenden sich aus.
 * Keine externen Requests, keine Cookies, kein Speicher im Browser.
 */

defined( 'ABSPATH' ) || exit;

function mvkd_katalog_sets() {
	static $sets = null;
	if ( null !== $sets ) {
		return $sets;
	}
	$sets = array();
	foreach ( ( glob( MVKD_DIR . 'katalog/*.json' ) ?: array() ) as $file ) {
		$d = json_decode( (string) file_get_contents( $file ), true );
		if ( is_array( $d ) && ! empty( $d['id'] ) && ! empty( $d['items'] ) ) {
			$sets[ $d['id'] ] = $d;
		}
	}
	return $sets;
}

function mvkd_katalog_get( $id ) {
	$s = mvkd_katalog_sets();
	return isset( $s[ $id ] ) ? $s[ $id ] : null;
}

add_action( 'init', function () {
	add_shortcode( 'mvk_katalog', 'mvkd_katalog_sc' );
	add_shortcode( 'mvk_korpus', 'mvkd_korpus_sc' );
} );

/** "stil:modern+landhaus;griff:grifflos" → array( 'stil' => array( 'modern', 'landhaus' ), … ) */
function mvkd_katalog_parse_filter( $s ) {
	$out = array();
	foreach ( preg_split( '/[;,]\s*(?=[a-z0-9_-]+:)/', (string) $s ) as $part ) {
		if ( strpos( $part, ':' ) === false ) {
			continue;
		}
		list( $k, $v ) = array_map( 'trim', explode( ':', $part, 2 ) );
		$vals = array_filter( array_map( 'sanitize_key', explode( '+', $v ) ) );
		if ( $k && $vals ) {
			$out[ sanitize_key( $k ) ] = array_values( $vals );
		}
	}
	return $out;
}

function mvkd_katalog_match( $item, $filter ) {
	foreach ( $filter as $k => $vals ) {
		$have = isset( $item['f'][ $k ] ) ? (array) $item['f'][ $k ] : array();
		if ( ! array_intersect( $have, $vals ) ) {
			return false;
		}
	}
	return true;
}

function mvkd_katalog_img( $id, $size, $attr ) {
	$id = (int) $id;
	if ( $id && function_exists( 'wp_get_attachment_image' ) ) {
		$h = wp_get_attachment_image( $id, $size, false, $attr );
		if ( $h ) {
			return $h;
		}
	}
	return '';
}

function mvkd_katalog_src( $id, $size = 'large' ) {
	$id = (int) $id;
	if ( $id && function_exists( 'wp_get_attachment_image_url' ) ) {
		$u = wp_get_attachment_image_url( $id, $size );
		return $u ? $u : '';
	}
	return '';
}

function mvkd_katalog_alt( $id, $fallback ) {
	$alt = function_exists( 'get_post_meta' ) ? trim( (string) get_post_meta( (int) $id, '_wp_attachment_image_alt', true ) ) : '';
	return $alt ? $alt : $fallback;
}

function mvkd_katalog_sc( $atts ) {
	$a = shortcode_atts( array(
		'set'    => '',
		'auszug' => 0,
		'ids'    => '',
		'filter' => '',
		'link'   => '',
		'zeigen' => 12,
		'anker'  => 'katalog',
		'finder' => '1',
	), $atts, 'mvk_katalog' );

	$set = mvkd_katalog_get( sanitize_key( $a['set'] ) );
	if ( ! $set ) {
		return '';
	}
	$layout  = isset( $set['layout'] ) ? $set['layout'] : 'karten';
	$items   = $set['items'];
	$auszug  = max( 0, (int) $a['auszug'] );
	$anchor  = sanitize_key( $a['anker'] );
	$facets  = isset( $set['facets'] ) ? $set['facets'] : array();
	$einheit = isset( $set['einheit'] ) ? $set['einheit'] : array( 'Eintrag', 'Einträge' );

	if ( $a['ids'] ) {
		$want = array_map( 'sanitize_key', explode( ',', $a['ids'] ) );
		$by   = array();
		foreach ( $items as $it ) {
			$by[ $it['id'] ] = $it;
		}
		$items = array();
		foreach ( $want as $w ) {
			if ( isset( $by[ $w ] ) ) {
				$items[] = $by[ $w ];
			}
		}
	}
	if ( $a['filter'] ) {
		$f     = mvkd_katalog_parse_filter( $a['filter'] );
		$items = array_values( array_filter( $items, function ( $it ) use ( $f ) {
			return mvkd_katalog_match( $it, $f );
		} ) );
	}
	if ( $auszug ) {
		$items = array_slice( $items, 0, $auszug );
	}
	if ( ! $items ) {
		return '';
	}

	$full  = ! $auszug;
	$total = count( $set['items'] );
	$cls   = 'mvk-kat mvk-kat--' . sanitize_html_class( $layout ) . ( $full ? ' mvk-kat--full' : ' mvk-kat--auszug' );
	$h     = '<div class="' . esc_attr( $cls ) . '"' . ( $full ? ' id="' . esc_attr( $anchor ) . '"' : '' ) . ' data-zeigen="' . (int) $a['zeigen'] . '" data-anker="' . esc_attr( $anchor ) . '" data-einheit="' . esc_attr( $einheit[0] . '|' . $einheit[1] ) . '">';

	if ( $full && ! empty( $set['finder'] ) && '0' !== (string) $a['finder'] ) {
		$h .= mvkd_katalog_finder( $set['finder'] );
	}

	if ( $full && $facets ) {
		$h .= '<div class="mvk-kat__tools">';
		$h .= '<button type="button" class="mvk-kat__toggle" aria-expanded="false">Filter <span class="mvk-kat__nsel"></span></button>';
		$h .= '<div class="mvk-kat__facets">';
		foreach ( $facets as $fc ) {
			$h .= '<fieldset class="mvk-kat__facet"><legend>' . esc_html( $fc['label'] ) . '</legend><div class="mvk-kat__chips">';
			foreach ( $fc['values'] as $v => $label ) {
				$n = 0;
				foreach ( $set['items'] as $it ) {
					if ( in_array( $v, isset( $it['f'][ $fc['key'] ] ) ? (array) $it['f'][ $fc['key'] ] : array(), true ) ) {
						$n++;
					}
				}
				if ( ! $n ) {
					continue;
				}
				$h .= '<button type="button" class="mvk-kat__chip" aria-pressed="false" data-f="' . esc_attr( $fc['key'] ) . '" data-v="' . esc_attr( $v ) . '">' . esc_html( $label ) . ' <span class="mvk-kat__n">' . $n . '</span></button>';
			}
			$h .= '</div></fieldset>';
		}
		$h .= '</div>';
		$h .= '<div class="mvk-kat__status"><p class="mvk-kat__count" aria-live="polite"><b>' . $total . '</b> ' . esc_html( $total === 1 ? $einheit[0] : $einheit[1] ) . '</p>';
		$h .= '<button type="button" class="mvk-kat__reset" hidden>Filter zurücksetzen</button></div>';
		$h .= '</div>';
	}

	$h .= '<ul class="mvk-kat__grid" role="list">';
	foreach ( $items as $i => $it ) {
		$h .= 'muster' === $layout ? mvkd_katalog_swatch( $it, $set ) : mvkd_katalog_card( $it, $set, $facets, $i );
	}
	$h .= '</ul>';

	if ( $full ) {
			$leer = ! empty( $set['leer'] ) ? $set['leer'] : 'Für diese Kombination gibt es keinen Eintrag. Lösen Sie einen Filter oder fragen Sie uns.';
			$h   .= '<p class="mvk-kat__empty" hidden>' . esc_html( $leer ) . ' <a href="' . esc_url( home_url( '/kontakt/' ) ) . '">Zur Beratung</a></p>';
		$h .= '<div class="mvk-kat__more-wrap"><button type="button" class="mvk-kat__more" hidden></button></div>';
		if ( ! empty( $set['nachweis'] ) ) {
			$h .= '<p class="mvk-kat__credit">' . esc_html( $set['nachweis'] ) . '</p>';
		}
		$h .= mvkd_katalog_schema( $set );
	} elseif ( $a['link'] ) {
		$label = isset( $set['auszug_link'] ) ? $set['auszug_link'] : 'Zum vollständigen Katalog';
		$h    .= '<p class="mvk-kat__all"><a href="' . esc_url( $a['link'] ) . '">' . esc_html( str_replace( '%n', (string) $total, $label ) ) . '</a></p>';
	}
	$h .= '</div>';
	return $h;
}

function mvkd_katalog_tags( $it, $facets ) {
	$tags = array();
	foreach ( $facets as $fc ) {
		if ( ! empty( $fc['hide_tag'] ) || empty( $it['f'][ $fc['key'] ] ) ) {
			continue;
		}
		foreach ( (array) $it['f'][ $fc['key'] ] as $v ) {
			if ( isset( $fc['values'][ $v ] ) ) {
				$tags[] = $fc['values'][ $v ];
			}
		}
	}
	return array_slice( array_unique( $tags ), 0, 5 );
}

function mvkd_katalog_dataf( $it ) {
	$out = '';
	foreach ( (array) ( isset( $it['f'] ) ? $it['f'] : array() ) as $k => $vals ) {
		$out .= ' data-k-' . esc_attr( $k ) . '="' . esc_attr( implode( ' ', (array) $vals ) ) . '"';
	}
	return $out;
}

function mvkd_katalog_lb( $it, $name ) {
	$list = array();
	foreach ( (array) ( isset( $it['imgs'] ) ? $it['imgs'] : array() ) as $id ) {
		$src = mvkd_katalog_src( $id, 'large' );
		if ( $src ) {
			$list[] = array( 'src' => $src, 'alt' => mvkd_katalog_alt( $id, $name ), 'cap' => $name );
		}
	}
	return $list;
}

function mvkd_katalog_card( $it, $set, $facets, $i ) {
	$name   = $it['name'];
	$pre    = isset( $set['prefix'] ) ? $set['prefix'] . ' ' : '';
	$imgs   = isset( $it['imgs'] ) ? (array) $it['imgs'] : array();
	$first  = $imgs ? $imgs[0] : 0;
	$lb     = mvkd_katalog_lb( $it, $pre . $name );
	$img    = mvkd_katalog_img( $first, 'medium_large', array(
		'class'   => 'mvk-kat__img',
		'loading' => 'lazy',
		'sizes'   => '(min-width: 1100px) 400px, (min-width: 640px) 46vw, 92vw',
		'alt'     => mvkd_katalog_alt( $first, $pre . $name ),
	) );
	$full   = $lb ? $lb[0]['src'] : '';
	$anchor = 'modell-' . $it['id'];

	$h  = '<li class="mvk-kat__item" id="' . esc_attr( $anchor ) . '"' . mvkd_katalog_dataf( $it ) . '>';
	$h .= '<article class="mvk-kat__card">';
	if ( $img ) {
		$h .= '<a class="mvk-kat__fig" href="' . esc_url( $full ) . '" data-lb="' . esc_attr( mvkd_json( $lb ) ) . '" aria-label="' . esc_attr( 'Bilder zu ' . $pre . $name . ' ansehen (' . count( $lb ) . ')' ) . '">' . $img;
		if ( count( $lb ) > 1 ) {
			$h .= '<span class="mvk-kat__nimg" aria-hidden="true">' . count( $lb ) . ' Bilder</span>';
		}
		$h .= '</a>';
	}
	$h .= '<div class="mvk-kat__body">';
	if ( ! empty( $it['linie'] ) ) {
		$h .= '<p class="mvk-kat__line">' . esc_html( $it['linie'] ) . '</p>';
	}
	$h .= '<h3 class="mvk-kat__name">' . esc_html( $name ) . ( ! empty( $it['zusatz'] ) ? ' <span>' . esc_html( $it['zusatz'] ) . '</span>' : '' ) . '</h3>';
	if ( ! empty( $it['text'] ) ) {
		$h .= '<p class="mvk-kat__text">' . mvkd_kses( $it['text'] ) . '</p>';
	}
	$tags = mvkd_katalog_tags( $it, $facets );
	if ( $tags ) {
		$h .= '<ul class="mvk-kat__tags" role="list"><li>' . implode( '</li><li>', array_map( 'esc_html', $tags ) ) . '</li></ul>';
	}
	if ( ! empty( $it['daten'] ) ) {
		$h .= '<details class="mvk-kat__spec"><summary>Front, Farbe, Material</summary><dl>';
		foreach ( $it['daten'] as $row ) {
			$h .= '<dt>' . esc_html( $row[0] ) . '</dt><dd>' . esc_html( $row[1] ) . '</dd>';
		}
		$h .= '</dl></details>';
	}
	if ( ! empty( $set['cta'] ) ) {
		$h .= '<a class="mvk-kat__cta" href="' . esc_url( home_url( $set['cta']['path'] ) ) . '">' . esc_html( str_replace( '%s', $pre . $name, $set['cta']['label'] ) ) . '</a>';
	}
	$h .= '</div></article></li>';
	return $h;
}

function mvkd_katalog_swatch( $it, $set ) {
	$imgs  = isset( $it['imgs'] ) ? (array) $it['imgs'] : array();
	$first = $imgs ? $imgs[0] : 0;
	$name  = $it['name'];
	$img   = mvkd_katalog_img( $first, 'medium', array(
		'class'   => 'mvk-kat__img',
		'loading' => 'lazy',
		'sizes'   => '(min-width: 1100px) 160px, 30vw',
		'alt'     => mvkd_katalog_alt( $first, 'Ballerina Front ' . $name ),
	) );
	$lb    = mvkd_katalog_lb( $it, $name . ( ! empty( $it['nr'] ) ? ' · ' . $it['nr'] : '' ) );
	$h     = '<li class="mvk-kat__item mvk-kat__sw"' . mvkd_katalog_dataf( $it ) . '>';
	$h    .= '<a class="mvk-kat__fig" href="' . esc_url( $lb ? $lb[0]['src'] : '' ) . '" data-lb="' . esc_attr( mvkd_json( $lb ) ) . '" aria-label="' . esc_attr( 'Farbmuster ' . $name . ' vergrößern' ) . '">' . $img . '</a>';
	$h    .= '<p class="mvk-kat__swname">' . esc_html( $name ) . '</p>';
	if ( ! empty( $it['nr'] ) || ! empty( $it['art'] ) ) {
		$h .= '<p class="mvk-kat__swmeta">' . esc_html( trim( ( ! empty( $it['art'] ) ? $it['art'] : '' ) . ( ! empty( $it['nr'] ) ? ' · ' . $it['nr'] : '' ), ' ·' ) ) . '</p>';
	}
	$h    .= '</li>';
	return $h;
}

function mvkd_katalog_finder( $fd ) {
	$h  = '<div class="mvk-kat__finder" data-finder="' . esc_attr( mvkd_json( $fd['fragen'] ) ) . '"' . ( ! empty( $fd['leer'] ) ? ' data-leer="' . esc_attr( $fd['leer'] ) . '"' : '' ) . '>';
	$h .= '<p class="mvk-kat__fk">' . esc_html( $fd['kicker'] ) . '</p>';
	$h .= '<p class="mvk-kat__ft">' . esc_html( $fd['titel'] ) . '</p>';
	$h .= '<ol class="mvk-kat__fq">';
	foreach ( $fd['fragen'] as $qi => $q ) {
		$h .= '<li><p class="mvk-kat__fqt" id="mvk-fq-' . (int) $qi . '">' . esc_html( $q['frage'] ) . '</p><div class="mvk-kat__fa" role="group" aria-labelledby="mvk-fq-' . (int) $qi . '">';
		foreach ( $q['antworten'] as $ai => $ans ) {
			$h .= '<button type="button" aria-pressed="false" data-q="' . (int) $qi . '" data-a="' . (int) $ai . '">' . esc_html( $ans['label'] ) . '</button>';
		}
		$h .= '</div></li>';
	}
	$h .= '</ol>';
	$h .= '<div class="mvk-kat__fres"><p aria-live="polite"></p><a class="mvk-kat__fgo" href="#" hidden>Passende Modelle ansehen</a></div>';
	$h .= '</div>';
	return $h;
}

function mvkd_katalog_schema( $set ) {
	if ( empty( $set['schema'] ) || ! function_exists( 'get_permalink' ) ) {
		return '';
	}
	$url  = get_permalink();
	$list = array();
	$pre  = isset( $set['prefix'] ) ? $set['prefix'] . ' ' : '';
	foreach ( $set['items'] as $i => $it ) {
		$e = array(
			'@type'    => 'ListItem',
			'position' => $i + 1,
			'name'     => $pre . $it['name'],
			'url'      => $url . '#modell-' . $it['id'],
		);
		$src = ! empty( $it['imgs'] ) ? mvkd_katalog_src( $it['imgs'][0], 'large' ) : '';
		if ( $src ) {
			$e['image'] = $src;
		}
		$list[] = $e;
	}
	$data = array(
		'@context'        => 'https://schema.org',
		'@type'           => 'ItemList',
		'name'            => $set['schema'],
		'numberOfItems'   => count( $list ),
		'itemListElement' => $list,
	);
	return '<script type="application/ld+json">' . mvkd_json( $data ) . '</script>';
}

function mvkd_json( $d ) {
	$j = function_exists( 'wp_json_encode' ) ? wp_json_encode( $d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) : json_encode( $d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
	return str_replace( array( '</', '<!--' ), array( '<\/', '<\!--' ), (string) $j );
}

function mvkd_kses( $s ) {
	return function_exists( 'wp_kses_post' ) ? wp_kses_post( $s ) : strip_tags( $s, '<strong><em><b><i><a><br>' );
}

/* ------------------------------------------------------------------ */
/* Korpus im Schnitt (Ballerina, Werte laut Hersteller, Stand 11/2026) */
/* ------------------------------------------------------------------ */
function mvkd_korpus_sc() {
	// Maßstab: 1 cm = 6 px. Schrank: 61 cm tief, 84,5 cm Korpushöhe. Beschriftung der Punkte steht als Liste im HTML (lesbar auf jedem Bildschirm).
	$s   = 6;
	$x0  = 120;           // Front (links)
	$y0  = 96;            // Oberkante Korpus
	$d   = 61 * $s;       // 366 px Tiefe
	$hh  = 84.5 * $s;     // 507 px Höhe
	$x1  = $x0 + $d;      // Rückwand-Außenseite
	$old = $x0 + 55.5 * $s;
	$sh  = $y0 + $hh * 0.47; // Querboden
	$bt  = 3.2;           // 8 mm Rückwand (überhöht dargestellt)
	$r   = '#D9010C';
	$a   = '#16171B';
	$g   = '#888B92';

	$o  = '<svg viewBox="0 0 600 660" xmlns="http://www.w3.org/2000/svg" role="img" aria-labelledby="mvk-korpus-t mvk-korpus-d" focusable="false">';
	$o .= '<title id="mvk-korpus-t">Ballerina-Unterschrank im Schnitt</title>';
	$o .= '<desc id="mvk-korpus-d">Seitenschnitt eines Ballerina-Unterschranks: 61 Zentimeter Korpustiefe statt bisher 55,5 Zentimeter, 84,5 Zentimeter Korpushöhe. Nummerierte Punkte: 1 Rückwand, 2 Querboden, 3 Lochreihe, 4 Kante.</desc>';
	$o .= sprintf( '<rect x="%d" y="%d" width="%d" height="%d" fill="#fff" stroke="%s" stroke-width="2"/>', $x0, $y0, $d, $hh, $a );
	$o .= sprintf( '<rect x="%.1f" y="%d" width="%.1f" height="%.1f" fill="%s" fill-opacity=".08"/>', $old, $y0, $x1 - $old, $hh, $r );
	$o .= sprintf( '<line x1="%.1f" y1="%d" x2="%.1f" y2="%.1f" stroke="%s" stroke-width="1.5" stroke-dasharray="6 6"/>', $old, $y0 - 4, $old, $y0 + $hh + 4, $g );
	$o .= sprintf( '<rect x="%.1f" y="%d" width="%.1f" height="%.1f" fill="%s"/>', $x1 - $bt - 2, $y0 + 2, $bt, $hh - 4, $a );
	for ( $k = 1; $k <= 4; $k++ ) {
		$o .= sprintf( '<rect x="%.1f" y="%.1f" width="5" height="5" fill="#fff" stroke="%s" stroke-width="1.4"/>', $x1 - $bt / 2 - 4.5, $y0 + $hh * $k / 5 - 2.5, $a );
	}
	$o .= sprintf( '<rect x="%d" y="%.1f" width="%.1f" height="7" fill="%s"/>', $x0 + 22, $sh, $d - 22 - $bt - 4, $a );
	for ( $k = 0; $k < 14; $k++ ) {
		$o .= sprintf( '<rect x="%.1f" y="%.1f" width="3" height="3" fill="%s"/>', $x0 + 38.5, $y0 + 68.5 + $k * 24, $g );
	}
	$o .= sprintf( '<rect x="%d" y="%d" width="14" height="%.1f" fill="#E9E6E1" stroke="%s" stroke-width="1.5"/>', $x0 - 16, $y0 + 4, $hh - 8, $a );
	$o .= sprintf( '<rect x="%d" y="%.1f" width="%d" height="22" fill="%s" fill-opacity=".12"/>', $x0 + 30, $y0 + $hh, $d - 40, $a );

	// Maßlinie Tiefe (oben)
	$ty = $y0 - 40;
	$o .= sprintf( '<path d="M%d %dH%.1fM%d %dV%dM%.1f %dV%d" stroke="%s" stroke-width="2" fill="none"/>', $x0, $ty, $x1, $x0, $ty - 10, $ty + 10, $x1, $ty - 10, $ty + 10, $r );
	$o .= sprintf( '<text x="%.1f" y="%d" text-anchor="middle" class="mvk-korpus__big" fill="%s">61 cm Tiefe</text>', ( $x0 + $x1 ) / 2, $ty - 14, $a );
	// Zuwachs (rechts oben)
	$o .= sprintf( '<path d="M%.1f %dH%.1f" stroke="%s" stroke-width="4"/>', $old, $y0 - 12, $x1, $r );
	$o .= sprintf( '<text x="%.1f" y="%d" class="mvk-korpus__lbl" fill="%s">+5,5 cm</text>', $x1 + 12, $y0 - 6, $r );
	$o .= sprintf( '<text x="%.1f" y="%.1f" text-anchor="end" class="mvk-korpus__sm" fill="%s">bisher 55,5 cm</text>', $old - 10, $y0 + $hh - 16, $g );
	// Maßlinie Höhe (links)
	$lx = $x0 - 50;
	$o .= sprintf( '<path d="M%d %dV%.1fM%d %dH%dM%d %.1fH%d" stroke="%s" stroke-width="2" fill="none"/>', $lx, $y0, $y0 + $hh, $lx - 10, $y0, $lx + 10, $lx - 10, $y0 + $hh, $lx + 10, $r );
	$o .= sprintf( '<text transform="translate(%d %.1f) rotate(-90)" text-anchor="middle" class="mvk-korpus__big" fill="%s">84,5 cm Höhe</text>', $lx - 16, $y0 + $hh / 2, $a );

	// Nummernmarken (eckig, rot)
	$marks = array(
		array( $x1 - 30, $y0 + $hh * 0.32, $x1 - $bt - 2 ),
		array( $x0 + $d * 0.56, $sh - 26, $x0 + $d * 0.56 ),
		array( $x0 + 74, $y0 + 68 + 9 * 24, $x0 + 42 ),
		array( $x0 + 22, $y0 + $hh * 0.86, $x0 - 2 ),
	);
	foreach ( $marks as $n => $m ) {
		if ( 1 === $n ) {
			$o .= sprintf( '<path d="M%.1f %.1fV%.1f" stroke="%s" stroke-width="1.5"/>', $m[0], $m[1] + 13, $sh, $r );
		} else {
			$o .= sprintf( '<path d="M%.1f %.1fH%.1f" stroke="%s" stroke-width="1.5"/>', $m[0], $m[1], $m[2], $r );
		}
		$o .= sprintf( '<rect x="%.1f" y="%.1f" width="26" height="26" fill="%s"/>', $m[0] - 13, $m[1] - 13, $r );
		$o .= sprintf( '<text x="%.1f" y="%.1f" text-anchor="middle" class="mvk-korpus__no" fill="#fff">%d</text>', $m[0], $m[1] + 6.5, $n + 1 );
	}
	$o .= '</svg>';

	$pts = array(
		array( '8 mm Rückwand', 'verschraubt, dadurch besonders stabil' ),
		array( '19 mm Querboden', 'für hohe Belastung ausgelegt' ),
		array( '3-mm-Lochreihe', 'Metall-Bodenträger, fest arretiert, mit Kippsicherung' ),
		array( 'PUR-Kanten', 'verleimt und feuchtigkeitsbeständig' ),
	);
	$l = '<ol class="mvk-korpus__legend">';
	foreach ( $pts as $p ) {
		$l .= '<li><b>' . esc_html( $p[0] ) . '</b> ' . esc_html( $p[1] ) . '</li>';
	}
	$l .= '<li class="mvk-korpus__x"><b>26 Korpusfarben</b> innen und außen dekorgleich, auf Wunsch als Akzent</li>';
	$l .= '<li class="mvk-korpus__x"><b>CARB2-Platten</b> formaldehydreduzierte Holzwerkstoffe</li>';
	$l .= '</ol>';

	return '<figure class="mvk-korpus"><div class="mvk-korpus__wrap">' . $o . $l . '</div><figcaption>Unterschrank im Schnitt, Maße und Angaben laut Ballerina-Küchen. Gestrichelt: die bisherige Korpustiefe von 55,5 cm.</figcaption></figure>';
}

/* ------------------------------------------------------------------ */
/* REST: Übersicht der Kataloge (nur lesen, für Prüfungen)             */
/* ------------------------------------------------------------------ */
add_action( 'rest_api_init', function () {
	register_rest_route( 'mvk-design/v1', '/katalog', array(
		'methods'             => 'GET',
		'permission_callback' => function () { return current_user_can( 'edit_pages' ); },
		'callback'            => function () {
			$out = array();
			foreach ( mvkd_katalog_sets() as $id => $s ) {
				$missing = 0;
				foreach ( $s['items'] as $it ) {
					foreach ( (array) ( isset( $it['imgs'] ) ? $it['imgs'] : array() ) as $mid ) {
						if ( ! function_exists( 'wp_attachment_is_image' ) || ! wp_attachment_is_image( (int) $mid ) ) {
							$missing++;
						}
					}
				}
				$out[] = array( 'id' => $id, 'items' => count( $s['items'] ), 'layout' => isset( $s['layout'] ) ? $s['layout'] : 'karten', 'fehlende_bilder' => $missing );
			}
			return array( 'version' => MVKD_VERSION, 'sets' => $out );
		},
	) );
} );
