<?php
/**
 * Plugin Name: MVK Design
 * Description: Fundament für MVK Redesign v2. Modul Medien (Bildtexte, Inventar, WebP, Umbenennen mit 301) und Modul Designsystem (Schriften, Bausteine mit mvk-Klassen, Bühne, Footer, Kontaktleiste, Grundriss-Werkzeug, FAQ-Schema) und Modul Katalog (Herstellerkataloge mit Filter, Stilfinder und Korpus-Schnitt). Das Designsystem wirkt nur auf v2-Seiten. Keine externen Requests.
 * Version: 0.5.3
 * Author: oriqen
 * Author URI: https://oriqen.de/
 * Requires PHP: 7.4
 * Text Domain: mvk-design
 */

defined( 'ABSPATH' ) || exit;

define( 'MVKD_VERSION', '0.5.3' );
define( 'MVKD_DIR', plugin_dir_path( __FILE__ ) );
define( 'MVKD_URL', plugin_dir_url( __FILE__ ) );

require_once MVKD_DIR . 'modules/medien.php';
require_once MVKD_DIR . 'modules/design.php';
require_once MVKD_DIR . 'modules/katalog.php';
