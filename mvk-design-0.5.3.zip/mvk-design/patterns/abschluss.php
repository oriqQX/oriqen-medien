<?php
defined( 'ABSPATH' ) || exit;
return array(
	'title'   => 'MVK Abschluss mit drei Wegen',
	'content' => <<<'MVK'
<!-- wp:group {"tagName":"section","align":"full","className":"mvk-section mvk-close"} -->
<section class="wp-block-group alignfull mvk-section mvk-close"><!-- wp:group {"className":"mvk-wide"} -->
<div class="wp-block-group mvk-wide"><!-- wp:group {"className":"mvk-head"} -->
<div class="wp-block-group mvk-head"><!-- wp:paragraph {"className":"mvk-kicker"} -->
<p class="mvk-kicker">Ihr nächster Schritt</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Überschrift</h2>
<!-- /wp:heading --></div>
<!-- /wp:group -->
<!-- wp:columns {"className":"mvk-close__ways"} -->
<div class="wp-block-columns mvk-close__ways"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"mvk-icon mvk-icon\u002d\u002dstudio"} -->
<p class="mvk-icon mvk-icon--studio"></p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Showroom besuchen</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Nickelstraße 30, 33378 Rheda-Wiedenbrück</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"mvk-icon mvk-icon\u002d\u002dhand"} -->
<p class="mvk-icon mvk-icon--hand"></p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Anrufen</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"mvk-close__big"} -->
<p class="mvk-close__big"><a href="tel:+495242406840">05242 406840</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"mvk-icon mvk-icon\u002d\u002dplan"} -->
<p class="mvk-icon mvk-icon--plan"></p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Küchenplaner</h3>
<!-- /wp:heading -->
<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-mvk-rot"} -->
<div class="wp-block-button is-style-mvk-rot"><a class="wp-block-button__link wp-element-button" href="https://mvk-kuechen-und-raumdesign.de/kontakt/kuechenplaner/">Küche planen</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
MVK
);
