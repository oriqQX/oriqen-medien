<?php
defined( 'ABSPATH' ) || exit;
return array(
	'title'   => 'MVK Bildband mit Zielpunkt-Callouts (Bild 5:2, Klassen mvk-x-NN mvk-y-NN mvk-lead-N, mvk-to-l)',
	'content' => <<<'MVK'
<!-- wp:group {"align":"full","className":"mvk-strip mvk-strip\u002d\u002dpt"} -->
<div class="wp-block-group alignfull mvk-strip mvk-strip--pt"><!-- wp:image {"id":1867,"sizeSlug":"full","linkDestination":"none","className":"mvk-cut"} -->
<figure class="wp-block-image size-full mvk-cut"><img src="https://mvk-kuechen-und-raumdesign.de/wp-content/uploads/2026/09/mvk-grifflose-kueche-anthrazit-kochinsel-lippstadt.webp" alt="" class="wp-image-1867"/></figure>
<!-- /wp:image -->
<!-- wp:paragraph {"className":"mvk-callout mvk-pt mvk-to-l mvk-x-40 mvk-y-50 mvk-lead-8"} -->
<p class="mvk-callout mvk-pt mvk-to-l mvk-x-40 mvk-y-50 mvk-lead-8"><strong>Grifflos</strong></p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"mvk-callout mvk-pt mvk-x-60 mvk-y-80 mvk-lead-10"} -->
<p class="mvk-callout mvk-pt mvk-x-60 mvk-y-80 mvk-lead-10"><strong>Kochinsel</strong></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
MVK
);
