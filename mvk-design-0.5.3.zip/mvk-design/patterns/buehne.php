<?php
defined( 'ABSPATH' ) || exit;
return array(
	'title'   => 'MVK Bühne mit Stufenpanel',
	'content' => <<<'MVK'
<!-- wp:group {"align":"full","className":"mvk-stage mvk-page-v2"} -->
<div class="wp-block-group alignfull mvk-stage mvk-page-v2"><!-- wp:image {"id":1861,"sizeSlug":"full","linkDestination":"none","className":"mvk-stage__img"} -->
<figure class="wp-block-image size-full mvk-stage__img"><img src="https://mvk-kuechen-und-raumdesign.de/wp-content/uploads/2026/09/mvk-kuechenstudio-rheda-wiedenbrueck-ausstellung-kochinsel-grau.webp" alt="" class="wp-image-1861"/></figure>
<!-- /wp:image -->
<!-- wp:group {"className":"mvk-stage__track"} -->
<div class="wp-block-group mvk-stage__track"><!-- wp:group {"className":"mvk-hero-card"} -->
<div class="wp-block-group mvk-hero-card"><!-- wp:group {"className":"mvk-steppanel"} -->
<div class="wp-block-group mvk-steppanel"><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Überschrift der Seite, normale Schreibung</h1>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"mvk-triad"} -->
<p class="mvk-triad">Beratung · Planung · Montage</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
<!-- wp:group {"className":"mvk-steppanel__sub"} -->
<div class="wp-block-group mvk-steppanel__sub"><!-- wp:paragraph -->
<p>Einleitung der Seite.</p>
<!-- /wp:paragraph -->
<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-mvk-rot"} -->
<div class="wp-block-button is-style-mvk-rot"><a class="wp-block-button__link wp-element-button" href="https://mvk-kuechen-und-raumdesign.de/kontakt/kuechenplaner/">Küche planen</a></div>
<!-- /wp:button -->
<!-- wp:button {"className":"is-style-mvk-linie"} -->
<div class="wp-block-button is-style-mvk-linie"><a class="wp-block-button__link wp-element-button" href="https://mvk-kuechen-und-raumdesign.de/unser-kuechenstudio-rheda-wiedenbrueck/">Showroom besuchen</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
<!-- wp:group {"className":"mvk-stage__panel"} -->
<div class="wp-block-group mvk-stage__panel"><!-- wp:paragraph {"className":"mvk-kicker"} -->
<p class="mvk-kicker">Kicker · Thema</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Überschrift Panel</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Text des Panels.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
MVK
);
