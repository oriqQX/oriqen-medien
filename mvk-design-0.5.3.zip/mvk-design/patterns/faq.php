<?php
defined( 'ABSPATH' ) || exit;
return array(
	'title'   => 'MVK FAQ mit Nummernmarke',
	'content' => <<<'MVK'
<!-- wp:group {"tagName":"section","align":"full","className":"mvk-section"} -->
<section class="wp-block-group alignfull mvk-section"><!-- wp:group {"className":"mvk-wide"} -->
<div class="wp-block-group mvk-wide"><!-- wp:columns {"className":"mvk-faq-wrap"} -->
<div class="wp-block-columns mvk-faq-wrap"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"mvk-kicker"} -->
<p class="mvk-kicker">Häufige Fragen</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Fragen zum Thema</h2>
<!-- /wp:heading --></div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"mvk-faq"} -->
<div class="wp-block-group mvk-faq"><!-- wp:details -->
<details class="wp-block-details"><summary>Frage eins?</summary><!-- wp:paragraph -->
<p>Antwort.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->
<!-- wp:details -->
<details class="wp-block-details"><summary>Frage zwei?</summary><!-- wp:paragraph -->
<p>Antwort.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->
<!-- wp:details -->
<details class="wp-block-details"><summary>Frage drei?</summary><!-- wp:paragraph -->
<p>Antwort.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
MVK
);
