<?php
defined( 'ABSPATH' ) || exit;
return array(
	'title'   => 'MVK Nutzen-Leiste',
	'content' => <<<'MVK'
<!-- wp:group {"align":"full","className":"mvk-benefits-wrap"} -->
<div class="wp-block-group alignfull mvk-benefits-wrap"><!-- wp:group {"className":"mvk-wide"} -->
<div class="wp-block-group mvk-wide"><!-- wp:columns {"className":"mvk-benefits"} -->
<div class="wp-block-columns mvk-benefits"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"mvk-icon mvk-icon\u002d\u002dhand"} -->
<p class="mvk-icon mvk-icon--hand"></p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"mvk-benefit__t"} -->
<p class="mvk-benefit__t">Titel eins</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p>Zwei kurze Zeilen.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"mvk-icon mvk-icon\u002d\u002dmass"} -->
<p class="mvk-icon mvk-icon--mass"></p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"mvk-benefit__t"} -->
<p class="mvk-benefit__t">Titel zwei</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p>Zwei kurze Zeilen.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"mvk-icon mvk-icon\u002d\u002dmontage"} -->
<p class="mvk-icon mvk-icon--montage"></p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"mvk-benefit__t"} -->
<p class="mvk-benefit__t">Titel drei</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p>Zwei kurze Zeilen.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
MVK
);
