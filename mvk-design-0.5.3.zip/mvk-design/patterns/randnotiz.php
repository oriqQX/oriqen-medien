<?php
defined( 'ABSPATH' ) || exit;
return array(
	'title'   => 'MVK Zweispalter mit Randnotiz',
	'content' => <<<'MVK'
<!-- wp:group {"tagName":"section","align":"full","className":"mvk-section"} -->
<section class="wp-block-group alignfull mvk-section"><!-- wp:group {"className":"mvk-wide"} -->
<div class="wp-block-group mvk-wide"><!-- wp:group {"className":"mvk-head"} -->
<div class="wp-block-group mvk-head"><!-- wp:paragraph {"className":"mvk-kicker"} -->
<p class="mvk-kicker">Kicker</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Überschrift</h2>
<!-- /wp:heading --></div>
<!-- /wp:group -->
<!-- wp:columns {"className":"mvk-notes"} -->
<div class="wp-block-columns mvk-notes"><!-- wp:column {"className":"mvk-notes__text"} -->
<div class="wp-block-column mvk-notes__text"><!-- wp:paragraph -->
<p>Langtext, läuft in zwei Spalten.</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p>Zweiter Absatz.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->
<!-- wp:column {"className":"mvk-notes__aside"} -->
<div class="wp-block-column mvk-notes__aside"><!-- wp:paragraph {"className":"mvk-callout"} -->
<p class="mvk-callout"><strong>Passgenau</strong> Fakt am Rand.</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"mvk-callout"} -->
<p class="mvk-callout"><strong>Alles aus einer Hand</strong> Fakt am Rand.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
MVK
);
