<?php
defined( 'ABSPATH' ) || exit;
return array(
	'title'   => 'MVK Reiter-Viewer',
	'content' => <<<'MVK'
<!-- wp:group {"tagName":"section","align":"full","className":"mvk-section"} -->
<section class="wp-block-group alignfull mvk-section"><!-- wp:group {"className":"mvk-wide"} -->
<div class="wp-block-group mvk-wide"><!-- wp:group {"className":"mvk-viewer"} -->
<div class="wp-block-group mvk-viewer"><!-- wp:group {"className":"mvk-viewer__panel"} -->
<div class="wp-block-group mvk-viewer__panel"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:image {"id":598,"sizeSlug":"large","linkDestination":"none","className":"mvk-cut"} -->
<figure class="wp-block-image size-large mvk-cut"><img src="https://mvk-kuechen-und-raumdesign.de/wp-content/uploads/2026/02/mvk-grifflose-kueche-schmaler-kochinsel-paderborn.webp" alt="" class="wp-image-598"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Variante eins</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Text.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
<!-- wp:group {"className":"mvk-viewer__panel"} -->
<div class="wp-block-group mvk-viewer__panel"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:image {"id":603,"sizeSlug":"large","linkDestination":"none","className":"mvk-cut"} -->
<figure class="wp-block-image size-large mvk-cut"><img src="https://mvk-kuechen-und-raumdesign.de/wp-content/uploads/2026/02/mvk-landhauskueche-kochinsel-paderborn.webp" alt="" class="wp-image-603"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Variante zwei</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Text.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
MVK
);
