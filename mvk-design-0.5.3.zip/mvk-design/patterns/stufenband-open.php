<?php
defined( 'ABSPATH' ) || exit;
return array(
	'title'   => 'MVK Stufenband Öffnung',
	'content' => <<<'MVK'
<!-- wp:group {"tagName":"section","align":"full","className":"mvk-band mvk-band\u002d\u002dopen"} -->
<section class="wp-block-group alignfull mvk-band mvk-band--open"><!-- wp:group {"className":"mvk-wide"} -->
<div class="wp-block-group mvk-wide"><!-- wp:group {"className":"mvk-head"} -->
<div class="wp-block-group mvk-head"><!-- wp:paragraph {"className":"mvk-kicker"} -->
<p class="mvk-kicker">Kicker · Thema</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Überschrift des Kapitels</h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"mvk-lead"} -->
<p class="mvk-lead">Einleitung des Kapitels.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
<!-- wp:paragraph -->
<p>Text des Kapitels.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
MVK
);
