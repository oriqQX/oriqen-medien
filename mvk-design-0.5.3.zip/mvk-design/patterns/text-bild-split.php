<?php
defined( 'ABSPATH' ) || exit;
return array(
	'title'   => 'MVK Text-Bild-Split (Foto klebt)',
	'content' => <<<'MVK'
<!-- wp:group {"tagName":"section","align":"full","className":"mvk-section"} -->
<section class="wp-block-group alignfull mvk-section"><!-- wp:group {"className":"mvk-wide"} -->
<div class="wp-block-group mvk-wide"><!-- wp:columns {"className":"mvk-split"} -->
<div class="wp-block-columns mvk-split"><!-- wp:column {"className":"mvk-split__media"} -->
<div class="wp-block-column mvk-split__media"><!-- wp:image {"id":1868,"sizeSlug":"large","linkDestination":"none","className":"mvk-cut"} -->
<figure class="wp-block-image size-large mvk-cut"><img src="https://mvk-kuechen-und-raumdesign.de/wp-content/uploads/2026/09/mvk-helle-l-kueche-magnolia-massivholz-tresen-herzebrock-clarholz.webp" alt="" class="wp-image-1868"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"mvk-kicker"} -->
<p class="mvk-kicker">Kicker · Thema</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Überschrift</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Langtext.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
MVK
);
