<?php
defined( 'ABSPATH' ) || exit;
return array(
	'title'   => 'MVK Vergleichsraster mit Filter',
	'content' => <<<'MVK'
<!-- wp:group {"tagName":"section","align":"full","className":"mvk-section"} -->
<section class="wp-block-group alignfull mvk-section"><!-- wp:group {"className":"mvk-wide"} -->
<div class="wp-block-group mvk-wide"><!-- wp:group {"className":"mvk-head"} -->
<div class="wp-block-group mvk-head"><!-- wp:paragraph {"className":"mvk-kicker"} -->
<p class="mvk-kicker">Kicker</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Überschrift</h2>
<!-- /wp:heading --></div>
<!-- /wp:group -->
<!-- wp:group {"className":"mvk-grid"} -->
<div class="wp-block-group mvk-grid"><!-- wp:group {"className":"mvk-card"} -->
<div class="wp-block-group mvk-card"><!-- wp:image {"id":623,"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="https://mvk-kuechen-und-raumdesign.de/wp-content/uploads/2026/02/mvk-marmor-arbeitsplatte-maserung-paderborn.webp" alt="" class="wp-image-623"/></figure>
<!-- /wp:image -->
<!-- wp:paragraph {"className":"mvk-card__tag"} -->
<p class="mvk-card__tag">Naturstein-Optik</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Variante eins</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Kurzer Text.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
<!-- wp:group {"className":"mvk-card"} -->
<div class="wp-block-group mvk-card"><!-- wp:image {"id":629,"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="https://mvk-kuechen-und-raumdesign.de/wp-content/uploads/2026/02/mvk-keramik-arbeitsplatte-praeziser-kante-rietberg.webp" alt="" class="wp-image-629"/></figure>
<!-- /wp:image -->
<!-- wp:paragraph {"className":"mvk-card__tag"} -->
<p class="mvk-card__tag">Keramik</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Variante zwei</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Kurzer Text.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
<!-- wp:group {"className":"mvk-card"} -->
<div class="wp-block-group mvk-card"><!-- wp:image {"id":626,"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="https://mvk-kuechen-und-raumdesign.de/wp-content/uploads/2026/02/mvk-matte-arbeitsplatte-anthrazit-lage.webp" alt="" class="wp-image-626"/></figure>
<!-- /wp:image -->
<!-- wp:paragraph {"className":"mvk-card__tag"} -->
<p class="mvk-card__tag">Kompaktlaminat</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Variante drei</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Kurzer Text.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
MVK
);
