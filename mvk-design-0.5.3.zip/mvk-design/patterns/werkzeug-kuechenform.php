<?php
defined( 'ABSPATH' ) || exit;
return array(
	'title'   => 'MVK Werkzeug Küchenform',
	'content' => <<<'MVK'
<!-- wp:group {"tagName":"section","align":"full","className":"mvk-section"} -->
<section class="wp-block-group alignfull mvk-section"><!-- wp:group {"className":"mvk-wide"} -->
<div class="wp-block-group mvk-wide"><!-- wp:group {"className":"mvk-viewer mvk-tool"} -->
<div class="wp-block-group mvk-viewer mvk-tool"><!-- wp:group {"className":"mvk-viewer__panel"} -->
<div class="wp-block-group mvk-viewer__panel"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:shortcode -->
[mvk_grundriss form="l"]
<!-- /wp:shortcode --></div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">L-Küche</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Text.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
<!-- wp:group {"className":"mvk-viewer__panel"} -->
<div class="wp-block-group mvk-viewer__panel"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:shortcode -->
[mvk_grundriss form="insel"]
<!-- /wp:shortcode --></div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Kochinsel</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Text.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
MVK
);
