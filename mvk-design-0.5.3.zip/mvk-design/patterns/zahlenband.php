<?php
defined( 'ABSPATH' ) || exit;
return array(
	'title'   => 'MVK Zahlenband',
	'content' => <<<'MVK'
<!-- wp:group {"tagName":"section","align":"full","className":"mvk-section mvk-fog"} -->
<section class="wp-block-group alignfull mvk-section mvk-fog"><!-- wp:group {"className":"mvk-wide"} -->
<div class="wp-block-group mvk-wide"><!-- wp:columns {"className":"mvk-figures"} -->
<div class="wp-block-columns mvk-figures"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"mvk-figure__num"} -->
<p class="mvk-figure__num">10</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"mvk-figure__lbl"} -->
<p class="mvk-figure__lbl">Musterküchen</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"mvk-figure__txt"} -->
<p class="mvk-figure__txt">auf zwei Ebenen</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"mvk-figure__num"} -->
<p class="mvk-figure__num">60</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"mvk-figure__lbl"} -->
<p class="mvk-figure__lbl">Oberflächen</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"mvk-figure__txt"} -->
<p class="mvk-figure__txt">zum Anfassen</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"mvk-figure__num"} -->
<p class="mvk-figure__num">40</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"mvk-figure__lbl"} -->
<p class="mvk-figure__lbl">Griffe</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"mvk-figure__txt"} -->
<p class="mvk-figure__txt">zum Vergleichen</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
MVK
);
