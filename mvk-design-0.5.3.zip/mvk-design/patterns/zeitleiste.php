<?php
defined( 'ABSPATH' ) || exit;
return array(
	'title'   => 'MVK Zeitleiste Ablauf',
	'content' => <<<'MVK'
<!-- wp:group {"tagName":"section","align":"full","className":"mvk-section mvk-fog"} -->
<section class="wp-block-group alignfull mvk-section mvk-fog"><!-- wp:group {"className":"mvk-wide"} -->
<div class="wp-block-group mvk-wide"><!-- wp:group {"className":"mvk-head"} -->
<div class="wp-block-group mvk-head"><!-- wp:paragraph {"className":"mvk-kicker"} -->
<p class="mvk-kicker">Ablauf</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Überschrift</h2>
<!-- /wp:heading --></div>
<!-- /wp:group -->
<!-- wp:group {"className":"mvk-steps"} -->
<div class="wp-block-group mvk-steps"><!-- wp:group {"className":"mvk-step"} -->
<div class="wp-block-group mvk-step"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Erstgespräch</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Text.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
<!-- wp:group {"className":"mvk-step"} -->
<div class="wp-block-group mvk-step"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">3D-Planung</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Text.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
<!-- wp:group {"className":"mvk-step"} -->
<div class="wp-block-group mvk-step"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Aufmaß vor Ort</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Text.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
<!-- wp:group {"className":"mvk-step"} -->
<div class="wp-block-group mvk-step"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Lieferung und Montage</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Text.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
<!-- wp:group {"className":"mvk-step"} -->
<div class="wp-block-group mvk-step"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Übergabe und Service</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Text.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
MVK
);
