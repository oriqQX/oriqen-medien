<?php
/**
 * MVK Design: Modul Designsystem (0.3.0).
 * Schriften, Tokens, Bausteine (mvk-Klassen auf Core-Blöcken), Bühne, Footer, Kontaktleiste,
 * Grundriss-Werkzeug, FAQ-Schema, Blockvorlagen. Wirkt nur auf v2-Seiten (mvkd_is_v2).
 */
defined( 'ABSPATH' ) || exit;

/* ------------------------------------------------------------------ */
/* 1. Einstellungen                                                    */
/* ------------------------------------------------------------------ */
function mvkd_design_opt( $key = null ) {
	$d = array(
		'footer_global' => false,
		'rating'        => '5,0',
		'stars'         => 5,
		'google_url'    => 'https://www.google.com/maps/place/MVK+K%C3%BCchen+%26+Raumdesign/@51.8329366,8.3650368,17z/data=!4m6!3m5!1s0x47ba4d3edfed40ff:0x8ca6de0d7e8e9754!8m2!3d51.8329366!4d8.3650368!16s%2Fg%2F11fn70pkvc',
		'route_url'     => 'https://www.google.com/maps/dir/?api=1&destination=MVK+K%C3%BCchen+%26+Raumdesign%2C+Nickelstra%C3%9Fe+30%2C+33378+Rheda-Wiedenbr%C3%BCck',
		'phone'         => '05242 406840',
		'phone_href'    => '+495242406840',
		'termin_url'    => '/kontakt/',
		'logo_id'       => 2009,
	);
	$o = wp_parse_args( (array) get_option( 'mvkd_design', array() ), $d );
	return null === $key ? $o : ( $o[ $key ] ?? null );
}

/* ------------------------------------------------------------------ */
/* 2. v2-Erkennung                                                     */
/* ------------------------------------------------------------------ */
/* Bestandsseiten nutzen eigene mvk-Klassen (mvk-sec, mvk-note, mvk-btn, mvk-reviews ...).
   Deshalb zählt nur die ausdrückliche Markierung: Klasse mvk-page-v2 oder Metafeld _mvkd_v2. */
function mvkd_content_is_v2( $content ) {
	return (bool) preg_match( '/\bmvk-page-v2\b/', (string) $content );
}

function mvkd_is_v2( $post_id = 0 ) {
	static $cache = array();
	if ( ! $post_id ) {
		if ( ! is_singular() ) {
			return false;
		}
		$post_id = get_queried_object_id();
	}
	if ( isset( $cache[ $post_id ] ) ) {
		return $cache[ $post_id ];
	}
	$on = (bool) get_post_meta( $post_id, '_mvkd_v2', true );
	if ( ! $on ) {
		$p  = get_post( $post_id );
		$on = $p && mvkd_content_is_v2( $p->post_content );
	}
	return $cache[ $post_id ] = $on;
}

function mvkd_footer_active() {
	return mvkd_design_opt( 'footer_global' ) || mvkd_is_v2();
}

/* ------------------------------------------------------------------ */
/* 3. Assets                                                           */
/* ------------------------------------------------------------------ */
add_filter( 'body_class', function ( $c ) {
	if ( mvkd_is_v2() ) {
		$c[] = 'mvk-v2';
	}
	if ( mvkd_footer_active() ) {
		$c[] = 'mvk-has-foot';
	}
	return $c;
} );

add_action( 'wp_enqueue_scripts', function () {
	if ( ! mvkd_is_v2() && ! mvkd_footer_active() ) {
		return;
	}
	$css = MVKD_DIR . 'assets/css/mvk.css';
	$js  = MVKD_DIR . 'assets/js/mvk.js';
	wp_enqueue_style( 'mvk-design', MVKD_URL . 'assets/css/mvk.css', array(), MVKD_VERSION . '.' . ( file_exists( $css ) ? filemtime( $css ) : 0 ) );
	if ( mvkd_is_v2() ) {
		wp_enqueue_script( 'mvk-design', MVKD_URL . 'assets/js/mvk.js', array(), MVKD_VERSION . '.' . ( file_exists( $js ) ? filemtime( $js ) : 0 ), array( 'in_footer' => true, 'strategy' => 'defer' ) );
	}
}, 20 );

add_action( 'wp_head', function () {
	if ( ! mvkd_is_v2() ) {
		return;
	}
	echo "<script>document.documentElement.classList.add('mvk-js');</script>\n";
	foreach ( array( 'barlow-condensed-latin-800-normal.woff2', 'montserrat-latin-wght-normal.woff2' ) as $f ) {
		printf( '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url( MVKD_URL . 'assets/fonts/' . $f ) );
	}
}, 2 );

/* Editor: bewusst ohne Frontend-CSS (Bühne und Stufen würden die Bearbeitung stören). Editor-Stile folgen. */

/* ------------------------------------------------------------------ */
/* 4. Blockstile und Vorlagen                                          */
/* ------------------------------------------------------------------ */
add_action( 'init', function () {
	if ( function_exists( 'register_block_style' ) ) {
		register_block_style( 'core/button', array( 'name' => 'mvk-rot', 'label' => 'MVK Rot' ) );
		register_block_style( 'core/button', array( 'name' => 'mvk-linie', 'label' => 'MVK Linie' ) );
	}
	if ( function_exists( 'register_block_pattern_category' ) ) {
		register_block_pattern_category( 'mvk-design', array( 'label' => 'MVK Design' ) );
		foreach ( glob( MVKD_DIR . 'patterns/*.php' ) as $file ) {
			$p = include $file;
			if ( is_array( $p ) && ! empty( $p['content'] ) ) {
				register_block_pattern( 'mvk-design/' . basename( $file, '.php' ), array(
					'title'      => $p['title'],
					'categories' => array( 'mvk-design' ),
					'content'    => $p['content'],
				) );
			}
		}
	}
	add_shortcode( 'mvk_grundriss', 'mvkd_grundriss_sc' );
	add_shortcode( 'mvk_dusche', 'mvkd_dusche_sc' );
} );

/* ------------------------------------------------------------------ */
/* 5. Footer und Kontaktleiste                                         */
/* ------------------------------------------------------------------ */
add_action( 'wp', function () {
	if ( is_admin() || ! mvkd_footer_active() ) {
		return;
	}
	remove_action( 'generate_footer', 'generate_construct_footer_widgets', 5 );
	remove_action( 'generate_footer', 'generate_construct_footer' );
	add_action( 'generate_footer', 'mvkd_footer', 10 );
	add_action( 'wp_footer', 'mvkd_contact_bar', 5 );
}, 20 );

function mvkd_icon( $name ) {
	$p = array(
		'phone' => '<path d="M5 3h4l2 5-2.5 1.5a11 11 0 0 0 6 6L16 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 5a2 2 0 0 1 2-2"/>',
		'cal'   => '<path d="M4 6h16v14H4zM4 10h16M8 3v5M16 3v5M8 14h3v3H8z"/>',
		'route' => '<path d="M12 21s-6-5.6-6-11a6 6 0 0 1 12 0c0 5.4-6 11-6 11z"/><path d="M12 7.5v5M9.5 10h5"/>',
		'star'  => '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z"/>',
		'arrow' => '<path d="M4 12h15M14 7l5 5-5 5"/>',
	);
	return '<svg class="mvk-ico" viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="square" aria-hidden="true" focusable="false">' . ( $p[ $name ] ?? '' ) . '</svg>';
}

/* Copyright der Bestandsseiten (GeneratePress-Footer): nur Firmenname, der oriqen-Verweis steht einmal im Band von oriqen Support. Ersetzt Snippet 5. */
add_filter( 'generate_copyright', function () {
	return '<span class="copyright">&copy; ' . esc_html( gmdate( 'Y' ) ) . ' MVK Küchen &amp; Raumdesign</span>';
}, 99 );

function mvkd_footer_links() {
	return array(
		'Leistungen' => array(
			array( 'Maßküchen & Küchenplanung', '/kuechen-kuechenplanung/', 1 ),
			array( 'Küchenausstattung', '/kuechen-kuechenplanung/kuechen-ausstattung/', 2 ),
			array( 'Ballerina Küchen', '/kuechen-kuechenplanung/ballerina-kuechen/', 2 ),
			array( 'Nolte Küchen', '/kuechen-kuechenplanung/nolte-kuechen/', 2 ),
			array( 'Miele Einbaugeräte', '/kuechen-kuechenplanung/miele-einbaugeraete/', 2 ),
			array( 'NEFF Einbaugeräte', '/kuechen-kuechenplanung/neff-einbaugeraete/', 2 ),
			array( 'Glasduschen nach Maß', '/glasduschen/', 1 ),
			array( 'Duschkabinen Varianten', '/glasduschen/duschkabinen-varianten/', 2 ),
			array( 'Erkelenz Glas', '/glasduschen/erkelenz-glas/', 2 ),
			array( 'Glastüren & Glastrennwände', '/glastueren-glastrennwaende/', 1 ),
			array( 'Gewerbe und Büro', '/glastueren-glastrennwaende/gewerbe-buero/', 2 ),
			array( 'Innentüren', '/innentueren/', 1 ),
		),
		'Magazin'    => array(
			array( 'Küchen Ratgeber', '/kuechen-ratgeber/', 1 ),
			array( 'Glasduschen Ratgeber', '/glasduschen-ratgeber/', 1 ),
			array( 'Innentüren Ratgeber', '/innentueren-ratgeber/', 1 ),
			array( 'Aktuelles', '/aktuelles/', 1 ),
		),
	);
}

function mvkd_footer() {
	$o     = mvkd_design_opt();
	$home  = home_url( '/' );
	$logo  = $o['logo_id'] ? wp_get_attachment_image( (int) $o['logo_id'], 'medium', false, array( 'class' => 'mvk-foot__logo', 'loading' => 'lazy', 'alt' => 'MVK Küchen & Raumdesign' ) ) : '';
	$stars = str_repeat( mvkd_icon( 'star' ), max( 0, min( 5, (int) $o['stars'] ) ) );
	$arrow = mvkd_icon( 'arrow' );
	$area  = array( 'Paderborn', 'Bielefeld', 'Gütersloh', 'Lippstadt', 'Detmold', 'Herford', 'Delbrück', 'Rietberg', 'Verl', 'Salzkotten', 'Schloß Holte-Stukenbrock', 'Warendorf', 'Oelde', 'Harsewinkel' );
	ob_start();
	?>
	<div class="mvk-foot" role="contentinfo">
		<div class="mvk-foot__space" aria-hidden="true"></div>
		<div class="mvk-foot__band">
			<div class="mvk-foot__in">
				<div class="mvk-foot__grid">
					<section class="mvk-foot__panel" aria-label="Direkter Kontakt">
						<p class="mvk-foot__k">Direkt sprechen</p>
						<a class="mvk-foot__phone" href="tel:<?php echo esc_attr( $o['phone_href'] ); ?>"><?php echo esc_html( $o['phone'] ); ?></a>
						<p class="mvk-foot__hours">Mo bis Fr 9 bis 18 Uhr<br>Sa 9 bis 13 Uhr</p>
						<div class="mvk-foot__go">
							<a href="<?php echo esc_url( home_url( $o['termin_url'] ) ); ?>">Termin vereinbaren <?php echo $arrow; // phpcs:ignore ?></a>
							<a href="<?php echo esc_url( $o['route_url'] ); ?>" target="_blank" rel="noopener">Route planen <?php echo $arrow; // phpcs:ignore ?></a>
							<a href="<?php echo esc_url( home_url( '/kontakt/kuechenplaner/' ) ); ?>">Küche online planen <?php echo $arrow; // phpcs:ignore ?></a>
						</div>
					</section>
					<div class="mvk-foot__brand">
						<a href="<?php echo esc_url( $home ); ?>" class="mvk-foot__home"><?php echo $logo; // phpcs:ignore ?></a>
						<p class="mvk-foot__claimline">Individuelle Küchen · Glasduschen · Glas Lofttüren &amp; Wände · Zimmertüren</p>
						<p class="mvk-foot__one">Alles aus einer Hand: Beratung, Aufmaß, Planung und Montage.</p>
					</div>
					<?php foreach ( mvkd_footer_links() as $title => $links ) : ?>
						<nav class="mvk-foot__col mvk-foot__nav" aria-label="<?php echo esc_attr( $title ); ?>">
							<p class="mvk-foot__h"><?php echo esc_html( $title ); ?></p>
							<ul>
								<?php foreach ( $links as $l ) : ?>
									<li class="mvk-foot__l<?php echo (int) $l[2]; ?>"><a href="<?php echo esc_url( home_url( $l[1] ) ); ?>"><?php echo esc_html( $l[0] ); ?></a></li>
								<?php endforeach; ?>
							</ul>
						</nav>
					<?php endforeach; ?>
					<div class="mvk-foot__col mvk-foot__studio">
						<p class="mvk-foot__h">Studio</p>
						<address>
							<strong>MVK Küchen &amp; Raumdesign</strong><br>
							Nickelstraße 30<br>
							33378 Rheda-Wiedenbrück
						</address>
						<ul class="mvk-foot__more">
							<li><a href="<?php echo esc_url( home_url( '/unser-kuechenstudio-rheda-wiedenbrueck/' ) ); ?>">Unser Küchenstudio</a></li>
							<li><a href="<?php echo esc_url( home_url( '/kontakt/kuechenplaner/' ) ); ?>">Küchenplaner</a></li>
							<li><a href="<?php echo esc_url( home_url( '/karriere/' ) ); ?>">Karriere</a></li>
							<li><a href="<?php echo esc_url( home_url( '/kontakt/' ) ); ?>">Kontakt</a></li>
						</ul>
					</div>
				</div>
				<div class="mvk-foot__dim"><b>Einsatzgebiet · rund 60 km</b></div>
				<p class="mvk-foot__cities"><?php echo esc_html( implode( "\u{00A0}· ", $area ) ); ?> und Orte im Umkreis. Entscheidend ist Ihr Projekt, nicht die Entfernung.</p>
				<div class="mvk-foot__meta">
					<p><span class="mvk-foot__lbl">Partner</span> <span class="mvk-foot__marks">Ballerina Küchen · Nolte Küchen · NEFF · Miele · Quooker · Erkelenz Glas · Grauthoff</span></p>
					<a class="mvk-foot__rating" href="<?php echo esc_url( $o['google_url'] ); ?>" target="_blank" rel="noopener" aria-label="<?php echo esc_attr( 'Google-Bewertung ' . $o['rating'] . ' von 5: Bewertungen ansehen' ); ?>">
						<span class="mvk-foot__score">Google <?php echo esc_html( $o['rating'] ); ?></span>
						<span class="mvk-foot__stars" aria-hidden="true"><?php echo $stars; // phpcs:ignore ?></span>
					</a>
				</div>
				<div class="mvk-foot__base">
					<p>© <?php echo esc_html( gmdate( 'Y' ) ); ?> MVK Küchen &amp; Raumdesign</p>
					<ul>
						<li><a href="<?php echo esc_url( home_url( '/impressum/' ) ); ?>">Impressum</a></li>
						<li><a href="<?php echo esc_url( home_url( '/datenschutz/' ) ); ?>">Datenschutz</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<?php
	echo ob_get_clean(); // phpcs:ignore
}

function mvkd_contact_bar() {
	$o = mvkd_design_opt();
	?>
	<nav class="mvk-cbar" aria-label="Schnellkontakt">
		<a href="tel:<?php echo esc_attr( $o['phone_href'] ); ?>"><?php echo mvkd_icon( 'phone' ); // phpcs:ignore ?><span>Anrufen</span></a>
		<a href="<?php echo esc_url( home_url( $o['termin_url'] ) ); ?>"><?php echo mvkd_icon( 'cal' ); // phpcs:ignore ?><span>Termin</span></a>
		<a href="<?php echo esc_url( $o['route_url'] ); ?>" target="_blank" rel="noopener"><?php echo mvkd_icon( 'route' ); // phpcs:ignore ?><span>Route</span></a>
	</nav>
	<?php
}

/* ------------------------------------------------------------------ */
/* 6. FAQ-Schema aus mvk-faq                                           */
/* ------------------------------------------------------------------ */
function mvkd_faq_items( $blocks, $inside = false, &$out = array() ) {
	foreach ( $blocks as $b ) {
		$cls = $b['attrs']['className'] ?? '';
		$in  = $inside || ( 'core/group' === $b['blockName'] && preg_match( '/\bmvk-faq\b/', $cls ) );
		if ( $in && 'core/details' === $b['blockName'] ) {
			$html = render_block( $b );
			if ( preg_match( '#<summary[^>]*>(.*?)</summary>(.*)</details>#s', $html, $m ) ) {
				$q = trim( wp_strip_all_tags( $m[1] ) );
				$a = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( $m[2] ) ) );
				if ( $q && $a ) {
					$out[] = array( '@type' => 'Question', 'name' => $q, 'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $a ) );
				}
			}
			continue;
		}
		if ( ! empty( $b['innerBlocks'] ) ) {
			mvkd_faq_items( $b['innerBlocks'], $in, $out );
		}
	}
	return $out;
}

add_action( 'wp_head', function () {
	if ( ! mvkd_is_v2() ) {
		return;
	}
	$p = get_post( get_queried_object_id() );
	if ( ! $p || false === strpos( $p->post_content, 'mvk-faq' ) ) {
		return;
	}
	$items = mvkd_faq_items( parse_blocks( $p->post_content ) );
	if ( count( $items ) < 3 ) {
		return;
	}
	$data = array( '@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $items );
	echo '<script type="application/ld+json" class="mvk-faq-schema">' . wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . "</script>\n";
}, 30 );

/* ------------------------------------------------------------------ */
/* 7. Grundriss-Werkzeug [mvk_grundriss form="l"]                      */
/* ------------------------------------------------------------------ */
function mvkd_grundriss_forms() {
	// Räume in cm (1 Einheit = 1 cm). Schränke: x, y, b, t. Geräte: typ, x, y. Maße: Liste.
	return array(
		'zeile'      => array( 'label' => 'Küchenzeile', 'room' => array( 420, 300 ), 'cab' => array( array( 30, 0, 360, 60 ) ), 'app' => array( array( 'f', 60, 30 ), array( 's', 190, 30 ), array( 'h', 320, 30 ) ), 'dim' => array( array( 'h', 30, 390, -30, 'Zeile' ) ) ),
		'zweizeilig' => array( 'label' => 'Zweizeilige Küche', 'room' => array( 420, 300 ), 'cab' => array( array( 30, 0, 360, 60 ), array( 30, 240, 300, 60 ) ), 'app' => array( array( 'f', 60, 30 ), array( 's', 200, 30 ), array( 'h', 180, 270 ) ), 'dim' => array( array( 'v', 60, 240, 400, 'ca. 1,20 m', 'l' ) ) ),
		'l'          => array( 'label' => 'L-Küche', 'room' => array( 420, 320 ), 'cab' => array( array( 0, 0, 380, 60 ), array( 0, 60, 60, 220 ) ), 'app' => array( array( 's', 200, 30 ), array( 'h', 330, 30 ), array( 'f', 30, 240 ) ), 'dim' => array( array( 'h', 0, 380, -30, 'Schenkel 1' ), array( 'v', 0, 280, -30, 'Schenkel 2' ) ) ),
		'u'          => array( 'label' => 'U-Küche', 'room' => array( 420, 320 ), 'cab' => array( array( 0, 0, 420, 60 ), array( 0, 60, 60, 200 ), array( 360, 60, 60, 200 ) ), 'app' => array( array( 's', 210, 30 ), array( 'h', 390, 190 ), array( 'f', 30, 200 ) ), 'dim' => array( array( 'h', 60, 360, 290, 'ca. 1,20 m' ) ) ),
		'g'          => array( 'label' => 'G-Küche', 'room' => array( 440, 340 ), 'cab' => array( array( 0, 0, 440, 60 ), array( 0, 60, 60, 220 ), array( 380, 60, 60, 220 ), array( 200, 220, 180, 60 ) ), 'app' => array( array( 's', 220, 30 ), array( 'h', 410, 160 ), array( 'f', 30, 200 ) ), 'dim' => array( array( 'v', 60, 220, 250, 'ca. 1,20 m' ) ) ),
		'insel'      => array( 'label' => 'Küche mit Kochinsel', 'room' => array( 460, 380 ), 'cab' => array( array( 40, 0, 380, 60 ), array( 110, 180, 240, 100 ) ), 'app' => array( array( 's', 160, 30 ), array( 'f', 390, 30 ), array( 'h', 230, 230 ) ), 'dim' => array( array( 'v', 60, 180, 80, 'ca. 1,20 m' ) ) ),
		'halbinsel'  => array( 'label' => 'Küche mit Halbinsel', 'room' => array( 440, 340 ), 'cab' => array( array( 0, 0, 400, 60 ), array( 300, 60, 100, 180 ) ), 'app' => array( array( 'f', 30, 30 ), array( 's', 170, 30 ), array( 'h', 350, 170 ) ), 'dim' => array( array( 'v', 60, 240, 260, 'Halbinsel', 'l' ) ) ),
	);
}

function mvkd_grundriss_svg( $form ) {
	$forms = mvkd_grundriss_forms();
	if ( empty( $forms[ $form ] ) ) {
		return '';
	}
	$f      = $forms[ $form ];
	list( $w, $h ) = $f['room'];
	$pad    = 60;
	$vb     = sprintf( '%d %d %d %d', -$pad, -$pad, $w + 2 * $pad, $h + 2 * $pad );
	$s      = '<svg class="mvk-plan" viewBox="' . $vb . '" role="img" aria-label="' . esc_attr( 'Grundriss-Schema: ' . $f['label'] ) . '" xmlns="http://www.w3.org/2000/svg">';
	$s     .= '<rect class="mvk-plan__room" x="0" y="0" width="' . $w . '" height="' . $h . '"/>';
	foreach ( $f['cab'] as $c ) {
		$s .= sprintf( '<rect class="mvk-plan__cab" x="%d" y="%d" width="%d" height="%d"/>', $c[0], $c[1], $c[2], $c[3] );
	}
	$pts = array();
	foreach ( $f['app'] as $a ) {
		list( $t, $x, $y ) = $a;
		$pts[]             = $x . ',' . $y;
		if ( 's' === $t ) {
			$s .= sprintf( '<rect class="mvk-plan__app" x="%d" y="%d" width="56" height="36"/><rect class="mvk-plan__app" x="%d" y="%d" width="40" height="24"/>', $x - 28, $y - 18, $x - 20, $y - 12 );
		} elseif ( 'h' === $t ) {
			$s .= sprintf( '<rect class="mvk-plan__app" x="%d" y="%d" width="56" height="44"/>', $x - 28, $y - 22 );
			foreach ( array( array( -13, -10 ), array( 13, -10 ), array( -13, 10 ), array( 13, 10 ) ) as $o ) {
				$s .= sprintf( '<circle class="mvk-plan__app" cx="%d" cy="%d" r="7"/>', $x + $o[0], $y + $o[1] );
			}
		} else {
			$s .= sprintf( '<rect class="mvk-plan__app" x="%d" y="%d" width="50" height="50"/><path class="mvk-plan__app" d="M%d %dL%d %d"/>', $x - 25, $y - 25, $x - 25, $y - 25, $x + 25, $y + 25 );
		}
	}
	if ( count( $pts ) === 3 ) {
		$s .= '<polygon class="mvk-plan__tri" points="' . implode( ' ', $pts ) . '"/>';
	}
	foreach ( $f['dim'] as $d ) {
		list( $o, $a, $b, $pos, $label ) = $d;
		$left = isset( $d[5] ) && 'l' === $d[5];
		if ( 'h' === $o ) {
			$s .= sprintf( '<g class="mvk-plan__dim"><path d="M%1$d %3$dH%2$d M%1$d %4$dV%5$d M%2$d %4$dV%5$d"/><text x="%6$d" y="%7$d" text-anchor="middle">%8$s</text></g>', $a, $b, $pos, $pos - 8, $pos + 8, ( $a + $b ) / 2, $pos - 10, esc_html( $label ) );
		} else {
			$s .= sprintf( '<g class="mvk-plan__dim"><path d="M%3$d %1$dV%2$d M%4$d %1$dH%5$d M%4$d %2$dH%5$d"/><text x="%6$d" y="%7$d" text-anchor="%9$s">%8$s</text></g>', $a, $b, $pos, $pos - 8, $pos + 8, $left ? $pos - 12 : $pos + 12, ( $a + $b ) / 2 + 5, esc_html( $label ), $left ? 'end' : 'start' );
		}
	}
	$s .= '</svg>';
	return $s;
}

function mvkd_grundriss_sc( $atts ) {
	$a = shortcode_atts( array( 'form' => 'l' ), $atts );
	return '<figure class="mvk-plan-fig">' . mvkd_grundriss_svg( sanitize_key( $a['form'] ) ) . '<figcaption>Schema, nicht maßstäblich. Rot: Arbeitsdreieck aus Kühlen, Spülen und Kochen.</figcaption></figure>';
}

/* ------------------------------------------------------------------ */
/* 7b. Duschform-Werkzeug [mvk_dusche form="nische"] (0.9.0)           */
/* ------------------------------------------------------------------ */
/**
 * Schemata der Duschformen in Draufsicht (eine Ansicht von vorn), Einheit cm, y nach vorn (unten = Raum).
 * Elemente: wall, floor, drain, glas, door, arc (Schwenkbereich), bar (Stabilisierungsstange), rail, arrow, tub, pane (Ansicht),
 * dim (h|v, von, bis, Lage, Text, Seite), lbl (x, y, Text, Ausrichtung). vb = sichtbarer Ausschnitt in cm.
 */
function mvkd_dusche_forms() {
	$w = 10; // Wandstärke im Schema
	return array(
		'nische'          => array( 'label' => 'Nischendusche mit Pendeltür und Festteil', 'vb' => array( -60, -55, 250, 235 ), 'el' => array(
			array( 'floor', 0, 0, 120, 90 ), array( 'drain', 60, 45 ),
			array( 'wall', -$w, -$w, 120 + 2 * $w, $w ), array( 'wall', -$w, 0, $w, 90 ), array( 'wall', 120, 0, $w, 90 ),
			array( 'glas', 0, 90, 45, 90 ), array( 'door', 45, 90, 120, 90 ),
			array( 'arc', 45, 90, 75, 0, 90 ), array( 'arc', 45, 90, 75, 0, -90 ),
			array( 'lbl', 22, 108, 'Festteil' ), array( 'lbl', 84, 108, 'Pendeltür' ),
			array( 'dim', 'h', 0, 120, -32, 'Nischenbreite' ), array( 'dim', 'v', 0, 90, 152, 'Tiefe' ),
		) ),
		'doppelfluegel'   => array( 'label' => 'Nischendusche mit Doppelflügeltür', 'vb' => array( -60, -55, 270, 235 ), 'el' => array(
			array( 'floor', 0, 0, 140, 90 ), array( 'drain', 70, 45 ),
			array( 'wall', -$w, -$w, 140 + 2 * $w, $w ), array( 'wall', -$w, 0, $w, 90 ), array( 'wall', 140, 0, $w, 90 ),
			array( 'door', 0, 90, 70, 90 ), array( 'door', 70, 90, 140, 90 ),
			array( 'arc', 0, 90, 70, 0, 90 ), array( 'arc', 0, 90, 70, 0, -90 ), array( 'arc', 140, 90, 70, 180, 90 ), array( 'arc', 140, 90, 70, 180, 270 ),
			array( 'lbl', 35, 110, 'Flügel' ), array( 'lbl', 105, 110, 'Flügel' ),
			array( 'dim', 'h', 0, 140, -32, 'Nischenbreite' ), array( 'dim', 'v', 0, 90, 172, 'Tiefe' ),
		) ),
		'nische-oberteil' => array( 'label' => 'Nischendusche mit Oberteil', 'view' => 'Ansicht von vorn', 'vb' => array( -70, -40, 270, 320 ), 'el' => array(
			array( 'wall', -$w, -$w, $w, 260 + $w ), array( 'wall', 120, -$w, $w, 260 + $w ), array( 'wall', -$w, -$w, 120 + 2 * $w, $w ), array( 'wall', -$w, 250, 120 + 2 * $w, 6 ),
			array( 'pane', 0, 0, 44, 250 ), array( 'pane', 46, 0, 74, 48 ), array( 'pane', 46, 50, 74, 200, 'door' ),
			array( 'lbl', 22, 150, 'Festteil' ), array( 'lbl', 83, 28, 'Oberteil' ), array( 'lbl', 83, 150, 'Tür' ),
			array( 'dim', 'v', 50, 250, 150, 'Türhöhe' ), array( 'dim', 'v', 0, 48, 150, 'bis Decke' ), array( 'dim', 'h', 0, 120, 272, 'Nischenbreite' ),
		) ),
		'eck-nische'      => array( 'label' => 'Eck-Nischenlösung mit mehreren Glaselementen', 'vb' => array( -60, -55, 250, 250 ), 'el' => array(
			array( 'floor', 0, 0, 120, 100 ), array( 'drain', 60, 50 ),
			array( 'wall', -$w, -$w, 120 + 2 * $w, $w ), array( 'wall', -$w, 0, $w, 100 ),
			array( 'glas', 120, 0, 120, 100 ), array( 'glas', 0, 100, 35, 100 ), array( 'door', 35, 100, 95, 100 ), array( 'glas', 95, 100, 120, 100 ),
			array( 'arc', 35, 100, 60, 0, 90 ), array( 'arc', 35, 100, 60, 0, -90 ),
			array( 'lbl', 17, 118, 'Festteil' ), array( 'lbl', 65, 118, 'Tür' ), array( 'lbl', 140, 50, 'Festteil', 'start' ), array( 'lbl', 128, 116, 'Eck-Beschlag', 'start' ),
			array( 'dim', 'h', 0, 120, -32, 'Breite' ), array( 'dim', 'v', 0, 100, -32, 'Tiefe', 'l' ),
		) ),
		'fuenfeck'        => array( 'label' => 'Fünfeckdusche', 'vb' => array( -60, -55, 230, 230 ), 'el' => array(
			array( 'floor', 0, 0, 100, 100, array( array( 0, 0 ), array( 100, 0 ), array( 100, 35 ), array( 35, 100 ), array( 0, 100 ) ) ), array( 'drain', 42, 42 ),
			array( 'wall', -$w, -$w, 100 + $w, $w ), array( 'wall', -$w, 0, $w, 100 ),
			array( 'glas', 100, 0, 100, 35 ), array( 'glas', 35, 100, 0, 100 ), array( 'door', 100, 35, 67.5, 67.5 ), array( 'door', 35, 100, 67.5, 67.5 ),
			array( 'arc', 100, 35, 46, 135, 225 ), array( 'arc', 35, 100, 46, 315, 225 ),
			array( 'lbl', 116, 20, 'Festteil', 'start' ), array( 'lbl', 17, 118, 'Festteil' ), array( 'lbl', 96, 92, 'zwei Flügel', 'start' ),
			array( 'dim', 'h', 0, 100, -32, 'Breite' ), array( 'dim', 'v', 0, 100, -32, 'Tiefe', 'l' ),
		) ),
		'fuenfeck-gross'  => array( 'label' => 'Fünfeckdusche in Übergröße', 'vb' => array( -60, -55, 270, 270 ), 'el' => array(
			array( 'floor', 0, 0, 140, 140, array( array( 0, 0 ), array( 140, 0 ), array( 140, 60 ), array( 60, 140 ), array( 0, 140 ) ) ), array( 'drain', 60, 60 ),
			array( 'wall', -$w, -$w, 140 + $w, $w ), array( 'wall', -$w, 0, $w, 140 ),
			array( 'glas', 140, 0, 140, 60 ), array( 'glas', 60, 140, 0, 140 ), array( 'door', 140, 60, 100, 100 ), array( 'door', 60, 140, 100, 100 ),
			array( 'arc', 140, 60, 56.6, 135, 225 ), array( 'arc', 60, 140, 56.6, 315, 225 ),
			array( 'lbl', 156, 30, 'Festteil', 'start' ), array( 'lbl', 30, 158, 'Festteil' ), array( 'lbl', 128, 128, 'zwei Flügel', 'start' ),
			array( 'dim', 'h', 0, 140, -32, 'Breite' ), array( 'dim', 'v', 0, 140, -32, 'Tiefe', 'l' ),
		) ),
		'eckdusche'       => array( 'label' => 'Eckdusche mit Drehtür und Seitenteil', 'vb' => array( -60, -55, 240, 255 ), 'el' => array(
			array( 'floor', 0, 0, 100, 90 ), array( 'drain', 50, 45 ),
			array( 'wall', -$w, -$w, 100 + $w, $w ), array( 'wall', -$w, 0, $w, 90 ),
			array( 'glas', 100, 0, 100, 90 ), array( 'door', 0, 90, 100, 90 ),
			array( 'arc', 0, 90, 100, 0, 90 ),
			array( 'lbl', 50, 108, 'Tür' ), array( 'lbl', 116, 45, 'Seitenteil', 'start' ),
			array( 'dim', 'h', 0, 100, -32, 'Breite' ), array( 'dim', 'v', 0, 90, -32, 'Tiefe', 'l' ),
		) ),
		'walkin'          => array( 'label' => 'Walk-In-Dusche', 'vb' => array( -60, -55, 270, 205 ), 'el' => array(
			array( 'floor', 0, 0, 140, 90 ), array( 'drain', 45, 45 ),
			array( 'wall', -$w, -$w, 140 + 2 * $w, $w ), array( 'wall', -$w, 0, $w, 90 ),
			array( 'glas', 0, 90, 90, 90 ), array( 'bar', 70, 90, 70, 0 ),
			array( 'lbl', 115, 80, 'offen' ), array( 'lbl', 76, 30, 'Stange', 'start' ),
			array( 'dim', 'h', 0, 90, 126, 'Festteil' ), array( 'dim', 'h', 90, 140, 126, 'Einstieg' ), array( 'dim', 'v', 0, 90, 172, 'Tiefe' ),
		) ),
		'u-dusche'        => array( 'label' => 'U-Dusche', 'vb' => array( -60, -55, 270, 235 ), 'el' => array(
			array( 'floor', 0, 0, 140, 90 ), array( 'drain', 70, 45 ),
			array( 'wall', -$w - 20, -$w, 140 + 2 * $w + 40, $w ),
			array( 'glas', 0, 0, 0, 90 ), array( 'glas', 140, 0, 140, 90 ), array( 'glas', 0, 90, 40, 90 ), array( 'door', 40, 90, 100, 90 ), array( 'glas', 100, 90, 140, 90 ),
			array( 'arc', 40, 90, 60, 0, 90 ), array( 'arc', 40, 90, 60, 0, -90 ),
			array( 'lbl', 20, 108, 'Festteil' ), array( 'lbl', 120, 108, 'Festteil' ), array( 'lbl', 70, 108, 'Tür' ),
			array( 'dim', 'h', 0, 140, -32, 'Breite' ), array( 'dim', 'v', 0, 90, 172, 'Tiefe' ),
		) ),
		'badewanne'       => array( 'label' => 'Falttür auf der Badewanne', 'vb' => array( -55, -55, 290, 205 ), 'el' => array(
			array( 'wall', -$w, -$w, 170 + 2 * $w, $w ), array( 'wall', -$w, 0, $w, 75 ), array( 'wall', 170, 0, $w, 75 ),
			array( 'tub', 0, 0, 170, 75 ),
			array( 'glas', 0, 75, 40, 75 ), array( 'door', 40, 75, 80, 75 ), array( 'arc', 0, 75, 80, 0, -90 ),
			array( 'lbl', 40, 93, 'zwei Faltflügel' ), array( 'lbl', 120, 40, 'Wanne' ),
			array( 'dim', 'h', 0, 80, 110, 'Aufsatz' ), array( 'dim', 'h', 0, 170, -32, 'Wannenlänge' ),
		) ),
		'nische-schiebe'  => array( 'label' => 'Nischendusche mit Schiebetür', 'vb' => array( -60, -55, 270, 210 ), 'el' => array(
			array( 'floor', 0, 0, 140, 90 ), array( 'drain', 70, 45 ),
			array( 'wall', -$w, -$w, 140 + 2 * $w, $w ), array( 'wall', -$w, 0, $w, 90 ), array( 'wall', 140, 0, $w, 90 ),
			array( 'glas', 0, 90, 72, 90 ), array( 'door', 66, 97, 140, 97 ), array( 'rail', 0, 103, 140, 103 ), array( 'arrow', 120, 112, 78, 112 ),
			array( 'lbl', 36, 80, 'Festteil' ), array( 'lbl', 103, 86, 'Schiebetür' ),
			array( 'dim', 'h', 0, 140, -32, 'Nischenbreite' ), array( 'dim', 'h', 72, 140, 132, 'Einstieg' ),
		) ),
	);
}

function mvkd_dusche_svg( $form ) {
	$forms = mvkd_dusche_forms();
	if ( empty( $forms[ $form ] ) ) {
		return '';
	}
	$f  = $forms[ $form ];
	$k  = 3; // 1 cm = 3 Einheiten
	$n  = function ( $v ) use ( $k ) { return round( $v * $k, 1 ); };
	$vb = $f['vb'];
	$s  = '<svg class="mvk-plan mvk-plan--dusche" viewBox="' . esc_attr( $n( $vb[0] ) . ' ' . $n( $vb[1] ) . ' ' . $n( $vb[2] ) . ' ' . $n( $vb[3] ) ) . '" role="img" aria-label="' . esc_attr( 'Schema ' . ( isset( $f['view'] ) ? $f['view'] : 'in Draufsicht' ) . ': ' . $f['label'] ) . '" xmlns="http://www.w3.org/2000/svg">';
	$order = array( 'floor', 'tub', 'drain', 'arc', 'bar', 'rail', 'wall', 'pane', 'glas', 'door', 'arrow', 'dim', 'lbl' );
	foreach ( $order as $type ) {
		foreach ( $f['el'] as $e ) {
			if ( $e[0] !== $type ) {
				continue;
			}
			switch ( $type ) {
				case 'floor':
					if ( ! empty( $e[5] ) ) {
						$pts = array();
						foreach ( $e[5] as $p ) {
							$pts[] = $n( $p[0] ) . ',' . $n( $p[1] );
						}
						$s .= '<polygon class="mvk-plan__floor" points="' . implode( ' ', $pts ) . '"/>';
					} else {
						$s .= sprintf( '<rect class="mvk-plan__floor" x="%s" y="%s" width="%s" height="%s"/>', $n( $e[1] ), $n( $e[2] ), $n( $e[3] ), $n( $e[4] ) );
					}
					break;
				case 'tub':
					$s .= sprintf( '<rect class="mvk-plan__tub" x="%s" y="%s" width="%s" height="%s"/><rect class="mvk-plan__basin" x="%s" y="%s" width="%s" height="%s" rx="%s"/><circle class="mvk-plan__drain" cx="%s" cy="%s" r="9"/>',
						$n( $e[1] ), $n( $e[2] ), $n( $e[3] ), $n( $e[4] ), $n( $e[1] + 8 ), $n( $e[2] + 8 ), $n( $e[3] - 16 ), $n( $e[4] - 16 ), $n( 22 ), $n( $e[1] + 22 ), $n( $e[2] + $e[4] / 2 ) );
					break;
				case 'drain':
					$s .= sprintf( '<circle class="mvk-plan__drain" cx="%s" cy="%s" r="9"/>', $n( $e[1] ), $n( $e[2] ) );
					break;
				case 'wall':
					$s .= sprintf( '<rect class="mvk-plan__wall" x="%s" y="%s" width="%s" height="%s"/>', $n( $e[1] ), $n( $e[2] ), $n( $e[3] ), $n( $e[4] ) );
					break;
				case 'pane':
					$s .= sprintf( '<rect class="mvk-plan__pane%s" x="%s" y="%s" width="%s" height="%s"/>', isset( $e[5] ) ? ' mvk-plan__pane--door' : '', $n( $e[1] ), $n( $e[2] ), $n( $e[3] ), $n( $e[4] ) );
					if ( isset( $e[5] ) ) {
						$s .= sprintf( '<path class="mvk-plan__handle" d="M%s %sV%s"/>', $n( $e[1] + 8 ), $n( $e[2] + $e[4] * .42 ), $n( $e[2] + $e[4] * .58 ) );
					}
					break;
				case 'glas':
				case 'door':
					$d = sprintf( 'M%s %sL%s %s', $n( $e[1] ), $n( $e[2] ), $n( $e[3] ), $n( $e[4] ) );
					$s .= '<path class="mvk-plan__glas' . ( 'door' === $type ? ' mvk-plan__glas--door' : '' ) . '" d="' . $d . '"/><path class="mvk-plan__glas-in" d="' . $d . '"/>';
					break;
				case 'arc':
					list( , $cx, $cy, $r, $a0, $a1 ) = $e;
					$x0  = $cx + $r * cos( deg2rad( $a0 ) );
					$y0  = $cy + $r * sin( deg2rad( $a0 ) );
					$x1  = $cx + $r * cos( deg2rad( $a1 ) );
					$y1  = $cy + $r * sin( deg2rad( $a1 ) );
					$swp = $a1 > $a0 ? 1 : 0;
					$s  .= sprintf( '<path class="mvk-plan__swing" d="M%s %sA%s %s 0 0 %d %s %sL%s %s"/>', $n( $x0 ), $n( $y0 ), $n( $r ), $n( $r ), $swp, $n( $x1 ), $n( $y1 ), $n( $cx ), $n( $cy ) );
					break;
				case 'bar':
					$s .= sprintf( '<path class="mvk-plan__bar" d="M%s %sL%s %s"/>', $n( $e[1] ), $n( $e[2] ), $n( $e[3] ), $n( $e[4] ) );
					break;
				case 'rail':
					$s .= sprintf( '<path class="mvk-plan__rail" d="M%s %sL%s %s"/>', $n( $e[1] ), $n( $e[2] ), $n( $e[3] ), $n( $e[4] ) );
					break;
				case 'arrow':
					$dir = $e[3] < $e[1] ? 1 : -1;
					$s  .= sprintf( '<path class="mvk-plan__arrow" d="M%1$s %2$sL%3$s %2$s M%4$s %5$sL%3$s %2$sL%4$s %6$s"/>', $n( $e[1] ), $n( $e[2] ), $n( $e[3] ), $n( $e[3] + 5 * $dir ), $n( $e[2] - 4 ), $n( $e[2] + 4 ) );
					break;
				case 'dim':
					list( , $o, $a, $b, $pos, $label ) = $e;
					$left = isset( $e[6] ) && 'l' === $e[6];
					if ( 'h' === $o ) {
						$s .= sprintf( '<g class="mvk-plan__dim"><path d="M%1$s %3$sH%2$s M%1$s %4$sV%5$s M%2$s %4$sV%5$s"/><text x="%6$s" y="%7$s" text-anchor="middle">%8$s</text></g>', $n( $a ), $n( $b ), $n( $pos ), $n( $pos - 3 ), $n( $pos + 3 ), $n( ( $a + $b ) / 2 ), $n( $pos - 4 ), esc_html( $label ) );
					} else {
						$tx = $left ? $pos - 4 : $pos + 4;
						$s .= sprintf( '<g class="mvk-plan__dim"><path d="M%3$s %1$sV%2$s M%4$s %1$sH%5$s M%4$s %2$sH%5$s"/><text x="%6$s" y="%7$s" text-anchor="%9$s">%8$s</text></g>', $n( $a ), $n( $b ), $n( $pos ), $n( $pos - 3 ), $n( $pos + 3 ), $n( $tx ), $n( ( $a + $b ) / 2 ) + 5, esc_html( $label ), $left ? 'end' : 'start' );
					}
					break;
				case 'lbl':
					$s .= sprintf( '<text class="mvk-plan__lbl" x="%s" y="%s" text-anchor="%s">%s</text>', $n( $e[1] ), $n( $e[2] ), isset( $e[4] ) ? esc_attr( $e[4] ) : 'middle', esc_html( $e[3] ) );
					break;
			}
		}
	}
	$s .= '</svg>';
	return $s;
}

function mvkd_dusche_sc( $atts ) {
	$a    = shortcode_atts( array( 'form' => 'nische' ), $atts );
	$form = sanitize_key( $a['form'] );
	$f    = mvkd_dusche_forms();
	if ( empty( $f[ $form ] ) ) {
		return '';
	}
	$types = array_map( function ( $e ) { return $e[0]; }, $f[ $form ]['el'] );
	if ( ! empty( $f[ $form ]['view'] ) ) {
		$cap = 'Schema in der Ansicht von vorn, nicht maßstäblich.';
	} else {
		$cap = 'Schema in Draufsicht, nicht maßstäblich.' . ( in_array( 'arc', $types, true ) ? ' Gestrichelt: Schwenkbereich der Tür.' : ( in_array( 'bar', $types, true ) ? ' Gepunktet: Stabilisierungsstange.' : '' ) );
	}
	return '<figure class="mvk-plan-fig mvk-plan-fig--dusche">' . mvkd_dusche_svg( $form ) . '<figcaption>' . esc_html( $cap ) . ' Rot: die Maße, die wir beim Aufmaß bei Ihnen nehmen.</figcaption></figure>';
}

/* ------------------------------------------------------------------ */
/* 8. Aufräumen: eigene Zwischendateien in uploads/_mvk-archiv         */
/* ------------------------------------------------------------------ */
function mvkd_do_purge( $a ) {
	$base    = trailingslashit( wp_get_upload_dir()['basedir'] ) . '_mvk-archiv/';
	$allowed = array( '_ersetzt', '_probe' );
	$dry     = ! empty( $a['dry_run'] );
	$res     = array( 'action' => 'purge', 'dry_run' => $dry, 'dirs' => array() );
	foreach ( (array) ( $a['dirs'] ?? array() ) as $d ) {
		if ( ! in_array( $d, $allowed, true ) ) {
			continue;
		}
		$dir = realpath( $base . $d );
		if ( ! $dir || 0 !== strpos( $dir, realpath( $base ) ) ) {
			$res['dirs'][ $d ] = array( 'files' => 0, 'kb' => 0, 'note' => 'nicht vorhanden' );
			continue;
		}
		$n  = 0;
		$kb = 0;
		$it = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS ), RecursiveIteratorIterator::CHILD_FIRST );
		foreach ( $it as $f ) {
			if ( $f->isFile() ) {
				$n++;
				$kb += $f->getSize() / 1024;
				if ( ! $dry ) {
					@unlink( $f->getPathname() ); // phpcs:ignore
				}
			} elseif ( $f->isDir() && ! $dry ) {
				@rmdir( $f->getPathname() ); // phpcs:ignore
			}
		}
		if ( ! $dry ) {
			@rmdir( $dir ); // phpcs:ignore
		}
		$res['dirs'][ $d ] = array( 'files' => $n, 'kb' => (int) round( $kb ) );
	}
	if ( ! $dry ) {
		mvkd_log( array( 'action' => 'purge', 'dirs' => $res['dirs'] ) );
	}
	return $res;
}

/* ------------------------------------------------------------------ */
/* 9. REST: Einstellungen Design                                       */
/* ------------------------------------------------------------------ */
add_action( 'rest_api_init', function () {
	register_rest_route( 'mvk-design/v1', '/design', array(
		array(
			'methods' => 'GET', 'permission_callback' => function () { return current_user_can( 'manage_options' ); },
			'callback' => function () { return array( 'version' => MVKD_VERSION, 'options' => mvkd_design_opt() ); },
		),
		array(
			'methods' => 'POST', 'permission_callback' => function () { return current_user_can( 'manage_options' ); },
			'callback' => function ( WP_REST_Request $r ) {
				$cur  = (array) get_option( 'mvkd_design', array() );
				$keys = array( 'footer_global', 'rating', 'stars', 'google_url', 'route_url', 'phone', 'phone_href', 'termin_url', 'logo_id' );
				foreach ( (array) $r->get_param( 'options' ) as $k => $v ) {
					if ( in_array( $k, $keys, true ) ) {
						$cur[ $k ] = is_bool( $v ) ? $v : sanitize_text_field( (string) $v );
					}
				}
				if ( isset( $cur['footer_global'] ) ) {
					$cur['footer_global'] = filter_var( $cur['footer_global'], FILTER_VALIDATE_BOOLEAN );
				}
				update_option( 'mvkd_design', $cur, false );
				return array( 'options' => mvkd_design_opt() );
			},
		),
	) );
} );

/* ------------------------------------------------------------------ */
/* 10. Seiten-Blueprints: Inhalt aus blueprints/pages/ in einen Entwurf */
/* ------------------------------------------------------------------ */
function mvkd_apply_blueprint( WP_REST_Request $r ) {
	$id   = (int) $r->get_param( 'post_id' );
	$file = sanitize_file_name( (string) $r->get_param( 'file' ) );
	$path = MVKD_DIR . 'blueprints/pages/' . $file;
	if ( ! preg_match( '/\.html$/', $file ) || ! is_readable( $path ) ) {
		return new WP_Error( 'mvkd_file', 'Blueprint nicht gefunden.', array( 'status' => 404 ) );
	}
	$p = get_post( $id );
	if ( ! $p || 'publish' === $p->post_status || 'private' === $p->post_status ) {
		return new WP_Error( 'mvkd_status', 'Nur Entwürfe dürfen überschrieben werden.', array( 'status' => 409 ) );
	}
	$html = file_get_contents( $path ); // phpcs:ignore
	$out  = array( 'post_id' => $id, 'file' => $file, 'bytes' => strlen( $html ), 'sha1' => sha1( $html ), 'dry_run' => (bool) $r->get_param( 'dry_run' ) );
	if ( $out['dry_run'] ) {
		return $out;
	}
	$data = array( 'ID' => $id, 'post_content' => $html );
	if ( $r->get_param( 'title' ) ) {
		$data['post_title'] = sanitize_text_field( (string) $r->get_param( 'title' ) );
	}
	$res = wp_update_post( wp_slash( $data ), true );
	if ( is_wp_error( $res ) ) {
		return $res;
	}
	update_post_meta( $id, '_mvkd_v2', 1 );
	update_post_meta( $id, '_generate-full-width-content', 'true' );
	update_post_meta( $id, '_generate-disable-headline', 'true' ); /* 0.5.5: Seitentitel des Themes aus, die H1 steht in der Bühne */
	$saved           = get_post_field( 'post_content', $id, 'raw' );
	$out['saved_ok'] = ( sha1( $saved ) === $out['sha1'] );
	mvkd_log( array( 'action' => 'blueprint', 'post' => $id, 'file' => $file, 'ok' => $out['saved_ok'] ) );
	return $out;
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'mvk-design/v1', '/content/apply', array(
		'methods' => 'POST', 'permission_callback' => function () { return current_user_can( 'manage_options' ); },
		'callback' => 'mvkd_apply_blueprint',
		'args' => array(
			'post_id' => array( 'type' => 'integer', 'required' => true ),
			'file'    => array( 'type' => 'string', 'required' => true ),
			'title'   => array( 'type' => 'string' ),
			'dry_run' => array( 'type' => 'boolean', 'default' => true ),
		),
	) );
} );

/* ------------------------------------------------------------------ */
/* 11. Bildimport aus oriqen-medien (Katalogbilder in Paketen)          */
/* ------------------------------------------------------------------ */
function mvkd_do_import( $a ) {
	$url = (string) ( $a['url'] ?? '' );
	if ( 0 !== strpos( $url, 'https://raw.githubusercontent.com/oriqQX/oriqen-medien/' ) ) {
		return new WP_Error( 'mvkd_url', 'Nur Dateien aus oriqen-medien.' );
	}
	$stem = sanitize_title( (string) ( $a['stem'] ?? '' ) );
	if ( ! $stem || 0 !== strpos( $stem, 'mvk-' ) ) {
		return new WP_Error( 'mvkd_stem', 'Dateiname muss mit mvk- beginnen.' );
	}
	$q   = isset( $a['quality'] ) ? max( 60, min( 100, (int) $a['quality'] ) ) : 92;
	$max = isset( $a['max'] ) ? (int) $a['max'] : 2000;
	$dir = wp_upload_dir();
	$name = wp_unique_filename( $dir['path'], $stem . '.webp' );
	$rep  = array( 'stem' => $stem, 'file' => $name, 'dry_run' => ! empty( $a['dry_run'] ) );
	if ( ! empty( $a['dry_run'] ) ) {
		return $rep;
	}
	if ( ! function_exists( 'download_url' ) ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
	}
	if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) {
		require_once ABSPATH . 'wp-admin/includes/image.php';
	}
	$tmp = download_url( $url, 60 );
	if ( is_wp_error( $tmp ) ) {
		return $tmp;
	}
	$dest = trailingslashit( $dir['path'] ) . $name;
	$opt  = isset( $a['opt'] ) ? (array) $a['opt'] : array();
	$mk   = mvkd_make_webp( $tmp, $dest, $max, $q, $opt );
	@unlink( $tmp ); // phpcs:ignore
	if ( is_wp_error( $mk ) ) {
		return $mk;
	}
	$id = wp_insert_attachment( array(
		'post_mime_type' => 'image/webp',
		'post_title'     => sanitize_text_field( (string) ( $a['title'] ?? $stem ) ),
		'post_content'   => sanitize_textarea_field( (string) ( $a['description'] ?? '' ) ),
		'post_excerpt'   => sanitize_text_field( (string) ( $a['caption'] ?? '' ) ),
		'post_status'    => 'inherit',
		'guid'           => trailingslashit( $dir['url'] ) . $name,
	), $dest, 0, true );
	if ( is_wp_error( $id ) ) {
		return $id;
	}
	update_post_meta( $id, '_wp_attachment_image_alt', sanitize_text_field( (string) ( $a['alt'] ?? '' ) ) );
	if ( ! empty( $a['source'] ) ) {
		update_post_meta( $id, '_mvkd_source', sanitize_text_field( (string) $a['source'] ) );
	}
	$qf = function () use ( $q ) { return $q; };
	add_filter( 'wp_editor_set_quality', $qf, 99 );
	mvkd_editor_hook( true, $q, $opt );
	$meta = wp_generate_attachment_metadata( $id, $dest );
	mvkd_editor_hook( false, $q );
	remove_filter( 'wp_editor_set_quality', $qf, 99 );
	wp_update_attachment_metadata( $id, $meta );
	delete_transient( 'mvkd_file_map' );
	$rep['id']     = $id;
	$rep['url']    = trailingslashit( $dir['url'] ) . $name;
	$rep['size']   = array( $meta['width'] ?? 0, $meta['height'] ?? 0, $mk['kb'] );
	$rep['engine'] = $mk['engine'];
	mvkd_log( array( 'action' => 'import', 'id' => $id, 'file' => $name, 'source' => $a['source'] ?? '' ) );
	return $rep;
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'mvk-design/v1', '/media/import', array(
		'methods' => 'POST', 'permission_callback' => function () { return current_user_can( 'manage_options' ); },
		'callback' => function ( WP_REST_Request $r ) {
			$dry   = (bool) $r->get_param( 'dry_run' );
			$out   = array();
			$items = (array) $r->get_param( 'items' );
			$man   = (string) $r->get_param( 'manifest' );
			if ( $man ) {
				/* Manifest (0.5.0): JSON-Liste in oriqen-medien, je Aufruf ein Ausschnitt per offset und limit. */
				if ( 0 !== strpos( $man, 'https://raw.githubusercontent.com/oriqQX/oriqen-medien/' ) ) {
					return new WP_Error( 'mvkd_url', 'Manifest nur aus oriqen-medien.', array( 'status' => 400 ) );
				}
				$res = wp_remote_get( $man, array( 'timeout' => 30 ) );
				$all = is_wp_error( $res ) ? null : json_decode( wp_remote_retrieve_body( $res ), true );
				if ( ! is_array( $all ) ) {
					return new WP_Error( 'mvkd_manifest', 'Manifest nicht lesbar.', array( 'status' => 400 ) );
				}
				$items = array_slice( $all, max( 0, (int) $r->get_param( 'offset' ) ), max( 1, min( 40, (int) ( $r->get_param( 'limit' ) ?: 10 ) ) ) );
			}
			foreach ( array_slice( $items, 0, 40 ) as $it ) {
				$it['dry_run'] = $dry;
				$res           = mvkd_do_import( (array) $it );
				$out[]         = is_wp_error( $res ) ? array( 'stem' => $it['stem'] ?? '', 'error' => $res->get_error_message() ) : $res;
			}
			if ( $r->get_param( 'kurz' ) ) {
				/* Kurzantwort (0.5.3): nur IDs in Manifest-Reihenfolge, Fehler mit Stamm. */
				$ids = array();
				$err = array();
				foreach ( $out as $o ) {
					$ids[] = isset( $o['id'] ) ? (int) $o['id'] : null;
					if ( isset( $o['error'] ) ) {
						$err[] = $o['stem'] . ': ' . $o['error'];
					}
				}
				return array( 'dry_run' => $dry, 'count' => count( $out ), 'ids' => $ids, 'errors' => $err );
			}
			return array( 'dry_run' => $dry, 'count' => count( $out ), 'items' => $out );
		},
		'args' => array(
			'items'    => array( 'type' => 'array', 'default' => array() ),
			'manifest' => array( 'type' => 'string', 'default' => '' ),
			'offset'   => array( 'type' => 'integer', 'default' => 0 ),
			'limit'    => array( 'type' => 'integer', 'default' => 10 ),
			'dry_run'  => array( 'type' => 'boolean', 'default' => true ),
			'kurz'     => array( 'type' => 'boolean', 'default' => false ),
		),
	) );
} );
