=== MVK Formulare ===
Version: 1.0.0
Autor: oriqen

Markenstil, Icons, Schriften und Formular-Definitionen für die Fluent-Forms-Formulare von MVK Küchen & Raumdesign.

* Shortcode [mvk_formular name="anfrage"] bettet das Anfrageformular ein (Conversational Form, Gratis-Version von Fluent Forms).
* Icons (assets/icons, PNG 400 x 300) und Schriften (assets/fonts, Barlow Condensed und Montserrat, SIL OFL) liegen im Plugin. Keine externen Requests.
* Stil (assets/mvk-formulare.css) wird nur auf Seiten mit dem Shortcode im Footer geladen und ist auf .mvkff begrenzt.
* Formular-Definitionen in assets/forms/*.json. POST /wp-json/mvk-formulare/v1/sync spielt sie ein (nur Administratoren, dry_run möglich), fehlende Formulare werden angelegt. Anfragen bleiben erhalten.
* Teilen-Adresse ?fluent-form=ID leitet per 301 auf /kontakt/ (nicht für eingeloggte Redakteure).

Wichtig: Bildkacheln lassen sich im Fluent-Editor der Gratis-Version nicht bearbeiten. Änderungen in build_forms.py, Plugin neu bauen, installieren, Sync aufrufen. Nicht im Fluent-Editor speichern.
