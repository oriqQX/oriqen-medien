<?php
/**
 * Plugin Name: MVK Formulare
 * Description: Markenstil, Icons, Schriften und Formular-Definitionen für die Fluent-Forms-Formulare von MVK Küchen & Raumdesign (Anfrage auf /kontakt/). Shortcode [mvk_formular name="anfrage"].
 * Version: 1.0.1
 * Author: oriqen
 * Author URI: https://oriqen.de/
 * Requires PHP: 7.4
 * Text Domain: mvk-formulare
 */

defined( 'ABSPATH' ) || exit;

define( 'MVKFF_VERSION', '1.0.1' );
define( 'MVKFF_DIR', plugin_dir_path( __FILE__ ) );
define( 'MVKFF_URL', plugin_dir_url( __FILE__ ) );

/**
 * Formular-IDs in Fluent Forms. Schlüssel = Datei in assets/forms/. Der Sync legt fehlende Formulare an und merkt sich die ID.
 */
function mvkff_form_ids() {
	$ids = get_option( 'mvkff_form_ids' );
	if ( ! is_array( $ids ) ) {
		$ids = array();
	}
	foreach ( glob( MVKFF_DIR . 'assets/forms/*.json' ) ?: array() as $file ) {
		$key = basename( $file, '.json' );
		if ( ! isset( $ids[ $key ] ) ) {
			$ids[ $key ] = 0;
		}
	}
	return apply_filters( 'mvkff_form_ids', $ids );
}

/**
 * Teilen-Adressen (?fluent-form=ID) => echte Seite.
 */
function mvkff_redirects() {
	$ids = mvkff_form_ids();
	$map = array();
	if ( ! empty( $ids['anfrage'] ) ) {
		$map[ (int) $ids['anfrage'] ] = '/kontakt/';
	}
	return apply_filters( 'mvkff_redirects', $map );
}

/* ------------------------------------------------------------------ */
/* 1. Shortcode                                                        */
/* ------------------------------------------------------------------ */
$GLOBALS['mvkff_needs_css'] = false;

add_shortcode( 'mvk_formular', function ( $atts ) {
	$atts = shortcode_atts( array( 'name' => 'anfrage' ), $atts, 'mvk_formular' );
	$key  = sanitize_key( $atts['name'] );
	$ids  = mvkff_form_ids();
	$id   = isset( $ids[ $key ] ) ? (int) $ids[ $key ] : 0;
	if ( ! $id ) {
		return current_user_can( 'edit_pages' ) ? '<p><strong>MVK Formulare:</strong> Formular „' . esc_html( $key ) . '“ ist noch nicht eingespielt.</p>' : '';
	}
	$GLOBALS['mvkff_needs_css'] = true;
	return '<div class="mvkff mvkff--' . esc_attr( $key ) . '">' . do_shortcode( '[fluentform type="conversational" id="' . $id . '"]' ) . '</div>';
} );

/* ------------------------------------------------------------------ */
/* 2. Markenstil und Schriften nach dem Formular laden                 */
/* ------------------------------------------------------------------ */
add_action( 'wp_footer', function () {
	if ( empty( $GLOBALS['mvkff_needs_css'] ) ) {
		return;
	}
	$href = MVKFF_URL . 'assets/mvk-formulare.css?ver=' . MVKFF_VERSION;
	echo '<link rel="stylesheet" id="mvkff-css" href="' . esc_url( $href ) . '" media="all">' . "\n"; // phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet
}, 999 );

// Die zwei Hauptschriften früh vorladen, damit die erste Frage nicht in der Ersatzschrift erscheint.
add_action( 'wp_head', function () {
	if ( ! is_singular() ) {
		return;
	}
	$post = get_post();
	if ( ! $post || false === strpos( (string) $post->post_content, '[mvk_formular' ) ) {
		return;
	}
	foreach ( array( 'barlow-condensed-latin-700-normal.woff2', 'montserrat-latin-400-normal.woff2' ) as $font ) {
		echo '<link rel="preload" href="' . esc_url( MVKFF_URL . 'assets/fonts/' . $font ) . '" as="font" type="font/woff2" crossorigin>' . "\n";
	}
}, 5 );

/* ------------------------------------------------------------------ */
/* 3. Weiterleitung der Teilen-Adressen                                */
/* ------------------------------------------------------------------ */
add_action( 'wp', function () {
	if ( is_admin() || wp_doing_ajax() || ! isset( $_GET['fluent-form'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}
	$form_id = absint( wp_unslash( $_GET['fluent-form'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
	$map     = mvkff_redirects();
	if ( ! isset( $map[ $form_id ] ) || isset( $_GET['embedded'] ) || current_user_can( 'edit_pages' ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}
	wp_safe_redirect( home_url( $map[ $form_id ] ), 301, 'MVK Formulare' );
	exit;
}, 1 );

/* ------------------------------------------------------------------ */
/* 4. Formular-Definitionen einspielen (REST, nur Administratoren)     */
/* ------------------------------------------------------------------ */
add_action( 'rest_api_init', function () {
	$admin = function () { return current_user_can( 'manage_options' ); };
	register_rest_route( 'mvk-formulare/v1', '/status', array(
		'methods'             => 'GET',
		'permission_callback' => $admin,
		'callback'            => function () {
			return array(
				'version'   => MVKFF_VERSION,
				'ids'       => mvkff_form_ids(),
				'redirects' => mvkff_redirects(),
				'icons'     => count( glob( MVKFF_DIR . 'assets/icons/*.png' ) ?: array() ),
				'fonts'     => array_map( 'basename', glob( MVKFF_DIR . 'assets/fonts/*.woff2' ) ?: array() ),
			);
		},
	) );
	register_rest_route( 'mvk-formulare/v1', '/sync', array(
		'methods'             => 'POST',
		'permission_callback' => $admin,
		'args'                => array(
			'dry_run' => array( 'type' => 'boolean', 'default' => false ),
			'only'    => array( 'type' => 'string', 'default' => '' ),
		),
		'callback'            => 'mvkff_sync',
	) );
} );

/**
 * Spielt assets/forms/*.json in Fluent Forms ein. Fehlt ein Formular, wird es angelegt.
 * Einträge (Anfragen) bleiben unberührt, ersetzt werden nur Felder und Einstellungen.
 */
function mvkff_sync( WP_REST_Request $req ) {
	global $wpdb;
	$forms_table = $wpdb->prefix . 'fluentform_forms';
	$meta_table  = $wpdb->prefix . 'fluentform_form_meta';
	$dry         = (bool) $req->get_param( 'dry_run' );
	$only        = sanitize_key( (string) $req->get_param( 'only' ) );
	$ids         = mvkff_form_ids();
	$report      = array();

	if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $forms_table ) ) !== $forms_table ) { // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		return new WP_Error( 'mvkff_no_fluent', 'Fluent Forms ist nicht installiert.', array( 'status' => 500 ) );
	}

	foreach ( $ids as $key => $form_id ) {
		if ( $only && $only !== $key ) {
			continue;
		}
		$file = MVKFF_DIR . 'assets/forms/' . sanitize_file_name( $key ) . '.json';
		if ( ! is_readable( $file ) ) {
			$report[ $key ] = 'Datei fehlt';
			continue;
		}
		$raw = (string) file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$raw = str_replace( '{ICONS}', addcslashes( MVKFF_URL . 'assets/icons/', '/' ), $raw );
		$def = json_decode( $raw, true );
		if ( ! is_array( $def ) || empty( $def['fields']['fields'] ) ) {
			$report[ $key ] = 'Datei ungültig';
			continue;
		}

		$form_id = (int) $form_id;
		$exists  = $form_id ? $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$forms_table} WHERE id = %d", $form_id ) ) : null; // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$report[ $key ] = array(
			'form_id'       => $exists ? $form_id : 'neu',
			'fields'        => count( $def['fields']['fields'] ),
			'notifications' => count( $def['notifications'] ),
			'dry_run'       => $dry,
		);
		if ( $dry ) {
			continue;
		}

		$row = array(
			'title'       => $def['title'],
			'status'      => 'published',
			'form_fields' => wp_json_encode( $def['fields'] ),
			'updated_at'  => current_time( 'mysql' ),
		);
		if ( $exists ) {
			$wpdb->update( $forms_table, $row, array( 'id' => $form_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		} else {
			$wpdb->insert( $forms_table, $row + array( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
				'has_payment' => 0,
				'type'        => 'form',
				'created_by'  => get_current_user_id(),
				'created_at'  => current_time( 'mysql' ),
			) );
			$form_id = (int) $wpdb->insert_id;
			$stored  = get_option( 'mvkff_form_ids' );
			$stored  = is_array( $stored ) ? $stored : array();
			$stored[ $key ] = $form_id;
			update_option( 'mvkff_form_ids', $stored, false );
			$report[ $key ]['form_id'] = $form_id;
			$report[ $key ]['angelegt'] = true;
		}

		$metas = array(
			'formSettings'             => wp_json_encode( $def['formSettings'] ),
			'is_conversion_form'       => 'yes',
			'template_name'            => 'conversational',
			'_primary_email_field'     => 'email',
			'ffc_form_settings_meta'   => wp_json_encode( array(
				'title' => $def['meta_title'], 'description' => '', 'featured_image' => '', 'share_key' => '',
				'google_font_href' => '', 'font_css' => '', 'i18n' => $def['i18n'],
			) ),
			'ffc_form_settings_design' => wp_json_encode( $def['design'] ),
		);
		foreach ( $metas as $meta_key => $value ) {
			$meta_id = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$meta_table} WHERE form_id = %d AND meta_key = %s LIMIT 1", $form_id, $meta_key ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			if ( $meta_id ) {
				$wpdb->update( $meta_table, array( 'value' => $value ), array( 'id' => $meta_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			} else {
				$wpdb->insert( $meta_table, array( 'form_id' => $form_id, 'meta_key' => $meta_key, 'value' => $value ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.SlowDBQuery
			}
		}
		$wpdb->delete( $meta_table, array( 'form_id' => $form_id, 'meta_key' => 'notifications' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.SlowDBQuery
		foreach ( $def['notifications'] as $n ) {
			$wpdb->insert( $meta_table, array( 'form_id' => $form_id, 'meta_key' => 'notifications', 'value' => wp_json_encode( $n ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.SlowDBQuery
		}
		do_action( 'fluentform/form_updated', $form_id );
	}

	return array( 'version' => MVKFF_VERSION, 'ids' => mvkff_form_ids(), 'result' => $report );
}
