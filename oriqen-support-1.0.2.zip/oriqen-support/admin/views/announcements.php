<?php
/**
 * Mitteilungen verwalten (nur Betreuer, auf der Übersicht).
 *
 * @package oriqen-support
 */

defined( 'ABSPATH' ) || exit;

$oqs_all = OQ_Support_Store::query(
	array(
		'type'     => 'announcement',
		'per_page' => 20,
	)
)['items'];
?>
<details class="oqs-card">
	<summary><strong>Mitteilungen verwalten</strong> <span class="oqs-muted">(nur für Betreuer sichtbar)</span></summary>
	<form class="oqs-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="oq_support_save_announcement">
		<?php wp_nonce_field( 'oq_support_save_announcement' ); ?>
		<p><label for="oqs-a-title">Titel</label><input id="oqs-a-title" type="text" name="title" required maxlength="255"></p>
		<p><label for="oqs-a-body">Text</label><textarea id="oqs-a-body" name="body"></textarea></p>
		<p><label for="oqs-a-exp">Sichtbar bis (optional)</label><input id="oqs-a-exp" type="date" name="expires"></p>
		<p><button class="oqs-button" type="submit">Mitteilung veröffentlichen</button></p>
	</form>
	<?php if ( $oqs_all ) : ?>
		<ul class="oqs-list">
			<?php foreach ( $oqs_all as $oqs_a ) : ?>
				<?php $oqs_exp = $oqs_a['meta']['expires'] ?? ''; ?>
				<li>
					<strong><?php echo esc_html( $oqs_a['title'] ); ?></strong>
					<span class="oqs-muted"><?php echo esc_html( OQ_Support_Plugin::local( $oqs_a['created_at'], 'd.m.Y' ) . ( $oqs_exp ? ', bis ' . mysql2date( 'd.m.Y', $oqs_exp ) : ', ohne Ablauf' ) . ( $oqs_exp && $oqs_exp < current_time( 'Y-m-d' ) ? ' (abgelaufen)' : '' ) ); ?></span>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-oqs-confirm="Diese Mitteilung löschen?" style="display:inline">
						<input type="hidden" name="action" value="oq_support_delete_item">
						<input type="hidden" name="id" value="<?php echo esc_attr( (string) $oqs_a['id'] ); ?>">
						<input type="hidden" name="back" value="oq-support">
						<?php wp_nonce_field( 'oq_support_delete_item' ); ?>
						<button type="submit" class="oqs-link-danger">Löschen</button>
					</form>
				</li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>
</details>
