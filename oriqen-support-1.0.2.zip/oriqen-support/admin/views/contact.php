<?php
/**
 * Kontakt & Betreuung.
 *
 * @package oriqen-support
 * @var bool $manager Betreuer.
 */

defined( 'ABSPATH' ) || exit;

$oqs_p      = OQ_Support_Plugin::profile();
$oqs_fields = OQ_Support_Plugin::profile_fields();
$oqs_edit   = $manager && ! empty( $_GET['edit'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$oqs_show   = function ( array $keys ) use ( $oqs_p, $oqs_fields ) {
	$out = '';
	foreach ( $keys as $k ) {
		if ( '' === $oqs_p[ $k ] ) {
			continue;
		}
		$v = esc_html( $oqs_p[ $k ] );
		if ( 'email' === $k ) {
			$v = '<a href="' . esc_url( 'mailto:' . $oqs_p[ $k ] ) . '">' . $v . '</a>';
		} elseif ( 'phone' === $k ) {
			$v = '<a href="' . esc_url( 'tel:' . preg_replace( '/[^0-9+]/', '', $oqs_p[ $k ] ) ) . '">' . $v . '</a>';
		} elseif ( 'website' === $k ) {
			$v = '<a href="' . esc_url( $oqs_p[ $k ] ) . '" target="_blank" rel="noopener">' . $v . '</a>';
		}
		$out .= '<dt>' . esc_html( $oqs_fields[ $k ] ) . '</dt><dd>' . $v . '</dd>';
	}
	return $out ? '<dl class="oqs-dl">' . $out . '</dl>' : '';
};
?>
<?php if ( $oqs_edit ) : ?>
	<form class="oqs-form oqs-card" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="oq_support_save_profile">
		<?php wp_nonce_field( 'oq_support_save_profile' ); ?>
		<?php foreach ( $oqs_fields as $oqs_k => $oqs_l ) : ?>
			<p><label for="oqs-p-<?php echo esc_attr( $oqs_k ); ?>"><?php echo esc_html( $oqs_l ); ?></label>
			<?php if ( in_array( $oqs_k, array( 'scope', 'emergency', 'ai_rules', 'availability' ), true ) ) : ?>
				<textarea id="oqs-p-<?php echo esc_attr( $oqs_k ); ?>" name="profile[<?php echo esc_attr( $oqs_k ); ?>]" rows="<?php echo 'ai_rules' === $oqs_k ? 8 : 3; ?>"><?php echo esc_textarea( $oqs_p[ $oqs_k ] ); ?></textarea>
			<?php else : ?>
				<input id="oqs-p-<?php echo esc_attr( $oqs_k ); ?>" type="<?php echo 'email' === $oqs_k ? 'email' : ( 'website' === $oqs_k ? 'url' : 'text' ); ?>" name="profile[<?php echo esc_attr( $oqs_k ); ?>]" value="<?php echo esc_attr( $oqs_p[ $oqs_k ] ); ?>">
			<?php endif; ?>
			<?php if ( 'ai_rules' === $oqs_k ) : ?>
				<br><span class="oqs-muted">Nur für Betreuer und die KI sichtbar. Beispiel: Kundeninhalte nur nach Freigabe veröffentlichen.</span>
			<?php endif; ?></p>
		<?php endforeach; ?>
		<p><button class="oqs-button" type="submit">Speichern</button> <a href="<?php echo esc_url( OQ_Support_Admin::url( 'oq-support-contact' ) ); ?>">Abbrechen</a></p>
	</form>
<?php else : ?>
	<?php if ( $manager ) : ?>
		<p><a class="oqs-button" href="<?php echo esc_url( OQ_Support_Admin::url( 'oq-support-contact', array( 'edit' => 1 ) ) ); ?>">Daten und KI-Regeln bearbeiten</a></p>
	<?php endif; ?>
	<div class="oqs-grid">
		<section class="oqs-card oqs-card--contact">
			<h2>So erreichen Sie uns</h2>
			<?php echo $oqs_show( array( 'studio', 'contact_person', 'email', 'phone', 'website', 'location', 'availability' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- in $oqs_show escaped. ?>
		</section>
		<?php $oqs_care = $oqs_show( array( 'client', 'package', 'scope', 'response_time', 'next_maintenance' ) ); ?>
		<?php if ( $oqs_care ) : ?>
			<section class="oqs-card">
				<h2>Ihre Betreuung</h2>
				<?php echo $oqs_care; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</section>
		<?php endif; ?>
		<?php if ( '' !== $oqs_p['emergency'] ) : ?>
			<section class="oqs-card oqs-card--announcement">
				<h2>Im Notfall</h2>
				<p style="white-space:pre-line"><?php echo esc_html( $oqs_p['emergency'] ); ?></p>
			</section>
		<?php endif; ?>
	</div>
	<?php if ( $manager && '' !== $oqs_p['ai_rules'] ) : ?>
		<section class="oqs-card">
			<h2>KI-Regeln <span class="oqs-muted">(nur für Betreuer sichtbar)</span></h2>
			<p style="white-space:pre-line"><?php echo esc_html( $oqs_p['ai_rules'] ); ?></p>
		</section>
	<?php endif; ?>
<?php endif; ?>
