<?php
/**
 * Handbuch.
 *
 * @package oriqen-support
 * @var bool $manager Betreuer.
 */

defined( 'ABSPATH' ) || exit;

$oqs_hb   = OQ_Support_Plugin::handbook();
$oqs_edit = $manager && ! empty( $_GET['edit'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$oqs_tiny = array(
	'teeny'         => true,
	'media_buttons' => false,
	'textarea_rows' => 8,
	'quicktags'     => true,
);
?>
<?php if ( $manager && ! $oqs_edit ) : ?>
	<p><a class="oqs-button" href="<?php echo esc_url( OQ_Support_Admin::url( 'oq-support-handbook', array( 'edit' => 1 ) ) ); ?>">Handbuch bearbeiten</a></p>
<?php endif; ?>

<?php if ( $oqs_edit ) : ?>
	<form class="oqs-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="oq_support_save_handbook">
		<?php wp_nonce_field( 'oq_support_save_handbook' ); ?>
		<?php foreach ( $oqs_hb['sections'] as $oqs_i => $oqs_s ) : ?>
			<section class="oqs-card">
				<input type="hidden" name="sections[<?php echo esc_attr( (string) $oqs_i ); ?>][key]" value="<?php echo esc_attr( $oqs_s['key'] ); ?>">
				<?php if ( 0 === strpos( $oqs_s['key'], 'custom_' ) ) : ?>
					<p><label for="oqs-hb-t-<?php echo esc_attr( (string) $oqs_i ); ?>">Titel</label><input id="oqs-hb-t-<?php echo esc_attr( (string) $oqs_i ); ?>" type="text" name="sections[<?php echo esc_attr( (string) $oqs_i ); ?>][title]" value="<?php echo esc_attr( $oqs_s['title'] ); ?>"></p>
				<?php else : ?>
					<h2><?php echo esc_html( $oqs_s['title'] ); ?></h2>
					<input type="hidden" name="sections[<?php echo esc_attr( (string) $oqs_i ); ?>][title]" value="<?php echo esc_attr( $oqs_s['title'] ); ?>">
				<?php endif; ?>
				<?php if ( 'tech' === $oqs_s['key'] ) : ?>
					<p class="oqs-hint"><strong>Hier keine Passwörter speichern.</strong></p>
				<?php endif; ?>
				<?php if ( 'brand' === $oqs_s['key'] ) : ?>
					<p><label for="oqs-hb-colors">Farben, eine pro Zeile (z. B. „#6600CC Akzent“)</label><textarea id="oqs-hb-colors" name="sections[<?php echo esc_attr( (string) $oqs_i ); ?>][colors]" rows="4"><?php echo esc_textarea( $oqs_s['colors'] ?? '' ); ?></textarea></p>
				<?php endif; ?>
				<?php
				wp_editor(
					$oqs_s['body'],
					'oqs_hb_' . preg_replace( '/[^a-z0-9]/', '', $oqs_s['key'] ),
					array_merge( $oqs_tiny, array( 'textarea_name' => 'sections[' . $oqs_i . '][body]' ) )
				);
				?>
				<?php if ( 0 === strpos( $oqs_s['key'], 'custom_' ) ) : ?>
					<p><label class="oqs-check"><input type="checkbox" name="sections[<?php echo esc_attr( (string) $oqs_i ); ?>][remove]" value="1"> Diesen Abschnitt entfernen</label></p>
				<?php endif; ?>
			</section>
		<?php endforeach; ?>
		<section class="oqs-card">
			<h2>Neuer Abschnitt</h2>
			<p><label for="oqs-hb-new">Titel</label><input id="oqs-hb-new" type="text" name="new_title"></p>
			<?php wp_editor( '', 'oqs_hb_new', array_merge( $oqs_tiny, array( 'textarea_name' => 'new_body' ) ) ); ?>
		</section>
		<p><button class="oqs-button" type="submit">Handbuch speichern</button> <a href="<?php echo esc_url( OQ_Support_Admin::url( 'oq-support-handbook' ) ); ?>">Abbrechen</a></p>
	</form>
<?php else : ?>
	<?php foreach ( $oqs_hb['sections'] as $oqs_s ) : ?>
		<section class="oqs-card" id="oqs-hb-<?php echo esc_attr( $oqs_s['key'] ); ?>">
			<h2><?php echo esc_html( $oqs_s['title'] ); ?></h2>
			<?php if ( 'tech' === $oqs_s['key'] ) : ?>
				<p class="oqs-hint"><strong>Hier keine Passwörter speichern.</strong> Zugangsdaten bewahren Sie bitte in einem Passwort-Manager auf.</p>
			<?php endif; ?>
			<?php $oqs_colors = 'brand' === $oqs_s['key'] ? OQ_Support_Plugin::parse_colors( $oqs_s['colors'] ?? '' ) : array(); ?>
			<?php if ( $oqs_colors ) : ?>
				<ul class="oqs-swatches">
					<?php foreach ( $oqs_colors as $oqs_c ) : ?>
						<li class="oqs-swatch"><i style="background:<?php echo esc_attr( $oqs_c[0] ); ?>"></i><span><code><?php echo esc_html( $oqs_c[0] ); ?></code> <?php echo esc_html( $oqs_c[1] ); ?></span></li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
			<?php if ( '' !== trim( wp_strip_all_tags( $oqs_s['body'] ) ) ) : ?>
				<div class="oqs-body"><?php echo wp_kses_post( wpautop( $oqs_s['body'] ) ); ?></div>
			<?php elseif ( ! $oqs_colors ) : ?>
				<p class="oqs-muted"><?php echo esc_html( OQ_Support_Plugin::handbook_placeholder( $oqs_s['key'] ) ); ?></p>
			<?php endif; ?>
		</section>
	<?php endforeach; ?>
<?php endif; ?>
