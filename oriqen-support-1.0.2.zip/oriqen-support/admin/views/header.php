<?php
/**
 * Kopfbereich der Plugin-Seiten.
 *
 * @package oriqen-support
 * @var string $title Seitentitel.
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="oqs-head">
	<?php echo OQ_Support_Admin::icon_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- mit wp_kses gefiltert. ?>
	<div class="oqs-head__text">
		<span class="oqs-brandname oqs-head__brand">oriqen support</span>
		<h1 class="oqs-head__title"><?php echo esc_html( $title ); ?></h1>
	</div>
</div>
<hr class="wp-header-end">
