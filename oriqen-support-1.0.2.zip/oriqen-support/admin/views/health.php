<?php
/**
 * Website-Check.
 *
 * @package oriqen-support
 */

defined( 'ABSPATH' ) || exit;

$oqs_items  = OQ_Support_Health::run();
$oqs_labels = array(
	'green'  => 'In Ordnung',
	'yellow' => 'Hinweis',
	'red'    => 'Bitte beachten',
	'info'   => 'Information',
);
?>
<p class="oqs-lead">Ein kurzer Blick auf den Zustand Ihrer Website. Grundlage sind nur Daten, die WordPress selbst kennt.</p>
<div class="oqs-card">
	<ul class="oqs-health">
		<?php foreach ( $oqs_items as $oqs_i ) : ?>
			<li>
				<span class="oqs-light oqs-light--<?php echo esc_attr( $oqs_i['light'] ); ?>" role="img" aria-label="<?php echo esc_attr( $oqs_labels[ $oqs_i['light'] ] ); ?>"></span>
				<div><strong><?php echo esc_html( $oqs_i['label'] ); ?></strong><br><?php echo esc_html( $oqs_i['text'] ); ?></div>
			</li>
		<?php endforeach; ?>
	</ul>
</div>
