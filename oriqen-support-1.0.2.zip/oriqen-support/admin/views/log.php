<?php
/**
 * Protokoll.
 *
 * @package oriqen-support
 * @var bool $manager Betreuer.
 */

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.Security.NonceVerification.Recommended -- reine Filter in der Adresse.
$oqs_f    = array(
	'category' => isset( $_GET['category'] ) ? sanitize_key( wp_unslash( $_GET['category'] ) ) : '',
	'source'   => isset( $_GET['source'] ) ? sanitize_key( wp_unslash( $_GET['source'] ) ) : '',
	'from'     => isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : '',
	'to'       => isset( $_GET['to'] ) ? sanitize_text_field( wp_unslash( $_GET['to'] ) ) : '',
	's'        => isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '',
);
$oqs_page = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
$oqs_edit = $manager && isset( $_GET['edit'] ) ? OQ_Support_Store::get( absint( $_GET['edit'] ) ) : null;
// phpcs:enable
if ( $oqs_edit && 'log' !== $oqs_edit['type'] ) {
	$oqs_edit = null;
}
$oqs_cats  = OQ_Support_Store::categories();
$oqs_res   = OQ_Support_Store::query(
	array(
		'type'     => 'log',
		'category' => isset( $oqs_cats[ $oqs_f['category'] ] ) ? $oqs_f['category'] : '',
		'source'   => isset( OQ_Support_Store::SOURCES[ $oqs_f['source'] ] ) ? $oqs_f['source'] : '',
		'since'    => OQ_Support_Actions::date_to_utc( $oqs_f['from'], '00:00:00' ),
		'until'    => $oqs_f['to'] ? OQ_Support_Actions::date_to_utc( gmdate( 'Y-m-d', strtotime( $oqs_f['to'] . ' +1 day' ) ), '00:00:00' ) : '',
		'search'   => $oqs_f['s'],
		'per_page' => 30,
		'page'     => $oqs_page,
	)
);
$oqs_pages = max( 1, (int) ceil( $oqs_res['total'] / 30 ) );
?>
<p class="oqs-lead">Hier steht, was an Ihrer Website gemacht wurde. Die neuesten Einträge stehen oben.</p>

<?php if ( $manager ) : ?>
<details class="oqs-card" id="oqs-log-form" <?php echo $oqs_edit ? 'open' : ''; ?>>
	<summary><strong><?php echo $oqs_edit ? 'Eintrag bearbeiten' : 'Neuer Eintrag'; ?></strong></summary>
	<form class="oqs-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="oq_support_save_log">
		<input type="hidden" name="id" value="<?php echo esc_attr( $oqs_edit ? (string) $oqs_edit['id'] : '' ); ?>">
		<?php wp_nonce_field( 'oq_support_save_log' ); ?>
		<p><label for="oqs-log-title">Titel</label><input id="oqs-log-title" type="text" name="title" required maxlength="255" value="<?php echo esc_attr( $oqs_edit ? $oqs_edit['title'] : '' ); ?>"></p>
		<p><label for="oqs-log-body">Text</label><textarea id="oqs-log-body" name="body"><?php echo esc_textarea( $oqs_edit ? $oqs_edit['body'] : '' ); ?></textarea></p>
		<div class="oqs-inline">
			<p><label for="oqs-log-cat">Kategorie</label><select id="oqs-log-cat" name="category">
				<?php foreach ( $oqs_cats as $oqs_k => $oqs_l ) : ?>
					<option value="<?php echo esc_attr( $oqs_k ); ?>" <?php selected( $oqs_edit ? $oqs_edit['category'] : 'inhalt', $oqs_k ); ?>><?php echo esc_html( $oqs_l ); ?></option>
				<?php endforeach; ?>
			</select></p>
			<p><label for="oqs-log-source">Quelle</label><select id="oqs-log-source" name="source">
				<option value="oriqen" <?php selected( $oqs_edit ? $oqs_edit['source'] : 'oriqen', 'oriqen' ); ?>>oriqen</option>
				<option value="ki" <?php selected( $oqs_edit ? $oqs_edit['source'] : '', 'ki' ); ?>>KI</option>
			</select></p>
			<p><label for="oqs-log-date">Datum</label><input id="oqs-log-date" type="date" name="date" value="<?php echo esc_attr( $oqs_edit ? OQ_Support_Plugin::local( $oqs_edit['created_at'], 'Y-m-d' ) : current_time( 'Y-m-d' ) ); ?>"></p>
		</div>
		<p><label for="oqs-log-ref">Betroffene Seite (ID oder URL, optional)</label><input id="oqs-log-ref" type="text" name="object_ref" value="<?php echo esc_attr( $oqs_edit ? (string) $oqs_edit['object_ref'] : '' ); ?>"></p>
		<p><button class="oqs-button" type="submit">Speichern</button>
		<?php if ( $oqs_edit ) : ?>
			<a href="<?php echo esc_url( OQ_Support_Admin::url( 'oq-support-log' ) ); ?>">Abbrechen</a>
		<?php endif; ?></p>
	</form>
</details>
<?php endif; ?>

<form class="oqs-filter oqs-form" method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>">
	<input type="hidden" name="page" value="oq-support-log">
	<p><label for="oqs-f-cat">Kategorie</label><select id="oqs-f-cat" name="category"><option value="">Alle</option>
		<?php foreach ( $oqs_cats as $oqs_k => $oqs_l ) : ?>
			<option value="<?php echo esc_attr( $oqs_k ); ?>" <?php selected( $oqs_f['category'], $oqs_k ); ?>><?php echo esc_html( $oqs_l ); ?></option>
		<?php endforeach; ?>
	</select></p>
	<p><label for="oqs-f-src">Quelle</label><select id="oqs-f-src" name="source"><option value="">Alle</option>
		<?php foreach ( OQ_Support_Store::SOURCES as $oqs_k => $oqs_l ) : ?>
			<option value="<?php echo esc_attr( $oqs_k ); ?>" <?php selected( $oqs_f['source'], $oqs_k ); ?>><?php echo esc_html( $oqs_l ); ?></option>
		<?php endforeach; ?>
	</select></p>
	<p><label for="oqs-f-from">Von</label><input id="oqs-f-from" type="date" name="from" value="<?php echo esc_attr( $oqs_f['from'] ); ?>"></p>
	<p><label for="oqs-f-to">Bis</label><input id="oqs-f-to" type="date" name="to" value="<?php echo esc_attr( $oqs_f['to'] ); ?>"></p>
	<p><label for="oqs-f-s">Suche im Titel</label><input id="oqs-f-s" type="text" name="s" value="<?php echo esc_attr( $oqs_f['s'] ); ?>"></p>
	<p><button class="oqs-button oqs-button--ghost" type="submit">Filtern</button></p>
</form>

<p class="oqs-muted"><?php echo esc_html( sprintf( '%d Einträge', $oqs_res['total'] ) ); ?></p>

<?php foreach ( $oqs_res['items'] as $oqs_e ) : ?>
	<article class="oqs-entry" id="oqs-log-<?php echo esc_attr( (string) $oqs_e['id'] ); ?>">
		<div class="oqs-entry__meta">
			<span class="oqs-date"><?php echo esc_html( OQ_Support_Plugin::local( $oqs_e['created_at'] ) ); ?></span>
			<?php echo OQ_Support_Admin::chip_category( $oqs_e['category'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php echo OQ_Support_Admin::source_badge( $oqs_e['source'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php if ( ! empty( $oqs_e['meta']['count'] ) && $oqs_e['meta']['count'] > 1 ) : ?>
				<span class="oqs-muted"><?php echo esc_html( sprintf( '%d× zusammengefasst, zuletzt %s', $oqs_e['meta']['count'], OQ_Support_Plugin::local( $oqs_e['updated_at'], 'H:i' ) ) ); ?></span>
			<?php endif; ?>
		</div>
		<p class="oqs-entry__title"><?php echo esc_html( $oqs_e['title'] ); ?></p>
		<?php if ( '' !== $oqs_e['body'] ) : ?>
			<div class="oqs-body"><?php echo wp_kses_post( wpautop( $oqs_e['body'] ) ); ?></div>
		<?php endif; ?>
		<?php $oqs_link = OQ_Support_Admin::object_link( $oqs_e['object_ref'] ); ?>
		<?php if ( $oqs_link ) : ?>
			<p class="oqs-muted">Betroffen: <?php echo $oqs_link; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- in object_link escaped. ?></p>
		<?php endif; ?>
		<?php if ( $manager ) : ?>
			<div class="oqs-entry__actions">
				<a href="<?php echo esc_url( OQ_Support_Admin::url( 'oq-support-log', array( 'edit' => $oqs_e['id'] ) ) . '#oqs-log-form' ); ?>">Bearbeiten</a>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-oqs-confirm="Diesen Eintrag löschen?">
					<input type="hidden" name="action" value="oq_support_delete_item">
					<input type="hidden" name="id" value="<?php echo esc_attr( (string) $oqs_e['id'] ); ?>">
					<input type="hidden" name="back" value="oq-support-log">
					<?php wp_nonce_field( 'oq_support_delete_item' ); ?>
					<button type="submit" class="oqs-link-danger">Löschen</button>
				</form>
			</div>
		<?php endif; ?>
	</article>
<?php endforeach; ?>

<?php if ( $oqs_pages > 1 ) : ?>
	<nav class="oqs-pager" aria-label="Seiten">
		<?php for ( $oqs_i = 1; $oqs_i <= $oqs_pages; $oqs_i++ ) : ?>
			<?php if ( $oqs_i === $oqs_page ) : ?>
				<span class="oqs-button oqs-button--small" aria-current="page"><?php echo esc_html( (string) $oqs_i ); ?></span>
			<?php else : ?>
				<a class="oqs-button oqs-button--small oqs-button--ghost" href="<?php echo esc_url( OQ_Support_Admin::url( 'oq-support-log', array_merge( array_filter( $oqs_f ), array( 'paged' => $oqs_i ) ) ) ); ?>"><?php echo esc_html( (string) $oqs_i ); ?></a>
			<?php endif; ?>
		<?php endfor; ?>
	</nav>
<?php endif; ?>
