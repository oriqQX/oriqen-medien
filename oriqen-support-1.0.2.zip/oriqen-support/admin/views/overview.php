<?php
/**
 * Übersicht.
 *
 * @package oriqen-support
 * @var bool $manager Betreuer.
 */

defined( 'ABSPATH' ) || exit;

$oqs_profile = OQ_Support_Plugin::profile();
$oqs_recent  = OQ_Support_Store::query(
	array(
		'type'     => 'log',
		'per_page' => 5,
	)
);
$oqs_open    = OQ_Support_Store::query(
	array(
		'type'     => 'request',
		'status'   => array( 'neu', 'in_arbeit' ),
		'per_page' => 5,
	)
);
$oqs_ann     = OQ_Support_Store::announcements();
$oqs_user    = wp_get_current_user();
?>
<p class="oqs-lead">Guten Tag<?php echo $oqs_user->display_name ? ', ' . esc_html( $oqs_user->display_name ) : ''; ?>. Hier sehen Sie alles zur Betreuung von <strong><?php echo esc_html( OQ_Support_Plugin::site_name() ); ?></strong>.</p>

<?php if ( $oqs_ann ) : ?>
	<div class="oqs-card oqs-card--announcement">
		<h2>Mitteilung von <span class="oqs-brandname">oriqen</span></h2>
		<h3><?php echo esc_html( $oqs_ann[0]['title'] ); ?></h3>
		<div class="oqs-body"><?php echo wp_kses_post( wpautop( $oqs_ann[0]['body'] ) ); ?></div>
	</div>
<?php endif; ?>

<p><a class="oqs-button" href="<?php echo esc_url( OQ_Support_Admin::url( 'oq-support-requests', array( 'new' => 1 ) ) . '#oqs-new' ); ?>">Wunsch eintragen</a></p>

<div class="oqs-grid">
	<?php if ( OQ_Support_Plugin::can_view( 'log' ) ) : ?>
	<section class="oqs-card">
		<h2>Letzte Änderungen</h2>
		<?php if ( ! $oqs_recent['items'] ) : ?>
			<p class="oqs-muted">Noch keine Einträge.</p>
		<?php else : ?>
			<ul class="oqs-list">
				<?php foreach ( $oqs_recent['items'] as $oqs_e ) : ?>
					<li>
						<span class="oqs-date"><?php echo esc_html( OQ_Support_Plugin::local( $oqs_e['created_at'], 'd.m.Y' ) ); ?></span>
						<?php echo OQ_Support_Admin::chip_category( $oqs_e['category'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<?php echo esc_html( $oqs_e['title'] ); ?>
					</li>
				<?php endforeach; ?>
			</ul>
			<p><a href="<?php echo esc_url( OQ_Support_Admin::url( 'oq-support-log' ) ); ?>">Zum Protokoll</a></p>
		<?php endif; ?>
	</section>
	<?php endif; ?>

	<?php if ( OQ_Support_Plugin::can_view( 'requests' ) ) : ?>
	<section class="oqs-card">
		<h2>Offene Wünsche <span class="oqs-count"><?php echo esc_html( (string) $oqs_open['total'] ); ?></span></h2>
		<?php if ( ! $oqs_open['items'] ) : ?>
			<p class="oqs-muted">Zurzeit ist nichts offen.</p>
		<?php else : ?>
			<ul class="oqs-list">
				<?php foreach ( $oqs_open['items'] as $oqs_r ) : ?>
					<li><?php echo OQ_Support_Admin::chip_status( $oqs_r['status'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> <a href="<?php echo esc_url( OQ_Support_Admin::url( 'oq-support-requests' ) . '#oqs-request-' . $oqs_r['id'] ); ?>"><?php echo esc_html( $oqs_r['title'] ); ?></a></li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	</section>
	<?php endif; ?>

	<?php if ( '' !== $oqs_profile['package'] || '' !== $oqs_profile['next_maintenance'] ) : ?>
	<section class="oqs-card">
		<h2>Betreuung</h2>
		<dl class="oqs-dl">
			<?php if ( '' !== $oqs_profile['package'] ) : ?>
				<dt>Paket</dt><dd><?php echo esc_html( $oqs_profile['package'] ); ?></dd>
			<?php endif; ?>
			<?php if ( '' !== $oqs_profile['next_maintenance'] ) : ?>
				<dt>Nächste Wartung</dt><dd><?php echo esc_html( $oqs_profile['next_maintenance'] ); ?></dd>
			<?php endif; ?>
		</dl>
	</section>
	<?php endif; ?>

	<section class="oqs-card oqs-card--contact">
		<h2>Kontakt</h2>
		<p><strong><?php echo esc_html( '' !== $oqs_profile['studio'] ? $oqs_profile['studio'] : 'oriqen Digital Studio' ); ?></strong>
		<?php if ( '' !== $oqs_profile['contact_person'] ) : ?>
			<br><?php echo esc_html( $oqs_profile['contact_person'] ); ?>
		<?php endif; ?></p>
		<ul class="oqs-list oqs-list--plain">
			<?php if ( '' !== $oqs_profile['email'] ) : ?>
				<li><a href="<?php echo esc_url( 'mailto:' . $oqs_profile['email'] ); ?>"><?php echo esc_html( $oqs_profile['email'] ); ?></a></li>
			<?php endif; ?>
			<?php if ( '' !== $oqs_profile['phone'] ) : ?>
				<li><a href="<?php echo esc_url( 'tel:' . preg_replace( '/[^0-9+]/', '', $oqs_profile['phone'] ) ); ?>"><?php echo esc_html( $oqs_profile['phone'] ); ?></a></li>
			<?php endif; ?>
			<?php if ( '' !== $oqs_profile['website'] ) : ?>
				<li><a href="<?php echo esc_url( $oqs_profile['website'] ); ?>" target="_blank" rel="noopener"><?php echo esc_html( preg_replace( '#^https?://|/$#', '', $oqs_profile['website'] ) ); ?></a></li>
			<?php endif; ?>
		</ul>
		<?php if ( OQ_Support_Plugin::can_view( 'contact' ) ) : ?>
			<p><a href="<?php echo esc_url( OQ_Support_Admin::url( 'oq-support-contact' ) ); ?>">Alle Kontaktdaten</a></p>
		<?php endif; ?>
	</section>
</div>

<?php
if ( $manager && is_readable( OQ_SUPPORT_DIR . 'admin/views/announcements.php' ) ) {
	include OQ_SUPPORT_DIR . 'admin/views/announcements.php';
}
