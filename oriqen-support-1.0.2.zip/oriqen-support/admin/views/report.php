<?php
/**
 * Monatsbericht.
 *
 * @package oriqen-support
 */

defined( 'ABSPATH' ) || exit;

$oqs_r    = OQ_Support_Report::build( isset( $_GET['month'] ) ? sanitize_text_field( wp_unslash( $_GET['month'] ) ) : '' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$oqs_cats = OQ_Support_Store::categories();
$oqs_opts = array();
for ( $oqs_i = 0; $oqs_i < 24; $oqs_i++ ) {
	$oqs_m              = gmdate( 'Y-m', strtotime( current_time( 'Y-m-01' ) . ' -' . $oqs_i . ' month' ) );
	$oqs_opts[ $oqs_m ] = OQ_Support_Report::month_names()[ (int) substr( $oqs_m, 5 ) ] . ' ' . substr( $oqs_m, 0, 4 );
}
?>
<form class="oqs-filter oqs-form oqs-no-print" method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>">
	<input type="hidden" name="page" value="oq-support-report">
	<p><label for="oqs-month">Monat</label><select id="oqs-month" name="month">
		<?php foreach ( $oqs_opts as $oqs_k => $oqs_l ) : ?>
			<option value="<?php echo esc_attr( $oqs_k ); ?>" <?php selected( $oqs_r['month'], $oqs_k ); ?>><?php echo esc_html( $oqs_l ); ?></option>
		<?php endforeach; ?>
	</select></p>
	<p><button class="oqs-button oqs-button--ghost" type="submit">Anzeigen</button></p>
	<p><button class="oqs-button" type="button" data-oqs-print="1">Als PDF speichern</button></p>
</form>

<article class="oqs-report">
	<header class="oqs-report__head">
		<span class="oqs-brandname" style="opacity:.8">oriqen support · Monatsbericht</span>
		<h2><?php echo esc_html( OQ_Support_Plugin::site_name() ); ?></h2>
		<span><?php echo esc_html( $oqs_r['label'] ); ?></span>
	</header>
	<div class="oqs-report__body">
		<div class="oqs-kpis">
			<div class="oqs-kpi"><strong><?php echo esc_html( (string) count( $oqs_r['logs'] ) ); ?></strong>Änderungen</div>
			<div class="oqs-kpi"><strong><?php echo esc_html( (string) count( $oqs_r['done'] ) ); ?></strong>erledigte Wünsche</div>
			<div class="oqs-kpi"><strong><?php echo esc_html( (string) $oqs_r['open'] ); ?></strong>offene Wünsche</div>
			<?php foreach ( $oqs_r['groups'] as $oqs_k => $oqs_list ) : ?>
				<div class="oqs-kpi"><strong><?php echo esc_html( (string) count( $oqs_list ) ); ?></strong><?php echo esc_html( $oqs_cats[ $oqs_k ] ); ?></div>
			<?php endforeach; ?>
		</div>

		<?php if ( ! $oqs_r['logs'] ) : ?>
			<p class="oqs-muted">In diesem Monat gibt es keine Protokolleinträge.</p>
		<?php endif; ?>
		<?php foreach ( $oqs_r['groups'] as $oqs_k => $oqs_list ) : ?>
			<section>
				<h3><?php echo esc_html( $oqs_cats[ $oqs_k ] ); ?></h3>
				<ul class="oqs-list">
					<?php foreach ( $oqs_list as $oqs_e ) : ?>
						<li><span class="oqs-date"><?php echo esc_html( OQ_Support_Plugin::local( $oqs_e['created_at'], 'd.m.' ) ); ?></span> <?php echo esc_html( $oqs_e['title'] ); ?>
							<?php if ( '' !== trim( wp_strip_all_tags( $oqs_e['body'] ) ) && 'system' !== $oqs_e['source'] ) : ?>
								<div class="oqs-body oqs-muted"><?php echo wp_kses_post( wpautop( $oqs_e['body'] ) ); ?></div>
							<?php endif; ?>
						</li>
					<?php endforeach; ?>
				</ul>
			</section>
		<?php endforeach; ?>

		<?php if ( $oqs_r['done'] ) : ?>
			<section>
				<h3>Erledigte Wünsche</h3>
				<ul class="oqs-list">
					<?php foreach ( $oqs_r['done'] as $oqs_d ) : ?>
						<li><?php echo esc_html( $oqs_d['title'] ); ?></li>
					<?php endforeach; ?>
				</ul>
			</section>
		<?php endif; ?>
	</div>
	<footer class="oqs-report__foot">Betreut von <span class="oqs-brandname">oriqen</span> Digital Studio, <span class="oqs-brandname">oriqen.de</span></footer>
</article>
