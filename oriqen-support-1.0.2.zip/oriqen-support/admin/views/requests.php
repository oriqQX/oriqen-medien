<?php
/**
 * Wünsche & Notizen.
 *
 * @package oriqen-support
 * @var bool $manager Betreuer.
 */

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.Security.NonceVerification.Recommended -- nur Anzeige.
$oqs_tab  = isset( $_GET['tab'] ) && 'notes' === $_GET['tab'] ? 'notes' : 'requests';
$oqs_hide = ! empty( $_GET['hide_done'] );
$oqs_edit = isset( $_GET['edit'] ) ? OQ_Support_Store::get( absint( $_GET['edit'] ) ) : null;
// phpcs:enable
$oqs_uid = get_current_user_id();
if ( $oqs_edit && ( 'note' !== $oqs_edit['type'] || ( (int) $oqs_edit['author_id'] !== $oqs_uid && ! $manager ) ) ) {
	$oqs_edit = null;
}
$oqs_author = function ( $id ) {
	$u = get_userdata( (int) $id );
	return $u ? $u->display_name : 'Unbekannt';
};
?>
<nav class="oqs-tabs" aria-label="Reiter">
	<a href="<?php echo esc_url( OQ_Support_Admin::url( 'oq-support-requests' ) ); ?>" <?php echo 'requests' === $oqs_tab ? 'aria-current="page"' : ''; ?>>Wünsche</a>
	<a href="<?php echo esc_url( OQ_Support_Admin::url( 'oq-support-requests', array( 'tab' => 'notes' ) ) ); ?>" <?php echo 'notes' === $oqs_tab ? 'aria-current="page"' : ''; ?>>Notizen</a>
</nav>

<?php if ( 'requests' === $oqs_tab ) : ?>
	<?php
	$oqs_list  = OQ_Support_Requests::list_requests();
	$oqs_pages = get_pages(
		array(
			'post_status' => 'publish',
			'number'      => 300,
			'sort_column' => 'post_title',
		)
	);
	?>
	<details class="oqs-card" id="oqs-new" <?php echo ! $oqs_list || isset( $_GET['new'] ) ? 'open' : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>>
		<summary><strong>Wunsch eintragen</strong></summary>
		<form class="oqs-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="oq_support_save_request">
			<?php wp_nonce_field( 'oq_support_save_request' ); ?>
			<p><label for="oqs-r-title">Was sollen wir tun?</label><input id="oqs-r-title" type="text" name="title" required maxlength="255"></p>
			<p><label for="oqs-r-body">Beschreibung</label><textarea id="oqs-r-body" name="body" placeholder="Je genauer, desto schneller können wir helfen."></textarea></p>
			<p><label for="oqs-object-select">Betroffene Seite (optional)</label><select id="oqs-object-select" name="object_page"><option value="">Keine Auswahl oder andere Adresse</option>
				<?php foreach ( $oqs_pages as $oqs_p ) : ?>
					<option value="<?php echo esc_attr( (string) $oqs_p->ID ); ?>"><?php echo esc_html( $oqs_p->post_title ? $oqs_p->post_title : '#' . $oqs_p->ID ); ?></option>
				<?php endforeach; ?>
			</select></p>
			<p><label for="oqs-object-url">Oder Adresse der Seite</label><input id="oqs-object-url" type="url" name="object_url" placeholder="https://"></p>
			<p><span class="oqs-check"><input id="oqs-r-prio" type="checkbox" name="priority" value="hoch"><label for="oqs-r-prio" style="margin:0;font-weight:400">Dringend</label></span></p>
			<p><button class="oqs-button" type="submit">Wunsch senden</button></p>
		</form>
	</details>

	<p class="oqs-check">
		<input type="checkbox" id="oqs-hide-done" <?php checked( $oqs_hide ); ?>>
		<label for="oqs-hide-done" style="margin:0;font-weight:400">Erledigte ausblenden</label>
		<noscript><a href="<?php echo esc_url( OQ_Support_Admin::url( 'oq-support-requests', $oqs_hide ? array() : array( 'hide_done' => 1 ) ) ); ?>"><?php echo $oqs_hide ? 'Alle zeigen' : 'Ausblenden'; ?></a></noscript>
	</p>

	<?php if ( ! $oqs_list ) : ?>
		<p class="oqs-muted">Noch keine Wünsche eingetragen.</p>
	<?php endif; ?>

	<?php foreach ( $oqs_list as $oqs_r ) : ?>
		<?php
		$oqs_done = in_array( $oqs_r['status'], array( 'erledigt', 'abgelehnt' ), true );
		if ( $oqs_done && $oqs_hide ) {
			continue;
		}
		?>
		<article class="oqs-entry" id="oqs-request-<?php echo esc_attr( (string) $oqs_r['id'] ); ?>" data-oqs-done="<?php echo $oqs_done ? '1' : '0'; ?>">
			<div class="oqs-entry__meta">
				<?php echo OQ_Support_Admin::chip_status( $oqs_r['status'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<?php if ( 'hoch' === $oqs_r['priority'] ) : ?>
					<span class="oqs-chip oqs-chip--hoch">Dringend</span>
				<?php endif; ?>
				<span class="oqs-date"><?php echo esc_html( OQ_Support_Plugin::local( $oqs_r['created_at'] ) . ' · ' . $oqs_author( $oqs_r['author_id'] ) ); ?></span>
			</div>
			<p class="oqs-entry__title"><?php echo esc_html( $oqs_r['title'] ); ?></p>
			<?php if ( '' !== $oqs_r['body'] ) : ?>
				<div class="oqs-body"><?php echo wp_kses_post( wpautop( $oqs_r['body'] ) ); ?></div>
			<?php endif; ?>
			<?php $oqs_link = OQ_Support_Admin::object_link( $oqs_r['object_ref'] ); ?>
			<?php if ( $oqs_link ) : ?>
				<p class="oqs-muted">Seite: <?php echo $oqs_link; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
			<?php endif; ?>

			<?php if ( $oqs_r['comments'] ) : ?>
				<div class="oqs-comments">
					<?php foreach ( $oqs_r['comments'] as $oqs_c ) : ?>
						<div class="oqs-comment <?php echo 'kunde' !== $oqs_c['source'] ? 'oqs-comment--oriqen' : ''; ?>">
							<span class="oqs-date"><?php echo esc_html( OQ_Support_Plugin::local( $oqs_c['created_at'] ) . ' · ' . $oqs_author( $oqs_c['author_id'] ) ); ?></span>
							<div class="oqs-body"><?php echo wp_kses_post( wpautop( $oqs_c['body'] ) ); ?></div>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<details>
				<summary><?php echo $manager ? 'Antworten oder Status setzen' : 'Kommentar schreiben'; ?></summary>
				<?php if ( $manager ) : ?>
					<form class="oqs-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="oq_support_request_status">
						<input type="hidden" name="id" value="<?php echo esc_attr( (string) $oqs_r['id'] ); ?>">
						<?php wp_nonce_field( 'oq_support_request_status' ); ?>
						<p><label for="oqs-st-<?php echo esc_attr( (string) $oqs_r['id'] ); ?>">Status</label><select id="oqs-st-<?php echo esc_attr( (string) $oqs_r['id'] ); ?>" name="status">
							<?php foreach ( OQ_Support_Store::STATUSES as $oqs_k => $oqs_l ) : ?>
								<option value="<?php echo esc_attr( $oqs_k ); ?>" <?php selected( $oqs_r['status'], $oqs_k ); ?>><?php echo esc_html( $oqs_l ); ?></option>
							<?php endforeach; ?>
						</select></p>
						<p><label for="oqs-ans-<?php echo esc_attr( (string) $oqs_r['id'] ); ?>">Antwort (optional)</label><textarea id="oqs-ans-<?php echo esc_attr( (string) $oqs_r['id'] ); ?>" name="body"></textarea></p>
						<p><button class="oqs-button" type="submit">Speichern</button></p>
					</form>
				<?php else : ?>
					<form class="oqs-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="oq_support_comment">
						<input type="hidden" name="id" value="<?php echo esc_attr( (string) $oqs_r['id'] ); ?>">
						<?php wp_nonce_field( 'oq_support_comment' ); ?>
						<p><label for="oqs-cm-<?php echo esc_attr( (string) $oqs_r['id'] ); ?>">Ihr Kommentar</label><textarea id="oqs-cm-<?php echo esc_attr( (string) $oqs_r['id'] ); ?>" name="body" required></textarea></p>
						<p><button class="oqs-button" type="submit">Kommentar senden</button></p>
					</form>
				<?php endif; ?>
			</details>
			<?php if ( $manager ) : ?>
				<div class="oqs-entry__actions">
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-oqs-confirm="Diesen Wunsch samt Verlauf löschen?">
						<input type="hidden" name="action" value="oq_support_delete_item">
						<input type="hidden" name="id" value="<?php echo esc_attr( (string) $oqs_r['id'] ); ?>">
						<input type="hidden" name="back" value="oq-support-requests">
						<?php wp_nonce_field( 'oq_support_delete_item' ); ?>
						<button type="submit" class="oqs-link-danger">Wunsch löschen</button>
					</form>
				</div>
			<?php endif; ?>
		</article>
	<?php endforeach; ?>

<?php else : ?>
	<?php
	$oqs_notes = OQ_Support_Store::query(
		array(
			'type'     => 'note',
			'orderby'  => 'updated_at',
			'per_page' => 200,
		)
	)['items'];
	?>
	<p class="oqs-lead">Ihr Notizbuch für alles, was wir wissen sollten: Ideen, Termine, Ansprechpartner, Hinweise. Wir lesen mit, damit nichts verloren geht.</p>
	<details class="oqs-card" id="oqs-note-form" <?php echo $oqs_edit || ! $oqs_notes ? 'open' : ''; ?>>
		<summary><strong><?php echo $oqs_edit ? 'Notiz bearbeiten' : 'Neue Notiz'; ?></strong></summary>
		<form class="oqs-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="oq_support_save_note">
			<input type="hidden" name="id" value="<?php echo esc_attr( $oqs_edit ? (string) $oqs_edit['id'] : '' ); ?>">
			<?php wp_nonce_field( 'oq_support_save_note' ); ?>
			<p><label for="oqs-n-title">Titel</label><input id="oqs-n-title" type="text" name="title" required maxlength="255" value="<?php echo esc_attr( $oqs_edit ? $oqs_edit['title'] : '' ); ?>"></p>
			<p><label for="oqs-n-body">Text</label><textarea id="oqs-n-body" name="body"><?php echo esc_textarea( $oqs_edit ? $oqs_edit['body'] : '' ); ?></textarea></p>
			<p><button class="oqs-button" type="submit">Notiz speichern</button>
			<?php if ( $oqs_edit ) : ?>
				<a href="<?php echo esc_url( OQ_Support_Admin::url( 'oq-support-requests', array( 'tab' => 'notes' ) ) ); ?>">Abbrechen</a>
			<?php endif; ?></p>
		</form>
	</details>
	<?php if ( ! $oqs_notes ) : ?>
		<p class="oqs-muted">Noch keine Notizen.</p>
	<?php endif; ?>
	<?php foreach ( $oqs_notes as $oqs_n ) : ?>
		<?php $oqs_mine = (int) $oqs_n['author_id'] === $oqs_uid || $manager; ?>
		<article class="oqs-entry">
			<div class="oqs-entry__meta"><span class="oqs-date"><?php echo esc_html( OQ_Support_Plugin::local( $oqs_n['updated_at'] ) . ' · ' . $oqs_author( $oqs_n['author_id'] ) ); ?></span></div>
			<p class="oqs-entry__title"><?php echo esc_html( $oqs_n['title'] ); ?></p>
			<div class="oqs-body"><?php echo wp_kses_post( wpautop( $oqs_n['body'] ) ); ?></div>
			<?php if ( $oqs_mine ) : ?>
				<div class="oqs-entry__actions">
					<a href="
					<?php
					echo esc_url(
						OQ_Support_Admin::url(
							'oq-support-requests',
							array(
								'tab'  => 'notes',
								'edit' => $oqs_n['id'],
							)
						) . '#oqs-note-form'
					);
					?>
								">Bearbeiten</a>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-oqs-confirm="Diese Notiz löschen?">
						<input type="hidden" name="action" value="oq_support_delete_item">
						<input type="hidden" name="id" value="<?php echo esc_attr( (string) $oqs_n['id'] ); ?>">
						<input type="hidden" name="back" value="oq-support-requests">
						<?php wp_nonce_field( 'oq_support_delete_item' ); ?>
						<button type="submit" class="oqs-link-danger">Löschen</button>
					</form>
				</div>
			<?php endif; ?>
		</article>
	<?php endforeach; ?>
<?php endif; ?>
