<?php
/**
 * Einstellungen (nur Betreuer).
 *
 * @package oriqen-support
 */

defined( 'ABSPATH' ) || exit;

$oqs_s        = OQ_Support_Plugin::settings();
$oqs_managers = OQ_Support_Plugin::managers();
$oqs_users    = get_users(
	array(
		'capability' => 'edit_posts',
		'number'     => 200,
		'orderby'    => 'display_name',
	)
);
?>
<form class="oqs-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
	<input type="hidden" name="action" value="oq_support_save_settings">
	<?php wp_nonce_field( 'oq_support_save_settings' ); ?>
	<section class="oqs-card">
		<h2>Footer-Verweis</h2>
		<p><label class="oqs-check"><input type="checkbox" name="footer_enabled" value="1" <?php checked( $oqs_s['footer_enabled'] ); ?>> Footer-Verweis anzeigen</label></p>
		<div class="oqs-inline">
			<p><label for="oqs-s-mode">Ausgabe</label><select id="oqs-s-mode" name="footer_mode">
				<option value="auto" <?php selected( $oqs_s['footer_mode'], 'auto' ); ?>>Automatisch am Seitenende</option>
				<option value="shortcode" <?php selected( $oqs_s['footer_mode'], 'shortcode' ); ?>>Nur per Shortcode [oriqen_credit]</option>
			</select></p>
			<p><label for="oqs-s-scheme">Farbschema</label><select id="oqs-s-scheme" name="footer_scheme">
				<option value="dark" <?php selected( $oqs_s['footer_scheme'], 'dark' ); ?>>Dunkel</option>
				<option value="light" <?php selected( $oqs_s['footer_scheme'], 'light' ); ?>>Hell</option>
				<option value="transparent" <?php selected( $oqs_s['footer_scheme'], 'transparent' ); ?>>Transparent</option>
			</select></p>
		</div>
		<p class="oqs-muted">Der Shortcode nimmt optional ein Farbschema an, z. B. [oriqen_credit scheme="light"].</p>
	</section>
	<section class="oqs-card">
		<h2>Zugriff</h2>
		<p><label for="oqs-s-role">Kunden sehen oriqen Support ab</label><select id="oqs-s-role" name="min_role">
			<option value="edit_posts" <?php selected( $oqs_s['min_role'], 'edit_posts' ); ?>>Redakteur (edit_posts)</option>
			<option value="manage_options" <?php selected( $oqs_s['min_role'], 'manage_options' ); ?>>Administrator (manage_options)</option>
		</select></p>
		<p><strong>Betreuer</strong> <span class="oqs-muted">(dürfen alles, mindestens einer muss bleiben)</span></p>
		<?php foreach ( $oqs_users as $oqs_u ) : ?>
			<p><label class="oqs-check"><input type="checkbox" name="managers[]" value="<?php echo esc_attr( (string) $oqs_u->ID ); ?>" <?php checked( in_array( (int) $oqs_u->ID, $oqs_managers, true ) ); ?>> <?php echo esc_html( $oqs_u->display_name . ' (' . $oqs_u->user_login . ')' ); ?></label></p>
		<?php endforeach; ?>
		<p><strong>Für Kunden sichtbare Bereiche</strong></p>
		<?php foreach ( OQ_Support_Plugin::section_labels() as $oqs_k => $oqs_l ) : ?>
			<p><label class="oqs-check"><input type="checkbox" name="sections[<?php echo esc_attr( $oqs_k ); ?>]" value="1" <?php checked( $oqs_s['sections'][ $oqs_k ] ); ?>> <?php echo esc_html( $oqs_l ); ?></label></p>
		<?php endforeach; ?>
	</section>
	<section class="oqs-card">
		<h2>Benachrichtigung und Daten</h2>
		<p><label for="oqs-s-mail">E-Mail bei neuen Wünschen und Kundenkommentaren (leer = aus)</label><input id="oqs-s-mail" type="email" name="notify_email" value="<?php echo esc_attr( $oqs_s['notify_email'] ); ?>"></p>
		<p><label for="oqs-s-ret">Automatische Systemeinträge aufbewahren (Monate)</label><input id="oqs-s-ret" type="number" min="1" max="120" name="retention_months" value="<?php echo esc_attr( (string) $oqs_s['retention_months'] ); ?>"></p>
		<p><label class="oqs-check"><input type="checkbox" name="delete_on_uninstall" value="1" <?php checked( $oqs_s['delete_on_uninstall'] ); ?>> Daten beim Löschen des Plugins entfernen</label></p>
	</section>
	<p><button class="oqs-button" type="submit">Einstellungen speichern</button></p>
</form>

<section class="oqs-card">
	<h2>Export und Import</h2>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-bottom:16px">
		<input type="hidden" name="action" value="oq_support_export">
		<?php wp_nonce_field( 'oq_support_export' ); ?>
		<button class="oqs-button oqs-button--ghost" type="submit">Alles als JSON herunterladen</button>
	</form>
	<form class="oqs-form" method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-oqs-confirm="Import jetzt ausführen?">
		<input type="hidden" name="action" value="oq_support_import">
		<?php wp_nonce_field( 'oq_support_import' ); ?>
		<p><label for="oqs-imp-file">Exportdatei (JSON, höchstens 2 MB)</label><input id="oqs-imp-file" type="file" name="file" accept=".json,application/json" required></p>
		<p><label for="oqs-imp-mode">Modus</label><select id="oqs-imp-mode" name="mode">
			<option value="merge">Zusammenführen (vorhandene Daten bleiben)</option>
			<option value="replace">Ersetzen (vorhandene Daten werden gelöscht)</option>
		</select></p>
		<p><button class="oqs-button" type="submit">Importieren</button></p>
	</form>
</section>
