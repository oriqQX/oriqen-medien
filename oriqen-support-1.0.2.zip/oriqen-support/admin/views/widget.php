<?php
/**
 * Dashboard-Widget (dezent, im WordPress-Stil).
 *
 * @package oriqen-support
 */

defined( 'ABSPATH' ) || exit;

$oqs_recent = OQ_Support_Store::query(
	array(
		'type'     => 'log',
		'per_page' => 3,
	)
)['items'];
$oqs_open   = OQ_Support_Store::count(
	array(
		'type'   => 'request',
		'status' => array( 'neu', 'in_arbeit' ),
	)
);
$oqs_ann    = OQ_Support_Store::announcements();
?>
<div class="oqs-widget">
	<style>.oqs-widget .oqs-q{display:inline-flex;width:18px;height:18px;vertical-align:-3px;margin-right:6px}.oqs-widget .oqs-q svg{width:100%;height:100%}.oqs-widget .oqs-q svg *{fill:#6600cc}.oqs-widget ul{margin:6px 0 12px}.oqs-widget li{margin:0 0 6px}.oqs-widget .oqs-brandname{text-transform:none;letter-spacing:normal}</style>
	<?php if ( $oqs_ann ) : ?>
		<div class="notice notice-info inline" style="margin:0 0 12px"><p><strong><?php echo esc_html( $oqs_ann[0]['title'] ); ?></strong><?php echo '' !== $oqs_ann[0]['body'] ? '<br>' . esc_html( wp_strip_all_tags( $oqs_ann[0]['body'] ) ) : ''; ?></p></div>
	<?php endif; ?>
	<p><?php echo OQ_Support_Admin::icon_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><strong><?php echo esc_html( 1 === $oqs_open ? '1 offener Wunsch' : $oqs_open . ' offene Wünsche' ); ?></strong></p>
	<?php if ( $oqs_recent && OQ_Support_Plugin::can_view( 'log' ) ) : ?>
		<p style="margin-bottom:0">Letzte Änderungen:</p>
		<ul>
			<?php foreach ( $oqs_recent as $oqs_e ) : ?>
				<li><span style="color:#5f5f5f"><?php echo esc_html( OQ_Support_Plugin::local( $oqs_e['created_at'], 'd.m.' ) ); ?></span> <?php echo esc_html( $oqs_e['title'] ); ?></li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>
	<p>
		<?php if ( OQ_Support_Plugin::can_view( 'requests' ) ) : ?>
			<a class="button button-primary" href="<?php echo esc_url( OQ_Support_Admin::url( 'oq-support-requests', array( 'new' => 1 ) ) . '#oqs-new' ); ?>">Wunsch eintragen</a>
		<?php endif; ?>
		<a class="button" href="<?php echo esc_url( OQ_Support_Admin::url() ); ?>">Zur Übersicht</a>
	</p>
</div>
