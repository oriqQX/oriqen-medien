/**
 * oriqen Support: Komfort im Backend. Alles funktioniert auch ohne JavaScript.
 */
( function () {
	'use strict';
	document.addEventListener(
		'submit',
		function ( e ) {
			var form = e.target;
			if ( form && form.getAttribute && form.getAttribute( 'data-oqs-confirm' ) ) {
				if ( ! window.confirm( form.getAttribute( 'data-oqs-confirm' ) ) ) {
					e.preventDefault();
				}
			}
		}
	);
	document.addEventListener(
		'click',
		function ( e ) {
			var btn = e.target.closest ? e.target.closest( '[data-oqs-print]' ) : null;
			if ( btn ) {
				e.preventDefault();
				window.print();
			}
		}
	);
	var toggle = document.getElementById( 'oqs-hide-done' );
	if ( toggle ) {
		var apply = function () {
			document.querySelectorAll( '[data-oqs-done="1"]' ).forEach(
				function ( el ) {
					el.hidden = toggle.checked;
				}
			);
		};
		toggle.addEventListener( 'change', apply );
		apply();
	}
	var pageSelect = document.getElementById( 'oqs-object-select' );
	var pageUrl    = document.getElementById( 'oqs-object-url' );
	if ( pageSelect && pageUrl ) {
		pageSelect.addEventListener(
			'change',
			function () {
				pageUrl.closest( 'p' ).hidden = '' !== pageSelect.value;
			}
		);
	}
}() );
