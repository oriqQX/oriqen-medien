<?php
/**
 * Formular-Aktionen über admin-post.php (funktionieren ohne JavaScript).
 *
 * @package oriqen-support
 */

defined( 'ABSPATH' ) || exit;

/**
 * Formular-Handler.
 */
class OQ_Support_Actions {

	/**
	 * Hooks.
	 */
	public static function init() {
		foreach ( array( 'save_log', 'delete_item', 'save_request', 'request_status', 'comment', 'save_note', 'save_handbook', 'save_profile', 'save_announcement', 'save_settings', 'export', 'import' ) as $a ) {
			add_action( 'admin_post_oq_support_' . $a, array( __CLASS__, $a ) );
		}
	}

	/**
	 * Nonce und Recht prüfen, sonst abbrechen.
	 *
	 * @param string $action Aktion.
	 * @param string $cap    Recht.
	 */
	protected static function verify( $action, $cap ) {
		check_admin_referer( 'oq_support_' . $action );
		if ( ! current_user_can( $cap ) ) {
			wp_die( esc_html__( 'Dafür fehlen die Rechte.', 'oriqen-support' ), 403 );
		}
	}

	/**
	 * Zurück zur Seite mit Meldung.
	 *
	 * @param string $page   Seite.
	 * @param string $msg    Meldung.
	 * @param array  $args   Parameter.
	 * @param string $anchor Anker.
	 */
	protected static function done( $page, $msg, array $args = array(), $anchor = '' ) {
		wp_safe_redirect( OQ_Support_Admin::url( $page, array_merge( $args, array( 'oqs_msg' => $msg ) ) ) . ( $anchor ? '#' . $anchor : '' ) );
		exit;
	}

	/**
	 * POST-Feld lesen (ungefiltert, wird anschließend bereinigt).
	 *
	 * @param string $key Name.
	 */
	protected static function field( $key ) {
		return isset( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce in verify(), Bereinigung in OQ_Support_Store::sanitize().
	}

	/**
	 * Lokales Datum (Y-m-d) in UTC-Zeitstempel.
	 *
	 * @param string $date Datum.
	 * @param string $time Uhrzeit.
	 */
	public static function date_to_utc( $date, $time = '12:00:00' ) {
		return preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $date ) ? get_gmt_from_date( $date . ' ' . $time ) : '';
	}

	/**
	 * Protokolleintrag anlegen oder ändern (Betreuer).
	 */
	public static function save_log() {
		self::verify( 'save_log', 'oq_support_manage' );
		$id   = absint( self::field( 'id' ) );
		$data = array(
			'title'      => self::field( 'title' ),
			'body'       => self::field( 'body' ),
			'category'   => self::field( 'category' ),
			'source'     => in_array( self::field( 'source' ), array( 'oriqen', 'ki' ), true ) ? self::field( 'source' ) : 'oriqen',
			'object_ref' => self::field( 'object_ref' ),
		);
		if ( '' === trim( (string) $data['title'] ) ) {
			self::done( 'oq-support-log', 'error' );
		}
		$date = self::date_to_utc( self::field( 'date' ) );
		if ( $date ) {
			$data['created_at'] = $date;
		}
		if ( $id ) {
			$item = OQ_Support_Store::get( $id );
			if ( ! $item || 'log' !== $item['type'] ) {
				self::done( 'oq-support-log', 'error' );
			}
			$r = OQ_Support_Store::update( $id, $data );
		} else {
			$data['type'] = 'log';
			$r            = OQ_Support_Store::insert( $data );
		}
		self::done( 'oq-support-log', is_wp_error( $r ) ? 'error' : 'saved' );
	}

	/**
	 * Eintrag löschen. Notizen: Verfasser oder Betreuer, alles andere: Betreuer.
	 */
	public static function delete_item() {
		self::verify( 'delete_item', 'oq_support_view' );
		$id   = absint( self::field( 'id' ) );
		$back = sanitize_key( (string) self::field( 'back' ) );
		$back = isset( OQ_Support_Admin::pages()[ $back ] ) ? $back : 'oq-support';
		$item = OQ_Support_Store::get( $id );
		if ( ! $item ) {
			self::done( $back, 'error' );
		}
		$own = 'note' === $item['type'] && get_current_user_id() === (int) $item['author_id'];
		if ( ! $own && ! OQ_Support_Plugin::is_manager() ) {
			self::done( $back, 'forbidden' );
		}
		OQ_Support_Store::delete( $id );
		self::done( $back, 'deleted', 'note' === $item['type'] ? array( 'tab' => 'notes' ) : array() );
	}
	/**
	 * Betroffene Seite aus Auswahl oder freier URL.
	 */
	protected static function object_ref_field() {
		$sel = absint( self::field( 'object_page' ) );
		return $sel ? (string) $sel : (string) self::field( 'object_url' );
	}

	/**
	 * Wunsch anlegen (Kunde und Betreuer).
	 */
	public static function save_request() {
		self::verify( 'save_request', 'oq_support_view' );
		$r = OQ_Support_Requests::create(
			array(
				'title'      => self::field( 'title' ),
				'body'       => self::field( 'body' ),
				'priority'   => self::field( 'priority' ),
				'object_ref' => self::object_ref_field(),
			)
		);
		self::done( 'oq-support-requests', is_wp_error( $r ) ? 'error' : 'request_saved', array(), is_wp_error( $r ) ? 'oqs-new' : 'oqs-request-' . $r );
	}

	/**
	 * Status setzen (Betreuer), optional mit Antwort.
	 */
	public static function request_status() {
		self::verify( 'request_status', 'oq_support_manage' );
		$id = absint( self::field( 'id' ) );
		$r  = OQ_Support_Requests::set_status( $id, (string) self::field( 'status' ) );
		if ( ! is_wp_error( $r ) && '' !== trim( (string) self::field( 'body' ) ) ) {
			OQ_Support_Requests::comment( $id, self::field( 'body' ) );
		}
		self::done( 'oq-support-requests', is_wp_error( $r ) ? 'error' : 'status_saved', array(), 'oqs-request-' . $id );
	}

	/**
	 * Kommentar.
	 */
	public static function comment() {
		self::verify( 'comment', 'oq_support_view' );
		$id = absint( self::field( 'id' ) );
		$r  = OQ_Support_Requests::comment( $id, self::field( 'body' ) );
		self::done( 'oq-support-requests', is_wp_error( $r ) ? 'error' : 'comment_saved', array(), 'oqs-request-' . $id );
	}

	/**
	 * Notiz anlegen oder ändern.
	 */
	public static function save_note() {
		self::verify( 'save_note', 'oq_support_view' );
		$r   = OQ_Support_Requests::save_note(
			absint( self::field( 'id' ) ),
			array(
				'title' => self::field( 'title' ),
				'body'  => self::field( 'body' ),
			)
		);
		$msg = is_wp_error( $r ) ? ( 'oq_support_forbidden' === $r->get_error_code() ? 'forbidden' : 'error' ) : 'saved';
		self::done( 'oq-support-requests', $msg, array( 'tab' => 'notes' ) );
	}
	/**
	 * Handbuch speichern (Betreuer).
	 */
	public static function save_handbook() {
		self::verify( 'save_handbook', 'oq_support_manage' );
		$in       = self::field( 'sections' );
		$sections = array();
		foreach ( is_array( $in ) ? $in : array() as $s ) {
			if ( is_array( $s ) && empty( $s['remove'] ) ) {
				$sections[] = $s;
			}
		}
		$new_title = trim( (string) self::field( 'new_title' ) );
		if ( '' !== $new_title ) {
			$sections[] = array(
				'key'   => 'custom_' . substr( md5( $new_title . microtime() ), 0, 8 ),
				'title' => $new_title,
				'body'  => self::field( 'new_body' ),
			);
		}
		update_option( 'oq_support_handbook', OQ_Support_Plugin::sanitize_handbook( array( 'sections' => $sections ) ), false );
		self::done( 'oq-support-handbook', 'saved' );
	}
	/**
	 * Kontakt, Betreuung und KI-Regeln (Betreuer).
	 */
	public static function save_profile() {
		self::verify( 'save_profile', 'oq_support_manage' );
		$in = self::field( 'profile' );
		update_option( 'oq_support_profile', OQ_Support_Plugin::sanitize_profile( is_array( $in ) ? $in : array() ), false );
		self::done( 'oq-support-contact', 'saved' );
	}

	/**
	 * Mitteilung anlegen (Betreuer).
	 */
	public static function save_announcement() {
		self::verify( 'save_announcement', 'oq_support_manage' );
		$exp = (string) self::field( 'expires' );
		$r   = '' === trim( (string) self::field( 'title' ) ) ? new WP_Error( 'x', '' ) : OQ_Support_Store::insert(
			array(
				'type'   => 'announcement',
				'title'  => self::field( 'title' ),
				'body'   => self::field( 'body' ),
				'source' => 'oriqen',
				'meta'   => preg_match( '/^\d{4}-\d{2}-\d{2}$/', $exp ) ? array( 'expires' => $exp ) : array(),
			)
		);
		self::done( 'oq-support', is_wp_error( $r ) ? 'error' : 'saved' );
	}

	/**
	 * Einstellungen und Betreuer (Betreuer).
	 */
	public static function save_settings() {
		self::verify( 'save_settings', 'oq_support_manage' );
		$sections = self::field( 'sections' );
		$in       = array(
			'footer_enabled'      => '1' === self::field( 'footer_enabled' ),
			'footer_mode'         => self::field( 'footer_mode' ),
			'footer_scheme'       => self::field( 'footer_scheme' ),
			'min_role'            => self::field( 'min_role' ),
			'notify_email'        => self::field( 'notify_email' ),
			'retention_months'    => self::field( 'retention_months' ),
			'delete_on_uninstall' => '1' === self::field( 'delete_on_uninstall' ),
			'sections'            => array(),
		);
		foreach ( array_keys( OQ_Support_Plugin::section_labels() ) as $k ) {
			$in['sections'][ $k ] = is_array( $sections ) && ! empty( $sections[ $k ] );
		}
		$managers = self::field( 'managers' );
		$managers = array_values( array_filter( array_map( 'absint', is_array( $managers ) ? $managers : array() ) ) );
		$managers = array_values(
			array_filter(
				$managers,
				function ( $id ) {
					return user_can( $id, 'edit_posts' );
				}
			)
		);
		if ( ! $managers ) {
			self::done( 'oq-support-settings', 'last_manager' );
		}
		foreach ( OQ_Support_Plugin::managers() as $old ) {
			if ( ! in_array( $old, $managers, true ) ) {
				delete_user_meta( $old, 'oq_support_manager' );
			}
		}
		foreach ( $managers as $id ) {
			update_user_meta( $id, 'oq_support_manager', '1' );
		}
		update_option( 'oq_support_settings', OQ_Support_Plugin::sanitize_settings( $in ), true );
		OQ_Support_Plugin::flush_settings();
		if ( ! in_array( get_current_user_id(), $managers, true ) ) {
			wp_safe_redirect( admin_url() );
			exit;
		}
		self::done( 'oq-support-settings', 'saved' );
	}

	/**
	 * Export als JSON-Download (Betreuer).
	 */
	public static function export() {
		self::verify( 'export', 'oq_support_manage' );
		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="oriqen-support-' . sanitize_file_name( wp_parse_url( home_url(), PHP_URL_HOST ) ) . '-' . gmdate( 'Y-m-d' ) . '.json"' );
		echo wp_json_encode( OQ_Support_Transfer::export(), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
		exit;
	}

	/**
	 * Import per Datei-Upload (Betreuer, nur JSON bis 2 MB).
	 */
	public static function import() {
		self::verify( 'import', 'oq_support_manage' );
		$f    = isset( $_FILES['file'] ) && is_array( $_FILES['file'] ) ? $_FILES['file'] : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.NonceVerification.Missing -- Nonce in verify(); tmp_name, size und name werden einzeln geprüft.
		$tmp  = isset( $f['tmp_name'] ) ? (string) $f['tmp_name'] : '';
		$name = isset( $f['name'] ) ? sanitize_file_name( (string) $f['name'] ) : '';
		if ( ! $tmp || ! is_uploaded_file( $tmp ) || (int) ( $f['size'] ?? 0 ) > 2 * MB_IN_BYTES || '.json' !== strtolower( substr( $name, -5 ) ) ) {
			self::done( 'oq-support-settings', 'import_invalid' );
		}
		$data = json_decode( (string) file_get_contents( $tmp ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- hochgeladene Datei nur lesen.
		$r    = OQ_Support_Transfer::import( $data, (string) self::field( 'mode' ) );
		self::done( 'oq-support-settings', is_wp_error( $r ) ? 'import_invalid' : 'imported' );
	}
}
