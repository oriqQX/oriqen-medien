<?php
/**
 * Backend: Menü, Seiten, Formular-Aktionen, Dashboard-Widget.
 *
 * @package oriqen-support
 */

defined( 'ABSPATH' ) || exit;

/**
 * Backend-Steuerung.
 */
class OQ_Support_Admin {

	/**
	 * Hook-Suffixe der eigenen Seiten.
	 *
	 * @var string[]
	 */
	private static $hooks = array();

	/**
	 * Hooks registrieren.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_filter( 'admin_footer_text', array( __CLASS__, 'footer_text' ) );
		if ( class_exists( 'OQ_Support_Actions' ) ) {
			OQ_Support_Actions::init();
		}
		add_action( 'wp_dashboard_setup', array( __CLASS__, 'dashboard_setup' ) );
	}

	/**
	 * Seiten: slug => title, Bereich, nur Betreuer, View.
	 */
	public static function pages() {
		return array(
			'oq-support'          => array( 'Übersicht', '', false, 'overview' ),
			'oq-support-log'      => array( 'Protokoll', 'log', false, 'log' ),
			'oq-support-requests' => array( 'Wünsche & Notizen', 'requests', false, 'requests' ),
			'oq-support-handbook' => array( 'Handbuch', 'handbook', false, 'handbook' ),
			'oq-support-health'   => array( 'Website-Check', 'health', false, 'health' ),
			'oq-support-report'   => array( 'Monatsbericht', 'report', false, 'report' ),
			'oq-support-contact'  => array( 'Kontakt & Betreuung', 'contact', false, 'contact' ),
			'oq-support-settings' => array( 'Einstellungen', '', true, 'settings' ),
		);
	}

	/**
	 * SVG des q aus der Datei (austauschbar), mit Fallback.
	 */
	public static function icon_svg() {
		static $svg = null;
		if ( null === $svg ) {
			$file = OQ_SUPPORT_DIR . 'assets/q-mark.svg';
			$svg  = is_readable( $file ) ? (string) file_get_contents( $file ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- lokale Plugin-Datei.
			if ( false === strpos( $svg, '<svg' ) ) {
				$svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="#000" fill-rule="evenodd" d="M11 2.5a8.5 8.5 0 1 0 0 17 8.5 8.5 0 0 0 0-17Zm0 3a5.5 5.5 0 1 1 0 11 5.5 5.5 0 0 1 0-11Z"/><rect fill="#000" x="16.5" y="11" width="3" height="11.5" rx="1.5"/></svg>';
			}
		}
		return $svg;
	}

	/**
	 * Daten-URI für das Menü (WordPress färbt es ein).
	 */
	public static function icon_uri() {
		return 'data:image/svg+xml;base64,' . base64_encode( self::icon_svg() ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Menü-Icon.
	}

	/**
	 * Das q als Inline-SVG (gefiltert).
	 *
	 * @param string $css_class CSS-Klasse.
	 */
	public static function icon_html( $css_class = 'oqs-q' ) {
		$attrs = array(
			'xmlns'        => true,
			'viewbox'      => true,
			'width'        => true,
			'height'       => true,
			'fill'         => true,
			'fill-rule'    => true,
			'clip-rule'    => true,
			'd'            => true,
			'x'            => true,
			'y'            => true,
			'rx'           => true,
			'ry'           => true,
			'cx'           => true,
			'cy'           => true,
			'r'            => true,
			'transform'    => true,
			'points'       => true,
			'stroke'       => true,
			'stroke-width' => true,
		);
		$svg   = wp_kses(
			self::icon_svg(),
			array(
				'svg'      => $attrs,
				'g'        => $attrs,
				'path'     => $attrs,
				'rect'     => $attrs,
				'circle'   => $attrs,
				'ellipse'  => $attrs,
				'polygon'  => $attrs,
				'polyline' => $attrs,
			)
		);
		return '<span class="' . esc_attr( $css_class ) . '" aria-hidden="true">' . $svg . '</span>';
	}

	/**
	 * Menü anlegen.
	 */
	public static function menu() {
		self::$hooks[] = add_menu_page( 'oriqen Support', 'oriqen Support', 'oq_support_view', 'oq-support', array( __CLASS__, 'render' ), self::icon_uri(), 3 );
		foreach ( self::pages() as $slug => $p ) {
			if ( ( $p[2] && ! OQ_Support_Plugin::is_manager() ) || ( $p[1] && ! OQ_Support_Plugin::can_view( $p[1] ) ) ) {
				continue;
			}
			self::$hooks[] = add_submenu_page( 'oq-support', $p[0] . ' ‹ oriqen Support', $p[0], $p[2] ? 'oq_support_manage' : 'oq_support_view', $slug, array( __CLASS__, 'render' ) );
		}
	}

	/**
	 * Ist die aktuelle Seite eine eigene?
	 *
	 * @param string $hook Hook-Suffix.
	 */
	public static function is_own( $hook ) {
		return in_array( $hook, self::$hooks, true );
	}

	/**
	 * CSS und JS nur auf den eigenen Seiten.
	 *
	 * @param string $hook Hook-Suffix.
	 */
	public static function assets( $hook ) {
		if ( ! self::is_own( $hook ) ) {
			return;
		}
		wp_enqueue_style( 'oq-support-admin', OQ_SUPPORT_URL . 'assets/admin.css', array(), OQ_SUPPORT_VERSION );
		wp_enqueue_script( 'oq-support-admin', OQ_SUPPORT_URL . 'assets/admin.js', array(), OQ_SUPPORT_VERSION, true );
	}

	/**
	 * Fußzeile auf den eigenen Seiten.
	 *
	 * @param string $text Standardtext.
	 */
	public static function footer_text( $text ) {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( $screen && self::is_own( $screen->id ) ) {
			return 'Betreut von <a href="https://oriqen.de/" target="_blank" rel="noopener" class="oqs-brandname">oriqen Digital Studio</a>';
		}
		return $text;
	}

	/**
	 * Adresse einer eigenen Seite.
	 *
	 * @param string $slug Seite.
	 * @param array  $args Parameter.
	 */
	public static function url( $slug = 'oq-support', array $args = array() ) {
		return add_query_arg( array_merge( array( 'page' => $slug ), $args ), admin_url( 'admin.php' ) );
	}

	/**
	 * Meldungstexte.
	 */
	public static function messages() {
		return array(
			'saved'          => 'Gespeichert.',
			'deleted'        => 'Gelöscht.',
			'request_saved'  => 'Vielen Dank, Ihr Wunsch ist eingetragen.',
			'comment_saved'  => 'Ihr Kommentar ist gespeichert.',
			'status_saved'   => 'Der Status ist gesetzt.',
			'imported'       => 'Der Import ist abgeschlossen.',
			'error'          => 'Das hat nicht geklappt. Bitte prüfen Sie die Eingaben.',
			'forbidden'      => 'Dafür fehlen die Rechte.',
			'last_manager'   => 'Mindestens ein Betreuer muss bleiben.',
			'import_invalid' => 'Die Datei ist keine gültige Exportdatei von oriqen Support.',
		);
	}

	/**
	 * Seite ausgeben.
	 */
	public static function render() {
		$slug  = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : 'oq-support'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$pages = self::pages();
		if ( ! isset( $pages[ $slug ] ) ) {
			$slug = 'oq-support';
		}
		$p = $pages[ $slug ];
		if ( ( $p[2] && ! OQ_Support_Plugin::is_manager() ) || ! OQ_Support_Plugin::can_view( $p[1] ) ) {
			wp_die( esc_html__( 'Dieser Bereich ist für Sie nicht freigeschaltet.', 'oriqen-support' ), 403 );
		}
		$title   = $p[0];
		$manager = OQ_Support_Plugin::is_manager();
		$msg     = isset( $_GET['oqs_msg'] ) ? sanitize_key( wp_unslash( $_GET['oqs_msg'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$msgs    = self::messages();
		echo '<div class="wrap oqs-wrap">';
		include OQ_SUPPORT_DIR . 'admin/views/header.php';
		if ( isset( $msgs[ $msg ] ) ) {
			$bad = in_array( $msg, array( 'error', 'forbidden', 'last_manager', 'import_invalid' ), true );
			echo '<div class="oqs-notice ' . ( $bad ? 'oqs-notice--error' : 'oqs-notice--ok' ) . '" role="status">' . esc_html( $msgs[ $msg ] ) . '</div>';
		}
		$view = OQ_SUPPORT_DIR . 'admin/views/' . $p[3] . '.php';
		if ( is_readable( $view ) ) {
			include $view;
		}
		echo '</div>';
	}

	/**
	 * Kategorie-Chip.
	 *
	 * @param string $cat Kategorie.
	 */
	public static function chip_category( $cat ) {
		$c = OQ_Support_Store::categories();
		return '<span class="oqs-chip oqs-chip--cat-' . esc_attr( $cat ) . '">' . esc_html( $c[ $cat ] ?? $cat ) . '</span>';
	}

	/**
	 * Status-Chip.
	 *
	 * @param string $status Status.
	 */
	public static function chip_status( $status ) {
		return '<span class="oqs-chip oqs-chip--' . esc_attr( $status ) . '">' . esc_html( OQ_Support_Store::STATUSES[ $status ] ?? $status ) . '</span>';
	}

	/**
	 * Quelle mit Symbol.
	 *
	 * @param string $source Quelle.
	 */
	public static function source_badge( $source ) {
		$icons = array(
			'oriqen' => 'dashicons-admin-users',
			'ki'     => 'dashicons-superhero-alt',
			'kunde'  => 'dashicons-businessperson',
			'system' => 'dashicons-admin-generic',
		);
		$label = OQ_Support_Store::SOURCES[ $source ] ?? $source;
		return '<span class="oqs-source oqs-source--' . esc_attr( $source ) . '"><span class="dashicons ' . esc_attr( $icons[ $source ] ?? 'dashicons-marker' ) . '" aria-hidden="true"></span>' . ( 'oriqen' === $source ? '<span class="oqs-brandname">oriqen</span>' : esc_html( $label ) ) . '</span>';
	}

	/**
	 * Link zur betroffenen Seite.
	 *
	 * @param string|null $ref Post-ID oder URL.
	 */
	public static function object_link( $ref ) {
		if ( null === $ref || '' === $ref ) {
			return '';
		}
		if ( ctype_digit( (string) $ref ) ) {
			$url   = get_permalink( (int) $ref );
			$title = get_the_title( (int) $ref );
			if ( ! $url ) {
				return '';
			}
			return '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html( '' !== $title ? $title : '#' . $ref ) . '</a>';
		}
		return '<a href="' . esc_url( $ref ) . '" target="_blank" rel="noopener">' . esc_html( preg_replace( '#^https?://#', '', $ref ) ) . '</a>';
	}

	/**
	 * Dashboard-Widget registrieren (Modul 10).
	 */
	public static function dashboard_setup() {
		if ( current_user_can( 'oq_support_view' ) && is_readable( OQ_SUPPORT_DIR . 'admin/views/widget.php' ) ) {
			wp_add_dashboard_widget( 'oq_support_widget', 'oriqen Support', array( __CLASS__, 'widget' ) );
		}
	}

	/**
	 * Dashboard-Widget ausgeben.
	 */
	public static function widget() {
		include OQ_SUPPORT_DIR . 'admin/views/widget.php';
	}
}
