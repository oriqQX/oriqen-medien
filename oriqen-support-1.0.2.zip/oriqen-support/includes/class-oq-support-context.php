<?php
/**
 * Kontextpaket für die KI.
 *
 * @package oriqen-support
 */

defined( 'ABSPATH' ) || exit;

/**
 * Baut das Kontextpaket als Daten und als Markdown.
 */
class OQ_Support_Context {

	const LIMIT = 4000;

	/**
	 * HTML in Markdown-nahen Text wandeln (rein).
	 *
	 * @param string $html HTML.
	 */
	public static function html_to_text( $html ) {
		$h = (string) $html;
		$h = preg_replace( '#<(script|style)\b[^>]*>.*?</\1>#is', '', $h );
		$h = preg_replace_callback(
			'#<h([1-6])[^>]*>(.*?)</h\1>#is',
			function ( $m ) {
				return "\n\n" . str_repeat( '#', min( 6, (int) $m[1] + 2 ) ) . ' ' . trim( wp_strip_all_tags( $m[2] ) ) . "\n\n";
			},
			$h
		);
		$h = preg_replace_callback(
			'#<a\s[^>]*href=("|\')(.*?)\1[^>]*>(.*?)</a>#is',
			function ( $m ) {
				$t = trim( wp_strip_all_tags( $m[3] ) );
				return '' === $t ? $m[2] : '[' . $t . '](' . $m[2] . ')';
			},
			$h
		);
		$h = preg_replace( '#<(strong|b)\b[^>]*>(.*?)</\1>#is', '**$2**', $h );
		$h = preg_replace( '#<(em|i)\b[^>]*>(.*?)</\1>#is', '*$2*', $h );
		$h = preg_replace( '#<code\b[^>]*>(.*?)</code>#is', '`$1`', $h );
		$h = preg_replace( '#<li\b[^>]*>#i', "\n- ", $h );
		$h = preg_replace( '#<br\s*/?>#i', "\n", $h );
		$h = preg_replace( '#</(p|div|ul|ol|li|table|tr|blockquote|h[1-6])>#i', "\n", $h );
		$h = html_entity_decode( wp_strip_all_tags( $h ), ENT_QUOTES, 'UTF-8' );
		$h = preg_replace( "/[ \t]+\n/", "\n", $h );
		$h = preg_replace( "/\n{3,}/", "\n\n", $h );
		return trim( $h );
	}

	/**
	 * Text kürzen mit Hinweis auf die Einzelroute (rein).
	 *
	 * @param string $text  Text.
	 * @param string $route Route.
	 */
	public static function cut( $text, $route ) {
		$text = (string) $text;
		if ( mb_strlen( $text ) <= self::LIMIT ) {
			return $text;
		}
		return rtrim( mb_substr( $text, 0, self::LIMIT ) ) . "\n\n[gekürzt, vollständig unter GET /" . OQ_Support_Rest::NS . $route . ']';
	}

	/**
	 * Erkannter Page-Builder.
	 */
	public static function builder() {
		$b = array();
		if ( defined( 'ELEMENTOR_VERSION' ) ) {
			$b[] = 'Elementor ' . ELEMENTOR_VERSION . ( defined( 'ELEMENTOR_PRO_VERSION' ) ? ' (Pro ' . ELEMENTOR_PRO_VERSION . ')' : '' );
		}
		if ( ! class_exists( 'Classic_Editor' ) ) {
			$b[] = 'Gutenberg (Block-Editor)' . ( function_exists( 'wp_is_block_theme' ) && wp_is_block_theme() ? ', Block-Theme' : '' );
		} else {
			$b[] = 'Klassischer Editor';
		}
		return implode( ', ', $b );
	}

	/**
	 * Status der oriqen AI Bridge.
	 */
	public static function bridge() {
		if ( defined( 'ORIQEN_AIB_VERSION' ) ) {
			return array(
				'active'    => true,
				'version'   => ORIQEN_AIB_VERSION,
				'namespace' => 'oriqen/v2',
				'text'      => 'oriqen AI Bridge ' . ORIQEN_AIB_VERSION . ' aktiv, Namespace oriqen/v2 (Alias oriqen/v1/elementor/{ID}), Manifest unter GET /oriqen/v2/',
			);
		}
		if ( function_exists( 'oriqen_bridge_get' ) ) {
			return array(
				'active'    => true,
				'version'   => '1.0',
				'namespace' => 'oriqen/v1',
				'text'      => 'oriqen Claude Bridge 1.0 aktiv, Route oriqen/v1/elementor/{ID}',
			);
		}
		return array(
			'active'    => false,
			'version'   => null,
			'namespace' => null,
			'text'      => 'nicht aktiv',
		);
	}

	/**
	 * Aktive Plugins mit Version.
	 */
	public static function plugins() {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$all = get_plugins();
		$out = array();
		foreach ( (array) get_option( 'active_plugins', array() ) as $f ) {
			$out[] = isset( $all[ $f ] ) ? trim( $all[ $f ]['Name'] . ' ' . $all[ $f ]['Version'] ) : (string) $f;
		}
		sort( $out );
		return $out;
	}

	/**
	 * Daten des Kontextpakets.
	 */
	public static function data() {
		global $wp_version;
		$profile = OQ_Support_Plugin::profile();
		$theme   = wp_get_theme();
		$hb      = array();
		foreach ( OQ_Support_Plugin::handbook()['sections'] as $s ) {
			$text = self::html_to_text( $s['body'] );
			if ( 'brand' === $s['key'] && '' !== trim( (string) ( $s['colors'] ?? '' ) ) ) {
				$text = "Farben:\n" . trim( $s['colors'] ) . ( '' !== $text ? "\n\n" . $text : '' );
			}
			$hb[] = array(
				'key'   => $s['key'],
				'title' => $s['title'],
				'text'  => self::cut( $text, '/handbook' ),
			);
		}
		$reqs = OQ_Support_Requests::list_requests( array( 'neu', 'in_arbeit' ) );
		$open = array();
		foreach ( $reqs as $r ) {
			$c = array();
			foreach ( $r['comments'] as $cm ) {
				$c[] = array(
					'source' => $cm['source'],
					'date'   => OQ_Support_Plugin::local( $cm['created_at'] ),
					'text'   => self::cut( self::html_to_text( $cm['body'] ), '/requests' ),
				);
			}
			$open[] = array(
				'id'       => $r['id'],
				'title'    => $r['title'],
				'status'   => $r['status'],
				'priority' => $r['priority'],
				'date'     => OQ_Support_Plugin::local( $r['created_at'] ),
				'page'     => OQ_Support_Rest::object_label( $r['object_ref'] ),
				'text'     => self::cut( self::html_to_text( $r['body'] ), '/requests' ),
				'comments' => $c,
			);
		}
		$notes = array();
		foreach ( OQ_Support_Store::query(
			array(
				'type'     => 'note',
				'orderby'  => 'updated_at',
				'per_page' => 50,
			)
		)['items'] as $n ) {
			$notes[] = array(
				'title' => $n['title'],
				'date'  => OQ_Support_Plugin::local( $n['updated_at'] ),
				'text'  => self::cut( self::html_to_text( $n['body'] ), '/notes' ),
			);
		}
		$logs = array();
		foreach ( OQ_Support_Store::query(
			array(
				'type'     => 'log',
				'per_page' => 25,
			)
		)['items'] as $l ) {
			$logs[] = array(
				'id'       => $l['id'],
				'date'     => OQ_Support_Plugin::local( $l['created_at'] ),
				'category' => $l['category'],
				'source'   => $l['source'],
				'title'    => $l['title'],
				'count'    => (int) ( $l['meta']['count'] ?? 1 ),
			);
		}
		$ann = array();
		foreach ( OQ_Support_Store::announcements() as $a ) {
			$ann[] = array(
				'title'   => $a['title'],
				'expires' => $a['meta']['expires'] ?? null,
			);
		}
		return array(
			'site'          => array(
				'name'      => OQ_Support_Plugin::site_name(),
				'url'       => home_url( '/' ),
				'client'    => $profile['client'],
				'package'   => $profile['package'],
				'scope'     => $profile['scope'],
				'generated' => current_time( 'c' ),
			),
			'ai_rules'      => self::cut( $profile['ai_rules'], '/profile' ),
			'tech'          => array(
				'wordpress' => $wp_version,
				'php'       => PHP_VERSION,
				'theme'     => trim( $theme->get( 'Name' ) . ' ' . $theme->get( 'Version' ) ) . ( $theme->parent() ? ' (Child von ' . $theme->parent()->get( 'Name' ) . ' ' . $theme->parent()->get( 'Version' ) . ')' : '' ),
				'builder'   => self::builder(),
				'plugins'   => self::plugins(),
				'bridge'    => self::bridge(),
			),
			'handbook'      => $hb,
			'requests'      => $open,
			'notes'         => $notes,
			'log'           => $logs,
			'announcements' => $ann,
			'instructions'  => self::instructions(),
		);
	}

	/**
	 * Fester Schluss-Abschnitt.
	 */
	public static function instructions() {
		$ns = '/' . OQ_Support_Rest::NS;
		return array(
			'Am Ende jeder Sitzung je sinnvoller Änderung einen Eintrag anlegen: POST ' . $ns . '/log mit {"title": "...", "body": "...", "category": "inhalt|design|technik|seo|sicherheit|wartung|sonstiges", "object_ref": "Post-ID oder URL", "date": "optional, Y-m-d oder Y-m-d H:i, für nachgetragene Änderungen"}. Quelle ist automatisch "ki".',
			'Erledigte Wünsche abschließen: PATCH ' . $ns . '/requests/{id} mit {"status": "erledigt", "comment": "kurze Antwort an den Kunden"}.',
			'Rückfragen an den Kunden als Kommentar: POST ' . $ns . '/requests/{id}/comments mit {"body": "..."}.',
			'Keine Passwörter, Zugangsdaten oder personenbezogenen Daten in Protokoll, Handbuch oder Notizen speichern.',
			'Die KI-Regeln oben gehen vor. Kundenseiten nur mit den Rechten und Werkzeugen ändern, die diese Sitzung hat.',
		);
	}

	/**
	 * Markdown-Fassung.
	 *
	 * @param array|null $d Daten.
	 */
	public static function markdown( $d = null ) {
		$d    = $d ? $d : self::data();
		$cats = OQ_Support_Store::categories();
		$src  = OQ_Support_Store::SOURCES;
		$o    = array();
		$o[]  = '# oriqen Support: Kontext für ' . $d['site']['name'];
		$o[]  = '';
		$o[]  = '- URL: ' . $d['site']['url'];
		$o[]  = '- Kunde: ' . ( '' !== $d['site']['client'] ? $d['site']['client'] : 'nicht gepflegt' );
		$o[]  = '- Betreuungspaket: ' . ( '' !== $d['site']['package'] ? $d['site']['package'] : 'nicht gepflegt' );
		if ( '' !== $d['site']['scope'] ) {
			$o[] = '- Leistungsumfang: ' . str_replace( "\n", ' ', $d['site']['scope'] );
		}
		$o[] = '- Stand: ' . $d['site']['generated'];
		if ( $d['announcements'] ) {
			$o[] = '- Aktive Mitteilung an den Kunden: ' . $d['announcements'][0]['title'];
		}
		$o[] = '';
		$o[] = '## KI-Regeln';
		$o[] = '';
		$o[] = '' !== trim( $d['ai_rules'] ) ? $d['ai_rules'] : 'Keine eigenen Regeln hinterlegt. Im Zweifel vor Veröffentlichungen beim Betreuer nachfragen.';
		$o[] = '';
		$o[] = '## Technik';
		$o[] = '';
		$o[] = '- WordPress ' . $d['tech']['wordpress'] . ', PHP ' . $d['tech']['php'];
		$o[] = '- Theme: ' . $d['tech']['theme'];
		$o[] = '- Page-Builder: ' . $d['tech']['builder'];
		$o[] = '- oriqen AI Bridge: ' . $d['tech']['bridge']['text'];
		$o[] = '- Aktive Plugins (' . count( $d['tech']['plugins'] ) . '): ' . implode( ', ', $d['tech']['plugins'] );
		$o[] = '';
		$o[] = '## Handbuch';
		foreach ( $d['handbook'] as $s ) {
			$o[] = '';
			$o[] = '### ' . $s['title'];
			$o[] = '';
			$o[] = '' !== $s['text'] ? $s['text'] : '(leer)';
		}
		$o[] = '';
		$o[] = '## Offene Wünsche (' . count( $d['requests'] ) . ')';
		$o[] = '';
		if ( ! $d['requests'] ) {
			$o[] = 'Keine offenen Wünsche.';
			$o[] = '';
		}
		foreach ( $d['requests'] as $r ) {
			$o[] = '### #' . $r['id'] . ' ' . $r['title'] . ' [' . $r['status'] . ( 'hoch' === $r['priority'] ? ', dringend' : '' ) . ']';
			$o[] = '';
			$o[] = 'Eingetragen ' . $r['date'] . ( $r['page'] ? ', Seite: ' . $r['page'] : '' );
			if ( '' !== $r['text'] ) {
				$o[] = '';
				$o[] = $r['text'];
			}
			foreach ( $r['comments'] as $c ) {
				$o[] = '';
				$o[] = '> ' . ( $src[ $c['source'] ] ?? $c['source'] ) . ', ' . $c['date'] . ': ' . str_replace( "\n", "\n> ", $c['text'] );
			}
			$o[] = '';
		}
		$o[] = '## Notizen des Kunden (' . count( $d['notes'] ) . ')';
		$o[] = '';
		if ( ! $d['notes'] ) {
			$o[] = 'Keine Notizen.';
		}
		foreach ( $d['notes'] as $n ) {
			$o[] = '- **' . $n['title'] . '** (' . $n['date'] . ')' . ( '' !== $n['text'] ? ': ' . str_replace( "\n", ' ', $n['text'] ) : '' );
		}
		$o[] = '';
		$o[] = '## Letzte Protokolleinträge';
		$o[] = '';
		if ( ! $d['log'] ) {
			$o[] = 'Noch keine Einträge.';
		}
		foreach ( $d['log'] as $l ) {
			$o[] = '- ' . $l['date'] . ' · ' . ( $cats[ $l['category'] ] ?? $l['category'] ) . ' · ' . ( $src[ $l['source'] ] ?? $l['source'] ) . ' · ' . $l['title'] . ( $l['count'] > 1 ? ' (' . $l['count'] . '×)' : '' );
		}
		$o[] = '';
		$o[] = '## So arbeitest du mit dieser Seite';
		$o[] = '';
		foreach ( $d['instructions'] as $i => $line ) {
			$o[] = ( $i + 1 ) . '. ' . $line;
		}
		return implode( "\n", $o ) . "\n";
	}
}
