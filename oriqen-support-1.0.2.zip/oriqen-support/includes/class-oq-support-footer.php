<?php
/**
 * Footer-Verweis auf oriqen.de (statisches Markup, Inline-CSS, kein JavaScript).
 *
 * @package oriqen-support
 */

defined( 'ABSPATH' ) || exit;

/**
 * Footer-Verweis.
 */
class OQ_Support_Footer {

	/**
	 * CSS schon ausgegeben?
	 *
	 * @var bool
	 */
	private static $css_done = false;

	/**
	 * Hooks.
	 */
	public static function init() {
		add_shortcode( 'oriqen_credit', array( __CLASS__, 'shortcode' ) );
		if ( ! is_admin() ) {
			add_action( 'wp_footer', array( __CLASS__, 'auto' ), 100 );
		}
	}

	/**
	 * Inline-CSS (einmal pro Seite).
	 */
	private static function css() {
		if ( self::$css_done ) {
			return '';
		}
		self::$css_done = true;
		return '<style id="oqs-credit-css">.oqs-credit{text-align:center;font-size:12.5px;line-height:1.5;padding:10px;margin:0}'
			. '.oqs-credit a{color:#6600CC;font-weight:700;text-decoration:none;text-transform:none!important;letter-spacing:normal!important;font-variant:normal!important}'
			. '.oqs-credit a:hover,.oqs-credit a:focus-visible{color:#5200A3;text-decoration:underline;text-underline-offset:3px}'
			. '.oqs-credit--dark{background:#140029;color:rgba(255,255,255,.75)}.oqs-credit--dark a{color:#C9A7FF}.oqs-credit--dark a:hover{color:#F3E6FF}'
			. '.oqs-credit--light{background:#f5f5f5;color:#1a1a1a}.oqs-credit--transparent{background:transparent;color:inherit}</style>';
	}

	/**
	 * Markup des Verweises.
	 *
	 * @param string $scheme dark|light|transparent.
	 */
	public static function markup( $scheme = '' ) {
		$s      = OQ_Support_Plugin::settings();
		$scheme = in_array( $scheme, array( 'dark', 'light', 'transparent' ), true ) ? $scheme : $s['footer_scheme'];
		return self::css() . '<div class="oqs-credit oqs-credit--' . esc_attr( $scheme ) . '">Entwickelt von <a href="https://oriqen.de/" target="_blank" rel="noopener" title="oriqen Digital Studio, Consulting und Design">oriqen.de</a> · Digital Studio | Consulting &amp; Design</div>';
	}

	/**
	 * Automatische Ausgabe am Seitenende.
	 */
	public static function auto() {
		$s = OQ_Support_Plugin::settings();
		if ( $s['footer_enabled'] && 'auto' === $s['footer_mode'] ) {
			echo self::markup(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- festes Markup, Klasse escaped.
		}
	}

	/**
	 * Shortcode [oriqen_credit scheme="dark|light|transparent"].
	 *
	 * @param array|string $atts Attribute.
	 */
	public static function shortcode( $atts ) {
		if ( ! OQ_Support_Plugin::settings()['footer_enabled'] ) {
			return '';
		}
		$atts = shortcode_atts( array( 'scheme' => '' ), (array) $atts, 'oriqen_credit' );
		return self::markup( (string) $atts['scheme'] );
	}
}
