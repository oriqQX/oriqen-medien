<?php
/**
 * Website-Check nur aus lokal vorhandenen Daten (keine externen Abfragen).
 *
 * @package oriqen-support
 */

defined( 'ABSPATH' ) || exit;

/**
 * Zustandsbericht mit Ampel.
 */
class OQ_Support_Health {

	/**
	 * Bekannte Plugins: Ordner => Name.
	 *
	 * @param string $kind backup|cache.
	 */
	private static function known( $kind ) {
		if ( 'backup' === $kind ) {
			return array(
				'duplicator'                 => 'Duplicator',
				'duplicator-pro'             => 'Duplicator Pro',
				'updraftplus'                => 'UpdraftPlus',
				'backwpup'                   => 'BackWPup',
				'all-in-one-wp-migration'    => 'All-in-One WP Migration',
				'wpvivid-backuprestore'      => 'WPvivid',
				'blogvault-real-time-backup' => 'BlogVault',
				'jetpack-backup'             => 'Jetpack VaultPress Backup',
				'backup-backup'              => 'Backup Migration',
			);
		}
		return array(
			'wp-optimize'             => 'WP-Optimize',
			'wp-rocket'               => 'WP Rocket',
			'w3-total-cache'          => 'W3 Total Cache',
			'litespeed-cache'         => 'LiteSpeed Cache',
			'wp-super-cache'          => 'WP Super Cache',
			'wp-fastest-cache'        => 'WP Fastest Cache',
			'fast-velocity-minify'    => 'Fast Velocity Minify',
			'autoptimize'             => 'Autoptimize',
			'breeze'                  => 'Breeze',
			'sg-cachepress'           => 'SiteGround Speed Optimizer',
			'cache-enabler'           => 'Cache Enabler',
			'hummingbird-performance' => 'Hummingbird',
		);
	}

	/**
	 * Aktive Plugin-Ordner.
	 */
	private static function active_dirs() {
		$out = array();
		foreach ( (array) get_option( 'active_plugins', array() ) as $f ) {
			$out[] = strtok( (string) $f, '/' );
		}
		return $out;
	}

	/**
	 * Punkt bauen.
	 *
	 * @param string $key   Schlüssel.
	 * @param string $label Bezeichnung.
	 * @param string $light green|yellow|red|info.
	 * @param string $text  Satz für den Kunden.
	 * @param array  $extra Zusatz.
	 */
	private static function item( $key, $label, $light, $text, array $extra = array() ) {
		return array(
			'key'   => $key,
			'label' => $label,
			'light' => $light,
			'text'  => $text,
			'extra' => $extra,
		);
	}

	/**
	 * Alle Punkte.
	 */
	public static function run() {
		global $wp_version;
		$items = array();

		$core = get_site_transient( 'update_core' );
		$new  = '';
		if ( is_object( $core ) && ! empty( $core->updates ) ) {
			foreach ( $core->updates as $u ) {
				if ( isset( $u->response ) && 'upgrade' === $u->response && ! empty( $u->current ) ) {
					$new = (string) $u->current;
					break;
				}
			}
		}
		$items[] = $new
			? self::item( 'core', 'WordPress', 'yellow', sprintf( 'WordPress %1$s ist installiert, Version %2$s steht bereit. Wir spielen sie bei der nächsten Wartung ein.', $wp_version, $new ) )
			: self::item( 'core', 'WordPress', 'green', sprintf( 'WordPress %s ist installiert. Nach dem letzten bekannten Stand ist das aktuell.', $wp_version ) );

		foreach ( array(
			'plugins' => array( 'update_plugins', 'Plugins', 'Plugin-Updates' ),
			'themes'  => array( 'update_themes', 'Themes', 'Theme-Updates' ),
		) as $key => $def ) {
			$t     = get_site_transient( $def[0] );
			$names = array();
			if ( is_object( $t ) && ! empty( $t->response ) ) {
				foreach ( (array) $t->response as $slug => $r ) {
					if ( 'plugins' === $key ) {
						$names[] = self::plugin_name( (string) $slug );
					} else {
						$names[] = wp_get_theme( (string) $slug )->get( 'Name' );
					}
				}
			}
			$n       = count( $names );
			$items[] = $n
				? self::item( $key, $def[1], 'yellow', ( 1 === $n ? '1 ' . substr( $def[2], 0, -1 ) . ' steht aus: ' : $n . ' ' . $def[2] . ' stehen aus: ' ) . implode( ', ', $names ) . '. Das ist normal, wir halten das im Blick.', array( 'names' => $names ) )
				: self::item( $key, $def[1], 'green', 'Keine ausstehenden ' . $def[2] . ' bekannt.' );
		}

		$items[] = version_compare( PHP_VERSION, '8.1', '<' )
			? self::item( 'php', 'PHP', 'yellow', sprintf( 'Der Server nutzt PHP %s. Eine Umstellung auf 8.1 oder neuer ist empfehlenswert, wir sprechen das mit Ihnen ab.', PHP_VERSION ) )
			: self::item( 'php', 'PHP', 'green', sprintf( 'Der Server nutzt PHP %s.', PHP_VERSION ) );

		$https   = 0 === strpos( home_url(), 'https://' ) && 0 === strpos( site_url(), 'https://' );
		$items[] = $https
			? self::item( 'https', 'Verschlüsselung', 'green', 'Die Website ist über HTTPS verschlüsselt erreichbar.' )
			: self::item( 'https', 'Verschlüsselung', 'red', 'Die Website-Adresse beginnt nicht mit https. Wir stellen das um.' );

		$items[] = '0' === (string) get_option( 'blog_public' )
			? self::item( 'visibility', 'Suchmaschinen', 'red', 'Suchmaschinen werden gebeten, die Website nicht aufzunehmen. Wenn die Seite fertig ist, muss das abgeschaltet werden.' )
			: self::item( 'visibility', 'Suchmaschinen', 'green', 'Suchmaschinen dürfen die Website aufnehmen.' );

		$debug   = defined( 'WP_DEBUG' ) && WP_DEBUG && ( ! defined( 'WP_DEBUG_DISPLAY' ) || WP_DEBUG_DISPLAY );
		$items[] = $debug
			? self::item( 'debug', 'Fehleranzeige', 'yellow', 'Der Fehlermodus ist eingeschaltet und zeigt Meldungen an. Das ist für die Entwicklung gedacht, wir schalten ihn wieder ab.' )
			: self::item( 'debug', 'Fehleranzeige', 'green', 'Technische Fehlermeldungen werden Besuchern nicht angezeigt.' );

		$users   = count_users();
		$admins  = (int) ( $users['avail_roles']['administrator'] ?? 0 );
		$items[] = self::item( 'admins', 'Administratoren', $admins > 3 ? 'yellow' : 'green', sprintf( 1 === $admins ? 'Es gibt %d Administrator.' : 'Es gibt %d Administratoren.', $admins ) . ( $admins > 3 ? ' Prüfen Sie gelegentlich, ob alle Zugänge noch gebraucht werden.' : '' ) );

		$dirs = self::active_dirs();
		foreach ( array(
			'backup' => array( 'Backup', 'Erkannte Backup-Lösung: %s.', 'Kein Backup-Plugin erkannt. Backups können auch beim Hosting laufen.' ),
			'cache'  => array( 'Cache', 'Erkannte Cache- und Optimierungs-Plugins: %s.', 'Kein Cache-Plugin erkannt.' ),
		) as $kind => $def ) {
			$found   = array_values( array_intersect_key( self::known( $kind ), array_flip( $dirs ) ) );
			$items[] = self::item( $kind, $def[0], 'info', $found ? sprintf( $def[1], implode( ', ', $found ) ) : $def[2], array( 'names' => $found ) );
		}

		$last    = OQ_Support_Store::query(
			array(
				'type'     => 'log',
				'category' => 'wartung',
				'per_page' => 1,
			)
		)['items'];
		$items[] = $last
			? self::item( 'maintenance', 'Letzte Wartung', 'info', 'Letzter Wartungseintrag: ' . OQ_Support_Plugin::local( $last[0]['created_at'], 'd.m.Y' ) . ', ' . $last[0]['title'] . '.', array( 'date' => $last[0]['created_at'] ) )
			: self::item( 'maintenance', 'Letzte Wartung', 'info', 'Noch kein Wartungseintrag im Protokoll.' );

		return $items;
	}

	/**
	 * Plugin-Name aus der Datei.
	 *
	 * @param string $file Plugin-Datei.
	 */
	private static function plugin_name( $file ) {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$all = get_plugins();
		return isset( $all[ $file ]['Name'] ) ? $all[ $file ]['Name'] : $file;
	}
}
