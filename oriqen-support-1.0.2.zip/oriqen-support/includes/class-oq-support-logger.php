<?php
/**
 * Automatische Protokolleinträge (source = system bzw. ki für die AI Bridge).
 *
 * @package oriqen-support
 */

defined( 'ABSPATH' ) || exit;

/**
 * Ereignisse erfassen und zusammenfassen.
 */
class OQ_Support_Logger {

	const MERGE_WINDOW = 1800;

	/**
	 * Schutz gegen Schleifen.
	 *
	 * @var bool
	 */
	private static $busy = false;

	/**
	 * Läuft gerade eine schreibende Anfrage der AI Bridge?
	 *
	 * @var bool
	 */
	private static $bridge = false;

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'upgrader_process_complete', array( __CLASS__, 'upgrader' ), 10, 2 );
		add_action( 'activated_plugin', array( __CLASS__, 'activated' ) );
		add_action( 'deactivated_plugin', array( __CLASS__, 'deactivated' ) );
		add_action( 'switch_theme', array( __CLASS__, 'switched_theme' ), 10, 2 );
		add_action( 'save_post', array( __CLASS__, 'save_post' ), 20, 3 );
		add_filter( 'rest_request_before_callbacks', array( __CLASS__, 'rest_before' ), 10, 3 );
		add_filter( 'rest_post_dispatch', array( __CLASS__, 'rest_after' ), 10, 3 );
	}

	/**
	 * Ereignis protokollieren. Gleiche Ereignisse am selben Objekt innerhalb von 30 Minuten
	 * werden zu einem Eintrag zusammengefasst (Zähler in meta.count).
	 *
	 * @param string      $title    Titel.
	 * @param string      $category Kategorie.
	 * @param string|null $ref      Objekt.
	 * @param string      $source   Quelle.
	 * @param string      $body     Text.
	 * @return int|WP_Error|false ID oder false bei Schleifenschutz.
	 */
	public static function event( $title, $category, $ref = null, $source = 'system', $body = '' ) {
		if ( self::$busy ) {
			return false;
		}
		self::$busy = true;
		$ref        = null === $ref ? null : (string) $ref;
		$key        = md5( $source . '|' . $title . '|' . (string) $ref );
		$recent     = OQ_Support_Store::query(
			array(
				'type'          => 'log',
				'source'        => $source,
				'updated_since' => gmdate( 'Y-m-d H:i:s', time() - self::MERGE_WINDOW ),
				'orderby'       => 'updated_at',
				'per_page'      => 50,
			)
		)['items'];
		$result     = null;
		foreach ( $recent as $item ) {
			if ( isset( $item['meta']['key'] ) && $item['meta']['key'] === $key ) {
				$meta          = $item['meta'];
				$meta['count'] = (int) ( $meta['count'] ?? 1 ) + 1;
				OQ_Support_Store::update( $item['id'], array( 'meta' => $meta ) );
				$result = (int) $item['id'];
				break;
			}
		}
		if ( null === $result ) {
			$result = OQ_Support_Store::insert(
				array(
					'type'       => 'log',
					'title'      => $title,
					'body'       => $body,
					'category'   => $category,
					'source'     => $source,
					'object_ref' => $ref,
					'meta'       => array(
						'key'   => $key,
						'count' => 1,
					),
				)
			);
		}
		self::$busy = false;
		return $result;
	}

	/**
	 * Name und Version eines Plugins.
	 *
	 * @param string $file Plugin-Datei relativ zum Plugin-Ordner.
	 */
	private static function plugin_label( $file ) {
		if ( ! function_exists( 'get_plugin_data' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$path = WP_PLUGIN_DIR . '/' . $file;
		if ( ! is_readable( $path ) ) {
			return $file;
		}
		$d = get_plugin_data( $path, false, false );
		return trim( ( $d['Name'] ? $d['Name'] : $file ) . ' ' . $d['Version'] );
	}

	/**
	 * Installationen und Updates.
	 *
	 * @param WP_Upgrader $upgrader Upgrader.
	 * @param array       $o        Optionen.
	 */
	public static function upgrader( $upgrader, $o ) {
		$type   = $o['type'] ?? '';
		$action = $o['action'] ?? '';
		if ( 'plugin' === $type ) {
			if ( 'install' === $action ) {
				$d = isset( $upgrader->new_plugin_data ) && is_array( $upgrader->new_plugin_data ) ? $upgrader->new_plugin_data : array();
				if ( ! empty( $d['Name'] ) ) {
					self::event( 'Plugin installiert: ' . trim( $d['Name'] . ' ' . ( $d['Version'] ?? '' ) ), 'technik' );
				}
				return;
			}
			$files = isset( $o['plugins'] ) ? (array) $o['plugins'] : ( isset( $o['plugin'] ) ? array( $o['plugin'] ) : array() );
			foreach ( $files as $f ) {
				if ( OQ_SUPPORT_BASENAME !== $f ) {
					self::event( 'Plugin aktualisiert: ' . self::plugin_label( $f ), 'wartung' );
				}
			}
		} elseif ( 'theme' === $type ) {
			if ( 'install' === $action ) {
				$d = isset( $upgrader->new_theme_data ) && is_array( $upgrader->new_theme_data ) ? $upgrader->new_theme_data : array();
				if ( ! empty( $d['Name'] ) ) {
					self::event( 'Theme installiert: ' . trim( $d['Name'] . ' ' . ( $d['Version'] ?? '' ) ), 'design' );
				}
				return;
			}
			$slugs = isset( $o['themes'] ) ? (array) $o['themes'] : ( isset( $o['theme'] ) ? array( $o['theme'] ) : array() );
			foreach ( $slugs as $s ) {
				$t = wp_get_theme( $s );
				self::event( 'Theme aktualisiert: ' . trim( $t->get( 'Name' ) . ' ' . $t->get( 'Version' ) ), 'wartung' );
			}
		} elseif ( 'core' === $type ) {
			$ver  = '';
			$file = ABSPATH . WPINC . '/version.php';
			if ( is_readable( $file ) && preg_match( "/wp_version\s*=\s*'([^']+)'/", (string) file_get_contents( $file ), $m ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- frisch aktualisierte Kerndatei lesen.
				$ver = $m[1];
			}
			self::event( trim( 'WordPress aktualisiert ' . ( $ver ? 'auf ' . $ver : '' ) ), 'wartung' );
		}
	}

	/**
	 * Plugin aktiviert.
	 *
	 * @param string $file Plugin.
	 */
	public static function activated( $file ) {
		if ( OQ_SUPPORT_BASENAME !== $file ) {
			self::event( 'Plugin aktiviert: ' . self::plugin_label( $file ), 'technik' );
		}
	}

	/**
	 * Plugin deaktiviert.
	 *
	 * @param string $file Plugin.
	 */
	public static function deactivated( $file ) {
		self::event( 'Plugin deaktiviert: ' . self::plugin_label( $file ), 'technik' );
	}

	/**
	 * Theme gewechselt.
	 *
	 * @param string   $name  Name.
	 * @param WP_Theme $theme Theme.
	 */
	public static function switched_theme( $name, $theme ) {
		$ver = $theme instanceof WP_Theme ? $theme->get( 'Version' ) : '';
		self::event( trim( 'Theme gewechselt: ' . $name . ' ' . $ver ), 'design' );
	}

	/**
	 * Inhaltsänderung durch einen Betreuer.
	 *
	 * @param int     $post_id ID.
	 * @param WP_Post $post    Beitrag.
	 * @param bool    $update  Aktualisierung.
	 */
	public static function save_post( $post_id, $post, $update ) {
		if ( self::$bridge || wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) ) {
			return;
		}
		if ( ! $post instanceof WP_Post || ! in_array( $post->post_type, array( 'page', 'post' ), true ) || 'publish' !== $post->post_status ) {
			return;
		}
		if ( ! OQ_Support_Plugin::is_manager() ) {
			return;
		}
		$what = 'page' === $post->post_type ? 'Seite' : 'Beitrag';
		self::event( $what . ' bearbeitet: ' . get_the_title( $post ), 'inhalt', (string) $post_id );
	}

	/**
	 * Ist das eine schreibende Anfrage an die AI Bridge?
	 *
	 * @param WP_REST_Request $request Anfrage.
	 */
	public static function is_bridge_write( $request ) {
		if ( ! $request instanceof WP_REST_Request || ! in_array( $request->get_method(), array( 'POST', 'PUT', 'PATCH', 'DELETE' ), true ) ) {
			return false;
		}
		$route = (string) $request->get_route();
		return 0 === strpos( $route, '/oriqen/v2/' ) || 0 === strpos( $route, '/oriqen/v1/elementor' );
	}

	/**
	 * Merken, dass die Bridge schreibt, damit save_post keinen zweiten Eintrag erzeugt.
	 *
	 * @param mixed           $response Antwort.
	 * @param array           $handler  Handler.
	 * @param WP_REST_Request $request  Anfrage.
	 */
	public static function rest_before( $response, $handler, $request ) {
		if ( self::is_bridge_write( $request ) ) {
			self::$bridge = true;
		}
		return $response;
	}

	/**
	 * Erfolgreiche Bridge-Änderung protokollieren.
	 *
	 * @param WP_HTTP_Response $result  Antwort.
	 * @param WP_REST_Server   $server  Server.
	 * @param WP_REST_Request  $request Anfrage.
	 */
	public static function rest_after( $result, $server, $request ) {
		if ( ! self::is_bridge_write( $request ) ) {
			return $result;
		}
		self::$bridge = false;
		$status       = $result instanceof WP_HTTP_Response ? (int) $result->get_status() : 0;
		$data         = $result instanceof WP_HTTP_Response ? $result->get_data() : null;
		if ( $status < 200 || $status >= 300 || ( is_array( $data ) && ! empty( $data['dry_run'] ) ) ) {
			return $result;
		}
		$route = (string) $request->get_route();
		$info  = self::bridge_info( $route, is_array( $data ) ? $data : array() );
		foreach ( $info['ids'] ? $info['ids'] : array( null ) as $id ) {
			$title = 'Änderung über die oriqen AI Bridge';
			if ( $id && get_post( $id ) ) {
				$title .= ': ' . get_the_title( $id );
			} elseif ( $info['area'] ) {
				$title .= ' (' . $info['area'] . ')';
			}
			self::event( $title, $info['category'], $id ? (string) $id : null, 'ki', 'Route: ' . esc_html( $route ) );
		}
		return $result;
	}

	/**
	 * Betroffene IDs, Bereich und Kategorie aus Route und Antwort (rein).
	 *
	 * @param string $route Route.
	 * @param array  $data  Antwortdaten.
	 */
	public static function bridge_info( $route, array $data ) {
		$seg  = explode( '/', trim( preg_replace( '#^/oriqen/v[12]/#', '', $route ), '/' ) );
		$area = $seg[0] ?? '';
		$map  = array(
			'elementor' => array( 'inhalt', 'Elementor' ),
			'blocks'    => array( 'inhalt', 'Blöcke' ),
			'seo'       => array( 'seo', 'SEO' ),
			'schema'    => array( 'seo', 'Schema' ),
			'redirects' => array( 'seo', 'Weiterleitungen' ),
			'replace'   => array( 'inhalt', 'Suchen und Ersetzen' ),
			'media'     => array( 'inhalt', 'Medien' ),
			'css'       => array( 'design', 'CSS' ),
			'snippets'  => array( 'technik', 'Snippets' ),
			'undo'      => array( 'sonstiges', 'Rückgängig' ),
		);
		if ( 'elementor' === $area && isset( $seg[1] ) && 'kit' === $seg[1] ) {
			$map['elementor'] = array( 'design', 'Elementor-Kit' );
		}
		$ids = array();
		if ( 'undo' !== $area ) {
			if ( isset( $seg[1] ) && ctype_digit( $seg[1] ) ) {
				$ids[] = (int) $seg[1];
			} elseif ( isset( $data['id'] ) && is_numeric( $data['id'] ) ) {
				$ids[] = (int) $data['id'];
			}
			foreach ( array( 'pages', 'items' ) as $list ) {
				if ( ! $ids && isset( $data[ $list ] ) && is_array( $data[ $list ] ) ) {
					foreach ( $data[ $list ] as $row ) {
						if ( is_array( $row ) && ! empty( $row['saved'] ) && isset( $row['id'] ) && 'items' !== $list ) {
							$ids[] = (int) $row['id'];
						}
					}
				}
			}
		}
		return array(
			'ids'      => array_slice( array_values( array_unique( $ids ) ), 0, 20 ),
			'area'     => $map[ $area ][1] ?? $area,
			'category' => $map[ $area ][0] ?? 'technik',
		);
	}
}
