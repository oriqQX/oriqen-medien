<?php
/**
 * Kern: Einstellungen, Rechte, Aktivierung, Upgrade.
 *
 * @package oriqen-support
 */

defined( 'ABSPATH' ) || exit;

/**
 * Kernklasse.
 */
class OQ_Support_Plugin {

	const DB_VERSION = '1';

	/**
	 * Zwischenspeicher der Einstellungen.
	 *
	 * @var array|null
	 */
	private static $settings = null;

	/**
	 * Start auf plugins_loaded.
	 */
	public static function init() {
		self::maybe_upgrade();
		add_filter( 'user_has_cap', array( __CLASS__, 'grant_caps' ), 10, 4 );
		add_action( 'oq_support_cleanup', array( 'OQ_Support_Store', 'cleanup' ) );
		add_action( 'update_option_oq_support_settings', array( __CLASS__, 'flush_settings' ) );
		foreach ( array( 'Logger', 'Footer', 'Rest' ) as $part ) {
			$class = 'OQ_Support_' . $part;
			if ( class_exists( $class ) ) {
				$class::init();
			}
		}
		if ( is_admin() && class_exists( 'OQ_Support_Admin' ) ) {
			OQ_Support_Admin::init();
		}
	}

	/* ---------- Einstellungen, Profil, Handbuch ---------- */

	/**
	 * Bereiche, die der Kunde sehen kann.
	 */
	public static function section_labels() {
		return array(
			'log'      => 'Protokoll',
			'requests' => 'Wünsche & Notizen',
			'handbook' => 'Handbuch',
			'health'   => 'Website-Check',
			'report'   => 'Monatsbericht',
			'contact'  => 'Kontakt & Betreuung',
		);
	}

	/**
	 * Standard-Einstellungen.
	 */
	public static function default_settings() {
		return array(
			'footer_enabled'      => true,
			'footer_mode'         => 'auto',
			'footer_scheme'       => 'dark',
			'min_role'            => 'edit_posts',
			'notify_email'        => '',
			'retention_months'    => 12,
			'delete_on_uninstall' => false,
			'sections'            => array_fill_keys( array_keys( self::section_labels() ), true ),
		);
	}

	/**
	 * Einstellungen (gecacht).
	 */
	public static function settings() {
		if ( null === self::$settings ) {
			$saved          = get_option( 'oq_support_settings', array() );
			self::$settings = self::sanitize_settings( is_array( $saved ) ? $saved : array() );
		}
		return self::$settings;
	}

	/**
	 * Cache leeren.
	 */
	public static function flush_settings() {
		self::$settings = null;
	}

	/**
	 * Einstellungen bereinigen und mit Standardwerten auffüllen.
	 *
	 * @param array $in Eingabe.
	 */
	public static function sanitize_settings( array $in ) {
		$d   = self::default_settings();
		$out = array(
			'footer_enabled'      => isset( $in['footer_enabled'] ) ? (bool) $in['footer_enabled'] : $d['footer_enabled'],
			'footer_mode'         => isset( $in['footer_mode'] ) && in_array( $in['footer_mode'], array( 'auto', 'shortcode' ), true ) ? $in['footer_mode'] : $d['footer_mode'],
			'footer_scheme'       => isset( $in['footer_scheme'] ) && in_array( $in['footer_scheme'], array( 'dark', 'light', 'transparent' ), true ) ? $in['footer_scheme'] : $d['footer_scheme'],
			'min_role'            => isset( $in['min_role'] ) && in_array( $in['min_role'], array( 'edit_posts', 'manage_options' ), true ) ? $in['min_role'] : $d['min_role'],
			'notify_email'        => isset( $in['notify_email'] ) ? (string) sanitize_email( (string) $in['notify_email'] ) : '',
			'retention_months'    => isset( $in['retention_months'] ) ? max( 1, min( 120, (int) $in['retention_months'] ) ) : $d['retention_months'],
			'delete_on_uninstall' => ! empty( $in['delete_on_uninstall'] ),
			'sections'            => array(),
		);
		foreach ( $d['sections'] as $key => $on ) {
			$out['sections'][ $key ] = isset( $in['sections'][ $key ] ) ? (bool) $in['sections'][ $key ] : $on;
		}
		return $out;
	}

	/**
	 * Profilfelder mit Beschriftung.
	 */
	public static function profile_fields() {
		return array(
			'client'           => 'Kunde',
			'package'          => 'Betreuungspaket',
			'scope'            => 'Leistungsumfang',
			'next_maintenance' => 'Nächste Wartung',
			'studio'           => 'Studio',
			'contact_person'   => 'Ansprechpartner',
			'email'            => 'E-Mail',
			'phone'            => 'Telefon',
			'website'          => 'Website',
			'location'         => 'Ort',
			'availability'     => 'Erreichbarkeit',
			'response_time'    => 'Reaktionszeit',
			'emergency'        => 'Notfallweg',
			'ai_rules'         => 'KI-Regeln',
		);
	}

	/**
	 * Profil mit Standardwerten.
	 */
	public static function profile() {
		$p   = get_option( 'oq_support_profile', array() );
		$p   = is_array( $p ) ? $p : array();
		$out = array();
		foreach ( array_keys( self::profile_fields() ) as $k ) {
			$out[ $k ] = isset( $p[ $k ] ) ? (string) $p[ $k ] : '';
		}
		return $out;
	}

	/**
	 * Profil bereinigen.
	 *
	 * @param array $in Eingabe.
	 */
	public static function sanitize_profile( array $in ) {
		$out = self::profile();
		foreach ( array_keys( self::profile_fields() ) as $k ) {
			if ( ! array_key_exists( $k, $in ) ) {
				continue;
			}
			$v = (string) $in[ $k ];
			if ( 'email' === $k ) {
				$out[ $k ] = sanitize_email( $v );
			} elseif ( 'website' === $k ) {
				$out[ $k ] = esc_url_raw( $v );
			} elseif ( in_array( $k, array( 'scope', 'emergency', 'ai_rules', 'availability' ), true ) ) {
				$out[ $k ] = sanitize_textarea_field( $v );
			} else {
				$out[ $k ] = sanitize_text_field( $v );
			}
		}
		return $out;
	}

	/**
	 * Feste Handbuch-Abschnitte.
	 */
	public static function handbook_fixed() {
		return array(
			'media'   => 'Bilder & Medien',
			'brand'   => 'Marke',
			'content' => 'Inhalte pflegen',
			'tech'    => 'Technik & Zugänge',
		);
	}

	/**
	 * Vorbelegung des Handbuchs.
	 */
	public static function default_handbook() {
		return array(
			'sections' => array(
				array(
					'key'   => 'media',
					'title' => 'Bilder & Medien',
					'body'  => "<ul>\n<li><strong>Beitragsbild:</strong> 1200 × 675 px (16:9).</li>\n<li><strong>Galerie:</strong> mindestens 1600 px an der langen Kante.</li>\n<li><strong>Format:</strong> WebP oder JPG.</li>\n<li><strong>Dateigröße:</strong> möglichst unter 300 KB.</li>\n<li><strong>Dateinamen:</strong> sprechend, ohne Umlaute und Leerzeichen, z. B. <code>kueche-landhaus-eiche.webp</code>.</li>\n<li><strong>Alternativtext:</strong> beschreibt den Bildinhalt in einem kurzen Satz.</li>\n</ul>",
				),
				array(
					'key'    => 'brand',
					'title'  => 'Marke',
					'body'   => '',
					'colors' => '',
				),
				array(
					'key'   => 'content',
					'title' => 'Inhalte pflegen',
					'body'  => '',
				),
				array(
					'key'   => 'tech',
					'title' => 'Technik & Zugänge',
					'body'  => '',
				),
			),
		);
	}

	/**
	 * Handbuch.
	 */
	public static function handbook() {
		$h = get_option( 'oq_support_handbook', array() );
		if ( ! is_array( $h ) || empty( $h['sections'] ) || ! is_array( $h['sections'] ) ) {
			$h = self::default_handbook();
		}
		return self::sanitize_handbook( $h );
	}

	/**
	 * Handbuch bereinigen. Feste Abschnitte bleiben immer erhalten, in fester Reihenfolge.
	 *
	 * @param array $in Eingabe mit sections.
	 */
	public static function sanitize_handbook( array $in ) {
		$by_key = array();
		$custom = array();
		foreach ( (array) ( $in['sections'] ?? array() ) as $s ) {
			if ( ! is_array( $s ) ) {
				continue;
			}
			$key   = isset( $s['key'] ) ? sanitize_key( (string) $s['key'] ) : '';
			$title = isset( $s['title'] ) ? sanitize_text_field( (string) $s['title'] ) : '';
			$item  = array(
				'key'   => $key,
				'title' => $title,
				'body'  => isset( $s['body'] ) ? wp_kses_post( (string) $s['body'] ) : '',
			);
			if ( 'brand' === $key ) {
				$item['colors'] = isset( $s['colors'] ) ? sanitize_textarea_field( (string) $s['colors'] ) : '';
			}
			if ( isset( self::handbook_fixed()[ $key ] ) ) {
				$item['title']  = self::handbook_fixed()[ $key ];
				$by_key[ $key ] = $item;
			} elseif ( '' !== $title ) {
				$item['key'] = 0 === strpos( $key, 'custom_' ) ? $key : 'custom_' . substr( md5( $title . count( $custom ) ), 0, 8 );
				$custom[]    = $item;
			}
		}
		$out = array();
		foreach ( self::handbook_fixed() as $key => $title ) {
			$out[] = $by_key[ $key ] ?? array(
				'key'   => $key,
				'title' => $title,
				'body'  => '',
			) + ( 'brand' === $key ? array( 'colors' => '' ) : array() );
		}
		return array( 'sections' => array_merge( $out, array_slice( $custom, 0, 30 ) ) );
	}

	/* ---------- Rechte ---------- */

	/**
	 * Eigene Capabilities zur Laufzeit gewähren (keine Rollen in der Datenbank).
	 *
	 * @param array   $allcaps Rechte.
	 * @param array   $caps    Angefragte Rechte.
	 * @param array   $args    Argumente.
	 * @param WP_User $user    Benutzer.
	 */
	public static function grant_caps( $allcaps, $caps, $args, $user ) {
		if ( ! in_array( 'oq_support_manage', (array) $caps, true ) && ! in_array( 'oq_support_view', (array) $caps, true ) ) {
			return $allcaps;
		}
		$uid = isset( $user->ID ) ? (int) $user->ID : 0;
		if ( $uid && '1' === (string) get_user_meta( $uid, 'oq_support_manager', true ) ) {
			$allcaps['oq_support_manage'] = true;
			$allcaps['oq_support_view']   = true;
			return $allcaps;
		}
		$role = self::settings()['min_role'];
		if ( ! empty( $allcaps[ $role ] ) ) {
			$allcaps['oq_support_view'] = true;
		}
		return $allcaps;
	}

	/**
	 * Ist der Benutzer Betreuer?
	 *
	 * @param int|null $uid Benutzer.
	 */
	public static function is_manager( $uid = null ) {
		return null === $uid ? current_user_can( 'oq_support_manage' ) : user_can( (int) $uid, 'oq_support_manage' );
	}

	/**
	 * Darf der aktuelle Benutzer den Bereich sehen?
	 *
	 * @param string $section Bereich oder leer.
	 */
	public static function can_view( $section = '' ) {
		if ( ! current_user_can( 'oq_support_view' ) ) {
			return false;
		}
		if ( '' === $section || self::is_manager() ) {
			return true;
		}
		$s = self::settings()['sections'];
		return ! isset( $s[ $section ] ) || $s[ $section ];
	}

	/**
	 * IDs aller Betreuer.
	 */
	public static function managers() {
		return array_map(
			'intval',
			get_users(
				array(
					'meta_key'   => 'oq_support_manager', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
					'meta_value' => '1', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
					'fields'     => 'ID',
				)
			)
		);
	}

	/* ---------- Lebenszyklus ---------- */

	/**
	 * Aktivierung.
	 */
	public static function activate() {
		OQ_Support_Store::install();
		add_option( 'oq_support_settings', self::default_settings(), '', true );
		add_option( 'oq_support_handbook', self::default_handbook(), '', false );
		add_option(
			'oq_support_profile',
			self::sanitize_profile(
				array(
					'studio'         => 'oriqen Digital Studio',
					'contact_person' => 'Dennis Fröhlich',
					'website'        => 'https://oriqen.de/',
					'location'       => 'Paderborn',
				)
			),
			'',
			false
		);
		self::flush_settings();
		$uid = get_current_user_id();
		if ( $uid ) {
			update_user_meta( $uid, 'oq_support_manager', '1' );
		} elseif ( ! self::managers() ) {
			$admins = get_users(
				array(
					'role'   => 'administrator',
					'number' => 1,
					'fields' => 'ID',
				)
			);
			if ( $admins ) {
				update_user_meta( (int) $admins[0], 'oq_support_manager', '1' );
			}
		}
		$first = false === get_option( 'oq_support_version', false );
		update_option( 'oq_support_version', OQ_SUPPORT_VERSION, true );
		OQ_Support_Store::insert(
			array(
				'type'     => 'log',
				'title'    => $first ? 'oriqen Support installiert' : 'oriqen Support aktiviert',
				'body'     => 'Version ' . OQ_SUPPORT_VERSION . '.',
				'category' => 'wartung',
				'source'   => 'system',
			)
		);
		if ( ! wp_next_scheduled( 'oq_support_cleanup' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'oq_support_cleanup' );
		}
	}

	/**
	 * Deaktivierung: nur Cron entfernen.
	 */
	public static function deactivate() {
		wp_clear_scheduled_hook( 'oq_support_cleanup' );
	}

	/**
	 * Schema und Version prüfen (bei jedem plugins_loaded, nur gecachte Optionen).
	 */
	public static function maybe_upgrade() {
		if ( get_option( 'oq_support_db_version' ) !== self::DB_VERSION ) {
			OQ_Support_Store::install();
		}
		$ver = get_option( 'oq_support_version', false );
		if ( false !== $ver && OQ_SUPPORT_VERSION !== $ver ) {
			update_option( 'oq_support_version', OQ_SUPPORT_VERSION, true );
			OQ_Support_Store::insert(
				array(
					'type'     => 'log',
					'title'    => 'oriqen Support aktualisiert auf ' . OQ_SUPPORT_VERSION,
					'category' => 'wartung',
					'source'   => 'system',
				)
			);
		}
	}

	/**
	 * Farbzeilen „#6600CC Name“ in Paare zerlegen (rein).
	 *
	 * @param string $text Zeilen.
	 * @return array[] hex, label.
	 */
	public static function parse_colors( $text ) {
		$out = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $text ) as $line ) {
			if ( preg_match( '/(#[0-9a-fA-F]{6}|#[0-9a-fA-F]{3})\b\s*[:,-]?\s*(.*)$/', trim( $line ), $m ) ) {
				$out[] = array( strtoupper( $m[1] ), trim( $m[2] ) );
			}
		}
		return $out;
	}

	/**
	 * Platzhalter für leere Handbuch-Abschnitte.
	 *
	 * @param string $key Abschnitt.
	 */
	public static function handbook_placeholder( $key ) {
		$p = array(
			'media'   => 'Hier stehen bald unsere Empfehlungen zu Bildgrößen, Formaten und Alternativtexten.',
			'brand'   => 'Hier stehen bald Ihre Markenfarben, Schriften, Logo-Regeln und die Tonalität.',
			'content' => 'Hier stehen bald kurze Anleitungen, zum Beispiel zum Anlegen eines Blogbeitrags oder zum Austausch eines Bildes.',
			'tech'    => 'Hier stehen bald Angaben zu Hosting, Domain, Backup-Lösung und wichtigen Plugins.',
		);
		return $p[ $key ] ?? 'Dieser Abschnitt ist noch leer.';
	}

	/* ---------- Hilfen ---------- */

	/**
	 * UTC-Zeit in Ortszeit formatieren.
	 *
	 * @param string $utc    Y-m-d H:i:s (UTC).
	 * @param string $format Format.
	 */
	public static function local( $utc, $format = 'd.m.Y H:i' ) {
		return $utc ? get_date_from_gmt( (string) $utc, $format ) : '';
	}

	/**
	 * Name der Website.
	 */
	public static function site_name() {
		$n = get_bloginfo( 'name' );
		return '' !== $n ? $n : wp_parse_url( home_url(), PHP_URL_HOST );
	}
}
