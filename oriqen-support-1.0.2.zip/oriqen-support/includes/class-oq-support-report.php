<?php
/**
 * Monatsbericht.
 *
 * @package oriqen-support
 */

defined( 'ABSPATH' ) || exit;

/**
 * Daten für einen Monat.
 */
class OQ_Support_Report {

	/**
	 * Monatsnamen.
	 */
	public static function month_names() {
		return array(
			1 => 'Januar',
			'Februar',
			'März',
			'April',
			'Mai',
			'Juni',
			'Juli',
			'August',
			'September',
			'Oktober',
			'November',
			'Dezember',
		);
	}

	/**
	 * Bericht bauen.
	 *
	 * @param string $month YYYY-MM (Ortszeit), leer = Vormonat.
	 */
	public static function build( $month = '' ) {
		if ( ! preg_match( '/^(\d{4})-(\d{2})$/', (string) $month, $m ) || (int) $m[2] < 1 || (int) $m[2] > 12 ) {
			$month = gmdate( 'Y-m', strtotime( current_time( 'Y-m-01' ) . ' -1 month' ) );
			preg_match( '/^(\d{4})-(\d{2})$/', $month, $m );
		}
		$start  = get_gmt_from_date( $month . '-01 00:00:00' );
		$end    = get_gmt_from_date( gmdate( 'Y-m-d', strtotime( $month . '-01 +1 month' ) ) . ' 00:00:00' );
		$logs   = OQ_Support_Store::query(
			array(
				'type'     => 'log',
				'since'    => $start,
				'until'    => $end,
				'order'    => 'asc',
				'per_page' => 500,
			)
		)['items'];
		$groups = array();
		foreach ( OQ_Support_Store::categories() as $k => $l ) {
			$groups[ $k ] = array();
		}
		foreach ( $logs as $l ) {
			$groups[ isset( $groups[ $l['category'] ] ) ? $l['category'] : 'sonstiges' ][] = $l;
		}
		$done = array();
		foreach ( OQ_Support_Store::query(
			array(
				'type'     => 'request',
				'status'   => array( 'erledigt' ),
				'per_page' => 500,
			)
		)['items'] as $r ) {
			$at = $r['meta']['done_at'] ?? $r['updated_at'];
			if ( $at >= $start && $at < $end ) {
				$done[] = $r;
			}
		}
		return array(
			'month'  => $month,
			'label'  => self::month_names()[ (int) $m[2] ] . ' ' . $m[1],
			'start'  => $start,
			'end'    => $end,
			'logs'   => $logs,
			'groups' => array_filter( $groups ),
			'done'   => $done,
			'open'   => OQ_Support_Store::count(
				array(
					'type'   => 'request',
					'status' => array( 'neu', 'in_arbeit' ),
				)
			),
		);
	}
}
