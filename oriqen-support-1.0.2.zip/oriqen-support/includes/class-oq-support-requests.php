<?php
/**
 * Wünsche, Kommentare und Notizen: gemeinsame Logik für Formulare und REST.
 *
 * @package oriqen-support
 */

defined( 'ABSPATH' ) || exit;

/**
 * Wünsche und Notizen.
 */
class OQ_Support_Requests {

	/**
	 * Quelle des aktuellen Benutzers.
	 */
	public static function source() {
		return OQ_Support_Plugin::is_manager() ? 'oriqen' : 'kunde';
	}

	/**
	 * Wunsch anlegen.
	 *
	 * @param array $d title, body, priority, object_ref.
	 * @return int|WP_Error
	 */
	public static function create( array $d ) {
		$title = trim( sanitize_text_field( (string) ( $d['title'] ?? '' ) ) );
		if ( '' === $title ) {
			return new WP_Error( 'oq_support_title_missing', 'Bitte geben Sie einen Titel an.', array( 'status' => 400 ) );
		}
		$id = OQ_Support_Store::insert(
			array(
				'type'       => 'request',
				'title'      => $title,
				'body'       => (string) ( $d['body'] ?? '' ),
				'priority'   => (string) ( $d['priority'] ?? 'normal' ),
				'status'     => 'neu',
				'object_ref' => (string) ( $d['object_ref'] ?? '' ),
				'source'     => self::source(),
			)
		);
		if ( ! is_wp_error( $id ) && 'kunde' === self::source() ) {
			self::notify( 'Neuer Wunsch: ' . $title, (string) ( $d['body'] ?? '' ), $id );
		}
		return $id;
	}

	/**
	 * Kommentar zu einem Wunsch.
	 *
	 * @param int    $request_id Wunsch.
	 * @param string $body       Text.
	 * @return int|WP_Error
	 */
	public static function comment( $request_id, $body ) {
		$req = OQ_Support_Store::get( (int) $request_id );
		if ( ! $req || 'request' !== $req['type'] ) {
			return new WP_Error( 'oq_support_not_found', 'Der Wunsch wurde nicht gefunden.', array( 'status' => 404 ) );
		}
		if ( '' === trim( wp_strip_all_tags( (string) $body ) ) ) {
			return new WP_Error( 'oq_support_body_missing', 'Bitte schreiben Sie einen Text.', array( 'status' => 400 ) );
		}
		$id = OQ_Support_Store::insert(
			array(
				'type'      => 'comment',
				'parent_id' => (int) $request_id,
				'title'     => '',
				'body'      => (string) $body,
				'source'    => self::source(),
			)
		);
		if ( ! is_wp_error( $id ) ) {
			OQ_Support_Store::update( (int) $request_id, array() );
			if ( 'kunde' === self::source() ) {
				self::notify( 'Neuer Kommentar zu: ' . $req['title'], (string) $body, (int) $request_id );
			}
		}
		return $id;
	}

	/**
	 * Status setzen (Betreuer).
	 *
	 * @param int    $id     Wunsch.
	 * @param string $status Status.
	 * @return true|WP_Error
	 */
	public static function set_status( $id, $status ) {
		$req = OQ_Support_Store::get( (int) $id );
		if ( ! $req || 'request' !== $req['type'] ) {
			return new WP_Error( 'oq_support_not_found', 'Der Wunsch wurde nicht gefunden.', array( 'status' => 404 ) );
		}
		if ( ! isset( OQ_Support_Store::STATUSES[ $status ] ) ) {
			return new WP_Error( 'oq_support_bad_status', 'Unbekannter Status. Erlaubt: neu, in_arbeit, erledigt, abgelehnt.', array( 'status' => 400 ) );
		}
		$meta = $req['meta'];
		if ( 'erledigt' === $status && 'erledigt' !== $req['status'] ) {
			$meta['done_at'] = gmdate( 'Y-m-d H:i:s' );
		} elseif ( 'erledigt' !== $status ) {
			unset( $meta['done_at'] );
		}
		return OQ_Support_Store::update(
			(int) $id,
			array(
				'status' => $status,
				'meta'   => $meta,
			)
		);
	}

	/**
	 * Notiz anlegen oder ändern (Verfasser oder Betreuer).
	 *
	 * @param int   $id Notiz oder 0.
	 * @param array $d  title, body.
	 * @return int|WP_Error
	 */
	public static function save_note( $id, array $d ) {
		$title = trim( sanitize_text_field( (string) ( $d['title'] ?? '' ) ) );
		if ( '' === $title ) {
			return new WP_Error( 'oq_support_title_missing', 'Bitte geben Sie einen Titel an.', array( 'status' => 400 ) );
		}
		if ( $id ) {
			$n = OQ_Support_Store::get( (int) $id );
			if ( ! $n || 'note' !== $n['type'] ) {
				return new WP_Error( 'oq_support_not_found', 'Die Notiz wurde nicht gefunden.', array( 'status' => 404 ) );
			}
			if ( get_current_user_id() !== (int) $n['author_id'] && ! OQ_Support_Plugin::is_manager() ) {
				return new WP_Error( 'oq_support_forbidden', 'Sie können nur eigene Notizen bearbeiten.', array( 'status' => 403 ) );
			}
			$r = OQ_Support_Store::update(
				(int) $id,
				array(
					'title' => $title,
					'body'  => (string) ( $d['body'] ?? '' ),
				)
			);
			return is_wp_error( $r ) ? $r : (int) $id;
		}
		return OQ_Support_Store::insert(
			array(
				'type'   => 'note',
				'title'  => $title,
				'body'   => (string) ( $d['body'] ?? '' ),
				'source' => self::source(),
			)
		);
	}

	/**
	 * Wünsche mit Kommentaren.
	 *
	 * @param array $status Filter.
	 */
	public static function list_requests( array $status = array() ) {
		$items = OQ_Support_Store::query(
			array(
				'type'     => 'request',
				'status'   => $status,
				'orderby'  => 'updated_at',
				'per_page' => 200,
			)
		)['items'];
		foreach ( $items as $k => $r ) {
			$items[ $k ]['comments'] = OQ_Support_Store::comments( $r['id'] );
		}
		return $items;
	}

	/**
	 * Benachrichtigung per E-Mail (nur wenn eine Adresse hinterlegt ist).
	 *
	 * @param string $subject Betreff.
	 * @param string $text    Text.
	 * @param int    $id      Wunsch.
	 */
	public static function notify( $subject, $text, $id ) {
		$to = OQ_Support_Plugin::settings()['notify_email'];
		if ( '' === $to || ! is_email( $to ) ) {
			return false;
		}
		$user = wp_get_current_user();
		$body = sprintf(
			"%s\n\nWebsite: %s\nVon: %s\n\n%s\n\nIm Backend ansehen:\n%s\n",
			$subject,
			OQ_Support_Plugin::site_name(),
			$user->exists() ? $user->display_name : 'unbekannt',
			trim( wp_strip_all_tags( (string) $text ) ),
			OQ_Support_Admin::url( 'oq-support-requests' ) . '#oqs-request-' . (int) $id
		);
		return wp_mail( $to, '[' . OQ_Support_Plugin::site_name() . '] ' . $subject, $body );
	}
}
