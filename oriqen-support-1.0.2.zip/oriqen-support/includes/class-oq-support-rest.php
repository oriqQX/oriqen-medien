<?php
/**
 * REST-Schnittstelle oriqen-support/v1 für KI und Betreuung.
 *
 * @package oriqen-support
 */

defined( 'ABSPATH' ) || exit;

/**
 * REST-Routen.
 */
class OQ_Support_Rest {

	const NS = 'oriqen-support/v1';

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	/**
	 * Rechteprüfung.
	 *
	 * @param string $level   customer|manager.
	 * @param string $section Bereich für Kunden.
	 */
	public static function perm( $level, $section = '' ) {
		return function () use ( $level, $section ) {
			if ( ! is_user_logged_in() ) {
				return new WP_Error( 'oq_support_auth', 'Bitte melden Sie sich an.', array( 'status' => 401 ) );
			}
			$ok = 'manager' === $level ? OQ_Support_Plugin::is_manager() : OQ_Support_Plugin::can_view( $section );
			return $ok ? true : new WP_Error( 'oq_support_forbidden', 'Dafür fehlen die Rechte.', array( 'status' => 403 ) );
		};
	}

	/**
	 * Route registrieren.
	 *
	 * @param string   $path    Pfad.
	 * @param string   $methods Methoden.
	 * @param callable $cb      Handler.
	 * @param callable $perm    Rechte.
	 * @param array    $args    Argumente.
	 */
	private static function add( $path, $methods, $cb, $perm, array $args = array() ) {
		register_rest_route(
			self::NS,
			$path,
			array(
				'methods'             => $methods,
				'callback'            => $cb,
				'permission_callback' => $perm,
				'args'                => $args,
			)
		);
	}

	/**
	 * Routen.
	 */
	public static function routes() {
		$c   = self::perm( 'customer' );
		$m   = self::perm( 'manager' );
		$id  = array(
			'id' => array(
				'type'     => 'integer',
				'required' => true,
			),
		);
		$int = function ( $def, $max ) {
			return array(
				'type'    => 'integer',
				'default' => $def,
				'minimum' => 1,
				'maximum' => $max,
			);
		};
		self::add(
			'/context',
			'GET',
			array( __CLASS__, 'context' ),
			$m,
			array(
				'format' => array(
					'type'    => 'string',
					'enum'    => array( 'markdown', 'json' ),
					'default' => 'markdown',
				),
			)
		);
		self::add(
			'/log',
			'GET',
			array( __CLASS__, 'log_list' ),
			self::perm( 'customer', 'log' ),
			array(
				'category' => array( 'type' => 'string' ),
				'source'   => array( 'type' => 'string' ),
				'since'    => array( 'type' => 'string' ),
				'per_page' => $int( 30, 100 ),
				'page'     => $int( 1, 10000 ),
			)
		);
		self::add(
			'/log',
			'POST',
			array( __CLASS__, 'log_create' ),
			$m,
			array(
				'title'      => array(
					'type'     => 'string',
					'required' => true,
				),
				'body'       => array( 'type' => 'string' ),
				'category'   => array(
					'type'    => 'string',
					'enum'    => array_keys( OQ_Support_Store::categories() ),
					'default' => 'sonstiges',
				),
				'source'     => array(
					'type'    => 'string',
					'enum'    => array( 'ki', 'oriqen' ),
					'default' => 'ki',
				),
				'object_ref' => array( 'type' => array( 'string', 'integer' ) ),
				'date'       => array(
					'type'        => 'string',
					'description' => 'Optional: Datum der Änderung, Y-m-d oder Y-m-d H:i (Ortszeit).',
				),
			)
		);
		self::add( '/log/(?P<id>\d+)', 'PATCH', array( __CLASS__, 'log_update' ), $m, $id );
		self::add( '/log/(?P<id>\d+)', 'DELETE', array( __CLASS__, 'log_delete' ), $m, $id );
		self::add( '/requests', 'GET', array( __CLASS__, 'requests_list' ), self::perm( 'customer', 'requests' ), array( 'status' => array( 'type' => 'string' ) ) );
		self::add(
			'/requests',
			'POST',
			array( __CLASS__, 'requests_create' ),
			self::perm( 'customer', 'requests' ),
			array(
				'title'      => array(
					'type'     => 'string',
					'required' => true,
				),
				'body'       => array( 'type' => 'string' ),
				'priority'   => array(
					'type'    => 'string',
					'enum'    => array( 'normal', 'hoch' ),
					'default' => 'normal',
				),
				'object_ref' => array( 'type' => array( 'string', 'integer' ) ),
			)
		);
		self::add(
			'/requests/(?P<id>\d+)',
			'PATCH',
			array( __CLASS__, 'requests_update' ),
			$m,
			array_merge(
				$id,
				array(
					'status'  => array(
						'type'     => 'string',
						'enum'     => array_keys( OQ_Support_Store::STATUSES ),
						'required' => true,
					),
					'comment' => array( 'type' => 'string' ),
				)
			)
		);
		self::add(
			'/requests/(?P<id>\d+)/comments',
			'POST',
			array( __CLASS__, 'requests_comment' ),
			self::perm( 'customer', 'requests' ),
			array_merge(
				$id,
				array(
					'body' => array(
						'type'     => 'string',
						'required' => true,
					),
				)
			)
		);
		self::add( '/notes', 'GET', array( __CLASS__, 'notes' ), $m );
		self::add( '/handbook', 'GET', array( __CLASS__, 'handbook_get' ), self::perm( 'customer', 'handbook' ) );
		self::add(
			'/handbook',
			'PUT',
			array( __CLASS__, 'handbook_put' ),
			$m,
			array(
				'sections' => array(
					'type'     => 'array',
					'required' => true,
				),
			)
		);
		self::add( '/profile', 'GET', array( __CLASS__, 'profile_get' ), $c );
		self::add( '/profile', 'PUT', array( __CLASS__, 'profile_put' ), $m );
		self::add(
			'/announcements',
			'POST',
			array( __CLASS__, 'announcement_create' ),
			$m,
			array(
				'title'   => array(
					'type'     => 'string',
					'required' => true,
				),
				'body'    => array( 'type' => 'string' ),
				'expires' => array(
					'type'    => 'string',
					'pattern' => '^\d{4}-\d{2}-\d{2}$',
				),
			)
		);
		self::add( '/health', 'GET', array( __CLASS__, 'health' ), self::perm( 'customer', 'health' ) );
		self::add( '/settings', 'GET', array( __CLASS__, 'settings_get' ), $m );
		self::add( '/settings', 'PUT', array( __CLASS__, 'settings_put' ), $m );
		self::add( '/export', 'GET', array( __CLASS__, 'export' ), $m );
		self::add(
			'/import',
			'POST',
			array( __CLASS__, 'import' ),
			$m,
			array(
				'data' => array(
					'type'     => 'object',
					'required' => true,
				),
				'mode' => array(
					'type'    => 'string',
					'enum'    => array( 'merge', 'replace' ),
					'default' => 'merge',
				),
			)
		);
	}

	/* ---------- Hilfen ---------- */

	/**
	 * Beschriftung einer betroffenen Seite.
	 *
	 * @param string|null $ref Post-ID oder URL.
	 */
	public static function object_label( $ref ) {
		if ( null === $ref || '' === $ref ) {
			return '';
		}
		if ( ctype_digit( (string) $ref ) && get_post( (int) $ref ) ) {
			return get_the_title( (int) $ref ) . ' (ID ' . $ref . ', ' . get_permalink( (int) $ref ) . ')';
		}
		return (string) $ref;
	}

	/**
	 * Eintrag für die Ausgabe.
	 *
	 * @param array $i Eintrag.
	 */
	public static function item( array $i ) {
		$u   = $i['author_id'] ? get_userdata( $i['author_id'] ) : null;
		$out = array(
			'id'         => $i['id'],
			'type'       => $i['type'],
			'title'      => $i['title'],
			'body'       => $i['body'],
			'source'     => $i['source'],
			'author'     => $u ? $u->display_name : null,
			'created_at' => mysql_to_rfc3339( $i['created_at'] ) . 'Z',
			'updated_at' => mysql_to_rfc3339( $i['updated_at'] ) . 'Z',
			'local_time' => OQ_Support_Plugin::local( $i['created_at'], 'c' ),
		);
		if ( 'log' === $i['type'] ) {
			$out['category'] = $i['category'];
			$out['count']    = (int) ( $i['meta']['count'] ?? 1 );
		}
		if ( 'request' === $i['type'] ) {
			$out['status']   = $i['status'];
			$out['priority'] = $i['priority'];
		}
		if ( 'comment' === $i['type'] ) {
			$out['parent_id'] = $i['parent_id'];
		}
		if ( 'announcement' === $i['type'] ) {
			$out['expires'] = $i['meta']['expires'] ?? null;
		}
		if ( in_array( $i['type'], array( 'log', 'request' ), true ) ) {
			$out['object_ref']   = $i['object_ref'];
			$out['object_label'] = self::object_label( $i['object_ref'] );
		}
		return $out;
	}

	/**
	 * Eintrag eines Typs laden oder 404.
	 *
	 * @param int    $id   ID.
	 * @param string $type Typ.
	 */
	private static function find( $id, $type ) {
		$i = OQ_Support_Store::get( (int) $id );
		return $i && $type === $i['type'] ? $i : new WP_Error( 'oq_support_not_found', 'Eintrag nicht gefunden.', array( 'status' => 404 ) );
	}

	/**
	 * Datum (Y-m-d lokal oder ISO) in UTC.
	 *
	 * @param string $s Datum.
	 */
	private static function utc( $s ) {
		$s = trim( (string) $s );
		if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $s ) ) {
			return get_gmt_from_date( $s . ' 00:00:00' );
		}
		$t = strtotime( $s );
		return $t ? gmdate( 'Y-m-d H:i:s', $t ) : '';
	}

	/**
	 * Optionales Datum für einen Protokolleintrag (Ortszeit), nie in der Zukunft.
	 *
	 * @param mixed $d Datum aus der Anfrage.
	 * @return array Leeres Array oder array( 'created_at' => UTC ).
	 */
	private static function log_date( $d ) {
		$d = trim( (string) $d );
		if ( '' === $d ) {
			return array();
		}
		if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d ) ) {
			$utc = OQ_Support_Actions::date_to_utc( $d );
		} elseif ( preg_match( '/^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}(:\d{2})?$/', $d ) ) {
			$utc = get_gmt_from_date( str_replace( 'T', ' ', strlen( $d ) === 16 ? $d . ':00' : $d ) );
		} else {
			return array();
		}
		if ( ! $utc || strtotime( $utc . ' UTC' ) > time() ) {
			return array();
		}
		return array( 'created_at' => $utc );
	}

	/* ---------- Handler ---------- */

	/**
	 * GET /context
	 *
	 * @param WP_REST_Request $r Anfrage.
	 */
	public static function context( $r ) {
		$d = OQ_Support_Context::data();
		if ( 'json' === $r['format'] ) {
			return array_merge( array( 'format' => 'json' ), $d );
		}
		return array(
			'format'   => 'markdown',
			'markdown' => OQ_Support_Context::markdown( $d ),
		);
	}

	/**
	 * GET /log
	 *
	 * @param WP_REST_Request $r Anfrage.
	 */
	public static function log_list( $r ) {
		$cat = (string) $r['category'];
		$src = (string) $r['source'];
		if ( '' !== $cat && ! isset( OQ_Support_Store::categories()[ $cat ] ) ) {
			return new WP_Error( 'oq_support_bad_param', 'Unbekannte Kategorie.', array( 'status' => 400 ) );
		}
		if ( '' !== $src && ! isset( OQ_Support_Store::SOURCES[ $src ] ) ) {
			return new WP_Error( 'oq_support_bad_param', 'Unbekannte Quelle.', array( 'status' => 400 ) );
		}
		$since = $r['since'] ? self::utc( $r['since'] ) : '';
		if ( $r['since'] && ! $since ) {
			return new WP_Error( 'oq_support_bad_param', '"since" ist kein gültiges Datum.', array( 'status' => 400 ) );
		}
		$res = OQ_Support_Store::query(
			array(
				'type'     => 'log',
				'category' => $cat,
				'source'   => $src,
				'since'    => $since,
				'per_page' => (int) $r['per_page'],
				'page'     => (int) $r['page'],
			)
		);
		return array(
			'total' => $res['total'],
			'items' => array_map( array( __CLASS__, 'item' ), $res['items'] ),
		);
	}

	/**
	 * POST /log
	 *
	 * @param WP_REST_Request $r Anfrage.
	 */
	public static function log_create( $r ) {
		if ( '' === trim( (string) $r['title'] ) ) {
			return new WP_Error( 'oq_support_title_missing', 'Der Titel fehlt.', array( 'status' => 400 ) );
		}
		$id = OQ_Support_Store::insert(
			array(
				'type'       => 'log',
				'title'      => $r['title'],
				'body'       => (string) $r['body'],
				'category'   => $r['category'],
				'source'     => $r['source'],
				'object_ref' => (string) $r['object_ref'],
			) + self::log_date( $r['date'] )
		);
		return is_wp_error( $id ) ? $id : new WP_REST_Response( self::item( OQ_Support_Store::get( $id ) ), 201 );
	}

	/**
	 * PATCH /log/{id}
	 *
	 * @param WP_REST_Request $r Anfrage.
	 */
	public static function log_update( $r ) {
		$i = self::find( $r['id'], 'log' );
		if ( is_wp_error( $i ) ) {
			return $i;
		}
		$p    = $r->get_json_params();
		$p    = is_array( $p ) && $p ? $p : $r->get_body_params();
		$data = array_intersect_key( (array) $p, array_flip( array( 'title', 'body', 'category', 'source', 'object_ref' ) ) );
		if ( ! $data ) {
			return new WP_Error( 'oq_support_bad_param', 'Keine änderbaren Felder übergeben (title, body, category, source, object_ref).', array( 'status' => 400 ) );
		}
		if ( isset( $data['title'] ) && '' === trim( (string) $data['title'] ) ) {
			return new WP_Error( 'oq_support_title_missing', 'Der Titel darf nicht leer sein.', array( 'status' => 400 ) );
		}
		if ( isset( $data['category'] ) && ! isset( OQ_Support_Store::categories()[ $data['category'] ] ) ) {
			return new WP_Error( 'oq_support_bad_param', 'Unbekannte Kategorie.', array( 'status' => 400 ) );
		}
		$ok = OQ_Support_Store::update( $i['id'], $data );
		return is_wp_error( $ok ) ? $ok : self::item( OQ_Support_Store::get( $i['id'] ) );
	}

	/**
	 * DELETE /log/{id}
	 *
	 * @param WP_REST_Request $r Anfrage.
	 */
	public static function log_delete( $r ) {
		$i = self::find( $r['id'], 'log' );
		if ( is_wp_error( $i ) ) {
			return $i;
		}
		OQ_Support_Store::delete( $i['id'] );
		return array(
			'deleted' => true,
			'id'      => $i['id'],
		);
	}

	/**
	 * GET /requests
	 *
	 * @param WP_REST_Request $r Anfrage.
	 */
	public static function requests_list( $r ) {
		$st = array_filter( array_map( 'trim', explode( ',', (string) $r['status'] ) ) );
		if ( array_diff( $st, array_keys( OQ_Support_Store::STATUSES ) ) ) {
			return new WP_Error( 'oq_support_bad_param', 'Unbekannter Status. Erlaubt: neu, in_arbeit, erledigt, abgelehnt.', array( 'status' => 400 ) );
		}
		$out = array();
		foreach ( OQ_Support_Requests::list_requests( $st ) as $q ) {
			$item             = self::item( $q );
			$item['comments'] = array_map( array( __CLASS__, 'item' ), $q['comments'] );
			$out[]            = $item;
		}
		return array( 'items' => $out );
	}

	/**
	 * POST /requests
	 *
	 * @param WP_REST_Request $r Anfrage.
	 */
	public static function requests_create( $r ) {
		$id = OQ_Support_Requests::create(
			array(
				'title'      => $r['title'],
				'body'       => (string) $r['body'],
				'priority'   => $r['priority'],
				'object_ref' => (string) $r['object_ref'],
			)
		);
		return is_wp_error( $id ) ? $id : new WP_REST_Response( self::item( OQ_Support_Store::get( $id ) ), 201 );
	}

	/**
	 * PATCH /requests/{id}
	 *
	 * @param WP_REST_Request $r Anfrage.
	 */
	public static function requests_update( $r ) {
		$ok = OQ_Support_Requests::set_status( (int) $r['id'], (string) $r['status'] );
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		if ( '' !== trim( (string) $r['comment'] ) ) {
			OQ_Support_Requests::comment( (int) $r['id'], (string) $r['comment'] );
		}
		$q               = OQ_Support_Store::get( (int) $r['id'] );
		$out             = self::item( $q );
		$out['comments'] = array_map( array( __CLASS__, 'item' ), OQ_Support_Store::comments( $q['id'] ) );
		return $out;
	}

	/**
	 * POST /requests/{id}/comments
	 *
	 * @param WP_REST_Request $r Anfrage.
	 */
	public static function requests_comment( $r ) {
		$id = OQ_Support_Requests::comment( (int) $r['id'], (string) $r['body'] );
		return is_wp_error( $id ) ? $id : new WP_REST_Response( self::item( OQ_Support_Store::get( $id ) ), 201 );
	}

	/**
	 * GET /notes
	 */
	public static function notes() {
		$res = OQ_Support_Store::query(
			array(
				'type'     => 'note',
				'orderby'  => 'updated_at',
				'per_page' => 200,
			)
		);
		return array( 'items' => array_map( array( __CLASS__, 'item' ), $res['items'] ) );
	}

	/**
	 * GET /handbook
	 */
	public static function handbook_get() {
		return OQ_Support_Plugin::handbook();
	}

	/**
	 * PUT /handbook
	 *
	 * @param WP_REST_Request $r Anfrage.
	 */
	public static function handbook_put( $r ) {
		update_option( 'oq_support_handbook', OQ_Support_Plugin::sanitize_handbook( array( 'sections' => (array) $r['sections'] ) ), false );
		return OQ_Support_Plugin::handbook();
	}

	/**
	 * GET /profile (Kunden sehen keine leeren Felder, KI-Regeln nur Betreuer).
	 */
	public static function profile_get() {
		$p = OQ_Support_Plugin::profile();
		if ( ! OQ_Support_Plugin::is_manager() ) {
			unset( $p['ai_rules'] );
			$p = array_filter( $p, 'strlen' );
		}
		return $p;
	}

	/**
	 * PUT /profile (nur übergebene Felder).
	 *
	 * @param WP_REST_Request $r Anfrage.
	 */
	public static function profile_put( $r ) {
		$p       = $r->get_json_params();
		$p       = is_array( $p ) && $p ? $p : $r->get_body_params();
		$unknown = array_diff( array_keys( (array) $p ), array_keys( OQ_Support_Plugin::profile_fields() ) );
		if ( $unknown ) {
			return new WP_Error( 'oq_support_bad_param', 'Unbekannte Felder: ' . implode( ', ', $unknown ) . '.', array( 'status' => 400 ) );
		}
		update_option( 'oq_support_profile', OQ_Support_Plugin::sanitize_profile( (array) $p ), false );
		return OQ_Support_Plugin::profile();
	}

	/**
	 * POST /announcements
	 *
	 * @param WP_REST_Request $r Anfrage.
	 */
	public static function announcement_create( $r ) {
		if ( '' === trim( (string) $r['title'] ) ) {
			return new WP_Error( 'oq_support_title_missing', 'Der Titel fehlt.', array( 'status' => 400 ) );
		}
		$id = OQ_Support_Store::insert(
			array(
				'type'   => 'announcement',
				'title'  => $r['title'],
				'body'   => (string) $r['body'],
				'source' => 'oriqen',
				'meta'   => $r['expires'] ? array( 'expires' => $r['expires'] ) : array(),
			)
		);
		return is_wp_error( $id ) ? $id : new WP_REST_Response( self::item( OQ_Support_Store::get( $id ) ), 201 );
	}

	/**
	 * GET /health
	 */
	public static function health() {
		return array( 'items' => OQ_Support_Health::run() );
	}

	/**
	 * GET /settings
	 */
	public static function settings_get() {
		return array_merge( OQ_Support_Plugin::settings(), array( 'managers' => OQ_Support_Plugin::managers() ) );
	}

	/**
	 * PUT /settings (nur übergebene Felder).
	 *
	 * @param WP_REST_Request $r Anfrage.
	 */
	public static function settings_put( $r ) {
		$p = $r->get_json_params();
		$p = is_array( $p ) && $p ? $p : $r->get_body_params();
		unset( $p['managers'] );
		$unknown = array_diff( array_keys( (array) $p ), array_keys( OQ_Support_Plugin::default_settings() ) );
		if ( $unknown ) {
			return new WP_Error( 'oq_support_bad_param', 'Unbekannte Felder: ' . implode( ', ', $unknown ) . '.', array( 'status' => 400 ) );
		}
		$cur = OQ_Support_Plugin::settings();
		if ( isset( $p['sections'] ) && is_array( $p['sections'] ) ) {
			$p['sections'] = array_merge( $cur['sections'], $p['sections'] );
		}
		update_option( 'oq_support_settings', OQ_Support_Plugin::sanitize_settings( array_merge( $cur, (array) $p ) ), true );
		OQ_Support_Plugin::flush_settings();
		return self::settings_get();
	}

	/**
	 * GET /export
	 */
	public static function export() {
		return OQ_Support_Transfer::export();
	}

	/**
	 * POST /import
	 *
	 * @param WP_REST_Request $r Anfrage.
	 */
	public static function import( $r ) {
		return OQ_Support_Transfer::import( (array) $r['data'], (string) $r['mode'] );
	}
}
