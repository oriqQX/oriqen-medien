<?php
/**
 * Datenhaltung: eine Tabelle für Protokoll, Wünsche, Notizen, Mitteilungen und Kommentare.
 *
 * @package oriqen-support
 */

defined( 'ABSPATH' ) || exit;

/**
 * Zugriff auf {prefix}oq_support_items.
 */
class OQ_Support_Store {

	const TYPES      = array( 'log', 'request', 'note', 'announcement', 'comment' );
	const STATUSES   = array(
		'neu'       => 'Neu',
		'in_arbeit' => 'In Arbeit',
		'erledigt'  => 'Erledigt',
		'abgelehnt' => 'Abgelehnt',
	);
	const PRIORITIES = array(
		'normal' => 'Normal',
		'hoch'   => 'Hoch',
	);
	const SOURCES    = array(
		'oriqen' => 'oriqen',
		'ki'     => 'KI',
		'kunde'  => 'Kunde',
		'system' => 'System',
	);

	/**
	 * Kategorien des Protokolls.
	 */
	public static function categories() {
		return array(
			'inhalt'     => 'Inhalt',
			'design'     => 'Design',
			'technik'    => 'Technik',
			'seo'        => 'SEO',
			'sicherheit' => 'Sicherheit',
			'wartung'    => 'Wartung',
			'sonstiges'  => 'Sonstiges',
		);
	}

	/**
	 * Tabellenname.
	 */
	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'oq_support_items';
	}

	/**
	 * Tabelle anlegen oder aktualisieren (dbDelta verliert keine Daten).
	 */
	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$t       = self::table();
		$collate = $wpdb->get_charset_collate();
		dbDelta(
			"CREATE TABLE {$t} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			type varchar(20) NOT NULL DEFAULT '',
			parent_id bigint(20) unsigned NULL DEFAULT NULL,
			title varchar(255) NOT NULL DEFAULT '',
			body longtext NOT NULL,
			category varchar(30) NOT NULL DEFAULT '',
			status varchar(20) NOT NULL DEFAULT '',
			priority varchar(10) NOT NULL DEFAULT '',
			source varchar(10) NOT NULL DEFAULT '',
			author_id bigint(20) unsigned NOT NULL DEFAULT 0,
			object_ref varchar(255) NULL DEFAULT NULL,
			meta longtext NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY type (type),
			KEY status (status),
			KEY created_at (created_at),
			KEY parent_id (parent_id)
			) {$collate};"
		);
		update_option( 'oq_support_db_version', OQ_Support_Plugin::DB_VERSION, true );
	}

	/**
	 * Eingaben bereinigen. Unbekannte Werte fallen auf sichere Standards zurück.
	 *
	 * @param array $d      Eingabe.
	 * @param bool  $partial Nur übergebene Felder.
	 * @return array|WP_Error
	 */
	public static function sanitize( array $d, $partial = false ) {
		$out = array();
		if ( ! $partial || isset( $d['type'] ) ) {
			$type = isset( $d['type'] ) ? (string) $d['type'] : '';
			if ( ! in_array( $type, self::TYPES, true ) ) {
				return new WP_Error( 'oq_support_bad_type', 'Unbekannter Eintragstyp.', array( 'status' => 400 ) );
			}
			$out['type'] = $type;
		}
		if ( array_key_exists( 'title', $d ) ) {
			$out['title'] = mb_substr( sanitize_text_field( (string) $d['title'] ), 0, 255 );
		}
		if ( array_key_exists( 'body', $d ) ) {
			$out['body'] = wp_kses_post( (string) $d['body'] );
		}
		if ( array_key_exists( 'category', $d ) ) {
			$c               = (string) $d['category'];
			$out['category'] = isset( self::categories()[ $c ] ) ? $c : 'sonstiges';
		}
		if ( array_key_exists( 'status', $d ) ) {
			$s             = (string) $d['status'];
			$out['status'] = isset( self::STATUSES[ $s ] ) ? $s : 'neu';
		}
		if ( array_key_exists( 'priority', $d ) ) {
			$out['priority'] = 'hoch' === $d['priority'] ? 'hoch' : 'normal';
		}
		if ( array_key_exists( 'source', $d ) ) {
			$s             = (string) $d['source'];
			$out['source'] = isset( self::SOURCES[ $s ] ) ? $s : 'oriqen';
		}
		if ( array_key_exists( 'object_ref', $d ) ) {
			$r                 = trim( (string) $d['object_ref'] );
			$out['object_ref'] = '' === $r ? null : ( ctype_digit( $r ) ? $r : mb_substr( esc_url_raw( $r ), 0, 255 ) );
			if ( '' === $out['object_ref'] ) {
				$out['object_ref'] = null;
			}
		}
		if ( array_key_exists( 'parent_id', $d ) ) {
			$out['parent_id'] = $d['parent_id'] ? absint( $d['parent_id'] ) : null;
		}
		if ( array_key_exists( 'author_id', $d ) ) {
			$out['author_id'] = absint( $d['author_id'] );
		}
		if ( array_key_exists( 'meta', $d ) ) {
			$out['meta'] = is_array( $d['meta'] ) ? wp_json_encode( $d['meta'] ) : null;
		}
		foreach ( array( 'created_at', 'updated_at' ) as $k ) {
			if ( isset( $d[ $k ] ) && preg_match( '/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', (string) $d[ $k ] ) ) {
				$out[ $k ] = (string) $d[ $k ];
			}
		}
		return $out;
	}

	/**
	 * Eintrag anlegen.
	 *
	 * @param array $data Daten.
	 * @return int|WP_Error ID.
	 */
	public static function insert( array $data ) {
		global $wpdb;
		$row = self::sanitize( $data );
		if ( is_wp_error( $row ) ) {
			return $row;
		}
		$now = gmdate( 'Y-m-d H:i:s' );
		$row = array_merge(
			array(
				'title'      => '',
				'body'       => '',
				'category'   => '',
				'status'     => '',
				'priority'   => '',
				'source'     => 'oriqen',
				'author_id'  => get_current_user_id(),
				'created_at' => $now,
				'updated_at' => $now,
			),
			$row
		);
		if ( 'request' === $row['type'] && '' === $row['status'] ) {
			$row['status'] = 'neu';
		}
		if ( 'request' === $row['type'] && '' === $row['priority'] ) {
			$row['priority'] = 'normal';
		}
		if ( 'log' === $row['type'] && '' === $row['category'] ) {
			$row['category'] = 'sonstiges';
		}
		$ok = $wpdb->insert( self::table(), $row ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		if ( ! $ok ) {
			return new WP_Error( 'oq_support_db', 'Der Eintrag konnte nicht gespeichert werden.', array( 'status' => 500 ) );
		}
		return (int) $wpdb->insert_id;
	}

	/**
	 * Eintrag ändern.
	 *
	 * @param int   $id   ID.
	 * @param array $data Daten.
	 * @return true|WP_Error
	 */
	public static function update( $id, array $data ) {
		global $wpdb;
		unset( $data['type'], $data['created_at'] );
		$row = self::sanitize( $data, true );
		if ( is_wp_error( $row ) ) {
			return $row;
		}
		if ( ! isset( $row['updated_at'] ) ) {
			$row['updated_at'] = gmdate( 'Y-m-d H:i:s' );
		}
		$ok = $wpdb->update( self::table(), $row, array( 'id' => (int) $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		return false === $ok ? new WP_Error( 'oq_support_db', 'Die Änderung konnte nicht gespeichert werden.', array( 'status' => 500 ) ) : true;
	}

	/**
	 * Eintrag samt Kommentaren löschen.
	 *
	 * @param int $id ID.
	 */
	public static function delete( $id ) {
		global $wpdb;
		$wpdb->delete( self::table(), array( 'parent_id' => (int) $id ), array( '%d' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		return (bool) $wpdb->delete( self::table(), array( 'id' => (int) $id ), array( '%d' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	}

	/**
	 * Zeile aufbereiten.
	 *
	 * @param array $r Zeile.
	 */
	private static function hydrate( array $r ) {
		foreach ( array( 'id', 'author_id' ) as $k ) {
			$r[ $k ] = (int) $r[ $k ];
		}
		$r['parent_id'] = null === $r['parent_id'] ? null : (int) $r['parent_id'];
		$m              = null === $r['meta'] ? null : json_decode( (string) $r['meta'], true );
		$r['meta']      = is_array( $m ) ? $m : array();
		return $r;
	}

	/**
	 * Einzelnen Eintrag laden.
	 *
	 * @param int $id ID.
	 * @return array|null
	 */
	public static function get( $id ) {
		global $wpdb;
		$t = self::table();
		$r = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id = %d", (int) $id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		return $r ? self::hydrate( $r ) : null;
	}

	/**
	 * WHERE-Teil aus Filtern bauen.
	 *
	 * @param array $a Filter.
	 * @return array SQL und Werte.
	 */
	private static function where( array $a ) {
		global $wpdb;
		$w = array( '1=1' );
		$v = array();
		foreach ( array( 'type', 'category', 'source', 'object_ref' ) as $k ) {
			if ( isset( $a[ $k ] ) && '' !== $a[ $k ] ) {
				$w[] = "{$k} = %s";
				$v[] = (string) $a[ $k ];
			}
		}
		if ( ! empty( $a['status'] ) ) {
			$st  = array_values( array_intersect( (array) $a['status'], array_keys( self::STATUSES ) ) );
			$st  = $st ? $st : array( '-' );
			$w[] = 'status IN (' . implode( ',', array_fill( 0, count( $st ), '%s' ) ) . ')';
			$v   = array_merge( $v, $st );
		}
		if ( isset( $a['parent_id'] ) ) {
			$w[] = 'parent_id = %d';
			$v[] = (int) $a['parent_id'];
		}
		if ( ! empty( $a['author_id'] ) ) {
			$w[] = 'author_id = %d';
			$v[] = (int) $a['author_id'];
		}
		if ( ! empty( $a['since'] ) ) {
			$w[] = 'created_at >= %s';
			$v[] = (string) $a['since'];
		}
		if ( ! empty( $a['until'] ) ) {
			$w[] = 'created_at < %s';
			$v[] = (string) $a['until'];
		}
		if ( ! empty( $a['updated_since'] ) ) {
			$w[] = 'updated_at >= %s';
			$v[] = (string) $a['updated_since'];
		}
		if ( isset( $a['search'] ) && '' !== $a['search'] ) {
			$w[] = 'title LIKE %s';
			$v[] = '%' . $wpdb->esc_like( (string) $a['search'] ) . '%';
		}
		return array( implode( ' AND ', $w ), $v );
	}

	/**
	 * Einträge abfragen.
	 *
	 * @param array $a Filter plus per_page, page, order (desc|asc).
	 * @return array items, total.
	 */
	public static function query( array $a ) {
		global $wpdb;
		$t                  = self::table();
		list( $sql, $vals ) = self::where( $a );
		$per                = isset( $a['per_page'] ) ? max( 1, min( 500, (int) $a['per_page'] ) ) : 30;
		$page               = isset( $a['page'] ) ? max( 1, (int) $a['page'] ) : 1;
		$order              = isset( $a['order'] ) && 'asc' === $a['order'] ? 'ASC' : 'DESC';
		$orderby            = isset( $a['orderby'] ) && 'updated_at' === $a['orderby'] ? 'updated_at' : 'created_at';
		// Platzhalter stehen im WHERE-Teil aus self::where(), Spalten und Richtung sind fest vorgegeben.
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders
		$total = (int) $wpdb->get_var( $vals ? $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE {$sql}", $vals ) : "SELECT COUNT(*) FROM {$t} WHERE {$sql}" );
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE {$sql} ORDER BY {$orderby} {$order}, id {$order} LIMIT %d OFFSET %d", array_merge( $vals, array( $per, ( $page - 1 ) * $per ) ) ), ARRAY_A );
		// phpcs:enable
		return array(
			'items' => array_map( array( __CLASS__, 'hydrate' ), (array) $rows ),
			'total' => $total,
		);
	}

	/**
	 * Anzahl.
	 *
	 * @param array $a Filter.
	 */
	public static function count( array $a ) {
		$a['per_page'] = 1;
		return self::query( $a )['total'];
	}

	/**
	 * Kommentare eines Wunsches.
	 *
	 * @param int $id Wunsch.
	 */
	public static function comments( $id ) {
		return self::query(
			array(
				'type'      => 'comment',
				'parent_id' => (int) $id,
				'per_page'  => 500,
				'order'     => 'asc',
			)
		)['items'];
	}

	/**
	 * Aktive Mitteilungen (nicht abgelaufen), neueste zuerst.
	 */
	public static function announcements() {
		$all   = self::query(
			array(
				'type'     => 'announcement',
				'per_page' => 50,
			)
		)['items'];
		$today = current_time( 'Y-m-d' );
		return array_values(
			array_filter(
				$all,
				function ( $a ) use ( $today ) {
					return empty( $a['meta']['expires'] ) || $a['meta']['expires'] >= $today;
				}
			)
		);
	}

	/**
	 * Aufräumen: Systemeinträge älter als die Aufbewahrungszeit.
	 */
	public static function cleanup() {
		global $wpdb;
		$t      = self::table();
		$months = OQ_Support_Plugin::settings()['retention_months'];
		$cut    = gmdate( 'Y-m-d H:i:s', strtotime( '-' . (int) $months . ' months' ) );
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$t} WHERE source = %s AND created_at < %s", 'system', $cut ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
	}
}
