<?php
/**
 * Export und Import aller Daten als JSON.
 *
 * @package oriqen-support
 */

defined( 'ABSPATH' ) || exit;

/**
 * Export und Import.
 */
class OQ_Support_Transfer {

	const MAX_ITEMS = 20000;

	/**
	 * Alles exportieren.
	 */
	public static function export() {
		$items = array();
		$page  = 1;
		do {
			$res   = OQ_Support_Store::query(
				array(
					'per_page' => 500,
					'page'     => $page,
					'order'    => 'asc',
				)
			);
			$items = array_merge( $items, $res['items'] );
			$have  = count( $items );
			++$page;
		} while ( $have < $res['total'] && $res['items'] );
		return array(
			'plugin'      => 'oriqen-support',
			'format'      => 1,
			'version'     => OQ_SUPPORT_VERSION,
			'exported_at' => gmdate( 'c' ),
			'site'        => home_url( '/' ),
			'settings'    => OQ_Support_Plugin::settings(),
			'profile'     => OQ_Support_Plugin::profile(),
			'handbook'    => OQ_Support_Plugin::handbook(),
			'items'       => $items,
		);
	}

	/**
	 * Struktur prüfen (rein).
	 *
	 * @param mixed $data Daten.
	 * @return true|WP_Error
	 */
	public static function validate( $data ) {
		if ( ! is_array( $data ) || ( $data['plugin'] ?? '' ) !== 'oriqen-support' ) {
			return new WP_Error( 'oq_support_import_invalid', 'Das ist keine Exportdatei von oriqen Support.', array( 'status' => 400 ) );
		}
		foreach ( array( 'settings', 'profile', 'handbook' ) as $k ) {
			if ( isset( $data[ $k ] ) && ! is_array( $data[ $k ] ) ) {
				return new WP_Error( 'oq_support_import_invalid', 'Der Bereich "' . $k . '" hat ein falsches Format.', array( 'status' => 400 ) );
			}
		}
		if ( ! isset( $data['items'] ) || ! is_array( $data['items'] ) || count( $data['items'] ) > self::MAX_ITEMS ) {
			return new WP_Error( 'oq_support_import_invalid', 'Die Einträge fehlen oder sind zu viele.', array( 'status' => 400 ) );
		}
		foreach ( $data['items'] as $i ) {
			if ( ! is_array( $i ) || ! in_array( $i['type'] ?? '', OQ_Support_Store::TYPES, true ) ) {
				return new WP_Error( 'oq_support_import_invalid', 'Ein Eintrag hat ein falsches Format.', array( 'status' => 400 ) );
			}
		}
		return true;
	}

	/**
	 * Importieren.
	 *
	 * @param array  $data Daten.
	 * @param string $mode merge oder replace.
	 * @return array|WP_Error Zähler.
	 */
	public static function import( $data, $mode = 'merge' ) {
		global $wpdb;
		$ok = self::validate( $data );
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		$mode = 'replace' === $mode ? 'replace' : 'merge';
		if ( 'replace' === $mode ) {
			$wpdb->query( 'DELETE FROM ' . esc_sql( OQ_Support_Store::table() ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery
			if ( isset( $data['settings'] ) ) {
				update_option( 'oq_support_settings', OQ_Support_Plugin::sanitize_settings( $data['settings'] ), true );
				OQ_Support_Plugin::flush_settings();
			}
			if ( isset( $data['profile'] ) ) {
				update_option( 'oq_support_profile', OQ_Support_Plugin::sanitize_profile( array_merge( array_fill_keys( array_keys( OQ_Support_Plugin::profile_fields() ), '' ), $data['profile'] ) ), false );
			}
			if ( isset( $data['handbook'] ) ) {
				update_option( 'oq_support_handbook', OQ_Support_Plugin::sanitize_handbook( $data['handbook'] ), false );
			}
		} else {
			if ( isset( $data['profile'] ) ) {
				$cur = OQ_Support_Plugin::profile();
				$add = array();
				foreach ( $cur as $k => $v ) {
					if ( '' === $v && ! empty( $data['profile'][ $k ] ) ) {
						$add[ $k ] = $data['profile'][ $k ];
					}
				}
				update_option( 'oq_support_profile', OQ_Support_Plugin::sanitize_profile( $add ), false );
			}
			if ( isset( $data['handbook']['sections'] ) && is_array( $data['handbook']['sections'] ) ) {
				$cur    = OQ_Support_Plugin::handbook()['sections'];
				$titles = wp_list_pluck( $cur, 'title' );
				foreach ( $data['handbook']['sections'] as $s ) {
					if ( ! is_array( $s ) ) {
						continue;
					}
					foreach ( $cur as $k => $c ) {
						if ( ( $s['key'] ?? '' ) === $c['key'] && '' === trim( wp_strip_all_tags( $c['body'] ) ) && ! empty( $s['body'] ) ) {
							$cur[ $k ]['body'] = $s['body'];
						}
					}
					if ( 0 === strpos( (string) ( $s['key'] ?? '' ), 'custom_' ) && ! in_array( $s['title'] ?? '', $titles, true ) ) {
						$cur[] = $s;
					}
				}
				update_option( 'oq_support_handbook', OQ_Support_Plugin::sanitize_handbook( array( 'sections' => $cur ) ), false );
			}
		}
		$existing = array();
		if ( 'merge' === $mode ) {
			foreach ( self::export()['items'] as $e ) {
				$existing[ $e['type'] . '|' . $e['title'] . '|' . $e['created_at'] . '|' . md5( (string) $e['body'] ) ] = true;
			}
		}
		$map     = array();
		$counts  = array(
			'imported' => 0,
			'skipped'  => 0,
		);
		$ordered = array_merge(
			array_filter(
				$data['items'],
				function ( $i ) {
					return 'comment' !== $i['type'];
				}
			),
			array_filter(
				$data['items'],
				function ( $i ) {
					return 'comment' === $i['type'];
				}
			)
		);
		foreach ( $ordered as $i ) {
			$sig = $i['type'] . '|' . ( $i['title'] ?? '' ) . '|' . ( $i['created_at'] ?? '' ) . '|' . md5( (string) ( $i['body'] ?? '' ) );
			if ( isset( $existing[ $sig ] ) ) {
				++$counts['skipped'];
				continue;
			}
			$row = array_intersect_key( $i, array_flip( array( 'type', 'title', 'body', 'category', 'status', 'priority', 'source', 'object_ref', 'meta', 'created_at', 'updated_at' ) ) );
			if ( 'comment' === $i['type'] ) {
				$parent = (int) ( $i['parent_id'] ?? 0 );
				if ( ! isset( $map[ $parent ] ) ) {
					++$counts['skipped'];
					continue;
				}
				$row['parent_id'] = $map[ $parent ];
			}
			$author           = (int) ( $i['author_id'] ?? 0 );
			$row['author_id'] = $author && get_userdata( $author ) ? $author : 0;
			$new              = OQ_Support_Store::insert( $row );
			if ( is_wp_error( $new ) ) {
				++$counts['skipped'];
				continue;
			}
			if ( isset( $i['id'] ) ) {
				$map[ (int) $i['id'] ] = $new;
			}
			++$counts['imported'];
		}
		return array_merge( array( 'mode' => $mode ), $counts );
	}
}
