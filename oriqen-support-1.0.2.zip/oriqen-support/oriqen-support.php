<?php
/**
 * Plugin Name:       oriqen Support
 * Plugin URI:        https://oriqen.de/
 * Description:       Kundenakte im Backend mit Protokoll, Wünschen, Handbuch, Website-Check und Monatsbericht. Liefert der KI-Betreuung über REST den vollständigen Kontext der Website und zeigt einen dezenten Footer-Verweis auf oriqen.de.
 * Version:           1.0.2
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Author:            oriqen Digital Studio
 * Author URI:        https://oriqen.de/
 * License:           GPL-2.0-or-later
 * Text Domain:       oriqen-support
 *
 * @package oriqen-support
 */

defined( 'ABSPATH' ) || exit;

define( 'OQ_SUPPORT_VERSION', '1.0.2' );
define( 'OQ_SUPPORT_FILE', __FILE__ );
define( 'OQ_SUPPORT_DIR', plugin_dir_path( __FILE__ ) );
define( 'OQ_SUPPORT_URL', plugin_dir_url( __FILE__ ) );
define( 'OQ_SUPPORT_BASENAME', plugin_basename( __FILE__ ) );

/**
 * Autoload der Klassen OQ_Support_* aus includes/class-oq-support-*.php.
 */
spl_autoload_register(
	function ( $class_name ) {
		if ( ! preg_match( '/^OQ_Support_[A-Za-z]+$/', $class_name ) ) {
			return;
		}
		$file = OQ_SUPPORT_DIR . 'includes/class-' . strtolower( str_replace( '_', '-', $class_name ) ) . '.php';
		if ( is_readable( $file ) ) {
			require_once $file;
		}
	}
);

register_activation_hook( __FILE__, array( 'OQ_Support_Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'OQ_Support_Plugin', 'deactivate' ) );
add_action( 'plugins_loaded', array( 'OQ_Support_Plugin', 'init' ) );
