=== oriqen Support ===
Contributors: oriqen
Tags: support, wartung, protokoll, kundenakte, ki
Requires at least: 6.4
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.0.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Kundenakte, Wünsche, Handbuch und Betreuungsprotokoll im Backend. Kontext für die KI-Betreuung über REST. Footer-Verweis auf oriqen.de.

== Description ==

oriqen Support begleitet die Betreuung Ihrer Website durch oriqen Digital Studio.

* Übersicht mit letzten Änderungen, offenen Wünschen und Kontakt
* Protokoll aller Arbeiten, auch automatisch bei Updates und Änderungen
* Wünsche eintragen und den Verlauf verfolgen, Notizbuch für Hinweise
* Handbuch mit Bildgrößen, Markenregeln und Anleitungen
* Website-Check mit Ampel aus lokalen WordPress-Daten
* Monatsbericht, als PDF speicherbar
* REST-Schnittstelle oriqen-support/v1 für die KI-Betreuung
* Footer-Verweis automatisch oder per Shortcode [oriqen_credit]

Das Plugin stellt keine Verbindung zu fremden Servern her. Alle Daten bleiben auf Ihrem Server.

== Installation ==

1. ZIP unter Plugins › Installieren › Plugin hochladen einspielen.
2. Aktivieren. Wer aktiviert, ist Betreuer.
3. Unter oriqen Support › Einstellungen weitere Betreuer und den Footer festlegen.

== Frequently Asked Questions ==

= Gehen Daten beim Deaktivieren verloren? =

Nein. Daten werden nur beim Löschen entfernt und nur, wenn „Daten beim Löschen entfernen“ eingeschaltet ist.

= Wo platziere ich den Footer-Verweis selbst? =

Mit dem Shortcode [oriqen_credit], zum Beispiel in einem Footer-Template. Stellen Sie dann die Ausgabe auf „Nur per Shortcode“.

== Changelog ==

= 1.0.2 =
* Footer-Verweis: „Entwickelt von oriqen.de · Digital Studio | Consulting & Design“, oriqen.de in oriqen-Violett.

= 1.0.1 =
* Echtes oriqen-q als Menü- und Kopf-Icon statt Platzhalter.
* Protokolleinträge per REST optional mit Datum.

= 1.0.0 =
* Erste Version.
