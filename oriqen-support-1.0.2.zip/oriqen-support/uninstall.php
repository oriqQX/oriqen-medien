<?php
/**
 * Löschen des Plugins: Daten nur entfernen, wenn „Daten beim Löschen entfernen“ aktiv ist.
 *
 * @package oriqen-support
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

wp_clear_scheduled_hook( 'oq_support_cleanup' );

$oq_support_settings = get_option( 'oq_support_settings', array() );
if ( empty( $oq_support_settings['delete_on_uninstall'] ) ) {
	return;
}

global $wpdb;
$wpdb->query( 'DROP TABLE IF EXISTS ' . esc_sql( $wpdb->prefix . 'oq_support_items' ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery
foreach ( array( 'oq_support_settings', 'oq_support_handbook', 'oq_support_profile', 'oq_support_db_version', 'oq_support_version' ) as $oq_support_option ) {
	delete_option( $oq_support_option );
}
delete_metadata( 'user', 0, 'oq_support_manager', '', true );
