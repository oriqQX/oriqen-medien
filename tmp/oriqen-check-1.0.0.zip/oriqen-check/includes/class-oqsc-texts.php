<?php
/**
 * Textkatalog aller Prüfungen. Deutsch, Sie-Form, Wir-Form für oriqen.
 * Platzhalter: {ort} wird durch den Ort ersetzt, ohne Ort durch „Ihrem Ort“ (nach „in“) bzw. „Ihren Ort“.
 *
 * @package oriqen-check
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Texte für Besucher, E-Mail und Backend.
 */
class OQSC_Texts {

	/**
	 * Leistungen von oriqen für die interne Vertriebsnotiz.
	 *
	 * @return array Schlüssel => Name, Pfad.
	 */
	public static function leistungen() {
		return array(
			'seo'       => array( 'SEO', '/seo/' ),
			'google'    => array( 'Google-Optimierung', '/seo/google-optimierung/' ),
			'betreuung' => array( 'Webseiten-Betreuung', '/webdesign/webseiten-betreuung/' ),
			'webdesign' => array( 'Webdesign', '/webdesign/' ),
			'recht'     => array( 'Datenschutz- und Rechtstexte-Check (Teil von Betreuung und Webdesign)', '/webdesign/webseiten-betreuung/' ),
			'social'    => array( 'Social Media', '/social-media/' ),
		);
	}

	/**
	 * Texte je Säule: Name, Beschreibung, Satz bei stark, mittel, schwach.
	 *
	 * @return array
	 */
	public static function pillars() {
		return array(
			'gefunden'     => array(
				'name'    => 'Gefunden',
				'frage'   => 'Versteht Google Ihre Seite?',
				'stark'   => 'Google kann Ihre Seite gut lesen und richtig einordnen.',
				'mittel'  => 'Google findet Ihre Seite, versteht aber nicht alles, was Sie anbieten.',
				'schwach' => 'Google tut sich schwer, Ihre Seite zu verstehen. Hier verschenken Sie Platzierungen.',
			),
			'vor_ort'      => array(
				'name'    => 'Vor Ort',
				'frage'   => 'Findet man Sie in Ihrer Region?',
				'stark'   => 'Ihre Seite sagt klar, wo Sie sind und wie man Sie erreicht.',
				'mittel'  => 'Kunden aus der Region finden Sie, aber wichtige lokale Signale fehlen.',
				'schwach' => 'Für Suchen in Ihrer Region ist Ihre Seite kaum sichtbar.',
			),
			'schnell'      => array(
				'name'    => 'Schnell',
				'frage'   => 'Lädt Ihre Seite zügig, auch auf dem Handy?',
				'stark'   => 'Ihre Seite lädt zügig und ist technisch gut aufgestellt.',
				'mittel'  => 'Ihre Seite lädt, aber auf dem Handy dauert es spürbar.',
				'schwach' => 'Ihre Seite ist auf dem Handy zu langsam. Viele Besucher springen ab, bevor sie etwas sehen.',
			),
			'ueberzeugend' => array(
				'name'    => 'Überzeugend',
				'frage'   => 'Fragen Besucher bei Ihnen an?',
				'stark'   => 'Besucher verstehen schnell, wer Sie sind, und finden den Weg zur Anfrage.',
				'mittel'  => 'Ihre Seite wirkt solide, aber der Weg zur Anfrage ist nicht überall klar.',
				'schwach' => 'Besucher verstehen nicht schnell genug, warum sie gerade Sie anfragen sollten.',
			),
			'rechtssicher' => array(
				'name'    => 'Rechtssicher',
				'frage'   => 'Gibt es rechtliche Stolperfallen?',
				'stark'   => 'Wir haben keine typischen rechtlichen Stolperfallen gefunden.',
				'mittel'  => 'Wir haben einzelne Punkte gefunden, die Sie prüfen lassen sollten.',
				'schwach' => 'Wir haben mehrere Punkte gefunden, die abmahngefährdet sein können. Lassen Sie das zeitnah prüfen.',
			),
			'ki'           => array(
				'name'    => 'KI-bereit',
				'frage'   => 'Verstehen ChatGPT und Co. Ihre Seite?',
				'stark'   => 'KI-Dienste wie ChatGPT, Perplexity und Google-KI können Sie gut verstehen und empfehlen.',
				'mittel'  => 'KI-Dienste finden Sie, können Sie aber noch nicht klar beschreiben.',
				'schwach' => 'Für KI-Suchen sind Sie kaum greifbar. Hier entsteht gerade ein neuer Weg zu Kunden.',
			),
		);
	}

	/**
	 * Einordnung des Index.
	 *
	 * @return array Untergrenze => Bezeichnung.
	 */
	public static function bands() {
		return array(
			85 => 'Stark aufgestellt',
			70 => 'Gute Basis mit Luft nach oben',
			50 => 'Hier verlieren Sie Kunden',
			0  => 'Dringender Handlungsbedarf',
		);
	}

	/**
	 * Satzteil je schwächster Säule für die Einordnung.
	 *
	 * @return array
	 */
	public static function weak_phrases() {
		return array(
			'gefunden'     => 'Google versteht Ihre Seite noch nicht vollständig',
			'vor_ort'      => 'lokal sind Sie kaum sichtbar',
			'schnell'      => 'auf dem Handy lädt die Seite zu langsam',
			'ueberzeugend' => 'Besucher finden den Weg zur Anfrage nicht leicht',
			'rechtssicher' => 'rechtlich gibt es offene Punkte',
			'ki'           => 'für KI-Suchen sind Sie noch kaum greifbar',
		);
	}

	/**
	 * Satz zur Einordnung.
	 *
	 * @param int    $index  Index.
	 * @param string $weak   Schwächste Säule.
	 * @param int    $weak_v Wert der schwächsten Säule.
	 * @return string
	 */
	public static function verdict( $index, $weak, $weak_v ) {
		$phrases = self::weak_phrases();
		$phrase  = isset( $phrases[ $weak ] ) ? $phrases[ $weak ] : '';
		if ( $index >= 85 ) {
			return $weak_v < 70 && $phrase ? 'Sehr ordentlich. Nur an einer Stelle hakt es: ' . $phrase . '.' : 'Sehr ordentlich. Ihre Seite ist in allen Bereichen gut aufgestellt.';
		}
		if ( $index >= 70 ) {
			return 'Solide Basis, aber ' . $phrase . '.';
		}
		if ( $index >= 50 ) {
			return 'Ihre Seite hat Lücken, die Anfragen kosten. Am deutlichsten: ' . $phrase . '.';
		}
		return 'Ihre Seite bremst Sie aus. Am dringendsten: ' . $phrase . '.';
	}

	/**
	 * Branchentipps für U01, U02, U04 und L01.
	 *
	 * @return array Prüfung => Branche => Tipp.
	 */
	public static function branch_tips() {
		return array(
			'U01' => array(
				'handwerk'       => 'Für Handwerksbetriebe hat sich bewährt: Gewerk und Ort in die Überschrift, darunter ein Satz mit Ihrem Einzugsgebiet und ein Foto von einem echten Auftrag, nicht aus der Bilddatenbank.',
				'kueche'         => 'Für Küchen- und Einrichtungshäuser: Zeigen Sie oben ein starkes Foto einer Küche, die Sie selbst geplant haben, und schreiben Sie dazu, wo Ihre Ausstellung ist.',
				'bau'            => 'Für Baubetriebe: Nennen Sie oben Ihre Kernleistung (zum Beispiel „Sanierung von Altbauten“) und das Gebiet, in dem Sie bauen. Ein Foto einer laufenden Baustelle wirkt glaubwürdiger als ein Symbolbild.',
				'gesundheit'     => 'Für Praxen: Oben gehören Fachrichtung, Ort und der Hinweis, ob Sie neue Patientinnen und Patienten aufnehmen. Das ist oft die erste Frage.',
				'gastronomie'    => 'Für Gastronomie: Küche, Ort und Öffnungszeiten gehören nach oben, dazu ein appetitliches Foto aus Ihrem Haus und der Knopf zur Reservierung.',
				'handel'         => 'Für den Handel: Sagen Sie oben, was man bei Ihnen kaufen kann und wo Ihr Geschäft ist. Ein Foto von Laden oder Sortiment schafft sofort Vertrauen.',
				'dienstleistung' => 'Für Dienstleister: Formulieren Sie oben das Ergebnis für den Kunden („Ihre Steuererklärung, ohne Stress“) und nennen Sie den Ort.',
				'sonstiges'      => 'Bewährt hat sich ein Satz nach dem Muster „Wir sind … in {ort} und helfen Ihnen bei …“.',
			),
			'U02' => array(
				'handwerk'       => 'Handwerkskunden rufen am liebsten an. Setzen Sie die Telefonnummer antippbar in den Kopfbereich und bieten Sie zusätzlich „Rückruf anfordern“ für alle, die gerade nicht telefonieren können.',
				'kueche'         => 'Bei Küchen ist „Beratungstermin vereinbaren“ der stärkste Knopf. Wer einen Termin bucht, ist schon halb überzeugt.',
				'bau'            => 'Bei Bauprojekten funktioniert „Projekt anfragen“ mit wenigen Feldern (Art des Vorhabens, Ort, Zeitraum) besser als ein leeres Nachrichtenfeld.',
				'gesundheit'     => 'Für Praxen ist ein Knopf „Termin vereinbaren“ ideal, gern mit Verweis auf Ihre Online-Terminbuchung. Telefonzeiten gehören direkt daneben.',
				'gastronomie'    => 'In der Gastronomie zählt „Tisch reservieren“, sichtbar ohne Scrollen. Für Feiern und Catering lohnt ein zweiter Knopf.',
				'handel'         => 'Im Handel helfen Knöpfe wie „Verfügbarkeit anfragen“ oder „Route zum Geschäft“, damit aus Besuchern Kunden im Laden werden.',
				'dienstleistung' => 'Für Dienstleister ist „Kostenloses Erstgespräch“ ein bewährter Einstieg, mit Telefonnummer und Formular nebeneinander.',
				'sonstiges'      => 'Ein klarer Knopf mit einem Verb („Jetzt anfragen“, „Termin vereinbaren“) ist besser als ein allgemeines „Kontakt“.',
			),
			'U04' => array(
				'handwerk'       => 'Bitten Sie zufriedene Kunden direkt nach der Abnahme um eine Google-Bewertung, am besten mit einer Karte oder einem QR-Code. Fotos vorher und nachher wirken als Referenz besonders stark.',
				'kueche'         => 'Zeigen Sie fertige Küchen mit einem kurzen Satz des Kunden. Echte Projekte aus der Region überzeugen mehr als Herstellerbilder.',
				'bau'            => 'Eine Referenzliste mit Ort, Art des Projekts und Foto zeigt, dass Sie solche Vorhaben schon oft umgesetzt haben.',
				'gesundheit'     => 'Bei Praxen gelten besondere Regeln für Werbung mit Bewertungen. Ein Link zu Ihrem Profil bei Google oder Jameda ist meist der sichere Weg.',
				'gastronomie'    => 'Binden Sie zwei, drei echte Gästestimmen ein und verlinken Sie Ihr Google-Profil. Neue Gäste schauen fast immer zuerst auf die Sterne.',
				'handel'         => 'Kundenstimmen zu Beratung und Service heben Sie vom Onlinehandel ab. Das ist Ihr Vorteil vor Ort.',
				'dienstleistung' => 'Kurze Fallbeispiele („Ausgangslage, Lösung, Ergebnis“) mit Namen und Erlaubnis des Kunden sind für Dienstleister die stärkste Referenz.',
				'sonstiges'      => 'Schon drei echte Bewertungen mit Namen und Ort machen einen großen Unterschied.',
			),
			'L01' => array(
				'handwerk'       => 'Nennen Sie {ort} und zusätzlich die Orte, in denen Sie regelmäßig arbeiten. Für jeden wichtigen Ort kann eine eigene, gut geschriebene Seite mit echten Projekten von dort sinnvoll sein.',
				'kueche'         => 'Schreiben Sie, wo Ihre Ausstellung liegt und aus welchen Orten Ihre Kunden kommen, etwa „Küchenstudio in {ort}, Kunden aus dem ganzen Kreis“.',
				'bau'            => 'Bauherren suchen nach „Bauunternehmen“ plus Ort. Nennen Sie {ort} und Ihr Baugebiet auf der Startseite und bei Ihren Referenzen.',
				'gesundheit'     => 'Patienten suchen nach Fachrichtung plus Ort oder Stadtteil. Nennen Sie {ort} und gern auch den Stadtteil oder eine bekannte Straße.',
				'gastronomie'    => 'Gäste suchen nach „Restaurant“ plus Ortsname oder sogar nach der Straße. Ort, Stadtteil und Parkmöglichkeiten gehören auf die Startseite.',
				'handel'         => 'Nennen Sie {ort} zusammen mit Ihrem Sortiment, zum Beispiel „Fahrräder in {ort}“. So finden Sie Kunden, die in der Nähe kaufen wollen.',
				'dienstleistung' => 'Auch wenn Sie überregional arbeiten: Ein klarer Bezug zu Ihrer Region schafft Vertrauen und bringt lokale Anfragen.',
				'sonstiges'      => 'Nennen Sie {ort} im Titel, in der Hauptüberschrift und im ersten Absatz. Das sind die Stellen, auf die Google zuerst schaut.',
			),
		);
	}

	/**
	 * Alle Texte je Prüfung.
	 *
	 * @return array
	 */
	public static function all() {
		return array(

			/* Säule 1: Gefunden */

			'G01' => array(
				'titel'          => 'Website erreichbar',
				'text_gut'       => 'Ihre Website ist erreichbar. Das ist die Grundlage für alles Weitere.',
				'text_schlecht'  => 'Ihre Startseite liefert einen Fehler statt Inhalt.',
				'was_heisst_das' => 'Wir haben Ihre Startseite so aufgerufen, wie es ein Browser oder Google tut, und geprüft, ob sie ohne Fehler antwortet.',
				'warum'          => 'Eine Seite, die nicht antwortet, verliert jeden Besucher und rutscht bei Google schnell nach hinten.',
				'so_beheben'     => array(
					'Rufen Sie Ihre Seite selbst auf, im Browser und auf dem Handy.',
					'Melden Sie Fehler sofort Ihrem Hoster oder Ihrer Agentur, mit Uhrzeit und Fehlermeldung.',
					'Prüfen Sie, ob ein Sicherheits-Plugin oder eine Firewall automatische Abrufe blockiert.',
				),
				'aufwand'        => 'fachhilfe',
				'leistung'       => 'betreuung',
			),
			'G02' => array(
				'titel'          => 'Für Google freigegeben',
				'text_gut'       => 'Google darf Ihre Seite lesen und in die Suchergebnisse aufnehmen.',
				'text_schlecht'  => 'Ihre Seite sagt Google ausdrücklich, dass sie nicht in den Suchergebnissen erscheinen soll.',
				'was_heisst_das' => 'Mit „noindex“ oder einer Sperre in der Datei robots.txt kann eine Website Suchmaschinen aussperren. Das ist für Testseiten gedacht, nicht für die fertige Seite.',
				'warum'          => 'Solange die Sperre aktiv ist, finden Kunden Sie über Google gar nicht.',
				'so_beheben'     => array(
					'In WordPress unter Einstellungen, Lesen: Den Haken bei „Suchmaschinen davon abhalten, diese Website zu indexieren“ entfernen.',
					'In Ihrem SEO-Plugin (zum Beispiel Yoast oder Rank Math) prüfen, ob die Startseite auf „noindex“ steht.',
					'Die Datei robots.txt prüfen: Die Zeile „Disallow: /“ sperrt die ganze Seite.',
					'Danach in der Google Search Console die Startseite neu zur Indexierung einreichen.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'seo',
			),
			'G03' => array(
				'titel'          => 'Seitentitel',
				'text_gut'       => 'Ihr Seitentitel ist vorhanden und wird bei Google vollständig angezeigt.',
				'text_schlecht'  => 'Ihr Seitentitel fehlt, ist zu lang oder sagt zu wenig.',
				'was_heisst_das' => 'Der Seitentitel ist die blaue, anklickbare Überschrift Ihres Eintrags bei Google. Er steht unsichtbar im Quelltext und erscheint auch im Browser-Tab.',
				'warum'          => 'Der Titel entscheidet mit, ob jemand bei Google auf Sie klickt oder auf den Mitbewerber.',
				'so_beheben'     => array(
					'Schreiben Sie einen Titel nach dem Muster „Leistung in {ort} | Firmenname“.',
					'Bleiben Sie bei etwa 50 bis 60 Zeichen, damit nichts abgeschnitten wird.',
					'In WordPress ändern Sie den Titel in Ihrem SEO-Plugin direkt unter der Seite im Feld „SEO-Titel“.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'seo',
			),
			'G04' => array(
				'titel'          => 'Beschreibung bei Google',
				'text_gut'       => 'Ihre Beschreibung hat eine gute Länge und füllt den Platz im Suchergebnis.',
				'text_schlecht'  => 'Ihre Beschreibung fehlt oder hat nicht die passende Länge.',
				'was_heisst_das' => 'Die Meta-Description ist der kurze Text unter Ihrem Titel bei Google. Sie beeinflusst das Ranking kaum, aber stark, ob jemand klickt.',
				'warum'          => 'Ein guter Text unter dem Titel ist Ihre kostenlose Werbeanzeige bei Google.',
				'so_beheben'     => array(
					'Schreiben Sie 120 bis 160 Zeichen: was Sie bieten, wo, und warum man Sie wählen sollte.',
					'Enden Sie mit einer Aufforderung, zum Beispiel „Jetzt unverbindlich anfragen“.',
					'In WordPress tragen Sie den Text im SEO-Plugin unter der Seite ins Feld „Meta-Beschreibung“ ein.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'seo',
			),
			'G05' => array(
				'titel'          => 'Hauptüberschrift (H1)',
				'text_gut'       => 'Ihre Startseite hat genau eine aussagekräftige Hauptüberschrift.',
				'text_schlecht'  => 'Die Hauptüberschrift fehlt, ist doppelt oder sagt nicht, worum es geht.',
				'was_heisst_das' => 'Die H1 ist die wichtigste Überschrift einer Seite. Google liest daraus, worum es auf der Seite geht.',
				'warum'          => 'Eine klare H1 hilft Google und Besuchern, Ihr Angebot in Sekunden einzuordnen.',
				'so_beheben'     => array(
					'Geben Sie der Startseite genau eine H1, zum Beispiel „Ihre Tischlerei in {ort}“.',
					'Stellen Sie weitere große Überschriften im Seiteneditor auf H2 um.',
					'In Elementor stellen Sie das unter „HTML-Tag“ der Überschrift ein, im Block-Editor in der Werkzeugleiste.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'seo',
			),
			'G06' => array(
				'titel'          => 'Gliederung mit Zwischenüberschriften',
				'text_gut'       => 'Ihre Seite ist mit Zwischenüberschriften sauber gegliedert.',
				'text_schlecht'  => 'Ihrer Seite fehlt eine klare Gliederung mit Zwischenüberschriften.',
				'was_heisst_das' => 'Überschriften haben Ebenen: H1 für das Hauptthema, H2 für Abschnitte, H3 für Unterpunkte. Wie in einem Inhaltsverzeichnis.',
				'warum'          => 'Eine klare Gliederung hilft Google beim Verstehen und Besuchern beim Überfliegen.',
				'so_beheben'     => array(
					'Geben Sie jedem Abschnitt eine H2, etwa „Unsere Leistungen“ oder „So arbeiten wir“.',
					'Springen Sie nicht von H1 direkt zu H3 oder H4.',
					'Wählen Sie Überschriften nach Bedeutung, nicht nach gewünschter Schriftgröße. Die Größe lässt sich getrennt einstellen.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'seo',
			),
			'G07' => array(
				'titel'          => 'Textumfang der Startseite',
				'text_gut'       => 'Auf Ihrer Startseite steht genug Text, damit Google Ihr Angebot versteht.',
				'text_schlecht'  => 'Auf Ihrer Startseite steht zu wenig Text.',
				'was_heisst_das' => 'Google liest Text, keine Bilder. Steht wenig da, weiß Google nicht, wofür es Sie anzeigen soll.',
				'warum'          => 'Mehr guter Text heißt mehr Suchbegriffe, bei denen Sie gefunden werden.',
				'so_beheben'     => array(
					'Beschreiben Sie Ihre wichtigsten Leistungen in jeweils zwei, drei Sätzen.',
					'Ergänzen Sie, für wen Sie arbeiten, wo und was Sie besonders macht.',
					'Beantworten Sie typische Kundenfragen direkt auf der Seite.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'seo',
			),
			'G08' => array(
				'titel'          => 'Bilder mit Beschreibung',
				'text_gut'       => 'Ihre Bilder haben fast alle eine Beschreibung (Alternativtext).',
				'text_schlecht'  => 'Vielen Ihrer Bilder fehlt eine Beschreibung (Alternativtext).',
				'was_heisst_das' => 'Der Alternativtext beschreibt ein Bild in Worten. Google und Vorleseprogramme für blinde Menschen können Bilder nur so verstehen.',
				'warum'          => 'Beschriebene Bilder werden in der Google-Bildersuche gefunden und machen Ihre Seite barrierearmer.',
				'so_beheben'     => array(
					'In WordPress unter Medien jedes Bild öffnen und das Feld „Alternativtext“ füllen.',
					'Beschreiben Sie, was zu sehen ist, etwa „Neue Eichenküche in einem Altbau in {ort}“.',
					'Reine Schmuckbilder bekommen einen leeren Alternativtext, das ist erlaubt.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'seo',
			),
			'G09' => array(
				'titel'          => 'Hauptadresse (Canonical)',
				'text_gut'       => 'Ihre Startseite gibt sich selbst als Hauptadresse an.',
				'text_schlecht'  => 'Die Hauptadresse Ihrer Startseite fehlt oder zeigt woandershin.',
				'was_heisst_das' => 'Mit dem Canonical-Verweis sagt eine Seite Google, unter welcher Adresse sie „offiziell“ zu finden ist. Das verhindert doppelte Einträge.',
				'warum'          => 'Ohne klare Hauptadresse kann Google Ihre Seite doppelt zählen oder die falsche Variante anzeigen.',
				'so_beheben'     => array(
					'Aktuelle SEO-Plugins wie Yoast oder Rank Math setzen den Verweis automatisch. Prüfen Sie, ob eines aktiv ist.',
					'Zeigt der Verweis auf eine fremde Domain, liegt meist ein Fehler beim Umzug der Seite vor.',
				),
				'aufwand'        => 'fachhilfe',
				'leistung'       => 'seo',
			),
			'G10' => array(
				'titel'          => 'Sitemap',
				'text_gut'       => 'Ihre Website hat eine gültige Sitemap.',
				'text_schlecht'  => 'Wir haben keine gültige Sitemap gefunden.',
				'was_heisst_das' => 'Eine Sitemap ist ein Inhaltsverzeichnis Ihrer Website für Suchmaschinen. Google findet darüber alle Seiten schneller.',
				'warum'          => 'Neue und geänderte Seiten landen mit Sitemap schneller bei Google.',
				'so_beheben'     => array(
					'WordPress erstellt unter /wp-sitemap.xml selbst eine Sitemap, SEO-Plugins unter /sitemap_index.xml.',
					'Tragen Sie die Adresse der Sitemap in die robots.txt ein („Sitemap: https://…“).',
					'Reichen Sie die Sitemap in der Google Search Console ein.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'seo',
			),
			'G11' => array(
				'titel'          => 'Sprache angegeben',
				'text_gut'       => 'Die Sprache Ihrer Seite ist korrekt angegeben.',
				'text_schlecht'  => 'Die Sprache Ihrer Seite fehlt oder ist falsch angegeben.',
				'was_heisst_das' => 'Im Quelltext steht, in welcher Sprache die Seite geschrieben ist. Browser, Google und Vorleseprogramme richten sich danach.',
				'warum'          => 'Eine falsche Sprache kann zu falscher Aussprache beim Vorlesen und zu ungewollten Übersetzungen führen.',
				'so_beheben'     => array(
					'In WordPress unter Einstellungen, Allgemein die Sprache auf „Deutsch“ stellen.',
					'Wenn das nicht hilft, setzt das Theme die Sprache falsch. Das ist eine kleine Korrektur für Ihre Agentur.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'seo',
			),
			'G12' => array(
				'titel'          => 'Vorschau beim Teilen',
				'text_gut'       => 'Wird Ihre Seite geteilt, erscheint eine ordentliche Vorschau mit Titel und Bild.',
				'text_schlecht'  => 'Beim Teilen Ihrer Seite fehlt Titel oder Bild in der Vorschau.',
				'was_heisst_das' => 'Wenn jemand Ihren Link in WhatsApp, Facebook oder LinkedIn teilt, wird eine Vorschau gebaut. Titel und Bild dafür heißen Open-Graph-Angaben.',
				'warum'          => 'Empfehlungen über WhatsApp sind Gold wert. Mit gutem Bild wird der Link viel öfter angeklickt.',
				'so_beheben'     => array(
					'Im SEO-Plugin unter dem Reiter „Social“ Titel und Bild für die Startseite festlegen.',
					'Nehmen Sie ein echtes Foto von Ihnen oder Ihrer Arbeit, ideal 1200 mal 630 Pixel.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'seo',
			),
			'G13' => array(
				'titel'          => 'Verlinkung auf eigene Seiten',
				'text_gut'       => 'Ihre Startseite verweist gut auf Ihre Unterseiten.',
				'text_schlecht'  => 'Ihre Startseite verweist kaum auf Ihre Unterseiten.',
				'was_heisst_das' => 'Interne Links verbinden Ihre Seiten miteinander. Google folgt ihnen und erkennt so, welche Seiten wichtig sind.',
				'warum'          => 'Gut verlinkte Unterseiten werden schneller gefunden und besser bewertet.',
				'so_beheben'     => array(
					'Verlinken Sie jede wichtige Leistung von der Startseite aus, mit sprechendem Linktext.',
					'Statt „hier klicken“ besser „mehr über unsere Einbauschränke“.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'seo',
			),
			'G14' => array(
				'titel'          => 'Funktionierende Links',
				'text_gut'       => 'Die Links unserer Stichprobe funktionieren.',
				'text_schlecht'  => 'Einige Links auf Ihrer Startseite führen ins Leere.',
				'was_heisst_das' => 'Wir haben eine Stichprobe Ihrer Links aufgerufen. Ein Fehler 404 bedeutet: Die Seite gibt es nicht mehr.',
				'warum'          => 'Kaputte Links frustrieren Besucher und lassen Ihre Seite bei Google ungepflegt wirken.',
				'so_beheben'     => array(
					'Rufen Sie die genannten Links auf und korrigieren oder entfernen Sie sie.',
					'Wurde eine Seite umbenannt, richten Sie eine Weiterleitung von der alten auf die neue Adresse ein, etwa mit dem Plugin „Redirection“.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'seo',
			),

			/* Säule 2: Vor Ort */

			'L01' => array(
				'titel'          => 'Ihr Ort ist sichtbar',
				'text_gut'       => 'Ihr Ort steht an den Stellen, auf die Google zuerst schaut.',
				'text_schlecht'  => 'Ihr Ort fehlt an den Stellen, auf die Google zuerst schaut.',
				'was_heisst_das' => 'Wer nach „Tischler“ und einem Ortsnamen sucht, bekommt vor allem Betriebe angezeigt, die diesen Ort deutlich nennen: im Titel, in der Hauptüberschrift und weit oben im Text.',
				'warum'          => 'Die meisten Kunden suchen mit Ortsnamen. Ohne Ort auf der Seite bleiben Sie bei diesen Suchen unsichtbar.',
				'so_beheben'     => array(
					'Nehmen Sie {ort} in den Seitentitel auf.',
					'Nennen Sie {ort} in der Hauptüberschrift oder direkt im ersten Absatz.',
					'Verwenden Sie den Ort natürlich im Satz, nicht als Liste von Ortsnamen.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'google',
			),
			'L02' => array(
				'titel'          => 'Adresse auffindbar',
				'text_gut'       => 'Ihre vollständige Adresse steht auf der Seite.',
				'text_schlecht'  => 'Ihre vollständige Adresse ist schwer zu finden.',
				'was_heisst_das' => 'Wir haben nach einer Anschrift mit Straße, Hausnummer, Postleitzahl und Ort auf Startseite und Kontaktseite gesucht.',
				'warum'          => 'Eine sichtbare Adresse zeigt Google und Kunden, dass Sie ein echter Betrieb vor Ort sind.',
				'so_beheben'     => array(
					'Setzen Sie Ihre Adresse in den Fußbereich jeder Seite.',
					'Schreiben Sie sie als Text, nicht nur als Bild oder Karte.',
					'Verwenden Sie genau die Schreibweise aus Ihrem Google-Unternehmensprofil.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'google',
			),
			'L03' => array(
				'titel'          => 'Telefon antippbar',
				'text_gut'       => 'Ihre Telefonnummer lässt sich auf dem Handy mit einem Fingertipp anrufen.',
				'text_schlecht'  => 'Ihre Telefonnummer fehlt oder lässt sich auf dem Handy nicht antippen.',
				'was_heisst_das' => 'Eine antippbare Nummer ist ein Link, der auf dem Handy direkt das Telefon öffnet. Technisch heißt das „tel:“-Link.',
				'warum'          => 'Viele Anfragen von lokalen Betrieben kommen per Telefon. Jeder zusätzliche Schritt kostet Anrufe.',
				'so_beheben'     => array(
					'Setzen Sie die Nummer als Link: Im Editor die Nummer markieren, Link einfügen und als Ziel „tel:+49…“ eintragen.',
					'Platzieren Sie die Nummer gut sichtbar im Kopfbereich.',
					'Auf dem Handy hilft zusätzlich ein Anrufknopf, der beim Scrollen sichtbar bleibt.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'google',
			),
			'L04' => array(
				'titel'          => 'Firmendaten für Maschinen',
				'text_gut'       => 'Ihre Firmendaten sind vollständig maschinenlesbar hinterlegt.',
				'text_schlecht'  => 'Ihre Firmendaten sind nicht oder nur teilweise maschinenlesbar hinterlegt.',
				'was_heisst_das' => 'Strukturierte Daten sind ein unsichtbarer Steckbrief im Quelltext: Name, Adresse, Telefon, Öffnungszeiten. Fachbegriff: Schema „LocalBusiness“.',
				'warum'          => 'Google, Karten-Apps und KI-Dienste übernehmen diese Angaben direkt und zeigen Sie dadurch öfter und richtiger an.',
				'so_beheben'     => array(
					'In Rank Math oder Yoast unter „Lokales SEO“ den Betriebstyp, Adresse, Telefon und Öffnungszeiten eintragen.',
					'Wählen Sie einen passenden Typ, etwa „Carpenter“ für Tischler oder „Dentist“ für Zahnärzte.',
					'Testen Sie das Ergebnis mit dem kostenlosen Test für Rich-Suchergebnisse von Google.',
				),
				'aufwand'        => 'fachhilfe',
				'leistung'       => 'google',
			),
			'L05' => array(
				'titel'          => 'Gleiche Angaben überall',
				'text_gut'       => 'Telefon und Postleitzahl sind überall gleich angegeben.',
				'text_schlecht'  => 'Ihre Kontaktdaten stehen nicht überall gleich auf der Seite.',
				'was_heisst_das' => 'Wir haben Telefonnummer und Postleitzahl auf Startseite, Impressum und in den strukturierten Daten verglichen.',
				'warum'          => 'Google vertraut Angaben, die überall übereinstimmen. Widersprüche schwächen Ihre lokale Sichtbarkeit.',
				'so_beheben'     => array(
					'Legen Sie eine Hauptnummer und eine Schreibweise der Adresse fest.',
					'Gleichen Sie Startseite, Impressum, strukturierte Daten und Google-Profil darauf ab.',
					'Alte Nummern nach einem Umzug überall entfernen, auch in Branchenbüchern.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'google',
			),
			'L06' => array(
				'titel'          => 'Öffnungszeiten',
				'text_gut'       => 'Ihre Öffnungs- oder Erreichbarkeitszeiten sind zu finden.',
				'text_schlecht'  => 'Wir haben keine Öffnungs- oder Erreichbarkeitszeiten gefunden.',
				'was_heisst_das' => 'Öffnungszeiten beantworten die Frage „Kann ich jetzt anrufen oder vorbeikommen?“.',
				'warum'          => 'Fehlen sie, ruft der Kunde lieber dort an, wo er sicher jemanden erreicht.',
				'so_beheben'     => array(
					'Schreiben Sie Öffnungs- oder Telefonzeiten in den Fußbereich und auf die Kontaktseite.',
					'Tragen Sie sie zusätzlich in Ihr Google-Unternehmensprofil und in die strukturierten Daten ein.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'google',
			),
			'L07' => array(
				'titel'          => 'Google-Profil verknüpft',
				'text_gut'       => 'Ihre Seite verweist auf Ihr Google-Unternehmensprofil.',
				'text_schlecht'  => 'Ihre Seite verweist nicht auf Ihr Google-Unternehmensprofil.',
				'was_heisst_das' => 'Das Google-Unternehmensprofil ist Ihr Eintrag in Google Maps mit Bewertungen, Fotos und Öffnungszeiten.',
				'warum'          => 'Das Profil ist für lokale Betriebe oft wichtiger als die Website. Beides verknüpft stärkt sich gegenseitig.',
				'so_beheben'     => array(
					'Falls noch nicht geschehen: Profil unter business.google.com anlegen und bestätigen.',
					'Verlinken Sie das Profil auf Ihrer Seite, etwa mit „Bewertungen bei Google ansehen“.',
					'Tragen Sie umgekehrt Ihre Website im Profil ein.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'google',
			),
			'L08' => array(
				'titel'          => 'Einzugsgebiet genannt',
				'text_gut'       => 'Ihre Seite nennt Ihr Einzugsgebiet.',
				'text_schlecht'  => 'Ihre Seite nennt kein Einzugsgebiet.',
				'was_heisst_das' => 'Viele Betriebe arbeiten nicht nur in einem Ort. Nennen Sie die Umgebung, finden Sie auch Kunden aus den Nachbarorten.',
				'warum'          => 'Kunden aus dem Umland suchen mit ihrem eigenen Ortsnamen und finden Sie sonst nicht.',
				'so_beheben'     => array(
					'Schreiben Sie einen Satz wie „Wir arbeiten in {ort} und im ganzen Kreis, etwa in …“.',
					'Für sehr wichtige Nachbarorte kann eine eigene Seite mit echten Referenzen von dort sinnvoll sein.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'google',
			),

			/* Säule 3: Schnell */

			'S01' => array(
				'titel'          => 'Tempo auf dem Handy',
				'text_gut'       => 'Google bewertet Ihr Tempo auf dem Handy als gut.',
				'text_schlecht'  => 'Google bewertet Ihr Tempo auf dem Handy als zu langsam.',
				'was_heisst_das' => 'Google misst mit PageSpeed Insights, wie schnell Ihre Seite auf einem durchschnittlichen Handy mit mobilem Internet lädt. 90 bis 100 Punkte sind gut.',
				'warum'          => 'Die meisten Besucher kommen über das Handy. Lädt die Seite länger als drei Sekunden, springt ein großer Teil ab.',
				'so_beheben'     => array(
					'Bilder verkleinern und in WebP umwandeln, etwa mit Imagify oder einem ähnlichen Plugin.',
					'Ein Cache-Plugin einsetzen und richtig einstellen.',
					'Nicht genutzte Plugins und schwere Effekte entfernen.',
					'Bei sehr schwachem Wert: Hosting und Theme prüfen lassen.',
				),
				'aufwand'        => 'fachhilfe',
				'leistung'       => 'betreuung',
			),
			'S02' => array(
				'titel'          => 'Hauptinhalt sichtbar (LCP)',
				'text_gut'       => 'Der wichtigste Inhalt Ihrer Seite erscheint schnell.',
				'text_schlecht'  => 'Der wichtigste Inhalt Ihrer Seite erscheint zu spät.',
				'was_heisst_das' => 'LCP (Largest Contentful Paint) misst, wann das größte Element im sichtbaren Bereich fertig geladen ist, meist das große Bild oben.',
				'warum'          => 'Solange oben nichts zu sehen ist, wirkt die Seite kaputt und Besucher gehen.',
				'so_beheben'     => array(
					'Das große Bild oben verkleinern (unter 200 KB) und im WebP-Format speichern.',
					'Dieses Bild nicht verzögert laden (kein „Lazy Load“ für das erste Bild).',
					'Schieberegler mit vielen großen Bildern oben durch ein starkes Einzelbild ersetzen.',
				),
				'aufwand'        => 'fachhilfe',
				'leistung'       => 'betreuung',
			),
			'S03' => array(
				'titel'          => 'Ruhiger Seitenaufbau (CLS)',
				'text_gut'       => 'Ihre Seite baut sich ruhig auf, nichts springt.',
				'text_schlecht'  => 'Beim Laden springen Inhalte auf Ihrer Seite.',
				'was_heisst_das' => 'CLS (Cumulative Layout Shift) misst, wie stark Inhalte beim Laden verrutschen. Etwa wenn ein Knopf nach unten springt, während man tippen will.',
				'warum'          => 'Springende Inhalte führen zu Fehlklicks und wirken unprofessionell.',
				'so_beheben'     => array(
					'Bildern feste Breite und Höhe geben.',
					'Banner, Cookie-Hinweise und Werbung so einbinden, dass sie keinen Inhalt verschieben.',
					'Schriften lokal laden und mit „font-display: swap“ einbinden.',
				),
				'aufwand'        => 'fachhilfe',
				'leistung'       => 'betreuung',
			),
			'S04' => array(
				'titel'          => 'Reaktionszeit (TBT)',
				'text_gut'       => 'Ihre Seite reagiert schnell auf Eingaben.',
				'text_schlecht'  => 'Ihre Seite ist beim Laden zu lange blockiert.',
				'was_heisst_das' => 'TBT (Total Blocking Time) misst, wie lange die Seite beim Laden mit Skripten beschäftigt ist und nicht auf Tippen reagiert.',
				'warum'          => 'Eine Seite, die nicht reagiert, fühlt sich kaputt an, auch wenn sie schon zu sehen ist.',
				'so_beheben'     => array(
					'Nicht benötigte Plugins, Slider und Animationen entfernen.',
					'Externe Skripte (Chat, Tracking, Widgets) nur laden, wo sie gebraucht werden.',
					'Skripte verzögert laden lassen, etwa mit einem Optimierungs-Plugin.',
				),
				'aufwand'        => 'fachhilfe',
				'leistung'       => 'betreuung',
			),
			'S05' => array(
				'titel'          => 'Antwortzeit des Servers',
				'text_gut'       => 'Ihr Server antwortet zügig.',
				'text_schlecht'  => 'Ihr Server braucht zu lange für die erste Antwort.',
				'was_heisst_das' => 'Wir haben gemessen, wie lange es dauert, bis Ihr Server nach dem Aufruf das erste Datenpaket schickt. Fachbegriff: Time to First Byte.',
				'warum'          => 'Alles andere wartet auf diese erste Antwort. Ein langsamer Server bremst jede einzelne Seite.',
				'so_beheben'     => array(
					'Ein Cache-Plugin einsetzen, damit fertige Seiten gespeichert und nicht jedes Mal neu gebaut werden.',
					'PHP-Version beim Hoster auf eine aktuelle Version stellen.',
					'Bei günstigem Hosting über einen schnelleren Tarif nachdenken.',
				),
				'aufwand'        => 'fachhilfe',
				'leistung'       => 'betreuung',
			),
			'S06' => array(
				'titel'          => 'Seitengewicht',
				'text_gut'       => 'Ihre Startseite ist schlank.',
				'text_schlecht'  => 'Ihre Startseite ist schwer, vor allem durch große Dateien.',
				'was_heisst_das' => 'Wir haben geprüft, wie viele Daten Ihre Startseite und eine Stichprobe Ihrer Bilder übertragen. Bilder über 500 KB sind für das Web fast immer zu groß.',
				'warum'          => 'Jedes Megabyte kostet auf dem Handy Ladezeit und Datenvolumen Ihrer Kunden.',
				'so_beheben'     => array(
					'Bilder vor dem Hochladen auf höchstens 2000 Pixel Breite verkleinern.',
					'Ein Plugin zur Bildoptimierung einsetzen und vorhandene Bilder nachträglich verkleinern lassen.',
					'Videos nicht direkt hochladen, sondern datenschutzfreundlich einbinden.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'betreuung',
			),
			'S07' => array(
				'titel'          => 'Komprimierung',
				'text_gut'       => 'Ihr Server verschickt die Seite komprimiert.',
				'text_schlecht'  => 'Ihr Server verschickt die Seite unkomprimiert.',
				'was_heisst_das' => 'Ein Server kann Text vor dem Versand zusammenpacken, ähnlich wie eine ZIP-Datei. Das spart oft 70 Prozent der Datenmenge.',
				'warum'          => 'Komprimierung ist eine der einfachsten Beschleunigungen überhaupt.',
				'so_beheben'     => array(
					'Viele Cache-Plugins schalten die Komprimierung (GZIP) mit einem Haken ein.',
					'Sonst den Hoster bitten, GZIP oder Brotli zu aktivieren.',
				),
				'aufwand'        => 'fachhilfe',
				'leistung'       => 'betreuung',
			),
			'S08' => array(
				'titel'          => 'Für Handys eingerichtet',
				'text_gut'       => 'Ihre Seite ist für Handys eingerichtet.',
				'text_schlecht'  => 'Ihre Seite ist nicht für Handys eingerichtet.',
				'was_heisst_das' => 'Eine kleine Angabe im Quelltext (Viewport) sagt dem Handy, dass die Seite sich an den kleinen Bildschirm anpassen soll.',
				'warum'          => 'Ohne diese Angabe sehen Handybesucher eine winzige Desktop-Seite und müssen zoomen. Google stuft das ab.',
				'so_beheben'     => array(
					'Moderne Themes setzen die Angabe automatisch. Fehlt sie, ist das Theme veraltet.',
					'Prüfen Sie Ihre Seite auf dem eigenen Handy: Ist Text ohne Zoomen lesbar?',
					'Bei veraltetem Theme ist eine Überarbeitung der Seite meist sinnvoller als ein Flicken.',
				),
				'aufwand'        => 'fachhilfe',
				'leistung'       => 'webdesign',
			),
			'S09' => array(
				'titel'          => 'Moderne Bildformate',
				'text_gut'       => 'Ihre Bilder nutzen überwiegend moderne, kleine Formate.',
				'text_schlecht'  => 'Ihre Bilder nutzen noch alte, große Formate.',
				'was_heisst_das' => 'WebP und AVIF sind Bildformate, die bei gleicher Qualität deutlich kleiner sind als JPG oder PNG.',
				'warum'          => 'Kleinere Bilder laden schneller, besonders auf dem Handy.',
				'so_beheben'     => array(
					'Ein Plugin zur Bildoptimierung (zum Beispiel Imagify) wandelt Bilder automatisch in WebP um.',
					'Neue Bilder schon vor dem Hochladen als WebP speichern.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'betreuung',
			),

			/* Säule 4: Überzeugend */

			'U01' => array(
				'titel'          => '5-Sekunden-Test',
				'text_gut'       => 'Besucher sehen sofort, was Sie anbieten und wo.',
				'text_schlecht'  => 'Besucher sehen nicht sofort, was Sie anbieten und wo.',
				'was_heisst_das' => 'Wir haben den ersten sichtbaren Bereich geprüft: Kopf, Hauptüberschrift und ersten Absatz. Steht dort, was Sie machen und wo Sie es machen?',
				'warum'          => 'Besucher entscheiden in wenigen Sekunden, ob sie bleiben. Wer zuerst suchen muss, ist schnell beim Mitbewerber.',
				'so_beheben'     => array(
					'Formulieren Sie oben einen klaren Satz: Leistung, Ort und Ihr Vorteil.',
					'Ersetzen Sie Begrüßungen wie „Herzlich willkommen“ durch eine Aussage über Ihr Angebot.',
					'Zeigen Sie daneben ein echtes Foto Ihrer Arbeit.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'webdesign',
			),
			'U02' => array(
				'titel'          => 'Klarer Weg zur Anfrage',
				'text_gut'       => 'Besucher finden sofort einen Weg, Sie anzufragen.',
				'text_schlecht'  => 'Besucher finden nicht sofort einen Weg, Sie anzufragen.',
				'was_heisst_das' => 'Wir haben im Kopfbereich und im oberen Viertel Ihrer Seite nach Knöpfen oder Links wie „Anfrage“, „Termin“ oder „Anrufen“ gesucht.',
				'warum'          => 'Wer sich entschieden hat, will jetzt anfragen. Jeder Moment des Suchens kostet Anfragen.',
				'so_beheben'     => array(
					'Setzen Sie einen auffälligen Knopf in den Kopfbereich, etwa „Jetzt anfragen“.',
					'Wiederholen Sie den Knopf nach jedem größeren Abschnitt.',
					'Nennen Sie im Knopf, was passiert: „Rückruf anfordern“ statt nur „Kontakt“.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'webdesign',
			),
			'U03' => array(
				'titel'          => 'Anfrageformular',
				'text_gut'       => 'Es gibt ein Formular für Anfragen.',
				'text_schlecht'  => 'Wir haben kein Formular für Anfragen gefunden.',
				'was_heisst_das' => 'Nicht jeder möchte anrufen. Viele schreiben lieber abends eine kurze Anfrage über ein Formular.',
				'warum'          => 'Ein Formular fängt die Anfragen auf, die außerhalb Ihrer Telefonzeiten entstehen.',
				'so_beheben'     => array(
					'Legen Sie ein kurzes Formular an: Name, E-Mail oder Telefon, Nachricht. Nicht mehr.',
					'In WordPress geht das zum Beispiel mit Fluent Forms oder Contact Form 7.',
					'Schützen Sie das Formular gegen Spam, ohne Google reCAPTCHA, etwa mit einem unsichtbaren Feld.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'webdesign',
			),
			'U04' => array(
				'titel'          => 'Bewertungen und Referenzen',
				'text_gut'       => 'Ihre Seite zeigt, dass andere mit Ihnen zufrieden sind.',
				'text_schlecht'  => 'Ihre Seite zeigt nicht, dass andere mit Ihnen zufrieden sind.',
				'was_heisst_das' => 'Bewertungen, Kundenstimmen und Referenzprojekte sind Belege von außen. Fachleute sprechen von „sozialem Beweis“.',
				'warum'          => 'Neue Kunden glauben anderen Kunden mehr als jeder Werbeaussage.',
				'so_beheben'     => array(
					'Zeigen Sie zwei, drei echte Kundenstimmen mit Namen und Ort.',
					'Verlinken Sie Ihre Google-Bewertungen.',
					'Legen Sie eine Seite mit Referenzprojekten und Fotos an.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'social',
			),
			'U05' => array(
				'titel'          => 'Menschen hinter dem Betrieb',
				'text_gut'       => 'Besucher erfahren, wer hinter Ihrem Betrieb steht.',
				'text_schlecht'  => 'Besucher erfahren nicht, wer hinter Ihrem Betrieb steht.',
				'was_heisst_das' => 'Wir haben nach einem Bereich „Über uns“, „Team“ oder einer Vorstellung des Inhabers gesucht.',
				'warum'          => 'Menschen kaufen bei Menschen. Ein Gesicht schafft Vertrauen, gerade bei Aufträgen im eigenen Zuhause.',
				'so_beheben'     => array(
					'Zeigen Sie ein echtes Foto von sich oder Ihrem Team.',
					'Schreiben Sie ein paar Sätze: seit wann es Sie gibt, was Ihnen wichtig ist.',
					'Verlinken Sie die Seite „Über uns“ im Menü.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'webdesign',
			),
			'U06' => array(
				'titel'          => 'Verschlüsselung (HTTPS)',
				'text_gut'       => 'Ihre Seite ist sicher verschlüsselt.',
				'text_schlecht'  => 'Ihre Seite ist nicht sauber verschlüsselt.',
				'was_heisst_das' => 'HTTPS verschlüsselt die Verbindung zwischen Besucher und Website. Das Schloss im Browser zeigt es an. Dafür braucht es ein gültiges Zertifikat.',
				'warum'          => 'Ohne HTTPS zeigen Browser „Nicht sicher“. Das schreckt ab und Google stuft die Seite herab.',
				'so_beheben'     => array(
					'Bei fast jedem Hoster gibt es kostenlose Zertifikate (Let’s Encrypt). Im Kundenbereich aktivieren.',
					'In WordPress unter Einstellungen, Allgemein beide Adressen auf https:// umstellen.',
					'Eine Weiterleitung von http:// auf https:// einrichten lassen.',
				),
				'aufwand'        => 'fachhilfe',
				'leistung'       => 'betreuung',
			),
			'U07' => array(
				'titel'          => 'Keine unverschlüsselten Inhalte',
				'text_gut'       => 'Alle Inhalte werden verschlüsselt geladen.',
				'text_schlecht'  => 'Einige Inhalte werden unverschlüsselt nachgeladen.',
				'was_heisst_das' => 'Lädt eine verschlüsselte Seite einzelne Bilder oder Skripte über http://, spricht man von gemischten Inhalten. Browser blockieren sie teilweise.',
				'warum'          => 'Blockierte Inhalte fehlen auf der Seite, und das Schloss im Browser kann verschwinden.',
				'so_beheben'     => array(
					'Die genannten Adressen von http:// auf https:// ändern.',
					'Bei vielen Fundstellen hilft ein Plugin, das alte Adressen in der Datenbank ersetzt, etwa „Better Search Replace“. Vorher eine Sicherung machen.',
				),
				'aufwand'        => 'fachhilfe',
				'leistung'       => 'betreuung',
			),
			'U08' => array(
				'titel'          => 'Seitensymbol (Favicon)',
				'text_gut'       => 'Ihre Seite hat ein eigenes Symbol im Browser-Tab.',
				'text_schlecht'  => 'Ihrer Seite fehlt ein eigenes Symbol im Browser-Tab.',
				'was_heisst_das' => 'Das Favicon ist das kleine Logo im Browser-Tab, in Lesezeichen und auf dem Handy-Startbildschirm. Google zeigt es auch neben Suchergebnissen.',
				'warum'          => 'Ein eigenes Symbol wirkt professionell und macht Ihren Eintrag bei Google wiedererkennbar.',
				'so_beheben'     => array(
					'In WordPress unter Design, Customizer, Website-Informationen ein „Website-Icon“ hochladen.',
					'Nutzen Sie ein quadratisches Bild, mindestens 512 mal 512 Pixel.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'betreuung',
			),
			'U09' => array(
				'titel'          => 'Aktualität',
				'text_gut'       => 'Ihre Seite wirkt aktuell.',
				'text_schlecht'  => 'Ihre Seite wirkt nicht aktuell.',
				'was_heisst_das' => 'Wir haben nach Jahreszahlen im Fußbereich und nach Datumsangaben von Beiträgen gesucht.',
				'warum'          => 'Eine veraltete Jahreszahl lässt Besucher zweifeln, ob es den Betrieb noch gibt.',
				'so_beheben'     => array(
					'Lassen Sie die Jahreszahl im Fußbereich automatisch erzeugen oder lassen Sie sie ganz weg.',
					'Veröffentlichen Sie ab und zu Neuigkeiten oder aktuelle Projekte.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'betreuung',
			),

			/* Säule 5: Rechtssicher */

			'R01' => array(
				'titel'          => 'Impressum erreichbar',
				'text_gut'       => 'Ihr Impressum ist von der Startseite aus erreichbar.',
				'text_schlecht'  => 'Ihr Impressum ist von der Startseite aus nicht erreichbar.',
				'was_heisst_das' => 'Geschäftliche Websites in Deutschland brauchen in der Regel ein Impressum, das von jeder Seite aus leicht zu erreichen ist.',
				'warum'          => 'Ein fehlendes Impressum ist ein häufiger Grund für Abmahnungen. Dies ist ein Hinweis, keine Rechtsberatung.',
				'so_beheben'     => array(
					'Verlinken Sie das Impressum im Fußbereich jeder Seite, mit dem Wort „Impressum“.',
					'Nutzen Sie einen geprüften Text, etwa von der IT-Recht Kanzlei oder eRecht24.',
					'Lassen Sie im Zweifel eine Fachstelle prüfen.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'recht',
			),
			'R02' => array(
				'titel'          => 'Impressum: Grundangaben',
				'text_gut'       => 'Die Grundangaben im Impressum haben wir erkannt.',
				'text_schlecht'  => 'Im Impressum fehlen vermutlich Grundangaben.',
				'was_heisst_das' => 'Wir prüfen nur, ob Name oder Rechtsform, eine Anschrift mit Postleitzahl und eine E-Mail-Adresse erkennbar sind. Je nach Rechtsform und Beruf sind weitere Angaben Pflicht.',
				'warum'          => 'Unvollständige Impressen sind ein häufiger Abmahngrund. Dies ist ein Hinweis, keine Rechtsberatung.',
				'so_beheben'     => array(
					'Ergänzen Sie fehlende Angaben, insbesondere eine E-Mail-Adresse zur schnellen Kontaktaufnahme.',
					'Prüfen Sie berufsspezifische Pflichtangaben, etwa Kammer oder Berufsbezeichnung.',
					'Lassen Sie den Text von einer Fachstelle prüfen.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'recht',
			),
			'R03' => array(
				'titel'          => 'Datenschutzerklärung erreichbar',
				'text_gut'       => 'Ihre Datenschutzerklärung ist von der Startseite aus erreichbar.',
				'text_schlecht'  => 'Ihre Datenschutzerklärung ist von der Startseite aus nicht erreichbar.',
				'was_heisst_das' => 'Websites, die Daten von Besuchern verarbeiten, brauchen eine Datenschutzerklärung. Das betrifft fast jede Website, schon wegen der Server-Protokolle.',
				'warum'          => 'Eine fehlende Datenschutzerklärung kann zu Abmahnungen und Bußgeldern führen. Dies ist ein Hinweis, keine Rechtsberatung.',
				'so_beheben'     => array(
					'Verlinken Sie die Datenschutzerklärung im Fußbereich jeder Seite.',
					'Lassen Sie sie mit einem Generator erstellen und von einer Fachstelle prüfen.',
					'Halten Sie sie aktuell, wenn Sie neue Dienste einbinden.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'recht',
			),
			'R04' => array(
				'titel'          => 'Einwilligungs-Werkzeug',
				'text_gut'       => 'Ein Werkzeug für Einwilligungen ist vorhanden oder nicht nötig.',
				'text_schlecht'  => 'Wir haben kein Werkzeug für Einwilligungen gefunden, obwohl Dienste geladen werden, die oft eine Einwilligung brauchen.',
				'was_heisst_das' => 'Ein Einwilligungs-Werkzeug (Cookie-Banner) fragt Besucher, bevor Dienste wie Statistik oder Videos starten. Bekannte Werkzeuge sind etwa Borlabs Cookie oder Usercentrics.',
				'warum'          => 'Dienste ohne nötige Einwilligung können Abmahnungen nach sich ziehen. Dies ist ein Hinweis, keine Rechtsberatung.',
				'so_beheben'     => array(
					'Prüfen Sie, welche externen Dienste Ihre Seite lädt, und ob Sie alle brauchen.',
					'Setzen Sie ein Einwilligungs-Werkzeug ein, das Dienste wirklich erst nach Zustimmung lädt.',
					'Lassen Sie die Einrichtung von einer Fachstelle prüfen.',
				),
				'aufwand'        => 'fachhilfe',
				'leistung'       => 'recht',
			),
			'R05' => array(
				'titel'          => 'Google Fonts',
				'text_gut'       => 'Ihre Seite lädt keine Schriften direkt von Google.',
				'text_schlecht'  => 'Ihre Seite lädt Schriften direkt von Google-Servern.',
				'was_heisst_das' => 'Google Fonts sind beliebte Schriftarten. Werden sie direkt von Google geladen, erfährt Google die IP-Adresse jedes Besuchers.',
				'warum'          => 'Ein Urteil des LG München von 2022 hat dafür Schadensersatz zugesprochen, danach rollte eine Abmahnwelle. Dies ist ein Hinweis, keine Rechtsberatung.',
				'so_beheben'     => array(
					'Schriften lokal auf Ihrem Server speichern, etwa mit dem Plugin „OMGF“ oder über die Theme-Einstellungen.',
					'In Elementor unter Einstellungen, Erweitert: „Google Fonts laden“ auf lokal oder aus stellen.',
					'Danach erneut prüfen, auch Plugins laden manchmal eigene Schriften nach.',
				),
				'aufwand'        => 'fachhilfe',
				'leistung'       => 'recht',
			),
			'R06' => array(
				'titel'          => 'Tracking ohne Einwilligung',
				'text_gut'       => 'Wir haben kein Tracking gefunden, das ohne Einwilligung startet.',
				'text_schlecht'  => 'Wir haben Tracking gefunden, das vermutlich ohne Einwilligung startet.',
				'was_heisst_das' => 'Tracking-Dienste wie Google Analytics oder der Meta Pixel zeichnen das Verhalten von Besuchern auf. Sie dürfen in der Regel erst nach Zustimmung starten.',
				'warum'          => 'Tracking ohne Einwilligung ist einer der häufigsten Datenschutzverstöße. Dies ist ein Hinweis, keine Rechtsberatung.',
				'so_beheben'     => array(
					'Binden Sie Tracking ausschließlich über Ihr Einwilligungs-Werkzeug ein.',
					'Prüfen Sie mit den Entwicklertools des Browsers, ob vor der Zustimmung Daten an Google oder Meta gehen.',
					'Fragen Sie sich, ob Sie das Tracking wirklich auswerten. Wenn nicht: entfernen.',
				),
				'aufwand'        => 'fachhilfe',
				'leistung'       => 'recht',
			),
			'R07' => array(
				'titel'          => 'Videos von YouTube und Vimeo',
				'text_gut'       => 'Videos sind datenschutzfreundlich eingebunden oder nicht vorhanden.',
				'text_schlecht'  => 'Videos werden direkt geladen, bevor Besucher zustimmen.',
				'was_heisst_das' => 'Eingebettete Videos laden Daten von YouTube oder Vimeo, sobald die Seite öffnet, nicht erst beim Abspielen.',
				'warum'          => 'Dabei werden Daten an Google oder Vimeo übertragen, wofür meist eine Einwilligung nötig ist. Dies ist ein Hinweis, keine Rechtsberatung.',
				'so_beheben'     => array(
					'Videos über ein Vorschaltbild einbinden, das erst nach Klick lädt. Viele Einwilligungs-Werkzeuge bieten das an.',
					'Bei YouTube mindestens die Adresse youtube-nocookie.com verwenden.',
				),
				'aufwand'        => 'fachhilfe',
				'leistung'       => 'recht',
			),
			'R08' => array(
				'titel'          => 'Google Maps',
				'text_gut'       => 'Karten sind datenschutzfreundlich eingebunden oder nicht vorhanden.',
				'text_schlecht'  => 'Eine Google-Karte wird direkt geladen, bevor Besucher zustimmen.',
				'was_heisst_das' => 'Eine eingebettete Google-Karte lädt beim Öffnen der Seite Daten von Google, auch wenn niemand sie benutzt.',
				'warum'          => 'Dafür ist meist eine Einwilligung nötig. Dies ist ein Hinweis, keine Rechtsberatung.',
				'so_beheben'     => array(
					'Ersetzen Sie die Karte durch ein Bild Ihrer Anfahrt mit Link zu Google Maps.',
					'Oder laden Sie die Karte über Ihr Einwilligungs-Werkzeug erst nach Klick.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'recht',
			),
			'R09' => array(
				'titel'          => 'Weitere Dienste von fremden Servern',
				'text_gut'       => 'Wir haben keine weiteren Dienste von fremden Servern gefunden.',
				'text_schlecht'  => 'Ihre Seite lädt Inhalte von weiteren fremden Servern.',
				'was_heisst_das' => 'Dazu zählen etwa Google reCAPTCHA, Chat-Fenster, Schriften anderer Anbieter oder Dateien von fremden Servern (CDN).',
				'warum'          => 'Jeder dieser Dienste erfährt die IP-Adresse Ihrer Besucher und muss in der Datenschutzerklärung stehen. Dies ist ein Hinweis, keine Rechtsberatung.',
				'so_beheben'     => array(
					'Prüfen Sie jeden genannten Dienst: Brauchen Sie ihn wirklich?',
					'Nennen Sie alle Dienste in Ihrer Datenschutzerklärung.',
					'Laden Sie Dateien nach Möglichkeit vom eigenen Server.',
				),
				'aufwand'        => 'fachhilfe',
				'leistung'       => 'recht',
			),
			'R10' => array(
				'titel'          => 'Cookies beim ersten Aufruf',
				'text_gut'       => 'Ihr Server setzt beim ersten Aufruf keine Cookies.',
				'text_schlecht'  => 'Ihr Server setzt beim ersten Aufruf Cookies.',
				'was_heisst_das' => 'Cookies sind kleine Dateien im Browser. Technisch notwendige Cookies sind erlaubt, alle anderen brauchen in der Regel eine Einwilligung.',
				'warum'          => 'Cookies ohne nötige Einwilligung sind ein häufiger Beanstandungsgrund. Dies ist ein Hinweis, keine Rechtsberatung.',
				'so_beheben'     => array(
					'Prüfen Sie, wofür die genannten Cookies da sind. Ein Einwilligungs-Werkzeug zeigt das oft an.',
					'Nicht notwendige Cookies erst nach Zustimmung setzen lassen.',
				),
				'aufwand'        => 'fachhilfe',
				'leistung'       => 'recht',
			),
			'R11' => array(
				'titel'          => 'Barrierefreiheit: Grundlagen',
				'text_gut'       => 'Die Grundlagen der Barrierefreiheit sind erfüllt.',
				'text_schlecht'  => 'Bei den Grundlagen der Barrierefreiheit fehlt etwas.',
				'was_heisst_das' => 'Wir prüfen vier Grundlagen: Sprachangabe, Bildbeschreibungen, beschriftete Formularfelder und einen markierten Hauptbereich. Seit dem 28.06.2025 gilt das Barrierefreiheitsstärkungsgesetz für viele Angebote an Verbraucher, Kleinstunternehmen bei Dienstleistungen sind teils ausgenommen.',
				'warum'          => 'Barrierearme Seiten erreichen mehr Menschen, etwa Ältere oder Menschen mit Sehschwäche. Ob das Gesetz für Sie gilt, klären Sie bitte mit einer Fachstelle.',
				'so_beheben'     => array(
					'Allen Bildern einen Alternativtext geben.',
					'Jedes Formularfeld mit einer sichtbaren Beschriftung versehen.',
					'Ihr Theme so einstellen, dass es einen Link „Zum Inhalt springen“ und einen Hauptbereich hat.',
				),
				'aufwand'        => 'fachhilfe',
				'leistung'       => 'recht',
			),
			'R12' => array(
				'titel'          => 'Barrierefreiheit laut Google',
				'text_gut'       => 'Google bewertet die Barrierefreiheit Ihrer Startseite als gut.',
				'text_schlecht'  => 'Google findet bei der Barrierefreiheit Ihrer Startseite Mängel.',
				'was_heisst_das' => 'Google prüft automatisch typische Hürden wie zu schwache Kontraste, fehlende Beschriftungen oder zu kleine Tippflächen. 90 bis 100 Punkte sind gut.',
				'warum'          => 'Schwache Kontraste und kleine Knöpfe stören alle Besucher, nicht nur Menschen mit Einschränkungen.',
				'so_beheben'     => array(
					'Prüfen Sie Ihre Seite mit PageSpeed Insights und schauen Sie in den Abschnitt „Barrierefreiheit“.',
					'Erhöhen Sie Kontraste, etwa grauer Text auf weißem Grund.',
					'Machen Sie Knöpfe und Links auf dem Handy groß genug zum Antippen.',
				),
				'aufwand'        => 'fachhilfe',
				'leistung'       => 'recht',
			),

			/* Säule 6: KI-bereit */

			'K01' => array(
				'titel'          => 'KI-Dienste zugelassen',
				'text_gut'       => 'KI-Dienste wie ChatGPT, Perplexity und Gemini dürfen Ihre Seite lesen.',
				'text_schlecht'  => 'Ihre Seite sperrt einige KI-Dienste aus.',
				'was_heisst_das' => 'In der Datei robots.txt kann man einzelne Programme aussperren, auch die Leseprogramme von ChatGPT, Claude oder Perplexity. Das kann eine bewusste Entscheidung sein.',
				'warum'          => 'Immer mehr Menschen fragen KI-Dienste nach Empfehlungen. Wer gesperrt ist, wird dort nicht genannt.',
				'so_beheben'     => array(
					'Prüfen Sie, ob die Sperre bewusst gesetzt wurde. Manche Sicherheits-Plugins tun das von selbst.',
					'Wenn Sie in KI-Antworten auftauchen möchten, entfernen Sie die Zeilen für diese Dienste aus der robots.txt.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'seo',
			),
			'K02' => array(
				'titel'          => 'llms.txt',
				'text_gut'       => 'Ihre Seite hat eine llms.txt.',
				'text_schlecht'  => 'Ihre Seite hat noch keine llms.txt.',
				'was_heisst_das' => 'Die llms.txt ist eine neue, kurze Textdatei, die KI-Diensten in einfachen Worten sagt, wer Sie sind und welche Seiten wichtig sind. Der Standard ist noch jung.',
				'warum'          => 'Sie kostet wenig Aufwand und hilft KI-Diensten, Sie richtig zu beschreiben.',
				'so_beheben'     => array(
					'Legen Sie eine Datei llms.txt im Hauptordner Ihrer Website an.',
					'Schreiben Sie hinein: Firmenname, ein Satz zu Leistung und Ort, Links zu den wichtigsten Seiten.',
					'Einige SEO-Plugins wie Rank Math erzeugen die Datei auf Wunsch automatisch.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'seo',
			),
			'K03' => array(
				'titel'          => 'Strukturierte Daten',
				'text_gut'       => 'Ihre Seite enthält strukturierte Daten, die Maschinen gut verstehen.',
				'text_schlecht'  => 'Ihrer Seite fehlen strukturierte Daten oder sie sind fehlerhaft.',
				'was_heisst_das' => 'Strukturierte Daten (JSON-LD) beschreiben im Quelltext, was auf der Seite steht: Betrieb, Leistungen, Fragen und Antworten. Für Menschen unsichtbar.',
				'warum'          => 'Google und KI-Dienste greifen bevorzugt auf diese klaren Angaben zurück.',
				'so_beheben'     => array(
					'Aktivieren Sie in Ihrem SEO-Plugin die Schema-Funktionen.',
					'Ergänzen Sie mindestens Angaben zu Ihrem Betrieb, ideal auch zu Ihren Leistungen.',
					'Prüfen Sie das Ergebnis mit dem Test für Rich-Suchergebnisse von Google.',
				),
				'aufwand'        => 'fachhilfe',
				'leistung'       => 'seo',
			),
			'K04' => array(
				'titel'          => 'Fragen und Antworten',
				'text_gut'       => 'Ihre Seite beantwortet typische Kundenfragen.',
				'text_schlecht'  => 'Ihre Seite beantwortet keine typischen Kundenfragen.',
				'was_heisst_das' => 'Ein Bereich mit häufigen Fragen (FAQ) beantwortet, was Kunden vor einer Anfrage wissen wollen: Preise, Dauer, Ablauf, Einzugsgebiet.',
				'warum'          => 'KI-Dienste und Google übernehmen gute Antworten gern direkt, mit Verweis auf Sie.',
				'so_beheben'     => array(
					'Sammeln Sie die fünf Fragen, die Kunden am Telefon am häufigsten stellen.',
					'Beantworten Sie jede in zwei, drei Sätzen auf der Startseite oder einer eigenen Seite.',
					'Hinterlegen Sie den Bereich mit dem Schema „FAQPage“, viele SEO-Plugins bieten dafür einen Block.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'seo',
			),
			'K05' => array(
				'titel'          => 'Klare Selbstbeschreibung',
				'text_gut'       => 'Ihr erster Absatz beschreibt klar, wer Sie sind, was Sie tun und wo.',
				'text_schlecht'  => 'Ihr erster Absatz beschreibt nicht klar, wer Sie sind, was Sie tun und wo.',
				'was_heisst_das' => 'KI-Dienste fassen Betriebe oft anhand des ersten Absatzes zusammen. Stehen Name, Leistung und Ort darin, wird die Zusammenfassung richtig.',
				'warum'          => 'Fragt jemand ChatGPT nach einem Betrieb wie Ihrem in {ort}, braucht die KI genau diese drei Angaben.',
				'so_beheben'     => array(
					'Schreiben Sie einen ersten Absatz nach dem Muster „[Firmenname] ist Ihr [Leistung] in {ort}. Wir …“.',
					'Halten Sie den Satz einfach und sachlich, ohne Werbefloskeln.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'seo',
			),
			'K06' => array(
				'titel'          => 'Lesbarkeit',
				'text_gut'       => 'Ihre Texte sind gut lesbar.',
				'text_schlecht'  => 'Ihre Texte sind schwer lesbar.',
				'was_heisst_das' => 'Wir berechnen den Lesbarkeitswert nach Flesch für deutsche Texte. Er sinkt mit langen Sätzen und langen Wörtern. Ab 50 gilt ein Text als gut lesbar.',
				'warum'          => 'Einfache Texte werden von Kunden schneller verstanden und von KI-Diensten treffender zusammengefasst.',
				'so_beheben'     => array(
					'Teilen Sie lange Sätze. Eine Aussage pro Satz.',
					'Ersetzen Sie Fachwörter durch Alltagssprache oder erklären Sie sie.',
					'Sprechen Sie Kunden direkt an: „Sie bekommen …“ statt „Der Kunde erhält …“.',
				),
				'aufwand'        => 'selbst',
				'leistung'       => 'seo',
			),
			'K07' => array(
				'titel'          => 'Inhalte ohne JavaScript lesbar',
				'text_gut'       => 'Ihre Inhalte stehen direkt im HTML.',
				'text_schlecht'  => 'Ihre Inhalte entstehen erst per JavaScript im Browser.',
				'was_heisst_das' => 'Manche Websites bauen ihren Text erst im Browser zusammen. Viele KI-Dienste und einfache Suchprogramme lesen aber nur, was der Server direkt ausliefert.',
				'warum'          => 'Was nicht im HTML steht, existiert für diese Programme nicht.',
				'so_beheben'     => array(
					'Sprechen Sie mit Ihrer Agentur über serverseitiges Rendern oder eine statische Vorabversion.',
					'Prüfen Sie im Browser mit „Seitenquelltext anzeigen“, ob Ihre Texte darin stehen.',
				),
				'aufwand'        => 'fachhilfe',
				'leistung'       => 'seo',
			),
		);
	}

	/**
	 * Platzhalter ersetzen.
	 *
	 * @param string $text Text.
	 * @param array  $ctx  ort.
	 * @return string
	 */
	public static function fill( $text, $ctx ) {
		$text = (string) $text;
		if ( isset( $ctx['ort'] ) && '' !== $ctx['ort'] ) {
			return str_replace( '{ort}', $ctx['ort'], $text );
		}
		// Ohne Ort: grammatisch passende Ersatzformen.
		$text = str_replace( array( 'in {ort}', 'um {ort}' ), array( 'in Ihrem Ort', 'um Ihren Ort' ), $text );
		return str_replace( '{ort}', 'Ihren Ort', $text );
	}
}
