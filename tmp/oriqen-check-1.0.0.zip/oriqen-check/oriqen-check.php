<?php
/**
 * Plugin Name:       oriqen Sichtbarkeits-Check
 * Plugin URI:        https://oriqen.de/
 * Description:       Selbstcheck für Besucher: prüft eine Website in sechs Säulen (Gefunden, Vor Ort, Schnell, Überzeugend, Rechtssicher, KI-bereit) und führt zur persönlichen Analyse durch oriqen. Shortcode: [oriqen_check]
 * Version:           1.0.0
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Author:            oriqen Digital Studio
 * Author URI:        https://oriqen.de/
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       oriqen-check
 *
 * @package oriqen-check
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'OQSC_VERSION', '1.0.0' );
define( 'OQSC_DB_VERSION', '1' );
define( 'OQSC_FILE', __FILE__ );
define( 'OQSC_DIR', plugin_dir_path( __FILE__ ) );
define( 'OQSC_URL', plugin_dir_url( __FILE__ ) );

/**
 * Autoload für alle Klassen mit Präfix OQSC_.
 *
 * OQSC_Admin_Rest wird zu includes/class-oqsc-admin-rest.php.
 */
spl_autoload_register(
	static function ( $class_name ) {
		if ( 0 !== strpos( $class_name, 'OQSC_' ) ) {
			return;
		}
		$file = OQSC_DIR . 'includes/class-' . strtolower( str_replace( '_', '-', $class_name ) ) . '.php';
		if ( is_readable( $file ) ) {
			require_once $file;
		}
	}
);

register_activation_hook( __FILE__, array( 'OQSC_Install', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'OQSC_Install', 'deactivate' ) );

add_action(
	'plugins_loaded',
	static function () {
		OQSC_Plugin::instance()->init();
	}
);
