/*!
 * oriqen Sichtbarkeits-Check, Frontend.
 * Vanilla JS, keine Bibliotheken, keine externen Dateien, keine Cookies.
 * Alle Texte von geprüften Websites werden ausschließlich per textContent gesetzt.
 */
(function () {
	'use strict';

	if (window.oqscLoaded) {
		return;
	}
	window.oqscLoaded = true;

	var SVGNS = 'http://www.w3.org/2000/svg';
	var Q_PATH = 'M542 590C543 589 546 575 547 565C547 562 548 554 549 548C551 535 551 535 540 532C501 520 482 501 474 464C471 448 471 414 471 213C471 68 470 19 469 18C468 16 387 16 386 18C385 19 385 28 385 38C385 49 384 59 384 60C383 64 379 63 372 56C343 32 320 21 285 13C266 9 233 9 212 13C165 22 137 36 105 68C78 95 62 128 54 168C52 183 51 227 53 240C57 256 61 271 65 280C66 284 68 288 69 290C69 291 72 296 74 301C101 351 150 388 207 397C210 397 217 399 220 399C231 401 274 401 286 399C321 393 350 379 374 356C379 352 381 351 383 352C385 354 385 357 386 402C386 449 387 455 390 470C397 505 421 542 448 560C470 574 493 583 525 589C540 592 540 592 542 590ZM241 334C240 334 235 333 230 332C198 325 167 300 151 267C139 243 135 227 136 202C137 172 145 146 163 123C172 111 192 95 207 89C210 87 214 85 217 84C234 77 270 75 292 81C326 90 356 115 371 144C385 173 389 205 381 240C373 277 348 307 311 325C295 332 285 334 262 335C251 335 242 335 241 334Z';
	var PILLARS = [
		{ key: 'gefunden', name: 'Gefunden' },
		{ key: 'vor_ort', name: 'Vor Ort' },
		{ key: 'schnell', name: 'Schnell' },
		{ key: 'ueberzeugend', name: 'Überzeugend' },
		{ key: 'rechtssicher', name: 'Rechtssicher' },
		{ key: 'ki', name: 'KI-bereit' }
	];
	var STATUS = {
		gut: { label: 'gut', icon: 'check' },
		verbesserbar: { label: 'verbesserbar', icon: 'warn' },
		kritisch: { label: 'kritisch', icon: 'cross' },
		hinweis: { label: 'Hinweis', icon: 'info' },
		nicht_pruefbar: { label: 'nicht prüfbar', icon: 'dash' }
	};
	var reducedMotion = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

	/* ------------------------------------------------------------------
	 * DOM-Hilfen (nur textContent, nie innerHTML)
	 * ---------------------------------------------------------------- */

	function el(tag, props, children) {
		var node = document.createElement(tag);
		props = props || {};
		Object.keys(props).forEach(function (k) {
			var v = props[k];
			if (v === null || v === undefined || v === false) {
				return;
			}
			if (k === 'text') {
				node.textContent = String(v);
			} else if (k === 'className') {
				node.className = v;
			} else if (k.indexOf('on') === 0 && typeof v === 'function') {
				node.addEventListener(k.slice(2), v);
			} else if (v === true) {
				node.setAttribute(k, '');
			} else {
				node.setAttribute(k, String(v));
			}
		});
		append(node, children);
		return node;
	}

	function append(node, children) {
		if (children === null || children === undefined) {
			return node;
		}
		if (!Array.isArray(children)) {
			children = [children];
		}
		children.forEach(function (c) {
			if (c === null || c === undefined || c === false) {
				return;
			}
			node.appendChild(typeof c === 'string' || typeof c === 'number' ? document.createTextNode(String(c)) : c);
		});
		return node;
	}

	function svg(tag, attrs, children) {
		var node = document.createElementNS(SVGNS, tag);
		Object.keys(attrs || {}).forEach(function (k) {
			node.setAttribute(k, String(attrs[k]));
		});
		(children || []).forEach(function (c) {
			node.appendChild(c);
		});
		return node;
	}

	function clear(node) {
		while (node.firstChild) {
			node.removeChild(node.firstChild);
		}
	}

	function qMark(size) {
		return svg('svg', { viewBox: '-36 -36 674 674', width: size, height: size, 'aria-hidden': 'true', focusable: 'false', class: 'oqsc-qmark' }, [
			svg('path', { d: Q_PATH, fill: 'currentColor', 'fill-rule': 'evenodd' })
		]);
	}

	function icon(name) {
		var paths = {
			check: 'M5 12.5l4.2 4.2L19 7',
			warn: 'M12 7v6M12 16.5v.5',
			cross: 'M7 7l10 10M17 7L7 17',
			info: 'M12 11v6M12 7.5v.5',
			dash: 'M7 12h10',
			copy: 'M9 9h10v10H9zM5 15V5h10',
			print: 'M7 9V4h10v5M7 17H5v-6h14v6h-2M8 14h8v6H8z',
			redo: 'M4 12a8 8 0 1 0 2.4-5.7M4 4v4h4',
			arrow: 'M5 12h14M13 6l6 6-6 6',
			phone: 'M6 3h4l2 5-2.5 1.5a11 11 0 0 0 5 5L16 12l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 4 5a2 2 0 0 1 2-2z'
		};
		return svg('svg', { viewBox: '0 0 24 24', width: 18, height: 18, 'aria-hidden': 'true', focusable: 'false', class: 'oqsc-ico' }, [
			svg('path', { d: paths[name] || paths.dash, fill: 'none', stroke: 'currentColor', 'stroke-width': 2, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' })
		]);
	}

	function statusBadge(status) {
		var s = STATUS[status] || STATUS.nicht_pruefbar;
		return el('span', { className: 'oqsc-badge oqsc-st-' + status }, [icon(s.icon), el('span', { text: s.label })]);
	}

	function germanDate(mysql) {
		if (!mysql) {
			return '';
		}
		var d = new Date(String(mysql).replace(' ', 'T') + 'Z');
		if (isNaN(d.getTime())) {
			return '';
		}
		return d.toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit', year: 'numeric' });
	}

	function germanTime(unix) {
		var d = new Date(unix * 1000);
		return d.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
	}

	function focusHeading(node) {
		if (!node) {
			return;
		}
		node.setAttribute('tabindex', '-1');
		try {
			node.focus({ preventScroll: true });
		} catch (e) {
			node.focus();
		}
	}

	function sleep(ms) {
		return new Promise(function (resolve) {
			setTimeout(resolve, ms);
		});
	}

	/* ------------------------------------------------------------------
	 * SHA-256 (synchron, für den Rechenbeweis)
	 * ---------------------------------------------------------------- */

	var K = [
		0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
		0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
		0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
		0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
		0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
		0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
		0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
		0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
	];
	var W = new Array(64);

	function sha256Words(ascii) {
		var bytes = [];
		var i;
		for (i = 0; i < ascii.length; i++) {
			bytes.push(ascii.charCodeAt(i) & 0xff);
		}
		var bitLen = bytes.length * 8;
		bytes.push(0x80);
		while ((bytes.length % 64) !== 56) {
			bytes.push(0);
		}
		for (i = 7; i >= 0; i--) {
			bytes.push(i > 3 ? 0 : (bitLen >>> (i * 8)) & 0xff);
		}
		var h0 = 0x6a09e667, h1 = 0xbb67ae85, h2 = 0x3c6ef372, h3 = 0xa54ff53a, h4 = 0x510e527f, h5 = 0x9b05688c, h6 = 0x1f83d9ab, h7 = 0x5be0cd19;
		for (var off = 0; off < bytes.length; off += 64) {
			for (i = 0; i < 16; i++) {
				W[i] = (bytes[off + i * 4] << 24) | (bytes[off + i * 4 + 1] << 16) | (bytes[off + i * 4 + 2] << 8) | bytes[off + i * 4 + 3];
			}
			for (i = 16; i < 64; i++) {
				var x = W[i - 15], y = W[i - 2];
				var s0 = ((x >>> 7) | (x << 25)) ^ ((x >>> 18) | (x << 14)) ^ (x >>> 3);
				var s1 = ((y >>> 17) | (y << 15)) ^ ((y >>> 19) | (y << 13)) ^ (y >>> 10);
				W[i] = (W[i - 16] + s0 + W[i - 7] + s1) | 0;
			}
			var a = h0, b = h1, c = h2, d = h3, e = h4, f = h5, g = h6, h = h7;
			for (i = 0; i < 64; i++) {
				var S1 = ((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7));
				var ch = (e & f) ^ (~e & g);
				var t1 = (h + S1 + ch + K[i] + W[i]) | 0;
				var S0 = ((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10));
				var maj = (a & b) ^ (a & c) ^ (b & c);
				var t2 = (S0 + maj) | 0;
				h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
			}
			h0 = (h0 + a) | 0; h1 = (h1 + b) | 0; h2 = (h2 + c) | 0; h3 = (h3 + d) | 0;
			h4 = (h4 + e) | 0; h5 = (h5 + f) | 0; h6 = (h6 + g) | 0; h7 = (h7 + h) | 0;
		}
		return [h0, h1, h2, h3, h4, h5, h6, h7];
	}

	function leadingZeroBits(words) {
		var bits = 0;
		for (var i = 0; i < words.length; i++) {
			var w = words[i] >>> 0;
			if (w === 0) {
				bits += 32;
				continue;
			}
			return bits + Math.clz32(w);
		}
		return bits;
	}

	/** Rechenbeweis in kleinen Häppchen lösen, damit die Seite bedienbar bleibt. */
	function solvePow(token, bits) {
		return new Promise(function (resolve) {
			var n = 0;
			function chunk() {
				var end = n + 4000;
				for (; n < end; n++) {
					if (leadingZeroBits(sha256Words(token + ':' + n)) >= bits) {
						resolve(String(n));
						return;
					}
				}
				setTimeout(chunk, 0);
			}
			chunk();
		});
	}

	/* ------------------------------------------------------------------
	 * REST
	 * ---------------------------------------------------------------- */

	function Api(cfg) {
		this.base = cfg.rest;
		this.nonce = cfg.nonce || '';
	}
	Api.prototype.call = function (method, path, body) {
		var headers = { Accept: 'application/json' };
		if (body) {
			headers['Content-Type'] = 'application/json';
		}
		if (this.nonce) {
			headers['X-WP-Nonce'] = this.nonce;
		}
		var url = this.base + path;
		return fetch(url, {
			method: method,
			headers: headers,
			body: body ? JSON.stringify(body) : undefined,
			credentials: 'same-origin',
			cache: 'no-store'
		}).then(function (res) {
			return res.text().then(function (txt) {
				var data = null;
				try {
					data = JSON.parse(txt);
				} catch (e) {
					data = null;
				}
				if (!data) {
					var err = new Error('Der Server hat unerwartet geantwortet. Bitte versuchen Sie es gleich noch einmal.');
					err.netz = true;
					throw err;
				}
				data._status = res.status;
				return data;
			});
		}, function () {
			var err = new Error('Keine Verbindung. Bitte prüfen Sie Ihre Internetverbindung.');
			err.netz = true;
			throw err;
		});
	};

	/** Holt ein Start-Token und löst den Rechenbeweis im Hintergrund. */
	function Ticket(api) {
		this.api = api;
		this.promise = null;
		this.refresh();
	}
	Ticket.prototype.refresh = function () {
		var api = this.api;
		var started = Date.now();
		this.info = null;
		this.promise = api.call('GET', 'token').then(function (t) {
			return solvePow(t.token, t.bits).then(function (pow) {
				var wait = (t.mindestzeit || 0) * 1000 + 250 - (Date.now() - started);
				return (wait > 0 ? sleep(wait) : Promise.resolve()).then(function () {
					return { token: t.token, pow: pow, verfuegbar: t.verfuegbar, meldung: t.meldung };
				});
			});
		});
		this.promise.catch(function () {});
		return this.promise;
	};
	Ticket.prototype.take = function () {
		var p = this.promise;
		var self = this;
		// Jedes Token gilt nur einmal: gleich das nächste vorbereiten.
		p.then(function () {
			self.refresh();
		}, function () {
			self.refresh();
		});
		return p;
	};

	/* ------------------------------------------------------------------
	 * Google-Vorschau: Abschneiden nach Pixelbreite
	 * ---------------------------------------------------------------- */

	var measureCtx = null;
	function textWidth(text, font) {
		if (!measureCtx) {
			measureCtx = document.createElement('canvas').getContext('2d');
		}
		if (!measureCtx) {
			return text.length * 8;
		}
		measureCtx.font = font;
		return measureCtx.measureText(text).width;
	}
	function truncatePx(text, font, maxPx) {
		text = String(text || '').replace(/\s+/g, ' ').trim();
		if (textWidth(text, font) <= maxPx) {
			return text;
		}
		var lo = 0;
		var hi = text.length;
		while (lo < hi) {
			var mid = (lo + hi + 1) >> 1;
			if (textWidth(text.slice(0, mid) + ' …', font) <= maxPx) {
				lo = mid;
			} else {
				hi = mid - 1;
			}
		}
		var cut = text.slice(0, lo);
		var space = cut.lastIndexOf(' ');
		if (space > lo * 0.6) {
			cut = cut.slice(0, space);
		}
		return cut.replace(/[\s,.;:|·\-–]+$/, '') + ' …';
	}

	/* ------------------------------------------------------------------
	 * App
	 * ---------------------------------------------------------------- */

	function App(root, cfg) {
		this.root = root;
		this.cfg = cfg;
		this.api = new Api(cfg);
		this.variant = cfg.variante === 'kompakt' ? 'kompakt' : 'voll';
		this.result = null;
		this.jobToken = '';
		root.classList.add('oqsc-ready');
		clear(root);
		if (this.variant === 'kompakt') {
			this.renderCompact();
			return;
		}
		this.ticket = new Ticket(this.api);
		this.live = el('div', { className: 'oqsc-sr', 'aria-live': 'polite', 'aria-atomic': 'true' });
		this.stage = el('div', { className: 'oqsc-stage' });
		append(root, [this.stage, this.live]);
		var params = new URLSearchParams(window.location.search);
		var token = params.get('oqcheck');
		if (token && /^[a-f0-9]{32}$/.test(token)) {
			this.loadResult(token, true);
		} else {
			this.renderStart({ url: params.get('oqurl') || '', ort: params.get('oqort') || '', branche: params.get('oqbranche') || '' });
		}
	}

	App.prototype.announce = function (text) {
		var live = this.live;
		live.textContent = '';
		setTimeout(function () {
			live.textContent = text;
		}, 60);
	};

	App.prototype.setUrlToken = function (token) {
		try {
			var url = new URL(window.location.href);
			if (token) {
				url.searchParams.set('oqcheck', token);
			} else {
				url.searchParams.delete('oqcheck');
			}
			['oqurl', 'oqort', 'oqbranche'].forEach(function (k) {
				url.searchParams.delete(k);
			});
			window.history.replaceState(null, '', url.toString());
		} catch (e) {
			/* Ohne History-API bleibt die Adresse, das Ergebnis funktioniert trotzdem. */
		}
	};

	App.prototype.view = function (cls) {
		clear(this.stage);
		this.stage.className = 'oqsc-stage ' + cls;
		return this.stage;
	};

	/* ---------- Kompakt ---------- */

	App.prototype.renderCompact = function () {
		var cfg = this.cfg;
		var id = 'oqsc-k-' + Math.random().toString(36).slice(2, 8);
		var input = el('input', { id: id, type: 'text', inputmode: 'url', autocomplete: 'url', placeholder: 'ihre-firma.de', required: true, className: 'oqsc-input', 'aria-describedby': id + '-h' });
		var form = el('form', { className: 'oqsc-compact', novalidate: true }, [
			el('div', { className: 'oqsc-compact-q' }, qMark(28)),
			el('div', { className: 'oqsc-compact-main' }, [
				el('label', { for: id, className: 'oqsc-compact-label', text: 'Wie sichtbar ist Ihre Website?' }),
				el('div', { className: 'oqsc-compact-row' }, [
					input,
					el('button', { type: 'submit', className: 'oqsc-btn oqsc-btn-primary' }, [el('span', { text: 'Jetzt prüfen' }), icon('arrow')])
				]),
				el('p', { id: id + '-h', className: 'oqsc-compact-hint', text: 'Kostenlos, in rund einer Minute, ohne Anmeldung.' })
			])
		]);
		form.addEventListener('submit', function (e) {
			e.preventDefault();
			var v = input.value.trim();
			if (!v || v.indexOf('.') < 0) {
				input.setAttribute('aria-invalid', 'true');
				input.focus();
				return;
			}
			var target = cfg.ziel || window.location.href;
			try {
				var u = new URL(target, window.location.href);
				u.searchParams.set('oqurl', v);
				window.location.href = u.toString();
			} catch (err) {
				window.location.href = target + (target.indexOf('?') < 0 ? '?' : '&') + 'oqurl=' + encodeURIComponent(v);
			}
		});
		append(this.root, form);
	};

	/* ---------- Start ---------- */

	App.prototype.renderStart = function (prefill, message) {
		var self = this;
		var cfg = this.cfg;
		var stage = this.view('oqsc-view-start');
		var h = el('h2', { className: 'oqsc-title', text: cfg.ueberschrift || 'Wie sichtbar ist Ihre Website?' });
		var urlIn = el('input', { id: 'oqsc-url', name: 'url', type: 'text', inputmode: 'url', autocomplete: 'url', placeholder: 'ihre-firma.de', required: true, className: 'oqsc-input oqsc-input-big', value: prefill.url || '', 'aria-describedby': 'oqsc-url-h' });
		var ortIn = el('input', { id: 'oqsc-ort', name: 'ort', type: 'text', autocomplete: 'address-level2', placeholder: 'zum Beispiel Paderborn', maxlength: 60, className: 'oqsc-input', value: prefill.ort || '' });
		var sel = el('select', { id: 'oqsc-branche', name: 'branche', className: 'oqsc-input' }, [el('option', { value: '', text: 'Bitte wählen (optional)' })]);
		Object.keys(cfg.branchen || {}).forEach(function (k) {
			append(sel, el('option', { value: k, text: cfg.branchen[k], selected: prefill.branche === k }));
		});
		var hp = el('div', { className: 'oqsc-hp', 'aria-hidden': 'true' }, [
			el('label', { for: 'oqsc-website', text: 'Bitte leer lassen' }),
			el('input', { id: 'oqsc-website', name: 'website', type: 'text', tabindex: '-1', autocomplete: 'off' })
		]);
		var msg = el('div', { className: 'oqsc-msg', role: 'alert' });
		var btn = el('button', { type: 'submit', className: 'oqsc-btn oqsc-btn-primary oqsc-btn-big' }, [el('span', { text: 'Jetzt prüfen' }), icon('arrow')]);
		var privacy = el('p', { className: 'oqsc-privacy' }, [
			'Wir prüfen nur öffentlich sichtbare Inhalte Ihrer Startseite und einiger Unterseiten. Wir setzen keine Cookies und speichern Ihre IP-Adresse nicht. ',
			cfg.datenschutz ? el('a', { href: cfg.datenschutz, text: 'Mehr in der Datenschutzerklärung.' }) : null
		]);
		var form = el('form', { className: 'oqsc-form', novalidate: true }, [
			el('div', { className: 'oqsc-field oqsc-field-url' }, [
				el('label', { for: 'oqsc-url', text: 'Ihre Website' }),
				urlIn,
				el('span', { id: 'oqsc-url-h', className: 'oqsc-help', text: 'Die Adresse Ihrer Startseite, zum Beispiel ihre-firma.de' })
			]),
			el('div', { className: 'oqsc-row' }, [
				el('div', { className: 'oqsc-field' }, [el('label', { for: 'oqsc-ort', text: 'Ihr Ort (optional)' }), ortIn]),
				el('div', { className: 'oqsc-field' }, [el('label', { for: 'oqsc-branche', text: 'Ihre Branche (optional)' }), sel])
			]),
			hp,
			msg,
			btn,
			privacy
		]);
		var pills = el('ul', { className: 'oqsc-pills', 'aria-label': 'Die sechs Säulen des Checks' });
		PILLARS.forEach(function (p) {
			append(pills, el('li', { text: p.name }));
		});
		append(stage, [
			el('div', { className: 'oqsc-start-head' }, [
				el('div', { className: 'oqsc-orb oqsc-orb-small', 'aria-hidden': 'true' }, qMark(34)),
				el('p', { className: 'oqsc-eyebrow' }, [el('span', { className: 'oqsc-brand', text: 'oriqen' }), ' Sichtbarkeits-Check']),
				h,
				el('p', { className: 'oqsc-lead', text: cfg.einleitung || '' }),
				pills
			]),
			form
		]);
		if (message) {
			msg.textContent = message;
		}
		form.addEventListener('submit', function (e) {
			e.preventDefault();
			var url = urlIn.value.trim();
			msg.textContent = '';
			urlIn.removeAttribute('aria-invalid');
			if (!url || url.indexOf('.') < 0 || /\s/.test(url)) {
				urlIn.setAttribute('aria-invalid', 'true');
				msg.textContent = 'Bitte geben Sie die Adresse Ihrer Website ein, zum Beispiel ihre-firma.de.';
				urlIn.focus();
				return;
			}
			btn.disabled = true;
			btn.classList.add('is-busy');
			btn.firstChild.textContent = 'Wird vorbereitet …';
			self.start({ url: url, ort: ortIn.value.trim(), branche: sel.value, website: hp.querySelector('input').value }).then(null, function (err) {
				btn.disabled = false;
				btn.classList.remove('is-busy');
				btn.firstChild.textContent = 'Jetzt prüfen';
				msg.textContent = err.message;
			});
		});
		if (this.hasRendered) {
			focusHeading(h);
		}
		this.hasRendered = true;
	};

	App.prototype.start = function (input) {
		var self = this;
		return this.ticket.take().then(function (t) {
			if (t.verfuegbar === false) {
				throw new Error(t.meldung || 'Der Check ist gerade nicht verfügbar.');
			}
			return self.api.call('POST', 'start', {
				url: input.url,
				ort: input.ort,
				branche: input.branche,
				token: t.token,
				pow: t.pow,
				website: input.website || ''
			});
		}).then(function (res) {
			if (res.fehler) {
				throw new Error(res.meldung || 'Der Check konnte nicht starten.');
			}
			self.setUrlToken(res.job);
			if (res.fertig) {
				self.fromCache = !!res.gespeichert;
				return self.loadResult(res.job, false);
			}
			self.runScan(res.job, res.schritte, res.domain || input.url, 0, res.warten ? res : null);
		});
	};

	/* ---------- Scan ---------- */

	App.prototype.buildOrbit = function () {
		var size = 280;
		var c = size / 2;
		var radii = [62, 76, 90, 104, 118, 132];
		var orbit = svg('svg', { viewBox: '0 0 ' + size + ' ' + size, class: 'oqsc-orbit-svg', 'aria-hidden': 'true', focusable: 'false' });
		var defs = svg('defs', {}, [
			svg('radialGradient', { id: 'oqsc-glow', cx: '50%', cy: '45%', r: '55%' }, [
				svg('stop', { offset: '0%', 'stop-color': '#B98BFF' }),
				svg('stop', { offset: '55%', 'stop-color': '#6600CC' }),
				svg('stop', { offset: '100%', 'stop-color': '#2A0055' })
			])
		]);
		orbit.appendChild(defs);
		var arcs = [];
		radii.forEach(function (r, i) {
			var len = 2 * Math.PI * r;
			orbit.appendChild(svg('circle', { cx: c, cy: c, r: r, class: 'oqsc-orbit-track' }));
			var arc = svg('circle', { cx: c, cy: c, r: r, class: 'oqsc-orbit-arc', 'stroke-dasharray': len.toFixed(1), 'stroke-dashoffset': len.toFixed(1), transform: 'rotate(-90 ' + c + ' ' + c + ')' });
			orbit.appendChild(arc);
			var g = svg('g', { class: 'oqsc-orbit-dot oqsc-orbit-dot-' + i, style: 'transform-origin:' + c + 'px ' + c + 'px' }, [
				svg('circle', { cx: c + r, cy: c, r: 4.2, class: 'oqsc-dot' })
			]);
			orbit.appendChild(g);
			arcs.push({ node: arc, len: len });
		});
		orbit.appendChild(svg('circle', { cx: c, cy: c, r: 44, fill: 'url(#oqsc-glow)', class: 'oqsc-core' }));
		var q = svg('svg', { x: c - 22, y: c - 22, width: 44, height: 44, viewBox: '-36 -36 674 674' }, [svg('path', { d: Q_PATH, fill: '#ffffff', 'fill-rule': 'evenodd' })]);
		orbit.appendChild(q);
		return { node: orbit, arcs: arcs };
	};

	App.prototype.runScan = function (job, steps, domain, startAt, waiting) {
		var self = this;
		this.jobToken = job;
		steps = steps && steps.length ? steps : [
			{ nr: 1, titel: 'Erreichbarkeit und Verschlüsselung' }, { nr: 2, titel: 'Startseite lesen' },
			{ nr: 3, titel: 'Rechtliche Seiten, robots.txt, Sitemap, llms.txt' }, { nr: 4, titel: 'Bilder und Links stichprobenartig' },
			{ nr: 5, titel: 'Ladezeit und Handyansicht (PageSpeed)' }, { nr: 6, titel: 'Auswertung' }
		];
		var stage = this.view('oqsc-view-scan');
		var orbit = this.buildOrbit();
		var h = el('h2', { className: 'oqsc-title', text: 'Wir prüfen ' + domain });
		var status = el('p', { className: 'oqsc-scan-status', text: 'Gleich geht es los …' });
		var list = el('ol', { className: 'oqsc-steps' });
		var items = steps.map(function (s) {
			var li = el('li', { className: 'oqsc-step is-pending' }, [
				el('span', { className: 'oqsc-step-icon', 'aria-hidden': 'true' }),
				el('span', { className: 'oqsc-step-body' }, [
					el('span', { className: 'oqsc-step-title', text: s.titel }),
					el('span', { className: 'oqsc-step-note' })
				])
			]);
			list.appendChild(li);
			return li;
		});
		var bar = el('div', { className: 'oqsc-progress', role: 'progressbar', 'aria-valuemin': '0', 'aria-valuemax': '6', 'aria-valuenow': String(startAt || 0), 'aria-label': 'Fortschritt des Checks' }, el('span'));
		append(stage, [
			el('div', { className: 'oqsc-scan-visual' }, [orbit.node]),
			el('div', { className: 'oqsc-scan-side' }, [h, status, bar, list, el('p', { className: 'oqsc-scan-hint', text: 'Das dauert meist 30 bis 60 Sekunden. Sie können die Seite offen lassen und nebenbei weiterlesen.' })])
		]);
		focusHeading(h);
		this.announce('Der Check für ' + domain + ' startet.');

		function setStep(n, note) {
			items.forEach(function (li, i) {
				li.className = 'oqsc-step ' + (i < n ? 'is-done' : (i === n ? 'is-active' : 'is-pending'));
			});
			if (n > 0 && note !== undefined && items[n - 1]) {
				items[n - 1].querySelector('.oqsc-step-note').textContent = note || '';
			}
			orbit.arcs.forEach(function (a, i) {
				a.node.setAttribute('stroke-dashoffset', (i < n ? 0 : a.len).toFixed(1));
			});
			bar.setAttribute('aria-valuenow', String(n));
			bar.firstChild.style.width = Math.round(100 * n / 6) + '%';
			if (items[n]) {
				status.textContent = 'Schritt ' + (n + 1) + ' von 6: ' + steps[n].titel;
			}
		}
		setStep(startAt || 0);

		var failures = 0;
		function next() {
			return self.api.call('POST', 'step', { job: job }).then(function (res) {
				failures = 0;
				if (res.fehler && !res.schritt) {
					throw new Error(res.meldung || 'Der Check konnte nicht fortgesetzt werden.');
				}
				if (res.warten) {
					if (res.position) {
						status.textContent = 'Kurz warten, Sie sind an Position ' + res.position + '. Gerade prüfen mehrere Besucher gleichzeitig.';
						self.announce(status.textContent);
					}
					return sleep(res.warten * 1000).then(next);
				}
				if (res.fehler) {
					setStep(res.schritt - 1);
					var e = new Error(res.meldung);
					e.endgueltig = true;
					throw e;
				}
				setStep(res.schritt, res.kurzbefund);
				self.announce('Schritt ' + res.schritt + ' erledigt: ' + res.titel + '. ' + (res.kurzbefund || ''));
				if (res.fertig) {
					status.textContent = 'Fertig. Ihr Ergebnis wird angezeigt.';
					return sleep(reducedMotion ? 0 : 700).then(function () {
						return self.loadResult(res.token || job, false);
					});
				}
				return next();
			}, function (err) {
				if (err.netz && failures < 3) {
					failures++;
					status.textContent = 'Verbindung kurz unterbrochen, wir versuchen es erneut …';
					return sleep(2000 * failures).then(next);
				}
				throw err;
			});
		}
		var begin = waiting ? sleep((waiting.warten || 10) * 1000) : Promise.resolve();
		if (waiting && waiting.position) {
			status.textContent = 'Kurz warten, Sie sind an Position ' + waiting.position + '. Gerade prüfen mehrere Besucher gleichzeitig.';
		}
		begin.then(next).then(null, function (err) {
			self.renderError(err.message, domain);
		});
	};

	/* ---------- Fehler ---------- */

	App.prototype.renderError = function (message, domain) {
		var self = this;
		var cfg = this.cfg;
		var stage = this.view('oqsc-view-error');
		var h = el('h2', { className: 'oqsc-title', text: 'Das hat leider nicht geklappt' });
		append(stage, [
			el('div', { className: 'oqsc-orb oqsc-orb-small', 'aria-hidden': 'true' }, qMark(34)),
			h,
			el('p', { className: 'oqsc-lead', text: message || 'Der Check konnte nicht abgeschlossen werden.' }),
			el('div', { className: 'oqsc-actions' }, [
				el('button', {
					type: 'button', className: 'oqsc-btn oqsc-btn-primary', onclick: function () {
						self.setUrlToken('');
						self.renderStart({ url: domain || '' });
					}
				}, [icon('redo'), el('span', { text: 'Neue Prüfung starten' })]),
				cfg.analyseUrl ? el('a', { className: 'oqsc-btn oqsc-btn-ghost', href: cfg.analyseUrl }, [el('span', { text: 'Persönliche Analyse anfragen' }), icon('arrow')]) : null
			])
		]);
		this.announce(message || 'Fehler');
		focusHeading(h);
	};

	/* ---------- Ergebnis laden ---------- */

	App.prototype.loadResult = function (token, resume) {
		var self = this;
		if (resume) {
			var stage = this.view('oqsc-view-loading');
			append(stage, [el('div', { className: 'oqsc-orb oqsc-orb-pulse', 'aria-hidden': 'true' }, qMark(40)), el('p', { className: 'oqsc-lead', text: 'Ergebnis wird geladen …' })]);
		}
		return this.api.call('GET', 'result/' + token).then(function (res) {
			if (res.status === 'wartet' || res.status === 'laeuft') {
				self.runScan(res.job || token, res.schritte, res.domain, res.schritt || 0, null);
				return;
			}
			if (res.fehler) {
				self.renderError(res.meldung, res.domain);
				return;
			}
			self.result = res;
			self.jobToken = token;
			self.renderResult(res);
		}, function (err) {
			self.renderError(err.message);
		});
	};

	/* ---------- Ergebnis ---------- */

	App.prototype.renderResult = function (r) {
		var self = this;
		var cfg = this.cfg;
		var stage = this.view('oqsc-view-result');
		var byPillar = {};
		PILLARS.forEach(function (p) {
			byPillar[p.key] = [];
		});
		(r.pruefungen || []).forEach(function (p) {
			if (byPillar[p.saeule]) {
				byPillar[p.saeule].push(p);
			}
		});

		// Druckkopf (nur in der Druckansicht sichtbar).
		append(stage, el('div', { className: 'oqsc-print-head' }, [
			cfg.logo ? el('img', { src: cfg.logo, alt: 'oriqen', width: 140, height: 51 }) : null,
			el('span', { text: 'Sichtbarkeits-Check' })
		]));

		// Kopf mit Index-Ring.
		var ringSize = 168;
		var rr = 70;
		var circ = 2 * Math.PI * rr;
		var ringArc = svg('circle', { cx: ringSize / 2, cy: ringSize / 2, r: rr, class: 'oqsc-ring-arc oqsc-ring-' + bandClass(r.index), 'stroke-dasharray': circ.toFixed(1), 'stroke-dashoffset': circ.toFixed(1), transform: 'rotate(-90 ' + ringSize / 2 + ' ' + ringSize / 2 + ')' });
		var ring = svg('svg', { viewBox: '0 0 ' + ringSize + ' ' + ringSize, class: 'oqsc-ring', 'aria-hidden': 'true', focusable: 'false' }, [
			svg('circle', { cx: ringSize / 2, cy: ringSize / 2, r: rr, class: 'oqsc-ring-track' }),
			ringArc
		]);
		var num = el('span', { className: 'oqsc-index-num', text: '0' });
		var h = el('h2', { className: 'oqsc-title oqsc-result-title' }, [el('span', { className: 'oqsc-sr', text: 'Ergebnis für ' }), document.createTextNode(r.domain || '')]);
		var meta = [];
		meta.push('Geprüft am ' + germanDate(r.datum));
		if (r.ort) {
			meta.push('Ort: ' + r.ort);
		}
		if (r.branche && cfg.branchen && cfg.branchen[r.branche]) {
			meta.push('Branche: ' + cfg.branchen[r.branche]);
		}
		var head = el('section', { className: 'oqsc-result-head oqsc-fade', 'aria-labelledby': 'oqsc-res-h' }, [
			el('div', { className: 'oqsc-ring-wrap', role: 'img', 'aria-label': 'Sichtbarkeits-Index ' + r.index + ' von 100' }, [ring, el('div', { className: 'oqsc-ring-center' }, [num, el('span', { className: 'oqsc-index-of', text: 'von 100' })])]),
			el('div', { className: 'oqsc-result-summary' }, [
				el('p', { className: 'oqsc-eyebrow' }, [el('span', { className: 'oqsc-brand', text: 'oriqen' }), ' Sichtbarkeits-Index']),
				h,
				el('p', { className: 'oqsc-verdict-label oqsc-band-' + bandClass(r.index), text: (r.einordnung && r.einordnung.label) || '' }),
				el('p', { className: 'oqsc-verdict', text: (r.einordnung && r.einordnung.satz) || '' }),
				el('p', { className: 'oqsc-meta', text: meta.join(' · ') }),
				this.fromCache ? el('p', { className: 'oqsc-note', text: 'Diese Website wurde in den letzten 24 Stunden schon geprüft. Sie sehen das gespeicherte Ergebnis.' }) : null,
				r.pagespeed && !r.pagespeed.ok ? el('p', { className: 'oqsc-note', text: 'Die Ladezeit-Messung von Google war diesmal nicht möglich. Die Säule „Schnell“ beruht deshalb nur auf unseren eigenen Messungen.' }) : null
			])
		]);
		h.id = 'oqsc-res-h';
		stage.appendChild(head);

		// Säulen.
		var pillarGrid = el('div', { className: 'oqsc-pillars' });
		(r.saeulen || []).forEach(function (s, i) {
			var v = s.wert;
			var cls = v === null ? 'na' : bandClass(v);
			pillarGrid.appendChild(el('a', { className: 'oqsc-pillar oqsc-fade oqsc-band-' + cls, href: '#oqsc-p-' + s.key, style: 'animation-delay:' + (reducedMotion ? 0 : 80 * i) + 'ms' }, [
				el('span', { className: 'oqsc-pillar-name', text: s.name }),
				el('span', { className: 'oqsc-pillar-value' }, [el('strong', { text: v === null ? '–' : String(v) }), el('span', { text: v === null ? ' nicht prüfbar' : ' / 100' })]),
				el('span', { className: 'oqsc-pillar-bar', 'aria-hidden': 'true' }, el('span', { style: 'width:' + (v === null ? 0 : v) + '%' })),
				el('span', { className: 'oqsc-pillar-text', text: s.satz })
			]));
		});
		stage.appendChild(el('section', { className: 'oqsc-section', 'aria-label': 'Die sechs Säulen' }, pillarGrid));

		// Hebel.
		if (r.hebel && r.hebel.length) {
			var levers = el('ol', { className: 'oqsc-levers' });
			r.hebel.forEach(function (lv, i) {
				var todo = el('ul', { className: 'oqsc-todo' });
				(lv.was_tun || []).forEach(function (t) {
					todo.appendChild(el('li', { text: t }));
				});
				levers.appendChild(el('li', { className: 'oqsc-lever oqsc-fade', style: 'animation-delay:' + (reducedMotion ? 0 : 120 * i) + 'ms' }, [
					el('span', { className: 'oqsc-lever-nr', 'aria-hidden': 'true', text: String(i + 1) }),
					el('div', { className: 'oqsc-lever-body' }, [
						el('h4', { text: lv.titel }),
						el('p', { className: 'oqsc-lever-meta' }, [
							el('span', { className: 'oqsc-chip', text: lv.saeule_name }),
							el('span', { className: 'oqsc-chip oqsc-chip-' + lv.wirkung, text: 'Wirkung ' + lv.wirkung }),
							el('span', { className: 'oqsc-chip oqsc-chip-aufwand', text: lv.aufwand === 'selbst' ? 'selbst machbar' : 'mit Fachhilfe' })
						]),
						el('p', { text: lv.befund }),
						el('p', { className: 'oqsc-todo-label', text: 'Was tun:' }),
						todo
					])
				]));
			});
			stage.appendChild(el('section', { className: 'oqsc-section' }, [el('h3', { className: 'oqsc-h3', text: 'Ihre drei wichtigsten Hebel' }), levers]));
		}

		// So sieht Google Sie / So sieht Ihr Kunde Sie.
		stage.appendChild(el('section', { className: 'oqsc-section oqsc-views' }, [
			this.renderSerp(r),
			this.renderPhone(r)
		]));

		// Alle Prüfungen.
		var onlyIssues = false;
		var toggle = el('button', { type: 'button', className: 'oqsc-btn oqsc-btn-small oqsc-btn-ghost', 'aria-pressed': 'false', text: 'Nur Punkte mit Handlungsbedarf zeigen' });
		var allWrap = el('div', { className: 'oqsc-checks' });
		(r.saeulen || []).forEach(function (s) {
			var group = el('section', { className: 'oqsc-check-group', id: 'oqsc-p-' + s.key, 'aria-labelledby': 'oqsc-ph-' + s.key }, [
				el('h4', { id: 'oqsc-ph-' + s.key, className: 'oqsc-group-title' }, [el('span', { text: s.name }), el('span', { className: 'oqsc-group-value', text: s.wert === null ? 'nicht prüfbar' : s.wert + ' / 100' })]),
				el('p', { className: 'oqsc-group-question', text: s.frage })
			]);
			byPillar[s.key].forEach(function (p) {
				group.appendChild(self.renderCheck(p));
			});
			allWrap.appendChild(group);
		});
		toggle.addEventListener('click', function () {
			onlyIssues = !onlyIssues;
			toggle.setAttribute('aria-pressed', onlyIssues ? 'true' : 'false');
			allWrap.classList.toggle('is-filtered', onlyIssues);
		});
		stage.appendChild(el('section', { className: 'oqsc-section' }, [
			el('div', { className: 'oqsc-section-head' }, [el('h3', { className: 'oqsc-h3', text: 'Alle Prüfungen im Detail' }), toggle]),
			el('p', { className: 'oqsc-legend' }, [statusBadge('gut'), statusBadge('verbesserbar'), statusBadge('kritisch'), statusBadge('hinweis'), statusBadge('nicht_pruefbar')]),
			allWrap,
			el('p', { className: 'oqsc-disclaimer', text: 'Alle Angaben zu rechtlichen Themen sind Hinweise aus einer automatischen Prüfung und keine Rechtsberatung. Lassen Sie rechtliche Fragen von einer Fachstelle prüfen.' })
		]));

		// Was ein Werkzeug nicht sieht.
		var cta = el('button', { type: 'button', className: 'oqsc-btn oqsc-btn-primary' }, [el('span', { text: 'Persönliche Analyse anfordern' }), icon('arrow')]);
		stage.appendChild(el('section', { className: 'oqsc-section oqsc-human' }, [
			el('div', { className: 'oqsc-orb oqsc-orb-small', 'aria-hidden': 'true' }, qMark(30)),
			el('h3', { className: 'oqsc-h3', text: 'Was ein Werkzeug nicht sieht' }),
			el('p', { text: cfg.abschluss || '' }),
			el('ul', { className: 'oqsc-human-list' }, [
				el('li', { text: 'Ihre Texte: Sprechen sie Ihre Kunden an und überzeugen sie?' }),
				el('li', { text: 'Ihr Angebot: Ist auf einen Blick klar, warum man Sie wählen sollte?' }),
				el('li', { text: 'Ihr Wettbewerb: Wie stehen Sie im Vergleich zu den Betrieben in Ihrer Region da?' }),
				el('li', { text: 'Ihre Bilder: Zeigen sie Ihre echte Arbeit und wirken sie professionell?' })
			]),
			cta
		]));

		// Aktionen.
		var copyBtn = el('button', { type: 'button', className: 'oqsc-btn oqsc-btn-ghost' }, [icon('copy'), el('span', { text: 'Ergebnis-Link kopieren' })]);
		var printBtn = el('button', { type: 'button', className: 'oqsc-btn oqsc-btn-ghost' }, [icon('print'), el('span', { text: 'Druckansicht' })]);
		var now = Math.floor(Date.now() / 1000);
		var recheckLabel = r.erneut_ab && r.erneut_ab > now ? 'Erneut prüfen ab ' + germanTime(r.erneut_ab) + ' Uhr' : 'Erneut prüfen';
		var recheckBtn = el('button', { type: 'button', className: 'oqsc-btn oqsc-btn-ghost', disabled: !!(r.erneut_ab && r.erneut_ab > now) }, [icon('redo'), el('span', { text: recheckLabel })]);
		var newBtn = el('button', { type: 'button', className: 'oqsc-btn oqsc-btn-ghost' }, [icon('arrow'), el('span', { text: 'Andere Website prüfen' })]);
		var actionMsg = el('p', { className: 'oqsc-msg', role: 'status' });
		stage.appendChild(el('section', { className: 'oqsc-section oqsc-actions-wrap', 'aria-label': 'Aktionen' }, [
			el('div', { className: 'oqsc-actions' }, [copyBtn, printBtn, recheckBtn, newBtn]),
			actionMsg,
			el('p', { className: 'oqsc-meta', text: 'Ihr Ergebnis-Link ist 30 Tage gültig.' })
		]));

		// Anfrage.
		var leadSection = this.renderLead(r);
		stage.appendChild(leadSection);

		// Druckfuß.
		append(stage, el('div', { className: 'oqsc-print-foot', text: (cfg.kontakt || 'oriqen') + ' · Ergebnis vom ' + germanDate(r.datum) + ' · Hinweise ohne Gewähr, keine Rechtsberatung.' }));

		cta.addEventListener('click', function () {
			leadSection.scrollIntoView({ behavior: reducedMotion ? 'auto' : 'smooth', block: 'start' });
			var first = leadSection.querySelector('input:not([type=hidden]):not([tabindex="-1"])');
			if (first) {
				setTimeout(function () {
					first.focus();
				}, reducedMotion ? 0 : 400);
			}
		});
		copyBtn.addEventListener('click', function () {
			var link = window.location.href;
			var done = function () {
				actionMsg.textContent = 'Link kopiert. Sie können ihn jetzt einfügen und teilen.';
			};
			if (navigator.clipboard && navigator.clipboard.writeText) {
				navigator.clipboard.writeText(link).then(done, function () {
					window.prompt('Link zum Kopieren:', link);
				});
			} else {
				window.prompt('Link zum Kopieren:', link);
			}
		});
		printBtn.addEventListener('click', function () {
			preparePrint();
			window.print();
			setTimeout(cleanupPrint, 1000);
		});
		newBtn.addEventListener('click', function () {
			self.setUrlToken('');
			self.fromCache = false;
			self.renderStart({});
			window.scrollTo({ top: self.root.getBoundingClientRect().top + window.pageYOffset - 20, behavior: reducedMotion ? 'auto' : 'smooth' });
		});
		recheckBtn.addEventListener('click', function () {
			recheckBtn.disabled = true;
			actionMsg.textContent = 'Neue Prüfung wird vorbereitet …';
			self.ticket.take().then(function (t) {
				return self.api.call('POST', 'recheck', { check: self.jobToken, token: t.token, pow: t.pow, website: '' });
			}).then(function (res) {
				if (res.fehler) {
					throw new Error(res.meldung);
				}
				self.fromCache = false;
				self.setUrlToken(res.job);
				self.runScan(res.job, res.schritte, res.domain || r.domain, 0, res.warten ? res : null);
			}).then(null, function (err) {
				actionMsg.textContent = err.message;
			});
		});

		this.animateIndex(num, ringArc, circ, r.index);
		this.announce('Ergebnis: Sichtbarkeits-Index ' + r.index + ' von 100. ' + ((r.einordnung && r.einordnung.label) || ''));
		focusHeading(h);
		var top = this.root.getBoundingClientRect().top + window.pageYOffset - 20;
		if (window.pageYOffset > top) {
			window.scrollTo({ top: top, behavior: reducedMotion ? 'auto' : 'smooth' });
		}
	};

	function bandClass(v) {
		if (v >= 85) {
			return 'gut';
		}
		if (v >= 70) {
			return 'solide';
		}
		if (v >= 50) {
			return 'mittel';
		}
		return 'schwach';
	}

	App.prototype.animateIndex = function (num, arc, circ, value) {
		value = Math.max(0, Math.min(100, value || 0));
		var target = circ * (1 - value / 100);
		if (reducedMotion) {
			num.textContent = String(value);
			arc.setAttribute('stroke-dashoffset', target.toFixed(1));
			return;
		}
		var start = null;
		var dur = 1400;
		function frame(ts) {
			if (!start) {
				start = ts;
			}
			var p = Math.min(1, (ts - start) / dur);
			var e = 1 - Math.pow(1 - p, 3);
			num.textContent = String(Math.round(value * e));
			arc.setAttribute('stroke-dashoffset', (circ - (circ - target) * e).toFixed(1));
			if (p < 1) {
				window.requestAnimationFrame(frame);
			}
		}
		window.requestAnimationFrame(frame);
	};

	App.prototype.renderCheck = function (p) {
		var good = p.status === 'gut';
		var issue = p.status === 'verbesserbar' || p.status === 'kritisch' || p.status === 'hinweis';
		var body = el('div', { className: 'oqsc-check-body' }, [
			el('p', { className: 'oqsc-check-text', text: p.text }),
			el('div', { className: 'oqsc-check-cols' }, [
				el('div', {}, [el('h5', { text: 'Was heißt das?' }), el('p', { text: p.was_heisst_das })]),
				el('div', {}, [el('h5', { text: 'Warum ist das wichtig?' }), el('p', { text: p.warum })])
			])
		]);
		if (!good && p.status !== 'nicht_pruefbar') {
			var ol = el('ol', { className: 'oqsc-fix' });
			(p.so_beheben || []).forEach(function (t) {
				ol.appendChild(el('li', { text: t }));
			});
			append(body, [
				el('h5', { text: 'So beheben Sie es' }),
				ol,
				el('p', { className: 'oqsc-check-aufwand' }, [el('span', { className: 'oqsc-chip oqsc-chip-aufwand', text: p.aufwand === 'selbst' ? 'selbst machbar' : 'mit Fachhilfe' })])
			]);
		}
		if (p.branchentipp) {
			append(body, el('p', { className: 'oqsc-tip' }, [el('strong', { text: 'Tipp für Ihre Branche: ' }), document.createTextNode(p.branchentipp)]));
		}
		return el('details', { className: 'oqsc-check oqsc-check-' + p.status + (issue ? ' is-issue' : '') }, [
			el('summary', {}, [
				statusBadge(p.status),
				el('span', { className: 'oqsc-check-title', text: p.titel }),
				el('span', { className: 'oqsc-check-befund', text: p.befund })
			]),
			body
		]);
	};

	App.prototype.renderSerp = function (r) {
		var v = r.vorschau || {};
		var url = v.url || '';
		var host = '';
		var path = '';
		try {
			var u = new URL(url);
			host = u.hostname.replace(/^www\./, '');
			path = u.pathname.replace(/\/$/, '').split('/').filter(Boolean).join(' › ');
		} catch (e) {
			host = r.domain || '';
		}
		var title = v.titel || r.domain || '';
		var desc = v.beschreibung || '';
		var site = v.name || host;
		function snippet(mode) {
			var isMobile = mode === 'mobile';
			var t = truncatePx(title, '20px Arial', isMobile ? 640 : 600);
			var d = truncatePx(desc, '14px Arial', isMobile ? 860 : 920);
			return el('div', { className: 'oqsc-serp oqsc-serp-' + mode }, [
				el('div', { className: 'oqsc-serp-site' }, [
					el('span', { className: 'oqsc-serp-fav', 'aria-hidden': 'true', text: (site || '?').charAt(0).toUpperCase() }),
					el('span', { className: 'oqsc-serp-names' }, [
						el('span', { className: 'oqsc-serp-name', text: site }),
						el('span', { className: 'oqsc-serp-url', text: 'https://' + host + (path ? ' › ' + path : '') })
					])
				]),
				el('div', { className: 'oqsc-serp-title', text: t || 'Kein Titel vorhanden' }),
				el('div', { className: 'oqsc-serp-desc' + (v.beschreibung_fehlt ? ' is-guess' : ''), text: d || 'Keine Beschreibung vorhanden.' })
			]);
		}
		var desk = snippet('desktop');
		var mob = snippet('mobile');
		mob.hidden = true;
		var b1 = el('button', { type: 'button', className: 'oqsc-tab', 'aria-pressed': 'true', text: 'Computer' });
		var b2 = el('button', { type: 'button', className: 'oqsc-tab', 'aria-pressed': 'false', text: 'Handy' });
		b1.addEventListener('click', function () {
			desk.hidden = false;
			mob.hidden = true;
			b1.setAttribute('aria-pressed', 'true');
			b2.setAttribute('aria-pressed', 'false');
		});
		b2.addEventListener('click', function () {
			desk.hidden = true;
			mob.hidden = false;
			b1.setAttribute('aria-pressed', 'false');
			b2.setAttribute('aria-pressed', 'true');
		});
		return el('div', { className: 'oqsc-view-card oqsc-fade' }, [
			el('h3', { className: 'oqsc-h3', text: 'So sieht Google Sie' }),
			el('div', { className: 'oqsc-tabs', role: 'group', 'aria-label': 'Ansicht wählen' }, [b1, b2]),
			el('div', { className: 'oqsc-serp-frame' }, [desk, mob]),
			el('p', { className: 'oqsc-meta', text: v.beschreibung_fehlt ? 'Ohne eigene Beschreibung nimmt Google einen Textschnipsel von der Seite, ungefähr so. Die Vorschau ist eine Annäherung, Google passt Titel und Text manchmal selbst an.' : 'Die Vorschau ist eine Annäherung mit der echten Abschneidung nach Pixelbreite. Google passt Titel und Text manchmal selbst an.' })
		]);
	};

	App.prototype.renderPhone = function (r) {
		var shot = typeof r.screenshot === 'string' && /^data:image\/(webp|jpeg|png);base64,/.test(r.screenshot) ? r.screenshot : '';
		var screen = el('div', { className: 'oqsc-phone-screen' });
		if (shot) {
			screen.appendChild(el('img', { src: shot, alt: 'Bildschirmfoto Ihrer Startseite auf dem Handy, aufgenommen von Google', loading: 'lazy' }));
		} else {
			screen.appendChild(el('div', { className: 'oqsc-phone-empty' }, [qMark(30), el('p', { text: 'Das Handy-Bildschirmfoto liefert Google zusammen mit der Ladezeit-Messung. Diesmal war es nicht verfügbar.' })]));
		}
		return el('div', { className: 'oqsc-view-card oqsc-fade' }, [
			el('h3', { className: 'oqsc-h3', text: 'So sieht Ihr Kunde Sie' }),
			el('div', { className: 'oqsc-phone' }, [el('span', { className: 'oqsc-phone-notch', 'aria-hidden': 'true' }), screen]),
			el('p', { className: 'oqsc-meta', text: 'Der erste Eindruck auf dem Handy. Sehen Sie hier sofort, was Sie anbieten, wo Sie sind und wie man Sie erreicht?' })
		]);
	};

	/* ---------- Anfrage ---------- */

	App.prototype.renderLead = function (r) {
		var self = this;
		var cfg = this.cfg;
		var section = el('section', { className: 'oqsc-section oqsc-request', id: 'oqsc-anfrage', 'aria-labelledby': 'oqsc-lead-h' });
		var h = el('h3', { className: 'oqsc-h3', id: 'oqsc-lead-h', text: 'Persönliche Analyse anfordern' });
		append(section, [h]);
		if (r.anfrage_offen === false) {
			append(section, el('p', { className: 'oqsc-lead-done', text: 'Zu diesem Ergebnis liegt uns bereits eine Anfrage vor. Wir melden uns bei Ihnen.' }));
			return section;
		}
		append(section, el('p', { text: 'Wir schauen uns Ihre Website persönlich an und sagen Ihnen, was sich für Ihren Betrieb wirklich lohnt. Das Ergebnis dieses Checks schicken wir automatisch mit, Sie müssen nichts erklären.' }));
		function field(id, label, type, attrs) {
			var input = type === 'textarea' ? el('textarea', Object.assign({ id: id, name: id, rows: 4, className: 'oqsc-input' }, attrs || {})) : el('input', Object.assign({ id: id, name: id, type: type, className: 'oqsc-input' }, attrs || {}));
			return { wrap: el('div', { className: 'oqsc-field' }, [el('label', { for: id, text: label }), input]), input: input };
		}
		var fName = field('oqsc-l-name', 'Ihr Name', 'text', { autocomplete: 'name', required: true, maxlength: 120 });
		var fMail = field('oqsc-l-email', 'Ihre E-Mail-Adresse', 'email', { autocomplete: 'email', required: true, maxlength: 190 });
		var fTel = field('oqsc-l-tel', 'Telefon (optional)', 'tel', { autocomplete: 'tel', maxlength: 40 });
		var fMsg = field('oqsc-l-msg', 'Ihre Nachricht (optional)', 'textarea', { maxlength: 2000, placeholder: 'Was ist Ihnen wichtig? Wann erreichen wir Sie am besten?' });
		var consent = el('input', { id: 'oqsc-l-ok', type: 'checkbox', required: true });
		var hp = el('div', { className: 'oqsc-hp', 'aria-hidden': 'true' }, [el('label', { for: 'oqsc-l-website', text: 'Bitte leer lassen' }), el('input', { id: 'oqsc-l-website', type: 'text', tabindex: '-1', autocomplete: 'off' })]);
		var msg = el('div', { className: 'oqsc-msg', role: 'alert' });
		var btn = el('button', { type: 'submit', className: 'oqsc-btn oqsc-btn-primary' }, [el('span', { text: 'Analyse anfordern' }), icon('arrow')]);
		var form = el('form', { className: 'oqsc-form oqsc-lead-form', novalidate: true }, [
			el('div', { className: 'oqsc-row' }, [fName.wrap, fMail.wrap]),
			el('div', { className: 'oqsc-row' }, [fTel.wrap]),
			fMsg.wrap,
			el('div', { className: 'oqsc-consent' }, [consent, el('label', { for: 'oqsc-l-ok' }, [cfg.einwilligung || 'Ich bin mit der Verarbeitung meiner Angaben einverstanden.', ' ', cfg.datenschutz ? el('a', { href: cfg.datenschutz, text: 'Datenschutzerklärung' }) : null])]),
			hp,
			msg,
			btn
		]);
		append(section, form);
		form.addEventListener('submit', function (e) {
			e.preventDefault();
			msg.textContent = '';
			[fName.input, fMail.input].forEach(function (i) {
				i.removeAttribute('aria-invalid');
			});
			if (fName.input.value.trim().length < 2) {
				fName.input.setAttribute('aria-invalid', 'true');
				msg.textContent = 'Bitte geben Sie Ihren Namen an.';
				fName.input.focus();
				return;
			}
			if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(fMail.input.value.trim())) {
				fMail.input.setAttribute('aria-invalid', 'true');
				msg.textContent = 'Bitte geben Sie eine gültige E-Mail-Adresse an.';
				fMail.input.focus();
				return;
			}
			if (!consent.checked) {
				msg.textContent = 'Bitte bestätigen Sie die Einwilligung.';
				consent.focus();
				return;
			}
			btn.disabled = true;
			btn.firstChild.textContent = 'Wird gesendet …';
			self.ticket.take().then(function (t) {
				return self.api.call('POST', 'lead', {
					check: self.jobToken,
					name: fName.input.value.trim(),
					email: fMail.input.value.trim(),
					telefon: fTel.input.value.trim(),
					nachricht: fMsg.input.value.trim(),
					einwilligung: true,
					token: t.token,
					pow: t.pow,
					website: hp.querySelector('input').value
				});
			}).then(function (res) {
				if (res.fehler) {
					throw new Error(res.meldung);
				}
				clear(section);
				var done = el('h3', { className: 'oqsc-h3', text: 'Vielen Dank!' });
				append(section, [el('div', { className: 'oqsc-orb oqsc-orb-small', 'aria-hidden': 'true' }, qMark(30)), done, el('p', { className: 'oqsc-lead-done', text: res.meldung })]);
				self.announce(res.meldung);
				focusHeading(done);
			}).then(null, function (err) {
				btn.disabled = false;
				btn.firstChild.textContent = 'Analyse anfordern';
				msg.textContent = err.message;
			});
		});
		return section;
	};

	/* ------------------------------------------------------------------
	 * Druck: alle Details öffnen
	 * ---------------------------------------------------------------- */

	var printRoot = null;
	function preparePrint() {
		if (printRoot) {
			return;
		}
		var stage = document.querySelector('.oqsc-app .oqsc-view-result');
		if (!stage) {
			return;
		}
		printRoot = document.createElement('div');
		printRoot.id = 'oqsc-print-root';
		printRoot.className = 'oqsc-app oqsc-print-root';
		var clone = stage.cloneNode(true);
		var i;
		var details = clone.querySelectorAll('details');
		for (i = 0; i < details.length; i++) {
			// Nur Punkte mit Handlungsbedarf ausführlich, gute Prüfungen als eine Zeile.
			if (details[i].classList.contains('is-issue')) {
				details[i].setAttribute('open', '');
			} else {
				details[i].removeAttribute('open');
			}
		}
		var hidden = clone.querySelectorAll('[hidden]');
		for (i = 0; i < hidden.length; i++) {
			hidden[i].removeAttribute('hidden');
		}
		var ids = clone.querySelectorAll('[id]');
		for (i = 0; i < ids.length; i++) {
			ids[i].removeAttribute('id');
		}
		printRoot.appendChild(clone);
		document.body.appendChild(printRoot);
		document.body.classList.add('oqsc-printing');
	}
	function cleanupPrint() {
		if (printRoot && printRoot.parentNode) {
			printRoot.parentNode.removeChild(printRoot);
		}
		printRoot = null;
		document.body.classList.remove('oqsc-printing');
	}
	window.addEventListener('beforeprint', preparePrint);
	window.addEventListener('afterprint', cleanupPrint);
	window.oqscPreparePrint = preparePrint;

	/* ------------------------------------------------------------------
	 * Start
	 * ---------------------------------------------------------------- */

	function readConfig(node) {
		var raw = node.getAttribute('data-oqsc-config');
		if (!raw) {
			var script = document.getElementById('oqsc-config');
			raw = script ? script.textContent : '';
		}
		try {
			var cfg = JSON.parse(raw || '{}');
			if (!cfg.rest) {
				return null;
			}
			if (node.getAttribute('data-variante')) {
				cfg.variante = node.getAttribute('data-variante');
			}
			if (node.getAttribute('data-ziel')) {
				cfg.ziel = node.getAttribute('data-ziel');
			}
			return cfg;
		} catch (e) {
			return null;
		}
	}

	function init() {
		var nodes = document.querySelectorAll('.oqsc-app:not(.oqsc-ready)');
		var fullTaken = false;
		for (var i = 0; i < nodes.length; i++) {
			var cfg = readConfig(nodes[i]);
			if (!cfg) {
				continue;
			}
			if (cfg.variante !== 'kompakt') {
				// Nur eine volle Ansicht je Seite, damit Ergebnis-Links eindeutig bleiben.
				if (fullTaken) {
					continue;
				}
				fullTaken = true;
			}
			try {
				new App(nodes[i], cfg); // eslint-disable-line no-new
			} catch (e) {
				if (window.console) {
					window.console.error('oriqen Check:', e);
				}
			}
		}
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}
}());
