<?php
/**
 * Admin-Routen (nur mit oqsc_manage), z. B. für die Auswertung über Easy MCP.
 *
 * @package oriqen-check
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin-REST und Datenabfragen für das Backend.
 */
class OQSC_Admin_Rest {

	/**
	 * Recht prüfen.
	 *
	 * @return bool
	 */
	public static function can() {
		return current_user_can( 'oqsc_manage' );
	}

	/**
	 * Routen registrieren.
	 */
	public static function register() {
		$ns = OQSC_Rest::NS;
		register_rest_route(
			$ns,
			'/admin/stats',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_stats' ),
				'permission_callback' => array( __CLASS__, 'can' ),
				'args'                => array(
					'tage' => array(
						'type'    => 'integer',
						'default' => 30,
						'minimum' => 1,
						'maximum' => 365,
					),
				),
			)
		);
		register_rest_route(
			$ns,
			'/admin/checks',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_checks' ),
				'permission_callback' => array( __CLASS__, 'can' ),
				'args'                => array(
					'id'      => array( 'type' => 'integer' ),
					'suche'   => array(
						'type'    => 'string',
						'default' => '',
					),
					'domain'  => array(
						'type'    => 'string',
						'default' => '',
					),
					'status'  => array(
						'type'    => 'string',
						'default' => '',
					),
					'anfrage' => array( 'type' => 'boolean' ),
					'seite'   => array(
						'type'    => 'integer',
						'default' => 1,
						'minimum' => 1,
					),
					'pro'     => array(
						'type'    => 'integer',
						'default' => 30,
						'minimum' => 1,
						'maximum' => 200,
					),
				),
			)
		);
		register_rest_route(
			$ns,
			'/admin/leads',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_leads' ),
				'permission_callback' => array( __CLASS__, 'can' ),
				'args'                => array(
					'id'     => array( 'type' => 'integer' ),
					'status' => array(
						'type'    => 'string',
						'default' => '',
					),
					'seite'  => array(
						'type'    => 'integer',
						'default' => 1,
						'minimum' => 1,
					),
					'pro'    => array(
						'type'    => 'integer',
						'default' => 30,
						'minimum' => 1,
						'maximum' => 200,
					),
				),
			)
		);
		register_rest_route(
			$ns,
			'/admin/leads/(?P<id>\d+)',
			array(
				'methods'             => 'PATCH',
				'callback'            => array( __CLASS__, 'rest_lead_patch' ),
				'permission_callback' => array( __CLASS__, 'can' ),
				'args'                => array(
					'status' => array( 'type' => 'string' ),
					'notiz'  => array( 'type' => 'string' ),
				),
			)
		);
		register_rest_route(
			$ns,
			'/admin/settings',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'rest_settings_get' ),
					'permission_callback' => array( __CLASS__, 'can' ),
				),
				array(
					'methods'             => 'PUT',
					'callback'            => array( __CLASS__, 'rest_settings_put' ),
					'permission_callback' => array( __CLASS__, 'can' ),
				),
			)
		);
	}

	/* ---------------- Daten ---------------- */

	/**
	 * Kennzahlen.
	 *
	 * @param int $days Zeitraum in Tagen.
	 * @return array
	 */
	public static function stats_data( $days = 30 ) {
		global $wpdb;
		$c     = $wpdb->prefix . 'oqsc_checks';
		$l     = $wpdb->prefix . 'oqsc_leads';
		$e     = $wpdb->prefix . 'oqsc_events';
		$days  = max( 1, (int) $days );
		$since = OQSC_Plugin::now( -$days * DAY_IN_SECONDS );
		$today = get_gmt_from_date( current_time( 'Y-m-d' ) . ' 00:00:00' );

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Tabellennamen aus $wpdb->prefix.
		$count = static function ( $from ) use ( $wpdb, $c ) {
			return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$c} WHERE status = 'fertig' AND created_at >= %s", $from ) );
		};
		$out = array(
			'zeitraum_tage'      => $days,
			'checks'             => array(
				'heute'     => $count( $today ),
				'heute_neu' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$c} WHERE quelle <> 'cache' AND created_at >= %s", $today ) ),
				'tage7'     => $count( OQSC_Plugin::now( -7 * DAY_IN_SECONDS ) ),
				'tage30'    => $count( OQSC_Plugin::now( -30 * DAY_IN_SECONDS ) ),
				'zeitraum'  => $count( $since ),
				'fehler'    => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$c} WHERE status = 'fehler' AND created_at >= %s", $since ) ),
			),
			'durchschnitt_index' => null,
			'saeulen'            => array(),
			'verteilung'         => array(
				'85 bis 100' => 0,
				'70 bis 84'  => 0,
				'50 bis 69'  => 0,
				'unter 50'   => 0,
			),
			'befunde'            => array(),
			'anfragen'           => array(
				'gesamt' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$l} WHERE created_at >= %s", $since ) ),
				'neu'    => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$l} WHERE status = 'neu'" ),
			),
			'schutz'             => array(),
			'laufend'            => OQSC_Guard::running_count(),
			'pause_bis'          => (int) get_option( 'oqsc_pause_bis', 0 ),
		);

		$avg = $wpdb->get_var( $wpdb->prepare( "SELECT AVG(index_wert) FROM {$c} WHERE status = 'fertig' AND quelle <> 'cache' AND created_at >= %s", $since ) );
		if ( null !== $avg ) {
			$out['durchschnitt_index'] = (int) round( (float) $avg );
		}

		// Ergebnisse (je Domain nur das neueste, Speicherkopien ausgenommen) für Säulen und Befunde.
		$rows   = $wpdb->get_results( $wpdb->prepare( "SELECT id, domain, index_wert, ergebnis FROM {$c} WHERE status = 'fertig' AND quelle <> 'cache' AND created_at >= %s ORDER BY id DESC LIMIT 2000", $since ), ARRAY_A );
		$events = $wpdb->get_results( $wpdb->prepare( "SELECT art, COUNT(*) AS n FROM {$e} WHERE created_at >= %s GROUP BY art", $since ), ARRAY_A );
		// phpcs:enable

		$seen     = array();
		$pillars  = array();
		$findings = array();
		$titles   = array();
		$n        = 0;
		foreach ( $rows as $row ) {
			if ( isset( $seen[ $row['domain'] ] ) ) {
				continue;
			}
			$seen[ $row['domain'] ] = true;
			$r                      = json_decode( (string) $row['ergebnis'], true );
			if ( ! is_array( $r ) ) {
				continue;
			}
			++$n;
			$v = (int) $row['index_wert'];
			if ( $v >= 85 ) {
				++$out['verteilung']['85 bis 100'];
			} elseif ( $v >= 70 ) {
				++$out['verteilung']['70 bis 84'];
			} elseif ( $v >= 50 ) {
				++$out['verteilung']['50 bis 69'];
			} else {
				++$out['verteilung']['unter 50'];
			}
			foreach ( isset( $r['saeulen'] ) ? $r['saeulen'] : array() as $s ) {
				if ( null === $s['wert'] ) {
					continue;
				}
				if ( ! isset( $pillars[ $s['key'] ] ) ) {
					$pillars[ $s['key'] ] = array( 0, 0, $s['name'] );
				}
				$pillars[ $s['key'] ][0] += $s['wert'];
				++$pillars[ $s['key'] ][1];
			}
			foreach ( isset( $r['pruefungen'] ) ? $r['pruefungen'] : array() as $p ) {
				if ( in_array( $p['status'], array( 'verbesserbar', 'kritisch' ), true ) || ( 'hinweis' === $p['status'] && 'R' === $p['id'][0] ) ) {
					$findings[ $p['id'] ] = isset( $findings[ $p['id'] ] ) ? $findings[ $p['id'] ] + 1 : 1;
					$titles[ $p['id'] ]   = $p['titel'];
				}
			}
		}
		foreach ( OQSC_Checks::pillars() as $key => $p ) {
			$out['saeulen'][] = array(
				'key'  => $key,
				'name' => $p[0],
				'wert' => isset( $pillars[ $key ] ) && $pillars[ $key ][1] ? (int) round( $pillars[ $key ][0] / $pillars[ $key ][1] ) : null,
			);
		}
		arsort( $findings );
		foreach ( array_slice( $findings, 0, 10, true ) as $id => $count_f ) {
			$out['befunde'][] = array(
				'id'     => $id,
				'titel'  => $titles[ $id ],
				'anzahl' => $count_f,
				'anteil' => $n ? (int) round( 100 * $count_f / $n ) : 0,
			);
		}
		$out['domains_ausgewertet'] = $n;
		foreach ( $events as $ev ) {
			$out['schutz'][ $ev['art'] ] = (int) $ev['n'];
		}
		return $out;
	}

	/**
	 * Liste der Checks.
	 *
	 * @param array $args suche, domain, status, anfrage, seite, pro.
	 * @return array gesamt, eintraege.
	 */
	public static function checks_list( $args ) {
		global $wpdb;
		$c      = $wpdb->prefix . 'oqsc_checks';
		$l      = $wpdb->prefix . 'oqsc_leads';
		$where  = array( '1=1' );
		$params = array();
		if ( ! empty( $args['suche'] ) ) {
			$like     = '%' . $wpdb->esc_like( $args['suche'] ) . '%';
			$where[]  = '(c.domain LIKE %s OR c.ort LIKE %s OR c.branche LIKE %s)';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}
		if ( ! empty( $args['domain'] ) ) {
			$where[]  = 'c.domain = %s';
			$params[] = OQSC_Fetcher::domain_key( $args['domain'] );
		}
		if ( ! empty( $args['status'] ) ) {
			$where[]  = 'c.status = %s';
			$params[] = sanitize_key( $args['status'] );
		}
		if ( isset( $args['anfrage'] ) && null !== $args['anfrage'] ) {
			$where[] = $args['anfrage'] ? 'l.id IS NOT NULL' : 'l.id IS NULL';
		}
		$pro   = max( 1, min( 200, isset( $args['pro'] ) ? (int) $args['pro'] : 30 ) );
		$seite = max( 1, isset( $args['seite'] ) ? (int) $args['seite'] : 1 );
		$sql_w = implode( ' AND ', $where );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared -- Bedingungen bestehen nur aus Platzhaltern.
		$base  = "FROM {$c} c LEFT JOIN {$l} l ON l.check_id = c.id WHERE {$sql_w}";
		$total = (int) ( $params ? $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT c.id) {$base}", $params ) ) : $wpdb->get_var( "SELECT COUNT(DISTINCT c.id) {$base}" ) );
		$q     = "SELECT c.id, c.token, c.domain, c.url, c.ort, c.branche, c.status, c.quelle, c.index_wert, c.created_at, c.fehler, MAX(l.id) AS lead_id {$base} GROUP BY c.id ORDER BY c.id DESC LIMIT %d OFFSET %d";
		$rows  = $wpdb->get_results( $wpdb->prepare( $q, array_merge( $params, array( $pro, ( $seite - 1 ) * $pro ) ) ), ARRAY_A );
		// phpcs:enable
		$out = array();
		foreach ( $rows as $r ) {
			$out[] = array(
				'id'         => (int) $r['id'],
				'token'      => $r['token'],
				'domain'     => $r['domain'],
				'url'        => $r['url'],
				'ort'        => $r['ort'],
				'branche'    => $r['branche'],
				'status'     => $r['status'],
				'quelle'     => $r['quelle'],
				'index_wert' => null === $r['index_wert'] ? null : (int) $r['index_wert'],
				'created_at' => $r['created_at'],
				'fehler'     => $r['fehler'],
				'anfrage'    => ! empty( $r['lead_id'] ),
				'lead_id'    => $r['lead_id'] ? (int) $r['lead_id'] : null,
			);
		}
		return array(
			'gesamt'    => $total,
			'seite'     => $seite,
			'pro'       => $pro,
			'eintraege' => $out,
		);
	}

	/**
	 * Detail eines Checks inkl. Vertriebsnotiz.
	 *
	 * @param int $id ID.
	 * @return array|null
	 */
	public static function check_detail( $id ) {
		$row = OQSC_Job::get_by_id( (int) $id );
		if ( ! $row ) {
			return null;
		}
		$r        = json_decode( (string) $row['ergebnis'], true );
		$branchen = OQSC_Plugin::branchen();
		return array(
			'id'             => (int) $row['id'],
			'token'          => $row['token'],
			'domain'         => $row['domain'],
			'url'            => $row['url'],
			'ort'            => $row['ort'],
			'branche'        => $row['branche'],
			'branche_label'  => isset( $branchen[ $row['branche'] ] ) ? $branchen[ $row['branche'] ] : '',
			'status'         => $row['status'],
			'quelle'         => $row['quelle'],
			'index_wert'     => null === $row['index_wert'] ? null : (int) $row['index_wert'],
			'fehler'         => (string) $row['fehler'],
			'created_at'     => $row['created_at'],
			'expires_at'     => $row['expires_at'],
			'ergebnis'       => is_array( $r ) ? $r : array(),
			'vertriebsnotiz' => is_array( $r ) && isset( $r['intern']['vertriebsnotiz'] ) ? $r['intern']['vertriebsnotiz'] : null,
		);
	}

	/**
	 * Liste der Anfragen.
	 *
	 * @param array $args status, seite, pro.
	 * @return array
	 */
	public static function leads_list( $args ) {
		global $wpdb;
		$c      = $wpdb->prefix . 'oqsc_checks';
		$l      = $wpdb->prefix . 'oqsc_leads';
		$where  = '1=1';
		$params = array();
		if ( ! empty( $args['status'] ) && array_key_exists( $args['status'], OQSC_Leads::status_labels() ) ) {
			$where    = 'l.status = %s';
			$params[] = $args['status'];
		}
		$pro   = max( 1, min( 200, isset( $args['pro'] ) ? (int) $args['pro'] : 30 ) );
		$seite = max( 1, isset( $args['seite'] ) ? (int) $args['seite'] : 1 );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared -- Bedingungen bestehen nur aus Platzhaltern.
		$total = (int) ( $params ? $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$l} l WHERE {$where}", $params ) ) : $wpdb->get_var( "SELECT COUNT(*) FROM {$l} l WHERE {$where}" ) );
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT l.id, l.check_id, l.name, l.email, l.telefon, l.status, l.created_at, c.domain, c.index_wert FROM {$l} l LEFT JOIN {$c} c ON c.id = l.check_id WHERE {$where} ORDER BY l.id DESC LIMIT %d OFFSET %d", array_merge( $params, array( $pro, ( $seite - 1 ) * $pro ) ) ), ARRAY_A );
		// phpcs:enable
		foreach ( $rows as &$r ) {
			$r['id']         = (int) $r['id'];
			$r['check_id']   = (int) $r['check_id'];
			$r['index_wert'] = null === $r['index_wert'] ? null : (int) $r['index_wert'];
		}
		unset( $r );
		return array(
			'gesamt'    => $total,
			'seite'     => $seite,
			'pro'       => $pro,
			'eintraege' => $rows,
		);
	}

	/**
	 * Detail einer Anfrage inkl. Befund.
	 *
	 * @param int $id ID.
	 * @return array|null
	 */
	public static function lead_detail( $id ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}oqsc_leads WHERE id = %d", $id ), ARRAY_A );
		if ( ! $row ) {
			return null;
		}
		unset( $row['ip_hash'] );
		$row['id']    = (int) $row['id'];
		$row['check'] = $row['check_id'] ? self::check_detail( (int) $row['check_id'] ) : null;
		return $row;
	}

	/**
	 * Einstellungen ohne Klartext-Schlüssel.
	 *
	 * @return array
	 */
	public static function public_settings() {
		$s = OQSC_Plugin::settings();
		$s['psi_key_gesetzt'] = '' !== $s['psi_key'];
		$s['psi_key']         = '' !== $s['psi_key'] ? str_repeat( '•', 8 ) . substr( $s['psi_key'], -4 ) : '';
		return $s;
	}

	/* ---------------- Routen ---------------- */

	/**
	 * GET /admin/stats.
	 *
	 * @param WP_REST_Request $req Anfrage.
	 * @return WP_REST_Response
	 */
	public static function rest_stats( WP_REST_Request $req ) {
		return new WP_REST_Response( self::stats_data( (int) $req['tage'] ), 200 );
	}

	/**
	 * GET /admin/checks.
	 *
	 * @param WP_REST_Request $req Anfrage.
	 * @return WP_REST_Response
	 */
	public static function rest_checks( WP_REST_Request $req ) {
		if ( $req['id'] ) {
			$d = self::check_detail( (int) $req['id'] );
			return $d ? new WP_REST_Response( $d, 200 ) : new WP_REST_Response( array( 'meldung' => 'Nicht gefunden.' ), 404 );
		}
		return new WP_REST_Response(
			self::checks_list(
				array(
					'suche'   => (string) $req['suche'],
					'domain'  => (string) $req['domain'],
					'status'  => (string) $req['status'],
					'anfrage' => $req->has_param( 'anfrage' ) ? (bool) $req['anfrage'] : null,
					'seite'   => (int) $req['seite'],
					'pro'     => (int) $req['pro'],
				)
			),
			200
		);
	}

	/**
	 * GET /admin/leads.
	 *
	 * @param WP_REST_Request $req Anfrage.
	 * @return WP_REST_Response
	 */
	public static function rest_leads( WP_REST_Request $req ) {
		if ( $req['id'] ) {
			$d = self::lead_detail( (int) $req['id'] );
			return $d ? new WP_REST_Response( $d, 200 ) : new WP_REST_Response( array( 'meldung' => 'Nicht gefunden.' ), 404 );
		}
		return new WP_REST_Response(
			self::leads_list(
				array(
					'status' => (string) $req['status'],
					'seite'  => (int) $req['seite'],
					'pro'    => (int) $req['pro'],
				)
			),
			200
		);
	}

	/**
	 * PATCH /admin/leads/{id}.
	 *
	 * @param WP_REST_Request $req Anfrage.
	 * @return WP_REST_Response
	 */
	public static function rest_lead_patch( WP_REST_Request $req ) {
		$id = (int) $req['id'];
		if ( ! self::lead_detail( $id ) ) {
			return new WP_REST_Response( array( 'meldung' => 'Nicht gefunden.' ), 404 );
		}
		$status = $req->has_param( 'status' ) ? sanitize_key( (string) $req['status'] ) : '';
		if ( $status && ! array_key_exists( $status, OQSC_Leads::status_labels() ) ) {
			return new WP_REST_Response( array( 'meldung' => 'Unbekannter Status. Erlaubt: ' . implode( ', ', array_keys( OQSC_Leads::status_labels() ) ) ), 400 );
		}
		$notiz = $req->has_param( 'notiz' ) ? sanitize_textarea_field( (string) $req['notiz'] ) : null;
		OQSC_Leads::update( $id, $status, $notiz );
		$d = self::lead_detail( $id );
		unset( $d['check'] );
		return new WP_REST_Response( $d, 200 );
	}

	/**
	 * GET /admin/settings.
	 *
	 * @return WP_REST_Response
	 */
	public static function rest_settings_get() {
		return new WP_REST_Response( self::public_settings(), 200 );
	}

	/**
	 * PUT /admin/settings.
	 *
	 * @param WP_REST_Request $req Anfrage.
	 * @return WP_REST_Response
	 */
	public static function rest_settings_put( WP_REST_Request $req ) {
		$input = $req->get_json_params();
		if ( ! is_array( $input ) ) {
			$input = $req->get_body_params();
		}
		OQSC_Plugin::save_settings( is_array( $input ) ? $input : array() );
		return new WP_REST_Response( self::public_settings(), 200 );
	}
}
