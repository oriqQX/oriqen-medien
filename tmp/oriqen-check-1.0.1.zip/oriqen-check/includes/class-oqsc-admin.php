<?php
/**
 * Backend-Seiten.
 *
 * @package oriqen-check
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Menü „oriqen Check“ mit Übersicht, Checks, Anfragen, Einstellungen, Datenschutz-Baustein.
 */
class OQSC_Admin {

	/**
	 * Instanz.
	 *
	 * @var OQSC_Admin|null
	 */
	private static $instance = null;

	/**
	 * Instanz holen.
	 *
	 * @return OQSC_Admin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Hooks.
	 */
	public function init() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
		add_action( 'admin_post_oqsc_save_settings', array( $this, 'save_settings' ) );
		add_action( 'admin_post_oqsc_lead_update', array( $this, 'lead_update' ) );
		add_action( 'admin_post_oqsc_export', array( 'OQSC_Export', 'handle' ) );
		add_action( 'admin_post_oqsc_pause_end', array( $this, 'pause_end' ) );
		add_action( 'admin_notices', array( $this, 'test_warning' ) );
	}

	/**
	 * Menü-Icon aus q-mark.svg (einfarbig, WordPress färbt es ein).
	 *
	 * @return string
	 */
	private function menu_icon() {
		$svg = file_get_contents( OQSC_DIR . 'assets/brand/q-mark.svg' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- lokale Datei.
		$svg = str_replace( 'fill="#000"', 'fill="black"', (string) $svg );
		return 'data:image/svg+xml;base64,' . base64_encode( $svg ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Data-URI für Menü-Icon.
	}

	/**
	 * Menü registrieren.
	 */
	public function menu() {
		$cap = 'oqsc_manage';
		add_menu_page( 'oriqen Check', 'oriqen Check', $cap, 'oqsc', array( $this, 'page_overview' ), $this->menu_icon(), 58 );
		add_submenu_page( 'oqsc', 'Übersicht', 'Übersicht', $cap, 'oqsc', array( $this, 'page_overview' ) );
		add_submenu_page( 'oqsc', 'Checks', 'Checks', $cap, 'oqsc-checks', array( $this, 'page_checks' ) );
		add_submenu_page( 'oqsc', 'Anfragen', 'Anfragen', $cap, 'oqsc-leads', array( $this, 'page_leads' ) );
		add_submenu_page( 'oqsc', 'Einstellungen', 'Einstellungen', $cap, 'oqsc-settings', array( $this, 'page_settings' ) );
		add_submenu_page( 'oqsc', 'Datenschutz-Baustein', 'Datenschutz-Baustein', $cap, 'oqsc-privacy', array( $this, 'page_privacy' ) );
	}

	/**
	 * Admin-CSS nur auf eigenen Seiten.
	 *
	 * @param string $hook Seiten-Hook.
	 */
	public function assets( $hook ) {
		if ( false === strpos( (string) $hook, 'oqsc' ) ) {
			return;
		}
		wp_enqueue_style( 'oqsc-admin', OQSC_URL . 'assets/admin.css', array(), OQSC_VERSION );
	}

	/**
	 * Rote Warnung, wenn die Testkonstante gesetzt ist.
	 */
	public function test_warning() {
		if ( OQSC_Plugin::test_local_allowed() && current_user_can( 'oqsc_manage' ) ) {
			echo '<div class="notice notice-error"><p><strong>oriqen Check:</strong> Die Konstante <code>OQSC_TEST_ALLOW_LOCAL</code> ist gesetzt. Damit sind lokale Prüfziele erlaubt. Auf einer echten Website sofort aus der wp-config.php entfernen.</p></div>';
		}
	}

	/**
	 * Kopf im oriqen-Stil.
	 *
	 * @param string $title Titel.
	 * @param string $sub   Untertitel.
	 */
	private function header( $title, $sub = '' ) {
		$svg = file_get_contents( OQSC_DIR . 'assets/brand/q-mark.svg' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- lokale Datei.
		$svg = str_replace( array( 'width="24" height="24"', 'fill="#000"' ), array( 'width="34" height="34" aria-hidden="true"', 'fill="currentColor"' ), (string) $svg );
		echo '<div class="oqsc-admin-head"><div class="oqsc-admin-q">';
		echo $svg; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- eigene, statische SVG-Datei.
		echo '</div><div><h1>' . esc_html( $title ) . '</h1>';
		if ( $sub ) {
			echo '<p>' . esc_html( $sub ) . '</p>';
		}
		echo '</div></div><hr class="wp-header-end">';
		if ( OQSC_Plugin::get( 'wartung' ) ) {
			echo '<div class="oqsc-admin-alert">Wartungsmodus ist aktiv. Besucher können gerade keine Checks starten.</div>';
		}
		$pause = (int) get_option( 'oqsc_pause_bis', 0 );
		if ( $pause > time() ) {
			$url = wp_nonce_url( admin_url( 'admin-post.php?action=oqsc_pause_end' ), 'oqsc_pause_end' );
			echo '<div class="oqsc-admin-alert">Automatischer Not-Aus aktiv bis ' . esc_html( wp_date( 'H:i', $pause ) ) . ' Uhr. <a href="' . esc_url( $url ) . '">Pause jetzt beenden</a></div>';
		}
	}

	/**
	 * Not-Aus vorzeitig beenden.
	 */
	public function pause_end() {
		if ( ! current_user_can( 'oqsc_manage' ) ) {
			wp_die( 'Keine Berechtigung.' );
		}
		check_admin_referer( 'oqsc_pause_end' );
		update_option( 'oqsc_pause_bis', 0, false );
		wp_safe_redirect( admin_url( 'admin.php?page=oqsc' ) );
		exit;
	}

	/**
	 * Übersicht.
	 */
	public function page_overview() {
		if ( ! current_user_can( 'oqsc_manage' ) ) {
			return;
		}
		$stats = OQSC_Admin_Rest::stats_data( 30 );
		echo '<div class="wrap oqsc-admin">';
		$this->header( 'oriqen Sichtbarkeits-Check', 'Übersicht der letzten 30 Tage' );

		echo '<div class="oqsc-admin-grid oqsc-admin-kpis">';
		$this->kpi( 'Checks heute', $stats['checks']['heute'] );
		$this->kpi( 'Checks 7 Tage', $stats['checks']['tage7'] );
		$this->kpi( 'Checks 30 Tage', $stats['checks']['tage30'] );
		$this->kpi( 'Ø Index', null === $stats['durchschnitt_index'] ? '–' : $stats['durchschnitt_index'] );
		$this->kpi( 'Anfragen 30 Tage', $stats['anfragen']['gesamt'], $stats['anfragen']['neu'] . ' neu' );
		echo '</div>';

		echo '<div class="oqsc-admin-grid oqsc-admin-two">';

		echo '<div class="oqsc-admin-card"><h2>Durchschnitt je Säule</h2>';
		foreach ( $stats['saeulen'] as $s ) {
			$this->bar( $s['name'], $s['wert'], 100, null === $s['wert'] ? '–' : $s['wert'] . ' / 100' );
		}
		echo '</div>';

		echo '<div class="oqsc-admin-card"><h2>Die zehn häufigsten Befunde</h2>';
		if ( empty( $stats['befunde'] ) ) {
			echo '<p class="oqsc-muted">Noch keine Daten.</p>';
		}
		$max = 1;
		foreach ( $stats['befunde'] as $b ) {
			$max = max( $max, $b['anzahl'] );
		}
		foreach ( $stats['befunde'] as $b ) {
			$this->bar( $b['id'] . ' ' . $b['titel'], $b['anzahl'], $max, $b['anzahl'] . ' (' . $b['anteil'] . ' %)' );
		}
		echo '</div>';

		echo '<div class="oqsc-admin-card"><h2>Verteilung des Index</h2>';
		$maxv = max( 1, max( $stats['verteilung'] ) );
		foreach ( $stats['verteilung'] as $label => $count ) {
			$this->bar( $label, $count, $maxv, (string) $count );
		}
		echo '</div>';

		echo '<div class="oqsc-admin-card"><h2>Schutz</h2><table class="oqsc-admin-mini">';
		$labels = array(
			'limit'           => 'Limits erreicht',
			'token_ungueltig' => 'Ungültige Starts (Bot-Schutz)',
			'pause'           => 'Automatische Pausen',
			'langsam'         => 'Langsame Schritte',
			'fehler'          => 'Fehler',
			'gesperrt'        => 'Gesperrte Ziele (Sperrliste, interne Adressen)',
		);
		foreach ( $labels as $key => $label ) {
			$val = isset( $stats['schutz'][ $key ] ) ? (int) $stats['schutz'][ $key ] : 0;
			echo '<tr><td>' . esc_html( $label ) . '</td><td>' . esc_html( (string) $val ) . '</td></tr>';
		}
		echo '<tr><td>Laufende Checks</td><td>' . esc_html( (string) $stats['laufend'] ) . '</td></tr>';
		echo '<tr><td>Checks heute (Limit gesamt)</td><td>' . esc_html( $stats['checks']['heute_neu'] . ' / ' . OQSC_Plugin::get( 'limit_global_tag' ) ) . '</td></tr>';
		echo '</table></div>';

		echo '</div></div>';
	}

	/**
	 * Kennzahl-Karte.
	 *
	 * @param string $label Bezeichnung.
	 * @param mixed  $value Wert.
	 * @param string $sub   Zusatz.
	 */
	private function kpi( $label, $value, $sub = '' ) {
		echo '<div class="oqsc-admin-card oqsc-admin-kpi"><span>' . esc_html( $label ) . '</span><strong>' . esc_html( (string) $value ) . '</strong>';
		if ( $sub ) {
			echo '<em>' . esc_html( $sub ) . '</em>';
		}
		echo '</div>';
	}

	/**
	 * CSS-Balken.
	 *
	 * @param string   $label Bezeichnung.
	 * @param int|null $value Wert.
	 * @param int      $max   Maximum.
	 * @param string   $text  Anzeige.
	 */
	private function bar( $label, $value, $max, $text ) {
		$pct = null === $value ? 0 : max( 0, min( 100, round( 100 * $value / max( 1, $max ) ) ) );
		echo '<div class="oqsc-bar"><div class="oqsc-bar-label"><span>' . esc_html( $label ) . '</span><b>' . esc_html( $text ) . '</b></div>';
		echo '<div class="oqsc-bar-track"><div class="oqsc-bar-fill" style="width:' . esc_attr( (string) $pct ) . '%"></div></div></div>';
	}

	/**
	 * Checks: Liste oder Detail.
	 */
	public function page_checks() {
		if ( ! current_user_can( 'oqsc_manage' ) ) {
			return;
		}
		global $wpdb;
		$table = $wpdb->prefix . 'oqsc_checks';
		echo '<div class="wrap oqsc-admin">';

		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- nur lesende Filter.
		$id = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
		if ( $id ) {
			$row = OQSC_Admin_Rest::check_detail( $id );
			$this->header( 'Check im Detail', $row ? $row['domain'] : '' );
			echo '<p><a href="' . esc_url( admin_url( 'admin.php?page=oqsc-checks' ) ) . '">&larr; Zurück zur Liste</a></p>';
			if ( ! $row ) {
				echo '<p>Nicht gefunden.</p></div>';
				return;
			}
			$this->render_result( $row );
			echo '</div>';
			return;
		}

		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
		$paged  = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
		// phpcs:enable
		$per    = 30;
		$list   = OQSC_Admin_Rest::checks_list(
			array(
				'suche' => $search,
				'seite' => $paged,
				'pro'   => $per,
			)
		);

		$this->header( 'Checks', $list['gesamt'] . ' Checks gespeichert' );
		echo '<form method="get" class="oqsc-admin-filter"><input type="hidden" name="page" value="oqsc-checks">';
		echo '<input type="search" name="s" value="' . esc_attr( $search ) . '" placeholder="Domain, Ort oder Branche">';
		echo '<button class="button">Suchen</button> ';
		$export = wp_nonce_url( admin_url( 'admin-post.php?action=oqsc_export&art=checks' ), 'oqsc_export' );
		echo '<a class="button button-primary" href="' . esc_url( $export ) . '">CSV-Export</a></form>';

		echo '<div class="oqsc-admin-card oqsc-admin-tablecard"><table class="oqsc-admin-table"><thead><tr><th>Domain</th><th>Index</th><th>Status</th><th>Datum</th><th>Ort</th><th>Branche</th><th>Anfrage</th><th></th></tr></thead><tbody>';
		$branchen = OQSC_Plugin::branchen();
		foreach ( $list['eintraege'] as $c ) {
			$link = admin_url( 'admin.php?page=oqsc-checks&id=' . (int) $c['id'] );
			echo '<tr><td><a href="' . esc_url( $link ) . '">' . esc_html( $c['domain'] ) . '</a>' . ( 'cache' === $c['quelle'] ? ' <span class="oqsc-chip">aus Speicher</span>' : '' ) . '</td>';
			echo '<td>' . ( null === $c['index_wert'] ? '–' : '<span class="oqsc-index ' . esc_attr( $this->index_class( (int) $c['index_wert'] ) ) . '">' . esc_html( (string) $c['index_wert'] ) . '</span>' ) . '</td>';
			echo '<td>' . esc_html( $c['status'] ) . '</td>';
			echo '<td>' . esc_html( $this->date( $c['created_at'] ) ) . '</td>';
			echo '<td>' . esc_html( $c['ort'] ) . '</td>';
			echo '<td>' . esc_html( isset( $branchen[ $c['branche'] ] ) ? $branchen[ $c['branche'] ] : '' ) . '</td>';
			echo '<td>' . ( $c['anfrage'] ? '<span class="oqsc-chip oqsc-chip-ok">ja</span>' : 'nein' ) . '</td>';
			echo '<td><a href="' . esc_url( $link ) . '">Ansehen</a></td></tr>';
		}
		if ( empty( $list['eintraege'] ) ) {
			echo '<tr><td colspan="8">Noch keine Checks.</td></tr>';
		}
		echo '</tbody></table></div>';
		$this->pagination( $list['gesamt'], $per, $paged, array( 's' => $search ), 'oqsc-checks' );
		echo '</div>';
	}

	/**
	 * Seitenblättern.
	 *
	 * @param int    $total Gesamt.
	 * @param int    $per   Pro Seite.
	 * @param int    $paged Aktuelle Seite.
	 * @param array  $args  Weitere Parameter.
	 * @param string $page  Seiten-Slug.
	 */
	private function pagination( $total, $per, $paged, $args, $page ) {
		$pages = (int) ceil( $total / $per );
		if ( $pages < 2 ) {
			return;
		}
		echo '<p class="oqsc-admin-pages">';
		for ( $i = 1; $i <= $pages; $i++ ) {
			$url = add_query_arg( array_merge( $args, array( 'page' => $page, 'paged' => $i ) ), admin_url( 'admin.php' ) );
			if ( $i === $paged ) {
				echo '<strong>' . esc_html( (string) $i ) . '</strong> ';
			} else {
				echo '<a href="' . esc_url( $url ) . '">' . esc_html( (string) $i ) . '</a> ';
			}
		}
		echo '</p>';
	}

	/**
	 * CSS-Klasse je Indexwert.
	 *
	 * @param int $v Wert.
	 * @return string
	 */
	private function index_class( $v ) {
		if ( $v >= 85 ) {
			return 'is-gut';
		}
		if ( $v >= 50 ) {
			return 'is-mittel';
		}
		return 'is-schlecht';
	}

	/**
	 * Datum lokal.
	 *
	 * @param string $mysql UTC-Datum.
	 * @return string
	 */
	private function date( $mysql ) {
		if ( ! $mysql ) {
			return '';
		}
		return wp_date( 'd.m.Y H:i', strtotime( $mysql . ' UTC' ) );
	}

	/**
	 * Ergebnis serverseitig darstellen (alles escaped).
	 *
	 * @param array $row Check mit Ergebnis.
	 */
	private function render_result( $row ) {
		$r = $row['ergebnis'];
		echo '<div class="oqsc-admin-grid oqsc-admin-kpis">';
		$this->kpi( 'Index', isset( $r['index'] ) ? $r['index'] : '–', isset( $r['einordnung']['label'] ) ? $r['einordnung']['label'] : '' );
		$this->kpi( 'Datum', $this->date( $row['created_at'] ) );
		$this->kpi( 'Ort / Branche', $row['ort'] ? $row['ort'] : '–', $row['branche_label'] );
		$this->kpi( 'Status', $row['status'], $row['fehler'] ? $row['fehler'] : '' );
		echo '</div>';

		if ( empty( $r ) ) {
			echo '<div class="oqsc-admin-card"><p>Für diesen Check liegt kein Ergebnis vor.</p></div>';
			return;
		}

		$result_url = $this->result_url( $row['token'] );
		if ( $result_url ) {
			echo '<p><a class="button" target="_blank" rel="noopener" href="' . esc_url( $result_url ) . '">Ergebnis wie Besucher ansehen</a></p>';
		}

		echo '<div class="oqsc-admin-card"><h2>Einordnung</h2><p>' . esc_html( isset( $r['einordnung']['satz'] ) ? $r['einordnung']['satz'] : '' ) . '</p>';
		foreach ( $r['saeulen'] as $s ) {
			$this->bar( $s['name'], $s['wert'], 100, null === $s['wert'] ? 'nicht prüfbar' : $s['wert'] . ' / 100' );
		}
		echo '</div>';

		if ( ! empty( $row['vertriebsnotiz'] ) ) {
			$n = $row['vertriebsnotiz'];
			echo '<div class="oqsc-admin-card oqsc-admin-note"><h2>Interne Vertriebsnotiz</h2>';
			echo '<p><strong>Auftragspotenzial: ' . esc_html( $n['potenzial'] ) . '</strong> (' . esc_html( $n['begruendung'] ) . ')</p><ul>';
			foreach ( $n['leistungen'] as $l ) {
				echo '<li><a href="' . esc_url( $l['url'] ) . '" target="_blank" rel="noopener">' . esc_html( $l['name'] ) . '</a>: ' . esc_html( implode( ', ', $l['gruende'] ) ) . '</li>';
			}
			echo '</ul></div>';
		}

		if ( ! empty( $r['hebel'] ) ) {
			echo '<div class="oqsc-admin-card"><h2>Die drei wichtigsten Hebel</h2><ol>';
			foreach ( $r['hebel'] as $h ) {
				echo '<li><strong>' . esc_html( $h['titel'] ) . '</strong> (' . esc_html( $h['saeule_name'] ) . ', ' . esc_html( 'selbst' === $h['aufwand'] ? 'selbst machbar' : 'mit Fachhilfe' ) . '): ' . esc_html( $h['befund'] ) . '</li>';
			}
			echo '</ol></div>';
		}

		echo '<div class="oqsc-admin-card"><h2>Alle Prüfungen</h2><table class="oqsc-admin-table"><thead><tr><th>ID</th><th>Prüfung</th><th>Status</th><th>Befund</th></tr></thead><tbody>';
		foreach ( $r['pruefungen'] as $p ) {
			echo '<tr><td>' . esc_html( $p['id'] ) . '</td><td>' . esc_html( $p['titel'] ) . '</td><td><span class="oqsc-chip oqsc-st-' . esc_attr( $p['status'] ) . '">' . esc_html( OQSC_Score::status_label( $p['status'] ) ) . '</span></td><td>' . esc_html( $p['befund'] ) . '</td></tr>';
		}
		echo '</tbody></table></div>';
	}

	/**
	 * Ergebnis-Link für Besucher.
	 *
	 * @param string $token Token.
	 * @return string
	 */
	private function result_url( $token ) {
		$base = OQSC_Plugin::get( 'check_seite_url', '' );
		if ( ! $base ) {
			return '';
		}
		return add_query_arg( 'oqcheck', $token, $base );
	}

	/**
	 * Anfragen: Liste oder Detail.
	 */
	public function page_leads() {
		if ( ! current_user_can( 'oqsc_manage' ) ) {
			return;
		}
		echo '<div class="wrap oqsc-admin">';
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- nur lesende Filter.
		$id     = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
		$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
		$paged  = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
		$saved  = isset( $_GET['gespeichert'] );
		// phpcs:enable
		$labels = OQSC_Leads::status_labels();

		if ( $id ) {
			$lead = OQSC_Admin_Rest::lead_detail( $id );
			$this->header( 'Anfrage', $lead ? $lead['name'] : '' );
			echo '<p><a href="' . esc_url( admin_url( 'admin.php?page=oqsc-leads' ) ) . '">&larr; Zurück zur Liste</a></p>';
			if ( ! $lead ) {
				echo '<p>Nicht gefunden.</p></div>';
				return;
			}
			if ( $saved ) {
				echo '<div class="notice notice-success"><p>Gespeichert.</p></div>';
			}
			echo '<div class="oqsc-admin-grid oqsc-admin-two"><div class="oqsc-admin-card"><h2>Kontakt</h2><table class="oqsc-admin-mini">';
			echo '<tr><td>Name</td><td>' . esc_html( $lead['name'] ) . '</td></tr>';
			echo '<tr><td>E-Mail</td><td><a href="' . esc_url( 'mailto:' . $lead['email'] ) . '">' . esc_html( $lead['email'] ) . '</a></td></tr>';
			echo '<tr><td>Telefon</td><td>' . esc_html( $lead['telefon'] ) . '</td></tr>';
			echo '<tr><td>Eingang</td><td>' . esc_html( $this->date( $lead['created_at'] ) ) . '</td></tr>';
			echo '<tr><td>Nachricht</td><td>' . nl2br( esc_html( $lead['nachricht'] ) ) . '</td></tr>';
			echo '<tr><td>Einwilligung</td><td><small>' . esc_html( $lead['einwilligung_text'] ) . '<br>' . esc_html( $this->date( $lead['einwilligung_zeit'] ) ) . '</small></td></tr>';
			echo '</table></div>';

			echo '<div class="oqsc-admin-card"><h2>Bearbeitung</h2><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			wp_nonce_field( 'oqsc_lead_update' );
			echo '<input type="hidden" name="action" value="oqsc_lead_update"><input type="hidden" name="id" value="' . esc_attr( (string) $lead['id'] ) . '">';
			echo '<p><label>Status<br><select name="status">';
			foreach ( $labels as $k => $l ) {
				echo '<option value="' . esc_attr( $k ) . '"' . selected( $lead['status'], $k, false ) . '>' . esc_html( $l ) . '</option>';
			}
			echo '</select></label></p><p><label>Interne Notiz<br><textarea name="notiz" rows="5" class="large-text">' . esc_textarea( (string) $lead['notiz'] ) . '</textarea></label></p>';
			echo '<p><button class="button button-primary">Speichern</button></p></form></div></div>';

			if ( $lead['check'] ) {
				echo '<h2 class="oqsc-admin-h2">Befund zur Anfrage: ' . esc_html( $lead['check']['domain'] ) . '</h2>';
				$this->render_result( $lead['check'] );
			}
			echo '</div>';
			return;
		}

		$per  = 30;
		$list = OQSC_Admin_Rest::leads_list(
			array(
				'status' => $status,
				'seite'  => $paged,
				'pro'    => $per,
			)
		);
		$this->header( 'Anfragen', $list['gesamt'] . ' Anfragen' );
		echo '<form method="get" class="oqsc-admin-filter"><input type="hidden" name="page" value="oqsc-leads"><select name="status"><option value="">Alle Status</option>';
		foreach ( $labels as $k => $l ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $status, $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select> <button class="button">Filtern</button> ';
		$export = wp_nonce_url( admin_url( 'admin-post.php?action=oqsc_export&art=leads' ), 'oqsc_export' );
		echo '<a class="button button-primary" href="' . esc_url( $export ) . '">CSV-Export</a></form>';

		echo '<div class="oqsc-admin-card oqsc-admin-tablecard"><table class="oqsc-admin-table"><thead><tr><th>Name</th><th>E-Mail</th><th>Domain</th><th>Index</th><th>Status</th><th>Eingang</th></tr></thead><tbody>';
		foreach ( $list['eintraege'] as $l ) {
			$link = admin_url( 'admin.php?page=oqsc-leads&id=' . (int) $l['id'] );
			echo '<tr><td><a href="' . esc_url( $link ) . '">' . esc_html( $l['name'] ) . '</a></td><td>' . esc_html( $l['email'] ) . '</td><td>' . esc_html( $l['domain'] ) . '</td>';
			echo '<td>' . esc_html( null === $l['index_wert'] ? '–' : (string) $l['index_wert'] ) . '</td>';
			echo '<td><span class="oqsc-chip oqsc-lead-' . esc_attr( $l['status'] ) . '">' . esc_html( isset( $labels[ $l['status'] ] ) ? $labels[ $l['status'] ] : $l['status'] ) . '</span></td>';
			echo '<td>' . esc_html( $this->date( $l['created_at'] ) ) . '</td></tr>';
		}
		if ( empty( $list['eintraege'] ) ) {
			echo '<tr><td colspan="6">Noch keine Anfragen.</td></tr>';
		}
		echo '</tbody></table></div>';
		$this->pagination( $list['gesamt'], $per, $paged, array( 'status' => $status ), 'oqsc-leads' );
		echo '</div>';
	}

	/**
	 * Anfrage aktualisieren.
	 */
	public function lead_update() {
		if ( ! current_user_can( 'oqsc_manage' ) ) {
			wp_die( 'Keine Berechtigung.' );
		}
		check_admin_referer( 'oqsc_lead_update' );
		$id     = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$status = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : '';
		$notiz  = isset( $_POST['notiz'] ) ? sanitize_textarea_field( wp_unslash( $_POST['notiz'] ) ) : '';
		OQSC_Leads::update( $id, $status, $notiz );
		wp_safe_redirect( admin_url( 'admin.php?page=oqsc-leads&id=' . $id . '&gespeichert=1' ) );
		exit;
	}

	/**
	 * Einstellungen.
	 */
	public function page_settings() {
		if ( ! current_user_can( 'oqsc_manage' ) ) {
			return;
		}
		$s = OQSC_Plugin::settings();
		echo '<div class="wrap oqsc-admin">';
		$this->header( 'Einstellungen', 'Limits, PageSpeed, Anfragen, Texte und Datenschutz' );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- nur Anzeige einer Bestätigung.
		if ( isset( $_GET['gespeichert'] ) ) {
			echo '<div class="notice notice-success"><p>Einstellungen gespeichert.</p></div>';
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="oqsc-admin-form">';
		wp_nonce_field( 'oqsc_save_settings' );
		echo '<input type="hidden" name="action" value="oqsc_save_settings">';

		echo '<div class="oqsc-admin-grid oqsc-admin-two">';

		echo '<div class="oqsc-admin-card"><h2>Schutz und Limits</h2>';
		$this->field_number( 'max_parallel', 'Gleichzeitig laufende Checks', $s );
		$this->field_number( 'limit_stunde', 'Checks pro Besucher und Stunde', $s );
		$this->field_number( 'limit_tag', 'Checks pro Besucher und Tag', $s );
		$this->field_number( 'limit_global_tag', 'Checks insgesamt pro Tag', $s );
		$this->field_number( 'cache_stunden', 'Ergebnis je Domain zwischenspeichern (Stunden)', $s );
		$this->field_number( 'recheck_minuten', '„Erneut prüfen“ je Domain frühestens nach (Minuten)', $s );
		$this->field_number( 'mindestzeit', 'Mindestzeit vor dem Start (Sekunden)', $s );
		$this->field_number( 'pow_bits', 'Rechenbeweis: Schwierigkeit in Bit (16 = vier Nullen)', $s );
		echo '</div>';

		echo '<div class="oqsc-admin-card"><h2>Not-Aus</h2>';
		$this->field_check( 'wartung', 'Wartungsmodus: keine neuen Checks', $s );
		$this->field_number( 'notaus_langsam_anzahl', 'Pause, wenn in 5 Minuten mehr als … Schritte langsam sind', $s );
		$this->field_number( 'notaus_langsam_sek', 'Als langsam gilt ein Schritt ab (Sekunden)', $s );
		$this->field_number( 'notaus_fehlerquote', 'Pause ab Fehlerquote in 5 Minuten (Prozent)', $s );
		$this->field_number( 'notaus_pause_min', 'Dauer der automatischen Pause (Minuten)', $s );
		$this->field_check( 'testmodus', 'Testmodus: Limits und Mindestzeit gelten nicht für angemeldete Administratoren', $s );
		echo '</div>';

		echo '<div class="oqsc-admin-card"><h2>PageSpeed Insights</h2>';
		$this->field_check( 'psi_aktiv', 'PageSpeed-Messung durchführen', $s );
		$masked = $s['psi_key'] ? str_repeat( '•', 8 ) . substr( $s['psi_key'], -4 ) : '';
		echo '<p><label>API-Schlüssel<br><input type="text" name="psi_key" value="" placeholder="' . esc_attr( $masked ? $masked : 'kein Schlüssel hinterlegt' ) . '" class="regular-text" autocomplete="off"></label><br><small>Leer lassen behält den gespeicherten Schlüssel. Ein einzelnes Minus (-) löscht ihn. Der Schlüssel wird nie angezeigt.</small></p>';
		echo '</div>';

		echo '<div class="oqsc-admin-card"><h2>Anfragen und Links</h2>';
		$this->field_text( 'empfaenger', 'Empfänger für Anfragen (E-Mail)', $s, 'email' );
		$this->field_text( 'check_seite_url', 'Adresse der Seite mit dem Check (für Ergebnis-Links, kompakte Variante, Kennung beim Abruf)', $s, 'url' );
		$this->field_text( 'analyse_url', 'Ziel-Link „persönliche Analyse“', $s, 'url' );
		$this->field_text( 'datenschutz_url', 'Link zur Datenschutzerklärung (leer: WordPress-Datenschutzseite)', $s, 'url' );
		$this->field_text( 'leistung_basis', 'Basis-Adresse für Leistungs-Links in der Vertriebsnotiz', $s, 'url' );
		$this->field_area( 'einwilligung_text', 'Einwilligungstext im Anfrageformular', $s );
		echo '</div>';

		echo '<div class="oqsc-admin-card"><h2>Texte im Tool</h2>';
		$this->field_text( 'ueberschrift', 'Überschrift', $s );
		$this->field_area( 'einleitung', 'Einleitung', $s );
		$this->field_area( 'abschluss', 'Abschluss („Was ein Werkzeug nicht sieht“)', $s );
		echo '</div>';

		echo '<div class="oqsc-admin-card"><h2>Aufbewahrung und Sonstiges</h2>';
		$this->field_number( 'ergebnis_tage', 'Ergebnis-Link gültig (Tage)', $s );
		$this->field_number( 'aufbewahrung_checks', 'Checks ohne Anfrage löschen nach (Tagen)', $s );
		$this->field_number( 'aufbewahrung_leads', 'Anfragen löschen nach (Monaten)', $s );
		$this->field_area( 'sperrliste', 'Sperrliste (eine Domain pro Zeile, *.beispiel.de erlaubt)', $s );
		$this->field_text( 'seiten_ids', 'Skripte auch ohne Shortcode laden auf Seiten-ID (kommagetrennt)', $s );
		$this->field_check( 'daten_loeschen', 'Beim Löschen des Plugins alle Daten entfernen', $s );
		echo '</div>';

		echo '</div><p><button class="button button-primary button-hero">Einstellungen speichern</button></p></form></div>';
	}

	/**
	 * Zahlenfeld.
	 *
	 * @param string $key   Schlüssel.
	 * @param string $label Bezeichnung.
	 * @param array  $s     Einstellungen.
	 */
	private function field_number( $key, $label, $s ) {
		echo '<p><label>' . esc_html( $label ) . '<br><input type="number" name="' . esc_attr( $key ) . '" value="' . esc_attr( (string) $s[ $key ] ) . '" class="small-text"></label></p>';
	}

	/**
	 * Textfeld.
	 *
	 * @param string $key   Schlüssel.
	 * @param string $label Bezeichnung.
	 * @param array  $s     Einstellungen.
	 * @param string $type  Feldtyp.
	 */
	private function field_text( $key, $label, $s, $type = 'text' ) {
		echo '<p><label>' . esc_html( $label ) . '<br><input type="' . esc_attr( $type ) . '" name="' . esc_attr( $key ) . '" value="' . esc_attr( (string) $s[ $key ] ) . '" class="regular-text"></label></p>';
	}

	/**
	 * Textbereich.
	 *
	 * @param string $key   Schlüssel.
	 * @param string $label Bezeichnung.
	 * @param array  $s     Einstellungen.
	 */
	private function field_area( $key, $label, $s ) {
		echo '<p><label>' . esc_html( $label ) . '<br><textarea name="' . esc_attr( $key ) . '" rows="4" class="large-text">' . esc_textarea( (string) $s[ $key ] ) . '</textarea></label></p>';
	}

	/**
	 * Kontrollkästchen.
	 *
	 * @param string $key   Schlüssel.
	 * @param string $label Bezeichnung.
	 * @param array  $s     Einstellungen.
	 */
	private function field_check( $key, $label, $s ) {
		echo '<p><label><input type="hidden" name="' . esc_attr( $key ) . '" value="0"><input type="checkbox" name="' . esc_attr( $key ) . '" value="1"' . checked( ! empty( $s[ $key ] ), true, false ) . '> ' . esc_html( $label ) . '</label></p>';
	}

	/**
	 * Einstellungen speichern.
	 */
	public function save_settings() {
		if ( ! current_user_can( 'oqsc_manage' ) ) {
			wp_die( 'Keine Berechtigung.' );
		}
		check_admin_referer( 'oqsc_save_settings' );
		$keys  = array_keys( OQSC_Install::defaults() );
		$input = array();
		foreach ( $keys as $key ) {
			if ( isset( $_POST[ $key ] ) ) {
				$input[ $key ] = wp_unslash( $_POST[ $key ] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- wird in sanitize_settings je Feld bereinigt.
			}
		}
		OQSC_Plugin::save_settings( $input );
		wp_safe_redirect( admin_url( 'admin.php?page=oqsc-settings&gespeichert=1' ) );
		exit;
	}

	/**
	 * Datenschutz-Baustein.
	 */
	public function page_privacy() {
		if ( ! current_user_can( 'oqsc_manage' ) ) {
			return;
		}
		echo '<div class="wrap oqsc-admin">';
		$this->header( 'Datenschutz-Baustein', 'Textvorschlag für die Datenschutzerklärung von oriqen.de' );
		echo '<div class="oqsc-admin-alert oqsc-admin-alert-soft">Dies ist ein Vorschlag, keine Rechtsberatung. Bitte von der IT-Recht Kanzlei prüfen lassen, bevor Sie ihn veröffentlichen.</div>';
		echo '<div class="oqsc-admin-card"><textarea class="large-text code" rows="30" readonly onclick="this.select()">' . esc_textarea( self::privacy_text() ) . '</textarea></div></div>';
	}

	/**
	 * Textvorschlag Datenschutz (auch für docs/DATENSCHUTZ-BAUSTEIN.md).
	 *
	 * @return string
	 */
	public static function privacy_text() {
		$s = OQSC_Plugin::settings();
		return "Sichtbarkeits-Check für Websites\n\n"
			. "Auf unserer Website bieten wir einen kostenlosen Sichtbarkeits-Check an. Sie geben dort die Adresse einer Website ein und können freiwillig einen Ort und eine Branche angeben. Unser Server ruft daraufhin öffentlich zugängliche Inhalte dieser Website ab (Startseite, robots.txt, Sitemap, llms.txt, Impressum, Datenschutzerklärung, Kontaktseite, einige Stylesheets, Bilder und Links) und wertet sie automatisch aus.\n\n"
			. "Verarbeitete Daten: die geprüfte Website-Adresse, Ihre optionalen Angaben zu Ort und Branche, das Ergebnis der Prüfung, der Zeitpunkt sowie ein Prüfwert (Hash) Ihrer IP-Adresse. Der Hash wird mit einem täglich wechselnden Schlüssel gebildet und lässt keinen Rückschluss auf Ihre IP-Adresse zu. Ihre IP-Adresse selbst speichern wir nicht.\n\n"
			. "Zweck: Durchführung des Checks, Bereitstellung des Ergebnisses über einen persönlichen Link, Schutz vor Missbrauch und Überlastung (Begrenzung der Anzahl der Prüfungen) sowie anonyme Auswertungen, welche Probleme häufig vorkommen.\n\n"
			. "Rechtsgrundlage: Art. 6 Abs. 1 lit. b DSGVO (Durchführung des von Ihnen angeforderten Checks) und Art. 6 Abs. 1 lit. f DSGVO (berechtigtes Interesse an Sicherheit und Stabilität unserer Website sowie an der Verbesserung unseres Angebots).\n\n"
			. 'Speicherdauer: Das Ergebnis ist über den Ergebnis-Link ' . (int) $s['ergebnis_tage'] . ' Tage abrufbar. Checks ohne Anfrage löschen wir nach ' . (int) $s['aufbewahrung_checks'] . " Tagen. Einträge zum Schutz vor Missbrauch löschen wir nach 30 Tagen.\n\n"
			. "Messung der Ladezeit mit Google PageSpeed Insights: Zur Messung der Ladezeit übermittelt unser Server die Adresse der geprüften Website an die PageSpeed-Insights-Schnittstelle der Google Ireland Limited, Gordon House, Barrow Street, Dublin 4, Irland. Die Anfrage geht von unserem Server aus, nicht von Ihrem Browser. Google erhält dabei keine Daten über Sie als Besucher, sondern nur die Adresse der geprüften Website. Google ruft diese Website zur Messung selbst auf.\n\n"
			. "Cookies und Speicher im Browser: Der Check setzt keine Cookies und speichert nichts dauerhaft in Ihrem Browser. Er lädt keine Inhalte von fremden Servern in Ihren Browser.\n\n"
			. "Anfrage zur persönlichen Analyse: Wenn Sie im Anschluss an den Check eine persönliche Analyse anfordern, verarbeiten wir Ihren Namen, Ihre E-Mail-Adresse, optional Ihre Telefonnummer und Ihre Nachricht zusammen mit dem Ergebnis des Checks, um Ihre Anfrage zu bearbeiten und Sie zu kontaktieren. Rechtsgrundlage ist Ihre Einwilligung nach Art. 6 Abs. 1 lit. a DSGVO sowie Art. 6 Abs. 1 lit. b DSGVO (vorvertragliche Maßnahmen). Sie können Ihre Einwilligung jederzeit mit Wirkung für die Zukunft widerrufen. Wir speichern Anfragen höchstens " . (int) $s['aufbewahrung_leads'] . " Monate, soweit keine gesetzlichen Aufbewahrungspflichten bestehen. Die Anfrage wird per E-Mail an uns übermittelt.\n\n"
			. 'Hinweis: Dieser Textvorschlag ersetzt keine Rechtsberatung. Bitte lassen Sie ihn von einer Fachstelle, etwa der IT-Recht Kanzlei, prüfen.';
	}
}
