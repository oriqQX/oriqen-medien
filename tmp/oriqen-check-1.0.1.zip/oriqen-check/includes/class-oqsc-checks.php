<?php
/**
 * Alle Prüfungen aus PRUEFKATALOG.md. Je Prüfung eine Methode.
 *
 * Jede Methode bekommt die gesammelten Daten und den Kontext (Ort, Branche, Jahr)
 * und liefert status (gut|verbesserbar|kritisch|hinweis|nicht_pruefbar), befund (ein Satz
 * mit dem konkreten Fund) und werte (Zahlen für Darstellung und Statistik).
 *
 * @package oriqen-check
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Prüfkatalog.
 */
class OQSC_Checks {

	/**
	 * Säulen: Schlüssel => Name, Gewicht im Index.
	 *
	 * @return array
	 */
	public static function pillars() {
		return array(
			'gefunden'     => array( 'Gefunden', 20 ),
			'vor_ort'      => array( 'Vor Ort', 20 ),
			'schnell'      => array( 'Schnell', 15 ),
			'ueberzeugend' => array( 'Überzeugend', 20 ),
			'rechtssicher' => array( 'Rechtssicher', 15 ),
			'ki'           => array( 'KI-bereit', 10 ),
		);
	}

	/**
	 * Katalog: ID => Säule, Gewicht (0 = Hinweis, zählt nicht).
	 *
	 * @return array
	 */
	public static function catalog() {
		return array(
			'G01' => array( 'gefunden', 5 ),
			'G02' => array( 'gefunden', 5 ),
			'G03' => array( 'gefunden', 4 ),
			'G04' => array( 'gefunden', 3 ),
			'G05' => array( 'gefunden', 3 ),
			'G06' => array( 'gefunden', 2 ),
			'G07' => array( 'gefunden', 2 ),
			'G08' => array( 'gefunden', 2 ),
			'G09' => array( 'gefunden', 1 ),
			'G10' => array( 'gefunden', 2 ),
			'G11' => array( 'gefunden', 1 ),
			'G12' => array( 'gefunden', 1 ),
			'G13' => array( 'gefunden', 1 ),
			'G14' => array( 'gefunden', 2 ),
			'L01' => array( 'vor_ort', 4 ),
			'L02' => array( 'vor_ort', 3 ),
			'L03' => array( 'vor_ort', 4 ),
			'L04' => array( 'vor_ort', 4 ),
			'L05' => array( 'vor_ort', 3 ),
			'L06' => array( 'vor_ort', 1 ),
			'L07' => array( 'vor_ort', 2 ),
			'L08' => array( 'vor_ort', 0 ),
			'S01' => array( 'schnell', 5 ),
			'S02' => array( 'schnell', 3 ),
			'S03' => array( 'schnell', 2 ),
			'S04' => array( 'schnell', 2 ),
			'S05' => array( 'schnell', 3 ),
			'S06' => array( 'schnell', 2 ),
			'S07' => array( 'schnell', 1 ),
			'S08' => array( 'schnell', 4 ),
			'S09' => array( 'schnell', 1 ),
			'U01' => array( 'ueberzeugend', 4 ),
			'U02' => array( 'ueberzeugend', 4 ),
			'U03' => array( 'ueberzeugend', 2 ),
			'U04' => array( 'ueberzeugend', 3 ),
			'U05' => array( 'ueberzeugend', 2 ),
			'U06' => array( 'ueberzeugend', 5 ),
			'U07' => array( 'ueberzeugend', 2 ),
			'U08' => array( 'ueberzeugend', 1 ),
			'U09' => array( 'ueberzeugend', 0 ),
			'R01' => array( 'rechtssicher', 5 ),
			'R02' => array( 'rechtssicher', 3 ),
			'R03' => array( 'rechtssicher', 5 ),
			'R04' => array( 'rechtssicher', 3 ),
			'R05' => array( 'rechtssicher', 4 ),
			'R06' => array( 'rechtssicher', 5 ),
			'R07' => array( 'rechtssicher', 2 ),
			'R08' => array( 'rechtssicher', 2 ),
			'R09' => array( 'rechtssicher', 0 ),
			'R10' => array( 'rechtssicher', 0 ),
			'R11' => array( 'rechtssicher', 2 ),
			'R12' => array( 'rechtssicher', 2 ),
			'K01' => array( 'ki', 3 ),
			'K02' => array( 'ki', 1 ),
			'K03' => array( 'ki', 4 ),
			'K04' => array( 'ki', 2 ),
			'K05' => array( 'ki', 3 ),
			'K06' => array( 'ki', 1 ),
			'K07' => array( 'ki', 2 ),
		);
	}

	/**
	 * Begriffe je Branche für „Leistung erkennbar“.
	 *
	 * @return array
	 */
	public static function branch_terms() {
		return array(
			'handwerk'       => array( 'tischler', 'schreiner', 'elektr', 'sanitär', 'sanitaer', 'heizung', 'klima', 'maler', 'lackier', 'dach', 'zimmerei', 'zimmerer', 'fliesen', 'bodenleger', 'parkett', 'maurer', 'metallbau', 'schlosser', 'glaser', 'installat', 'kfz', 'werkstatt', 'handwerk', 'meisterbetrieb', 'raumausstatt', 'gerüst', 'galabau', 'garten- und landschaftsbau', 'steinmetz', 'schornstein', 'fenster', 'türen', 'treppen', 'möbel', 'photovoltaik', 'solar', 'bad' ),
			'kueche'         => array( 'küche', 'kueche', 'einbauküche', 'küchenstudio', 'möbel', 'einrichtung', 'wohnen', 'innenarchitekt', 'raumdesign', 'schrank', 'interior', 'planung', 'bad', 'wohnraum' ),
			'bau'            => array( 'bau', 'rohbau', 'ausbau', 'sanierung', 'renovierung', 'trockenbau', 'hausbau', 'architekt', 'modernisierung', 'umbau', 'abbruch', 'estrich', 'putz', 'dämmung', 'fassade', 'pflaster', 'tiefbau', 'fertighaus', 'massivhaus', 'baugeschäft' ),
			'gesundheit'     => array( 'praxis', 'arzt', 'ärztin', 'zahnarzt', 'zahnärzt', 'physiotherap', 'ergotherap', 'heilpraktik', 'therapie', 'pflege', 'apotheke', 'logopäd', 'osteopath', 'psycho', 'kosmetik', 'massage', 'podolog', 'hörakustik', 'optiker', 'tierarzt', 'hebamme', 'medizin', 'behandlung', 'prophylaxe' ),
			'gastronomie'    => array( 'restaurant', 'café', 'cafe', 'bistro', 'imbiss', 'gaststätte', 'gasthof', 'gasthaus', 'hotel', 'catering', 'bar ', 'pizzeria', 'speisekarte', 'essen', 'frühstück', 'mittagstisch', 'bäckerei', 'konditorei', 'metzgerei', 'eiscafé', 'küche', 'brauhaus', 'biergarten' ),
			'handel'         => array( 'shop', 'laden', 'geschäft', 'fachhandel', 'fachgeschäft', 'verkauf', 'boutique', 'sortiment', 'markt', 'händler', 'großhandel', 'einzelhandel', 'onlineshop', 'online-shop', 'kaufen', 'produkte' ),
			'dienstleistung' => array( 'beratung', 'agentur', 'service', 'dienstleist', 'steuerberat', 'rechtsanwalt', 'anwalt', 'kanzlei', 'versicherung', 'makler', 'immobilien', 'reinigung', 'umzug', 'fahrschule', 'friseur', 'coaching', 'buchhaltung', 'fotograf', 'hausmeister', 'sicherheitsdienst', 'pflegedienst', 'transport', 'logistik', 'webdesign', 'marketing', 'it-service', 'schulung' ),
		);
	}

	/**
	 * Alle Prüfungen ausführen.
	 *
	 * @param array $data    Gesammelte Daten.
	 * @param array $context ort, branche, jahr.
	 * @return array Liste der Prüfergebnisse (roh, ohne Texte).
	 */
	public static function run_all( $data, $context ) {
		$ctx = self::prepare( $data, $context );
		$out = array();
		foreach ( self::catalog() as $id => $meta ) {
			$method = 'check_' . strtolower( $id );
			try {
				$r = self::$method( $data, $ctx );
			} catch ( Throwable $e ) {
				$r = self::np( 'Diese Prüfung konnte nicht ausgewertet werden.' );
			}
			$r['id']      = $id;
			$r['saeule']  = $meta[0];
			$r['gewicht'] = $meta[1];
			if ( ! isset( $r['werte'] ) ) {
				$r['werte'] = array();
			}
			$out[ $id ] = $r;
		}
		return $out;
	}

	/**
	 * Vorbereitung: Ort, Branche, Seitendaten.
	 *
	 * @param array $data    Daten.
	 * @param array $context Kontext.
	 * @return array
	 */
	public static function prepare( $data, $context ) {
		$page = isset( $data['page'] ) && is_array( $data['page'] ) ? $data['page'] : array();
		$ort  = isset( $context['ort'] ) ? trim( (string) $context['ort'] ) : '';
		$ort_quelle = $ort ? 'angegeben' : '';
		if ( ! $ort && ! empty( $page['business']['ort'] ) ) {
			$ort        = $page['business']['ort'];
			$ort_quelle = 'erkannt';
		}
		if ( ! $ort && ! empty( $page['addresses'] ) ) {
			foreach ( $page['addresses'] as $a ) {
				if ( $a['strasse'] ) {
					$ort        = $a['ort'];
					$ort_quelle = 'erkannt';
					break;
				}
			}
		}
		if ( ! $ort && ! empty( $data['impressum']['inhalt']['addresses'] ) ) {
			$ort        = $data['impressum']['inhalt']['addresses'][0]['ort'];
			$ort_quelle = 'erkannt';
		}
		// Ortsnamen ohne Zusätze wie „Paderborn (Elsen)“ oder „Bielefeld Mitte“, Doppelnamen bleiben ganz.
		$ort_kern = trim( preg_replace( '/[\s(,\/].*$/u', '', $ort ) );
		return array(
			'page'       => $page,
			'ort'        => $ort,
			'ort_kern'   => $ort_kern ? $ort_kern : $ort,
			'ort_quelle' => $ort_quelle,
			'branche'    => isset( $context['branche'] ) ? (string) $context['branche'] : '',
			'jahr'       => isset( $context['jahr'] ) ? (int) $context['jahr'] : (int) gmdate( 'Y' ),
			'https'      => ! empty( $data['home']['https'] ),
			'psi'        => isset( $data['psi'] ) && ! empty( $data['psi']['ok'] ) ? $data['psi'] : null,
		);
	}

	/* ------------------------------------------------------------------
	 * Hilfen
	 * ---------------------------------------------------------------- */

	/**
	 * Ergebnis bauen.
	 *
	 * @param string $status Status.
	 * @param string $befund Befund.
	 * @param array  $werte  Werte.
	 * @return array
	 */
	private static function r( $status, $befund, $werte = array() ) {
		return array(
			'status' => $status,
			'befund' => $befund,
			'werte'  => $werte,
		);
	}

	/**
	 * Nicht prüfbar.
	 *
	 * @param string $befund Grund.
	 * @return array
	 */
	private static function np( $befund ) {
		return self::r( 'nicht_pruefbar', $befund );
	}

	/**
	 * Ist die Startseite gelesen?
	 *
	 * @param array $ctx Kontext.
	 * @return bool
	 */
	private static function has_page( $ctx ) {
		return ! empty( $ctx['page']['ok'] );
	}

	/**
	 * Enthält ein Text einen Begriff (ohne Groß und Klein, ganze Wörter)?
	 *
	 * @param string $text   Text.
	 * @param string $needle Begriff.
	 * @return bool
	 */
	public static function contains_word( $text, $needle ) {
		$needle = trim( (string) $needle );
		if ( '' === $needle ) {
			return false;
		}
		$hay = mb_strtolower( (string) $text );
		if ( preg_match( '/(?<![\p{L}\p{N}])' . preg_quote( mb_strtolower( $needle ), '/' ) . '/u', $hay ) ) {
			return true;
		}
		// Bei Ortsteilen wie „Paderborn-Elsen“ genügt der Hauptort.
		$parts = explode( '-', $needle );
		if ( count( $parts ) > 1 && mb_strlen( $parts[0] ) >= 4 ) {
			return (bool) preg_match( '/(?<![\p{L}\p{N}])' . preg_quote( mb_strtolower( $parts[0] ), '/' ) . '(?![\p{L}])/u', $hay );
		}
		return false;
	}

	/**
	 * Breite eines Textes in Pixeln in Arial (Breiten je 1000 Einheiten).
	 *
	 * @param string $text Text.
	 * @param int    $size Schriftgröße in px.
	 * @return int
	 */
	public static function text_px( $text, $size = 20 ) {
		static $w = null;
		if ( null === $w ) {
			$w   = array(
				' ' => 278, '!' => 278, '"' => 355, '#' => 556, '$' => 556, '%' => 889, '&' => 667, "'" => 191, '(' => 333, ')' => 333,
				'*' => 389, '+' => 584, ',' => 278, '-' => 333, '.' => 278, '/' => 278, ':' => 278, ';' => 278, '<' => 584, '=' => 584,
				'>' => 584, '?' => 556, '@' => 1015, '[' => 278, '\\' => 278, ']' => 278, '^' => 469, '_' => 556, '`' => 333, '{' => 334,
				'|' => 260, '}' => 334, '~' => 584,
				'A' => 667, 'B' => 667, 'C' => 722, 'D' => 722, 'E' => 667, 'F' => 611, 'G' => 778, 'H' => 722, 'I' => 278, 'J' => 500,
				'K' => 667, 'L' => 556, 'M' => 833, 'N' => 722, 'O' => 778, 'P' => 667, 'Q' => 778, 'R' => 722, 'S' => 667, 'T' => 611,
				'U' => 722, 'V' => 667, 'W' => 944, 'X' => 667, 'Y' => 667, 'Z' => 611,
				'a' => 556, 'b' => 556, 'c' => 500, 'd' => 556, 'e' => 556, 'f' => 278, 'g' => 556, 'h' => 556, 'i' => 222, 'j' => 222,
				'k' => 500, 'l' => 222, 'm' => 833, 'n' => 556, 'o' => 556, 'p' => 556, 'q' => 556, 'r' => 333, 's' => 500, 't' => 278,
				'u' => 556, 'v' => 500, 'w' => 722, 'x' => 500, 'y' => 500, 'z' => 500,
				'ä' => 556, 'ö' => 556, 'ü' => 556, 'Ä' => 667, 'Ö' => 778, 'Ü' => 722, 'ß' => 611, '€' => 556, '–' => 556, '—' => 1000,
				'„' => 333, '“' => 333, '”' => 333, '‚' => 222, '‘' => 222, '’' => 222, '·' => 278, '•' => 350, '©' => 737, '®' => 737,
				'…' => 1000, '»' => 556, '«' => 556, '|' => 260, 'é' => 556, 'è' => 556, 'à' => 556, 'ç' => 500,
			);
			for ( $i = 0; $i <= 9; $i++ ) {
				$w[ (string) $i ] = 556;
			}
		}
		$sum   = 0;
		$chars = preg_split( '//u', (string) $text, -1, PREG_SPLIT_NO_EMPTY );
		foreach ( $chars as $ch ) {
			$sum += isset( $w[ $ch ] ) ? $w[ $ch ] : 556;
		}
		return (int) round( $sum * $size / 1000 );
	}

	/**
	 * Silben eines deutschen Wortes (Vokalgruppen).
	 *
	 * @param string $word Wort.
	 * @return int
	 */
	private static function syllables( $word ) {
		$word = mb_strtolower( $word );
		$n    = preg_match_all( '/[aeiouyäöü]+/u', $word );
		return max( 1, (int) $n );
	}

	/**
	 * Flesch-Wert nach Amstad (deutsche Anpassung).
	 *
	 * @param string $text Text.
	 * @return array wert, woerter, saetze.
	 */
	public static function flesch_amstad( $text ) {
		$sentences = preg_split( '/[.!?:;]+(?=\s|$)/u', (string) $text, -1, PREG_SPLIT_NO_EMPTY );
		$sentences = array_filter(
			$sentences,
			static function ( $s ) {
				return count( OQSC_Parser::words( $s ) ) > 0;
			}
		);
		$words     = array();
		foreach ( OQSC_Parser::words( $text ) as $w ) {
			$w = preg_replace( '/[^\p{L}\p{N}\-]/u', '', $w );
			if ( '' !== $w && preg_match( '/\p{L}/u', $w ) ) {
				$words[] = $w;
			}
		}
		$wc = count( $words );
		$sc = max( 1, count( $sentences ) );
		if ( ! $wc ) {
			return array(
				'wert'    => 0,
				'woerter' => 0,
				'saetze'  => 0,
			);
		}
		$syl = 0;
		foreach ( $words as $w ) {
			$syl += self::syllables( $w );
		}
		$asl   = $wc / $sc;
		$asw   = $syl / $wc;
		$score = 180 - $asl - ( 58.5 * $asw );
		return array(
			'wert'    => (int) round( max( 0, min( 100, $score ) ) ),
			'woerter' => $wc,
			'saetze'  => count( $sentences ),
		);
	}

	/**
	 * Ist der Text der H1 aussagekräftig (nicht „Willkommen“, „Home“)?
	 *
	 * @param string $h1 Text.
	 * @return bool
	 */
	private static function h1_meaningful( $h1 ) {
		$h1 = trim( mb_strtolower( (string) $h1 ) );
		if ( '' !== self::find_service( $h1, '' ) && ! preg_match( '/^(herzlich willkommen|willkommen|home|startseite)\b/u', $h1 ) ) {
			return true;
		}
		if ( count( OQSC_Parser::words( $h1 ) ) < 2 ) {
			return false;
		}
		return ! preg_match( '/^(herzlich willkommen|willkommen|home|startseite|aktuelles|news|start|hallo|hello|welcome)( auf| bei| in| zu)?( unserer| der| unserer homepage| unserer website)?[!.]*$/u', $h1 );
	}

	/**
	 * Leistungsbegriff im Text?
	 *
	 * @param string $text    Text.
	 * @param string $branche Branche.
	 * @return string Gefundener Begriff oder leer.
	 */
	private static function find_service( $text, $branche ) {
		$terms = self::branch_terms();
		$lists = isset( $terms[ $branche ] ) ? array( $terms[ $branche ] ) : array_values( $terms );
		if ( isset( $terms[ $branche ] ) ) {
			// Andere Branchen als Rückfall, falls die Auswahl nicht genau passt.
			$lists = array_merge( $lists, array_values( $terms ) );
		}
		$lt = mb_strtolower( (string) $text );
		foreach ( $lists as $list ) {
			foreach ( $list as $term ) {
				if ( false !== mb_strpos( $lt, $term ) ) {
					return trim( $term );
				}
			}
		}
		return '';
	}

	/**
	 * Mögliche Firmennamen (Schema, og:site_name, Domain).
	 *
	 * @param array $data Daten.
	 * @param array $ctx  Kontext.
	 * @return array Kennwörter.
	 */
	private static function name_tokens( $data, $ctx ) {
		$page   = $ctx['page'];
		$names  = array();
		$stop   = array( 'gmbh', 'und', 'für', 'ihre', 'ihr', 'der', 'die', 'das', 'home', 'startseite', 'willkommen', 'www', 'online', 'shop', 'website', 'homepage', 'mbh', 'co', 'kg', 'inh', 'inhaber', 'team', 'praxis', 'firma' );
		$source = array();
		if ( ! empty( $page['business']['name'] ) ) {
			$source[] = $page['business']['name'];
		}
		if ( ! empty( $page['og_site_name'] ) ) {
			$source[] = $page['og_site_name'];
		}
		$domain = isset( $data['domain'] ) ? $data['domain'] : '';
		if ( $domain ) {
			$sld      = preg_replace( '/\.[a-z]{2,}$/', '', $domain );
			$sld      = preg_replace( '/\.(co|com|org)$/', '', $sld );
			$source[] = str_replace( array( '-', '.' ), ' ', $sld );
		}
		foreach ( $source as $s ) {
			foreach ( preg_split( '/[\s,&+|·•\/]+/u', mb_strtolower( $s ) ) as $tok ) {
				$tok = trim( $tok, ".:;!?()\"'„“”" );
				if ( mb_strlen( $tok ) >= 4 && ! in_array( $tok, $stop, true ) && ( ! $ctx['ort_kern'] || mb_strtolower( $ctx['ort_kern'] ) !== $tok ) ) {
					$names[] = $tok;
				}
			}
		}
		return array_values( array_unique( $names ) );
	}

	/**
	 * Liste lesbar verbinden.
	 *
	 * @param array $items Einträge.
	 * @return string
	 */
	public static function join_list( $items ) {
		$items = array_values( array_filter( array_map( 'strval', $items ) ) );
		$n     = count( $items );
		if ( 0 === $n ) {
			return '';
		}
		if ( 1 === $n ) {
			return $items[0];
		}
		return implode( ', ', array_slice( $items, 0, -1 ) ) . ' und ' . $items[ $n - 1 ];
	}

	/* ------------------------------------------------------------------
	 * Säule 1: Gefunden
	 * ---------------------------------------------------------------- */

	/**
	 * G01 Erreichbar.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_g01( $d, $ctx ) {
		$status = isset( $d['home']['status'] ) ? (int) $d['home']['status'] : 0;
		$n      = isset( $d['home']['redirects'] ) ? count( $d['home']['redirects'] ) : 0;
		$werte  = array(
			'status'          => $status,
			'weiterleitungen' => $n,
		);
		if ( $status >= 200 && $status < 300 ) {
			$text = 'Ihre Startseite ist erreichbar und antwortet ohne Fehler.';
			if ( $n >= 3 ) {
				$text .= ' Auf dem Weg dorthin gibt es allerdings ' . $n . ' Weiterleitungen, das kostet bei jedem Aufruf Zeit.';
			}
			return self::r( 'gut', $text, $werte );
		}
		return self::r( 'kritisch', 'Die Startseite antwortet mit dem Fehlercode ' . $status . '.', $werte );
	}

	/**
	 * G02 Indexierbar.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_g02( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$meta   = isset( $ctx['page']['robots_meta'] ) ? $ctx['page']['robots_meta'] : '';
		$header = isset( $d['home']['headers']['x-robots-tag'] ) ? strtolower( $d['home']['headers']['x-robots-tag'] ) : '';
		if ( false !== strpos( $meta, 'noindex' ) || false !== strpos( $meta, 'none' ) ) {
			return self::r( 'kritisch', 'Im Quelltext Ihrer Startseite steht die Anweisung „noindex“. Google nimmt die Seite deshalb nicht in die Suchergebnisse auf.' );
		}
		if ( false !== strpos( $header, 'noindex' ) ) {
			return self::r( 'kritisch', 'Ihr Server sendet die Anweisung „noindex“ mit. Google nimmt die Seite deshalb nicht in die Suchergebnisse auf.' );
		}
		$robots = isset( $d['robots']['regeln'] ) ? $d['robots']['regeln'] : array();
		if ( ! empty( $d['robots']['gefunden'] ) && ( OQSC_Parser::robots_blocks_root( $robots, 'googlebot' ) ) ) {
			return self::r( 'kritisch', 'Ihre robots.txt sperrt die gesamte Website für Suchmaschinen. Google darf Ihre Seiten nicht lesen.' );
		}
		return self::r( 'gut', 'Google darf Ihre Startseite lesen und in die Suchergebnisse aufnehmen.' );
	}

	/**
	 * G03 Seitentitel.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_g03( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$title = $ctx['page']['title'];
		if ( '' === $title ) {
			return self::r( 'kritisch', 'Ihre Startseite hat keinen Seitentitel. Google denkt sich dann selbst einen aus.', array( 'px' => 0 ) );
		}
		$px    = self::text_px( $title, 20 );
		$len   = mb_strlen( $title );
		$werte = array(
			'px'      => $px,
			'zeichen' => $len,
			'titel'   => $title,
		);
		$ort   = $ctx['ort_kern'];
		$bonus = '';
		if ( $ort ) {
			$bonus = self::contains_word( $title, $ort ) ? ' Ihr Ort ' . $ort . ' steht im Titel, sehr gut.' : ' Ihr Ort ' . $ort . ' fehlt im Titel.';
		}
		if ( $len < 20 || preg_match( '/^(startseite|home|willkommen|homepage|start|index)$/iu', trim( $title ) ) ) {
			return self::r( 'verbesserbar', 'Ihr Titel „' . $title . '“ ist sehr kurz und sagt wenig über Ihr Angebot.' . $bonus, $werte );
		}
		if ( $px > 600 ) {
			return self::r( 'verbesserbar', 'Ihr Titel ist etwa ' . $px . ' Pixel breit. Google zeigt nur rund 580 Pixel, der Rest wird mit „…“ abgeschnitten.' . $bonus, $werte );
		}
		if ( $ort && ! self::contains_word( $title, $ort ) ) {
			return self::r( 'gut', 'Ihr Titel hat eine gute Länge (' . $px . ' von etwa 580 Pixeln).' . $bonus, $werte );
		}
		return self::r( 'gut', 'Ihr Titel hat eine gute Länge (' . $px . ' von etwa 580 Pixeln) und wird vollständig angezeigt.' . $bonus, $werte );
	}

	/**
	 * G04 Beschreibung.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_g04( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$desc = $ctx['page']['description'];
		if ( '' === $desc ) {
			return self::r( 'kritisch', 'Es gibt keine Beschreibung. Google nimmt dann irgendeinen Textschnipsel von der Seite.' );
		}
		$len   = mb_strlen( $desc );
		$px    = self::text_px( $desc, 14 );
		$werte = array(
			'zeichen' => $len,
			'px'      => $px,
		);
		if ( $len < 70 ) {
			return self::r( 'verbesserbar', 'Ihre Beschreibung hat nur ' . $len . ' Zeichen. Gut sind 120 bis 160 Zeichen, damit Sie den Platz bei Google nutzen.', $werte );
		}
		if ( $len > 160 && $px > 920 ) {
			return self::r( 'verbesserbar', 'Ihre Beschreibung hat ' . $len . ' Zeichen. Google kürzt ab etwa 160 Zeichen, das Ende ist dann nicht zu sehen.', $werte );
		}
		return self::r( 'gut', 'Ihre Beschreibung hat ' . $len . ' Zeichen und passt in das Suchergebnis.', $werte );
	}

	/**
	 * G05 H1.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_g05( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$h1    = array_values( array_filter( $ctx['page']['h1'], 'strlen' ) );
		$werte = array( 'anzahl' => count( $ctx['page']['h1'] ) );
		if ( 0 === count( $h1 ) ) {
			return self::r( 'kritisch', 'Ihre Startseite hat keine Hauptüberschrift (H1).', $werte );
		}
		if ( count( $ctx['page']['h1'] ) > 1 ) {
			return self::r( 'verbesserbar', 'Ihre Startseite hat ' . count( $ctx['page']['h1'] ) . ' Hauptüberschriften (H1), zum Beispiel „' . $h1[0] . '“ und „' . ( isset( $h1[1] ) ? $h1[1] : '' ) . '“. Eine einzige ist klarer.', $werte );
		}
		$werte['h1'] = $h1[0];
		if ( ! self::h1_meaningful( $h1[0] ) ) {
			return self::r( 'verbesserbar', 'Ihre Hauptüberschrift lautet „' . $h1[0] . '“. Sie sagt nicht, was Sie anbieten.', $werte );
		}
		return self::r( 'gut', 'Ihre Hauptüberschrift lautet „' . $h1[0] . '“.', $werte );
	}

	/**
	 * G06 Gliederung.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_g06( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$hs = array_values(
			array_filter(
				$ctx['page']['headings'],
				static function ( $h ) {
					return empty( $h[2] );
				}
			)
		);
		if ( ! $hs ) {
			$hs = $ctx['page']['headings'];
		}
		if ( ! $hs ) {
			return self::r( 'kritisch', 'Ihre Startseite hat keine einzige Überschrift.' );
		}
		$h2   = 0;
		$skip = '';
		$prev = 0;
		foreach ( $hs as $i => $h ) {
			if ( 2 === $h[0] ) {
				++$h2;
			}
			if ( $i < 6 && $prev && $h[0] > $prev + 1 && '' === $skip ) {
				$skip = 'H' . $prev . ' folgt direkt H' . $h[0];
			}
			$prev = $h[0];
		}
		$werte = array(
			'h2'     => $h2,
			'gesamt' => count( $hs ),
		);
		if ( ! $h2 ) {
			return self::r( 'verbesserbar', 'Unter der Hauptüberschrift fehlen Zwischenüberschriften (H2).', $werte );
		}
		if ( $skip ) {
			return self::r( 'verbesserbar', 'Die Gliederung springt am Anfang eine Ebene über (' . $skip . ').', $werte );
		}
		return self::r( 'gut', 'Ihre Seite ist mit ' . $h2 . ' Zwischenüberschriften (H2) sauber gegliedert.', $werte );
	}

	/**
	 * G07 Textumfang.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_g07( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$n     = (int) $ctx['page']['word_count'];
		$werte = array( 'woerter' => $n );
		if ( $n < 100 ) {
			return self::r( 'kritisch', 'Auf Ihrer Startseite stehen nur rund ' . $n . ' Wörter lesbarer Text.', $werte );
		}
		if ( $n < 250 ) {
			return self::r( 'verbesserbar', 'Auf Ihrer Startseite stehen rund ' . $n . ' Wörter. Für Google sind 300 und mehr hilfreich.', $werte );
		}
		return self::r( 'gut', 'Auf Ihrer Startseite stehen rund ' . OQSC_Plugin::num( $n ) . ' Wörter lesbarer Text.', $werte );
	}

	/**
	 * G08 Alternativtexte.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_g08( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$total = (int) $ctx['page']['img_total'];
		$alt   = (int) $ctx['page']['img_alt'];
		if ( 0 === $total ) {
			return self::r( 'gut', 'Auf Ihrer Startseite sind keine Bilder eingebunden, die eine Beschreibung brauchen.', array( 'anteil' => 100 ) );
		}
		$pct   = (int) round( 100 * $alt / $total );
		$werte = array(
			'anteil' => $pct,
			'bilder' => $total,
			'ohne'   => $total - $alt,
		);
		if ( $pct >= 90 ) {
			return self::r( 'gut', ( $alt === $total ? 'Alle ' . $total . ' Bilder haben' : $alt . ' von ' . $total . ' Bildern haben' ) . ' eine Beschreibung (Alternativtext).', $werte );
		}
		if ( $pct < 50 ) {
			return self::r( 'kritisch', ( 0 === $alt ? 'Keines Ihrer ' . $total . ' Bilder hat' : 'Nur ' . $alt . ' von ' . $total . ' Bildern ' . ( 1 === $alt ? 'hat' : 'haben' ) ) . ' eine Beschreibung (Alternativtext).', $werte );
		}
		return self::r( 'verbesserbar', ( $total - $alt ) . ' von ' . $total . ' Bildern ' . ( 1 === $total - $alt ? 'fehlt' : 'fehlen' ) . ' eine Beschreibung (Alternativtext).', $werte );
	}

	/**
	 * G09 Canonical.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_g09( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$can = $ctx['page']['canonical'];
		if ( '' === $can ) {
			return self::r( 'verbesserbar', 'Ihre Startseite gibt keine Hauptadresse (Canonical) an.' );
		}
		$host = wp_parse_url( $can, PHP_URL_HOST );
		if ( ! $host || OQSC_Fetcher::domain_key( $host ) !== $d['domain'] ) {
			return self::r( 'verbesserbar', 'Die angegebene Hauptadresse zeigt auf eine andere Domain (' . $host . '). Google könnte dann die andere Adresse bevorzugen.' );
		}
		$final = isset( $d['home']['final_url'] ) ? $d['home']['final_url'] : '';
		$norm  = static function ( $u ) {
			return rtrim( preg_replace( '#^https?://(www\.)?#', '', strtolower( preg_replace( '/[?#].*$/', '', $u ) ) ), '/' );
		};
		if ( $norm( $can ) !== $norm( $final ) ) {
			return self::r( 'verbesserbar', 'Die Hauptadresse (Canonical) Ihrer Startseite zeigt auf eine Unterseite: ' . $can );
		}
		return self::r( 'gut', 'Ihre Startseite nennt sich selbst als Hauptadresse (Canonical).' );
	}

	/**
	 * G10 Sitemap.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_g10( $d, $ctx ) {
		if ( ! isset( $d['sitemap'] ) ) {
			return self::np( 'Die Sitemap konnte nicht geprüft werden.' );
		}
		if ( ! empty( $d['sitemap']['gueltig'] ) ) {
			$n = isset( $d['sitemap']['eintraege'] ) ? (int) $d['sitemap']['eintraege'] : 0;
			return self::r( 'gut', 'Wir haben eine gültige Sitemap gefunden' . ( $n ? ' (' . $n . ( 1 === $n ? ' Eintrag' : ' Einträge' ) . ' auf der ersten Ebene)' : '' ) . '.', array( 'url' => $d['sitemap']['url'] ) );
		}
		if ( ! empty( $d['sitemap']['gefunden'] ) ) {
			return self::r( 'verbesserbar', 'Unter ' . $d['sitemap']['url'] . ' liegt eine Datei, aber keine gültige Sitemap.' );
		}
		return self::r( 'verbesserbar', 'Wir haben keine Sitemap gefunden, weder in der robots.txt noch an den üblichen Adressen.' );
	}

	/**
	 * G11 Sprache.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_g11( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$lang = $ctx['page']['lang'];
		if ( '' === $lang ) {
			return self::r( 'verbesserbar', 'Im Quelltext ist keine Sprache angegeben.' );
		}
		if ( 0 !== stripos( $lang, 'de' ) ) {
			return self::r( 'verbesserbar', 'Als Sprache ist „' . $lang . '“ angegeben, Ihre Texte sind aber vermutlich deutsch.', array( 'lang' => $lang ) );
		}
		return self::r( 'gut', 'Die Sprache ist korrekt als „' . $lang . '“ angegeben.', array( 'lang' => $lang ) );
	}

	/**
	 * G12 Vorschau beim Teilen.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_g12( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$t = '' !== $ctx['page']['og_title'];
		$i = '' !== $ctx['page']['og_image'];
		if ( $t && $i ) {
			return self::r( 'gut', 'Titel und Bild für die Vorschau beim Teilen sind hinterlegt.' );
		}
		if ( $t || $i ) {
			return self::r( 'verbesserbar', $t ? 'Für die Vorschau beim Teilen fehlt ein Bild.' : 'Für die Vorschau beim Teilen fehlt ein Titel.' );
		}
		return self::r( 'verbesserbar', 'Für die Vorschau beim Teilen (WhatsApp, Facebook, LinkedIn) sind weder Titel noch Bild hinterlegt.' );
	}

	/**
	 * G13 Interne Verlinkung.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_g13( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$n = (int) $ctx['page']['internal_count'];
		if ( $n < 5 ) {
			return self::r( 'verbesserbar', 'Ihre Startseite verlinkt nur ' . $n . ' Mal auf eigene Unterseiten.', array( 'links' => $n ) );
		}
		return self::r( 'gut', 'Ihre Startseite verlinkt ' . $n . ' Mal auf eigene Seiten.', array( 'links' => $n ) );
	}

	/**
	 * G14 Kaputte Links.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_g14( $d, $ctx ) {
		$links  = array();
		$broken = array();
		foreach ( isset( $d['stichprobe'] ) ? $d['stichprobe'] : array() as $s ) {
			if ( 'link' !== $s['art'] ) {
				continue;
			}
			$links[] = $s;
			if ( $s['status'] >= 400 && ! in_array( (int) $s['status'], array( 403, 405, 429 ), true ) ) {
				$broken[] = $s['url'] . ' (Fehler ' . $s['status'] . ')';
			}
		}
		if ( ! $links ) {
			return self::np( 'Es gab keine internen Links für eine Stichprobe.' );
		}
		if ( $broken ) {
			return self::r( 'kritisch', 'In unserer Stichprobe von ' . count( $links ) . ' Links führen ' . count( $broken ) . ' ins Leere: ' . implode( ', ', $broken ), array( 'kaputt' => count( $broken ) ) );
		}
		return self::r( 'gut', 'Alle ' . count( $links ) . ' Links unserer Stichprobe funktionieren.', array( 'kaputt' => 0 ) );
	}

	/* ------------------------------------------------------------------
	 * Säule 2: Vor Ort
	 * ---------------------------------------------------------------- */

	/**
	 * L01 Ort sichtbar.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_l01( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$ort = $ctx['ort_kern'];
		if ( ! $ort ) {
			return self::r( 'kritisch', 'Wir konnten auf Ihrer Startseite keinen Ort erkennen. Geben Sie Ihren Ort beim Check an, dann prüfen wir genauer.' );
		}
		$p     = $ctx['page'];
		$where = array();
		if ( self::contains_word( $p['title'], $ort ) ) {
			$where[] = 'im Titel';
		}
		foreach ( $p['h1'] as $h ) {
			if ( self::contains_word( $h, $ort ) ) {
				$where[] = 'in der Hauptüberschrift';
				break;
			}
		}
		if ( self::contains_word( $p['first_words'], $ort ) ) {
			$where[] = 'im Text weiter oben';
		}
		$werte = array(
			'ort'    => $ort,
			'quelle' => $ctx['ort_quelle'],
		);
		$hint  = 'erkannt' === $ctx['ort_quelle'] ? ' (aus Ihrer Adresse erkannt)' : '';
		if ( ! $where ) {
			return self::r( 'kritisch', $ort . $hint . ' taucht weder im Titel noch in der Hauptüberschrift noch in den ersten 200 Wörtern auf.', $werte );
		}
		if ( 1 === count( $where ) && 'im Text weiter oben' === $where[0] ) {
			return self::r( 'gut', $ort . $hint . ' steht im Text weiter oben. Noch stärker wirkt der Ort im Titel und in der Hauptüberschrift.', $werte );
		}
		return self::r( 'gut', $ort . $hint . ' steht ' . self::join_list( $where ) . '.', $werte );
	}

	/**
	 * L02 Adresse.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_l02( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$home    = $ctx['page']['addresses'];
		$contact = isset( $d['kontakt']['inhalt']['addresses'] ) ? $d['kontakt']['inhalt']['addresses'] : array();
		$imp     = isset( $d['impressum']['inhalt']['addresses'] ) ? $d['impressum']['inhalt']['addresses'] : array();
		foreach ( array( 'Startseite' => $home, 'Kontaktseite' => $contact ) as $where => $list ) {
			foreach ( $list as $a ) {
				if ( $a['strasse'] ) {
					return self::r( 'gut', 'Ihre Adresse mit Straße und Postleitzahl (' . $a['plz'] . ' ' . $a['ort'] . ') steht auf der ' . $where . '.', array( 'plz' => $a['plz'] ) );
				}
			}
		}
		if ( $home || $contact ) {
			$a = $home ? $home[0] : $contact[0];
			return self::r( 'verbesserbar', 'Wir haben Postleitzahl und Ort (' . $a['plz'] . ' ' . $a['ort'] . ') gefunden, aber keine vollständige Anschrift mit Straße.' );
		}
		if ( $imp ) {
			return self::r( 'verbesserbar', 'Ihre Adresse steht nur im Impressum. Kunden suchen sie auf der Startseite oder der Kontaktseite.' );
		}
		return self::r( 'kritisch', 'Wir haben auf Startseite und Kontaktseite keine Adresse gefunden.' );
	}

	/**
	 * L03 Telefon antippbar.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_l03( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$p = $ctx['page'];
		if ( $p['tel_links'] ) {
			return self::r( 'gut', 'Ihre Telefonnummer ist auf der Startseite antippbar. Auf dem Handy genügt ein Fingertipp zum Anruf.', array( 'tel_links' => count( $p['tel_links'] ) ) );
		}
		if ( $p['phones_text'] ) {
			return self::r( 'verbesserbar', 'Ihre Telefonnummer steht auf der Startseite, ist aber nicht antippbar. Kunden müssen sie abtippen.' );
		}
		$contact = isset( $d['kontakt']['inhalt'] ) ? $d['kontakt']['inhalt'] : array();
		if ( ! empty( $contact['tel_links'] ) || ! empty( $contact['phones'] ) ) {
			return self::r( 'verbesserbar', 'Ihre Telefonnummer steht nur auf der Kontaktseite, nicht auf der Startseite.' );
		}
		return self::r( 'kritisch', 'Wir haben auf Ihrer Startseite keine Telefonnummer gefunden.' );
	}

	/**
	 * L04 Strukturierte Firmendaten.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_l04( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$b = $ctx['page']['business'];
		if ( ! $b ) {
			return self::r( 'kritisch', 'Ihre Seite enthält keine maschinenlesbaren Firmendaten (Schema „LocalBusiness“).' );
		}
		$missing = array();
		if ( '' === $b['name'] ) {
			$missing[] = 'Name';
		}
		if ( '' === $b['strasse'] || '' === $b['plz'] ) {
			$missing[] = 'Anschrift';
		}
		if ( '' === $b['telefon'] ) {
			$missing[] = 'Telefon';
		}
		if ( ! $b['oeffnungszeiten'] ) {
			$missing[] = 'Öffnungszeiten';
		}
		$werte = array(
			'typ'    => $b['typ'],
			'fehlt'  => $missing,
		);
		if ( ! $b['lokal'] ) {
			return self::r( 'verbesserbar', 'Ihre Firmendaten sind als allgemeine Organisation hinterlegt, nicht als lokaler Betrieb (LocalBusiness).' . ( $missing ? ' Es fehlen außerdem: ' . self::join_list( $missing ) . '.' : '' ), $werte );
		}
		if ( $missing ) {
			return self::r( 'verbesserbar', 'Ihre Firmendaten sind als „' . $b['typ'] . '“ hinterlegt, aber es fehlen: ' . self::join_list( $missing ) . '.', $werte );
		}
		return self::r( 'gut', 'Ihre Firmendaten sind vollständig als „' . $b['typ'] . '“ hinterlegt: Name, Anschrift, Telefon und Öffnungszeiten.', $werte );
	}

	/**
	 * L05 Gleiche Angaben überall.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_l05( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$p   = $ctx['page'];
		$imp = isset( $d['impressum']['inhalt'] ) ? $d['impressum']['inhalt'] : array();

		$phones = array(
			'Startseite'           => array_unique( array_merge( $p['tel_links'], $p['phones_text'] ) ),
			'Impressum'            => array_unique( array_merge( isset( $imp['tel_links'] ) ? $imp['tel_links'] : array(), isset( $imp['phones'] ) ? $imp['phones'] : array() ) ),
			'strukturierte Daten'  => ! empty( $p['business']['telefon_norm'] ) ? array( $p['business']['telefon_norm'] ) : array(),
		);
		$plz = array(
			'Startseite'          => array_unique( wp_list_pluck( $p['addresses'], 'plz' ) ),
			'Impressum'           => array_unique( wp_list_pluck( isset( $imp['addresses'] ) ? $imp['addresses'] : array(), 'plz' ) ),
			'strukturierte Daten' => ! empty( $p['business']['plz'] ) ? array( $p['business']['plz'] ) : array(),
		);
		$compare = static function ( $sets ) {
			$sets = array_filter( $sets );
			if ( count( $sets ) < 2 ) {
				return null;
			}
			$names = array_keys( $sets );
			$bad   = array();
			$n     = count( $names );
			for ( $i = 0; $i < $n; $i++ ) {
				for ( $j = $i + 1; $j < $n; $j++ ) {
					if ( ! array_intersect( $sets[ $names[ $i ] ], $sets[ $names[ $j ] ] ) ) {
						$bad[] = $names[ $i ] . ' und ' . $names[ $j ];
					}
				}
			}
			return $bad;
		};
		$bad_phone = $compare( $phones );
		$bad_plz   = $compare( $plz );
		if ( null === $bad_phone && null === $bad_plz ) {
			return self::np( 'Telefon und Postleitzahl stehen an zu wenigen Stellen für einen Abgleich.' );
		}
		$issues = array();
		if ( $bad_phone ) {
			$issues[] = 'Telefonnummer (' . implode( '; ', $bad_phone ) . ')';
		}
		if ( $bad_plz ) {
			$issues[] = 'Postleitzahl (' . implode( '; ', $bad_plz ) . ')';
		}
		if ( $issues ) {
			return self::r( 'verbesserbar', 'Diese Angaben weichen voneinander ab: ' . implode( ' sowie ', $issues ) . '.' );
		}
		$checked = array();
		if ( null !== $bad_phone ) {
			$checked[] = 'Telefonnummer';
		}
		if ( null !== $bad_plz ) {
			$checked[] = 'Postleitzahl';
		}
		return self::r( 'gut', self::join_list( $checked ) . ' stimmen auf Startseite, Impressum und in den strukturierten Daten überein, soweit vorhanden.' );
	}

	/**
	 * L06 Öffnungszeiten.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_l06( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$p = $ctx['page'];
		if ( ! empty( $p['business']['oeffnungszeiten'] ) ) {
			return self::r( 'gut', 'Ihre Öffnungszeiten sind in den strukturierten Daten hinterlegt.' );
		}
		$text = isset( $d['kontakt']['inhalt']['text'] ) ? $d['kontakt']['inhalt']['text'] : '';
		$re   = '/öffnungszeit|geöffnet|sprechzeit|sprechstunde|(mo|di|mi|do|fr|sa|montag|dienstag|freitag)\.?\s*(-|–|bis)\s*(mo|di|mi|do|fr|sa|so|freitag|samstag|sonntag)|\d{1,2}[:.]\d{2}\s*(-|–|bis)\s*\d{1,2}[:.]\d{2}\s*uhr|\d{1,2}\s*(-|–|bis)\s*\d{1,2}\s*uhr/iu';
		if ( ! empty( $p['hours_signal'] ) || preg_match( $re, $text ) ) {
			return self::r( 'gut', 'Ihre Öffnungszeiten stehen als Text auf der Seite. In den strukturierten Daten fehlen sie noch.' );
		}
		return self::r( 'verbesserbar', 'Wir haben keine Öffnungs- oder Erreichbarkeitszeiten gefunden.' );
	}

	/**
	 * L07 Google-Profil verknüpft.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_l07( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		foreach ( $ctx['page']['links'] as $l ) {
			if ( preg_match( '#google\.[a-z.]+/maps|maps\.google\.|g\.page/|maps\.app\.goo\.gl|goo\.gl/maps|search\.google\.com/local|g\.co/kgs|business\.google\.com|google\.[a-z.]+/search\?.*(ludocid|kgmid)#i', $l['url'] ) ) {
				return self::r( 'gut', 'Ihre Seite verlinkt auf Ihr Google-Unternehmensprofil oder Ihre Google-Bewertungen.' );
			}
		}
		foreach ( $ctx['page']['embeds'] as $e ) {
			if ( 'maps' === $e['art'] ) {
				return self::r( 'gut', 'Ihre Seite bindet eine Google-Karte ein. Ein direkter Link zu Ihrem Google-Profil und zu den Bewertungen wäre noch besser.' );
			}
		}
		return self::r( 'verbesserbar', 'Wir haben keinen Link zu Ihrem Google-Unternehmensprofil gefunden.' );
	}

	/**
	 * L08 Einzugsgebiet (Hinweis).
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_l08( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		if ( ! empty( $ctx['page']['area_signal'] ) ) {
			return self::r( 'gut', 'Ihre Startseite nennt ein Einzugsgebiet, etwa die Umgebung oder die Region.' );
		}
		return self::r( 'hinweis', 'Ihre Startseite sagt nicht, in welchen Orten rund um ' . ( $ctx['ort_kern'] ? $ctx['ort_kern'] : 'Ihren Standort' ) . ' Sie außerdem arbeiten.' );
	}

	/* ------------------------------------------------------------------
	 * Säule 3: Schnell
	 * ---------------------------------------------------------------- */

	/**
	 * Grund, warum PageSpeed fehlt.
	 *
	 * @param array $d Daten.
	 * @return string
	 */
	private static function psi_reason( $d ) {
		$g = isset( $d['psi']['grund'] ) ? $d['psi']['grund'] : '';
		$m = array(
			'aus'        => 'Die Ladezeit-Messung ist auf dieser Website abgeschaltet.',
			'kontingent' => 'Die Ladezeit-Messung von Google ist gerade ausgelastet.',
			'zeit'       => 'Die Ladezeit-Messung von Google hat zu lange gedauert.',
			'fehler'     => 'Google konnte Ihre Seite für die Ladezeit-Messung nicht laden.',
		);
		return isset( $m[ $g ] ) ? $m[ $g ] : 'Die Ladezeit-Messung war nicht möglich.';
	}

	/**
	 * S01 PageSpeed mobil.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_s01( $d, $ctx ) {
		if ( ! $ctx['psi'] ) {
			return self::np( self::psi_reason( $d ) );
		}
		$v = (int) $ctx['psi']['performance'];
		$w = array( 'wert' => $v );
		if ( $v >= 90 ) {
			return self::r( 'gut', 'Google bewertet das Tempo Ihrer Seite auf dem Handy mit ' . $v . ' von 100 Punkten.', $w );
		}
		if ( $v >= 50 ) {
			return self::r( 'verbesserbar', 'Google bewertet das Tempo Ihrer Seite auf dem Handy mit ' . $v . ' von 100 Punkten.', $w );
		}
		return self::r( 'kritisch', 'Google bewertet das Tempo Ihrer Seite auf dem Handy mit nur ' . $v . ' von 100 Punkten.', $w );
	}

	/**
	 * S02 LCP.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_s02( $d, $ctx ) {
		if ( ! $ctx['psi'] || null === $ctx['psi']['lcp'] ) {
			return self::np( self::psi_reason( $d ) );
		}
		$s = round( $ctx['psi']['lcp'] / 1000, 1 );
		$w = array( 'sekunden' => $s );
		$t = 'Das größte Element Ihrer Startseite ist auf dem Handy nach ' . OQSC_Plugin::num( $s, 1 ) . ' Sekunden sichtbar.';
		if ( $s <= 2.5 ) {
			return self::r( 'gut', $t, $w );
		}
		return self::r( $s <= 4 ? 'verbesserbar' : 'kritisch', $t . ' Gut sind höchstens 2,5 Sekunden.', $w );
	}

	/**
	 * S03 CLS.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_s03( $d, $ctx ) {
		if ( ! $ctx['psi'] || null === $ctx['psi']['cls'] ) {
			return self::np( self::psi_reason( $d ) );
		}
		$v = round( (float) $ctx['psi']['cls'], 2 );
		$w = array( 'wert' => $v );
		$t = 'Der Wert für Layout-Verschiebungen liegt bei ' . OQSC_Plugin::num( $v, 2 ) . '.';
		if ( $v <= 0.1 ) {
			return self::r( 'gut', $t . ' Inhalte bleiben beim Laden ruhig stehen.', $w );
		}
		return self::r( $v <= 0.25 ? 'verbesserbar' : 'kritisch', $t . ' Gut sind höchstens 0,1.', $w );
	}

	/**
	 * S04 TBT.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_s04( $d, $ctx ) {
		if ( ! $ctx['psi'] || null === $ctx['psi']['tbt'] ) {
			return self::np( self::psi_reason( $d ) );
		}
		$v = (int) round( $ctx['psi']['tbt'] );
		$w = array( 'ms' => $v );
		$t = 'Ihre Seite ist beim Laden insgesamt ' . OQSC_Plugin::num( $v ) . ' Millisekunden blockiert.';
		if ( $v <= 200 ) {
			return self::r( 'gut', $t, $w );
		}
		return self::r( $v <= 600 ? 'verbesserbar' : 'kritisch', $t . ' Gut sind höchstens 200 Millisekunden.', $w );
	}

	/**
	 * S05 Serverantwort.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_s05( $d, $ctx ) {
		$t = isset( $d['home']['ttfb'] ) ? $d['home']['ttfb'] : null;
		if ( null === $t ) {
			return self::np( 'Die Antwortzeit konnte nicht gemessen werden.' );
		}
		$t = round( (float) $t, 2 );
		$w = array( 'sekunden' => $t );
		$s = 'Ihr Server hat nach ' . OQSC_Plugin::num( $t, 2 ) . ' Sekunden mit der Antwort begonnen.';
		if ( $t <= 0.8 ) {
			return self::r( 'gut', $s, $w );
		}
		return self::r( $t <= 1.8 ? 'verbesserbar' : 'kritisch', $s . ' Gut sind höchstens 0,8 Sekunden.', $w );
	}

	/**
	 * S06 Seitengewicht.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_s06( $d, $ctx ) {
		if ( ! isset( $d['home']['groesse'] ) ) {
			return self::np( 'Das Seitengewicht konnte nicht ermittelt werden.' );
		}
		$html = (int) $d['home']['groesse'];
		$big  = array();
		$max  = 0;
		foreach ( isset( $d['stichprobe'] ) ? $d['stichprobe'] : array() as $s ) {
			if ( 'bild' === $s['art'] && $s['groesse'] > 500 * 1024 ) {
				$big[] = basename( (string) wp_parse_url( $s['url'], PHP_URL_PATH ) ) . ' (' . OQSC_Plugin::num( $s['groesse'] / 1024 ) . ' KB)';
				$max   = max( $max, (int) $s['groesse'] );
			}
		}
		$total = $ctx['psi'] && ! empty( $ctx['psi']['bytes'] ) ? (int) $ctx['psi']['bytes'] : 0;
		$werte = array(
			'html_kb'   => (int) round( $html / 1024 ),
			'gesamt_kb' => $total ? (int) round( $total / 1024 ) : null,
			'gross'     => count( $big ),
		);
		$parts = array();
		$parts[] = 'Der HTML-Code Ihrer Startseite wiegt ' . OQSC_Plugin::num( $html / 1024 ) . ' KB';
		if ( $total ) {
			$parts[] = 'die ganze Seite laut Google ' . OQSC_Plugin::num( $total / 1048576, 1 ) . ' MB';
		}
		$text = implode( ', ', $parts ) . '.';
		if ( $big ) {
			$text .= ' Sehr große Bilder: ' . implode( ', ', $big ) . '.';
		}
		if ( $max > 1536 * 1024 || $total > 5 * 1048576 ) {
			return self::r( 'kritisch', $text, $werte );
		}
		if ( $big || $html > 1048576 || $total > 3 * 1048576 ) {
			return self::r( 'verbesserbar', $text, $werte );
		}
		return self::r( 'gut', $text . ' Das ist im grünen Bereich.', $werte );
	}

	/**
	 * S07 Komprimierung.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_s07( $d, $ctx ) {
		$enc = isset( $d['home']['headers']['content-encoding'] ) ? strtolower( $d['home']['headers']['content-encoding'] ) : '';
		if ( preg_match( '/gzip|br|zstd|deflate/', $enc ) ) {
			return self::r( 'gut', 'Ihr Server verschickt die Seite komprimiert (' . $enc . ').' );
		}
		return self::r( 'verbesserbar', 'Ihr Server verschickt die Seite unkomprimiert.' );
	}

	/**
	 * S08 Mobile Darstellung.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_s08( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$v = strtolower( $ctx['page']['viewport'] );
		if ( '' === $v ) {
			return self::r( 'kritisch', 'Ihrer Seite fehlt die Angabe für Handys (Viewport). Sie wird auf dem Handy wie eine verkleinerte Desktop-Seite angezeigt.' );
		}
		if ( false === strpos( $v, 'device-width' ) ) {
			return self::r( 'verbesserbar', 'Die Angabe für Handys (Viewport) ist vorhanden, passt sich aber nicht an die Bildschirmbreite an.' );
		}
		if ( preg_match( '/user-scalable\s*=\s*(no|0)|maximum-scale\s*=\s*1(\.0)?\b/', $v ) ) {
			return self::r( 'gut', 'Ihre Seite ist für Handys eingerichtet. Allerdings ist das Vergrößern mit zwei Fingern gesperrt, das stört Menschen mit Sehschwäche.' );
		}
		return self::r( 'gut', 'Ihre Seite ist für Handys eingerichtet und passt sich der Bildschirmbreite an.' );
	}

	/**
	 * S09 Moderne Bildformate.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_s09( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$raster = 0;
		$modern = 0;
		foreach ( $ctx['page']['images'] as $img ) {
			if ( 'svg' === $img['ext'] || 'gif' === $img['ext'] ) {
				continue;
			}
			++$raster;
			if ( $img['modern'] ) {
				++$modern;
			}
		}
		if ( 0 === $raster ) {
			return self::r( 'gut', 'Auf Ihrer Startseite sind keine Fotos eingebunden, die ein modernes Format bräuchten.' );
		}
		// Server, die das Format aushandeln (zum Beispiel Imagify, WebP Express), liefern WebP trotz .jpg/.png in der Adresse.
		$negotiated = 0;
		foreach ( isset( $d['stichprobe'] ) ? $d['stichprobe'] : array() as $smp ) {
			if ( 'bild' === $smp['art'] && preg_match( '#image/(webp|avif)#i', (string) $smp['typ'] ) && ! preg_match( '/\.(webp|avif)(\?|$)/i', (string) $smp['url'] ) ) {
				++$negotiated;
			}
		}
		if ( $negotiated ) {
			return self::r( 'gut', 'Ihr Server liefert Bilder automatisch im modernen Format (WebP oder AVIF) aus, auch wenn die Adressen auf .jpg oder .png enden.', array( 'anteil' => 100 ) );
		}
		$pct = (int) round( 100 * $modern / $raster );
		$w   = array( 'anteil' => $pct );
		if ( $pct >= 50 ) {
			return self::r( 'gut', $pct . ' % Ihrer Bilder nutzen moderne, kleine Formate (WebP oder AVIF).', $w );
		}
		if ( 0 === $pct ) {
			return self::r( 'verbesserbar', 'Keines Ihrer ' . $raster . ' Bilder nutzt ein modernes Format wie WebP oder AVIF.', $w );
		}
		return self::r( 'verbesserbar', 'Erst ' . $pct . ' % Ihrer Bilder nutzen moderne Formate wie WebP oder AVIF.', $w );
	}

	/* ------------------------------------------------------------------
	 * Säule 4: Überzeugend
	 * ---------------------------------------------------------------- */

	/**
	 * U01 5-Sekunden-Test.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_u01( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$p       = $ctx['page'];
		$area    = $p['first_area'];
		$service = self::find_service( $area, $ctx['branche'] );
		$h1ok    = isset( $p['h1'][0] ) && self::h1_meaningful( $p['h1'][0] );
		$has_svc = '' !== $service || $h1ok;
		$has_ort = $ctx['ort_kern'] && self::contains_word( $area, $ctx['ort_kern'] );
		$werte   = array(
			'angebot'  => $has_svc,
			'ort'      => $has_ort,
		);
		if ( $has_svc && $has_ort ) {
			return self::r( 'gut', 'Oben auf Ihrer Startseite steht, was Sie anbieten und wo: Besucher wissen sofort, dass sie richtig sind.', $werte );
		}
		if ( $has_svc ) {
			return self::r( 'verbesserbar', 'Oben auf Ihrer Startseite steht, was Sie anbieten, aber nicht wo' . ( $ctx['ort_kern'] ? ' (' . $ctx['ort_kern'] . ')' : '' ) . '.', $werte );
		}
		if ( $has_ort ) {
			return self::r( 'verbesserbar', 'Oben auf Ihrer Startseite steht Ihr Ort, aber nicht klar, was Sie anbieten.', $werte );
		}
		return self::r( 'kritisch', 'Im ersten sichtbaren Bereich steht weder klar, was Sie anbieten, noch wo Sie arbeiten.', $werte );
	}

	/**
	 * U02 Klarer Anfrage-Weg.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_u02( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$p = $ctx['page'];
		if ( $p['contact_cta'] ) {
			$label = $p['contact_cta'][0];
			return self::r( 'gut', 'Gleich oben gibt es einen klaren Weg zur Anfrage' . ( 'Telefon-Link' !== $label && mb_strlen( $label ) < 40 ? ' („' . $label . '“)' : '' ) . '.' );
		}
		if ( ! empty( $p['kontakt_url'] ) || $p['tel_links'] || $p['mail_links'] ) {
			return self::r( 'verbesserbar', 'Ein Weg zur Anfrage existiert, aber erst weiter unten oder im Fußbereich. Oben fehlt ein deutlicher Knopf.' );
		}
		return self::r( 'kritisch', 'Wir haben keinen Knopf und keinen Link zur Anfrage gefunden, weder oben noch weiter unten.' );
	}

	/**
	 * U03 Kontaktformular.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_u03( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		if ( $ctx['page']['form_email'] ) {
			return self::r( 'gut', 'Auf Ihrer Startseite gibt es ein Formular für Anfragen.' );
		}
		if ( ! empty( $d['kontakt']['inhalt']['form_email'] ) ) {
			return self::r( 'gut', 'Auf Ihrer Kontaktseite gibt es ein Formular für Anfragen.' );
		}
		return self::r( 'verbesserbar', 'Wir haben weder auf der Startseite noch auf der Kontaktseite ein Anfrageformular gefunden.' );
	}

	/**
	 * U04 Bewertungen und Referenzen.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_u04( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$p = $ctx['page'];
		if ( $p['has_review_schema'] && $p['review_signal'] ) {
			return self::r( 'gut', 'Ihre Startseite zeigt Bewertungen oder Referenzen und hinterlegt sie auch maschinenlesbar.' );
		}
		if ( $p['review_signal'] ) {
			return self::r( 'gut', 'Ihre Startseite zeigt Bewertungen, Kundenstimmen oder Referenzen.' );
		}
		if ( $p['has_review_schema'] ) {
			return self::r( 'verbesserbar', 'Bewertungen sind maschinenlesbar hinterlegt, für Besucher aber auf der Startseite kaum sichtbar.' );
		}
		return self::r( 'verbesserbar', 'Wir haben auf der Startseite keine Bewertungen, Kundenstimmen oder Referenzen gefunden.' );
	}

	/**
	 * U05 Menschen hinter dem Betrieb.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_u05( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		if ( $ctx['page']['about_signal'] ) {
			return self::r( 'gut', 'Besucher finden einen Bereich über Sie, Ihr Team oder den Inhaber.' );
		}
		return self::r( 'verbesserbar', 'Wir haben keinen Bereich „Über uns“ oder „Team“ gefunden.' );
	}

	/**
	 * U06 Verschlüsselung.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_u06( $d, $ctx ) {
		$h = isset( $d['home'] ) ? $d['home'] : array();
		if ( ! empty( $h['ssl_fehler'] ) ) {
			return self::r( 'kritisch', 'Ihr Sicherheitszertifikat ist ungültig oder abgelaufen. Browser zeigen Besuchern eine Warnung.' );
		}
		if ( empty( $h['https'] ) ) {
			return self::r( 'kritisch', 'Ihre Seite ist nicht verschlüsselt (kein HTTPS). Browser zeigen „Nicht sicher“ an.' );
		}
		if ( empty( $d['http']['zu_https'] ) ) {
			return self::r( 'verbesserbar', 'Ihre Seite ist verschlüsselt, aber die unverschlüsselte Adresse (http://) leitet nicht automatisch auf https:// um.' );
		}
		return self::r( 'gut', 'Ihre Seite ist verschlüsselt, das Zertifikat ist gültig und http:// leitet auf https:// um.' );
	}

	/**
	 * U07 Gemischte Inhalte.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_u07( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		if ( ! $ctx['https'] ) {
			return self::np( 'Ihre Seite läuft ohne HTTPS, gemischte Inhalte spielen erst mit Verschlüsselung eine Rolle.' );
		}
		$m = $ctx['page']['mixed_content'];
		if ( $m ) {
			return self::r( 'verbesserbar', count( $m ) . ( 1 === count( $m ) ? ' Datei wird' : ' Dateien werden' ) . ' unverschlüsselt nachgeladen, zum Beispiel ' . $m[0] . '.', array( 'anzahl' => count( $m ) ) );
		}
		return self::r( 'gut', 'Alle Dateien werden verschlüsselt geladen.' );
	}

	/**
	 * U08 Favicon.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_u08( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		if ( $ctx['page']['favicon'] ) {
			return self::r( 'gut', 'Ihre Seite hat ein eigenes Symbol (Favicon) für Browser-Tab und Lesezeichen.' );
		}
		return self::r( 'verbesserbar', 'Im Quelltext ist kein Seitensymbol (Favicon) eingebunden.' );
	}

	/**
	 * U09 Aktualität (Hinweis).
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_u09( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$year = (int) $ctx['page']['copyright_year'];
		$news = $ctx['page']['newest_date'];
		$jahr = $ctx['jahr'];
		if ( $year && $year < $jahr - 2 ) {
			return self::r( 'hinweis', 'Im Fußbereich steht „© ' . $year . '“. Das wirkt, als wäre die Seite seit Jahren nicht gepflegt.', array( 'jahr' => $year ) );
		}
		if ( $news && (int) substr( $news, 0, 4 ) < $jahr - 2 && ! $year ) {
			return self::r( 'hinweis', 'Der neueste Beitrag, den wir gefunden haben, stammt aus ' . substr( $news, 0, 4 ) . '.' );
		}
		if ( $year ) {
			return self::r( 'gut', 'Die Jahreszahl im Fußbereich ist aktuell (' . $year . ').' );
		}
		return self::r( 'gut', 'Wir haben keine veraltete Jahreszahl gefunden.' );
	}

	/* ------------------------------------------------------------------
	 * Säule 5: Rechtssicher (Hinweise, keine Rechtsberatung)
	 * ---------------------------------------------------------------- */

	/**
	 * R01 Impressum erreichbar.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_r01( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		if ( empty( $d['impressum']['url'] ) ) {
			return self::r( 'kritisch', 'Wir haben auf der Startseite keinen Link mit dem Wort „Impressum“ gefunden.' );
		}
		if ( empty( $d['impressum']['ok'] ) ) {
			$st = isset( $d['impressum']['status'] ) ? (int) $d['impressum']['status'] : 0;
			if ( 'zeit' === ( isset( $d['impressum']['fehler'] ) ? $d['impressum']['fehler'] : '' ) || ( ! $st && 'budget' === ( isset( $d['impressum']['fehler'] ) ? $d['impressum']['fehler'] : '' ) ) ) {
				return self::np( 'Die Impressumsseite hat nicht rechtzeitig geantwortet.' );
			}
			return self::r( 'kritisch', 'Der Link zum Impressum ist da, aber die Seite lädt nicht' . ( $st ? ' (Fehler ' . $st . ')' : '' ) . '.' );
		}
		return self::r( 'gut', 'Ihr Impressum ist von der Startseite aus verlinkt und lädt.' );
	}

	/**
	 * R02 Impressum Grundangaben.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_r02( $d, $ctx ) {
		if ( empty( $d['impressum']['ok'] ) || empty( $d['impressum']['inhalt']['ok'] ) ) {
			return self::np( 'Das Impressum konnte nicht gelesen werden.' );
		}
		$imp     = $d['impressum']['inhalt'];
		$text    = $imp['text'];
		$missing = array();
		$has_name = (bool) preg_match( '/\b(gmbh|ug|e\.\s?k\.|e\.\s?kfr\.|gbr|ohg|kg|ag|partg|e\.\s?v\.|inhaber|inhaberin|inh\.|vertreten durch|geschäftsführer|geschäftsführerin|vertretungsberechtigt|einzelunternehm|freiberuf|praxis|dr\.|dipl\.)/iu', $text );
		if ( ! $has_name ) {
			foreach ( self::name_tokens( $d, $ctx ) as $tok ) {
				if ( false !== mb_stripos( $text, $tok ) ) {
					$has_name = true;
					break;
				}
			}
		}
		if ( ! $has_name ) {
			$missing[] = 'Name oder Rechtsform';
		}
		$has_addr = false;
		foreach ( $imp['addresses'] as $a ) {
			if ( $a['strasse'] ) {
				$has_addr = true;
			}
		}
		if ( ! $has_addr ) {
			$missing[] = 'Anschrift mit Straße und Postleitzahl';
		}
		if ( ! $imp['emails'] && ! $imp['form_email'] ) {
			$missing[] = 'E-Mail-Adresse';
		}
		$note = ' Wir prüfen nur diese Grundangaben, nicht die Vollständigkeit.';
		if ( ! $missing ) {
			return self::r( 'gut', 'Im Impressum haben wir Name, Anschrift mit Postleitzahl und eine E-Mail-Adresse erkannt.' . $note );
		}
		if ( 1 === count( $missing ) ) {
			return self::r( 'verbesserbar', 'Im Impressum haben wir diese Angabe nicht erkannt: ' . $missing[0] . '.' . $note );
		}
		return self::r( 'kritisch', 'Im Impressum haben wir diese Angaben nicht erkannt: ' . self::join_list( $missing ) . '.' . $note );
	}

	/**
	 * R03 Datenschutzerklärung.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_r03( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		if ( empty( $d['datenschutz']['url'] ) ) {
			return self::r( 'kritisch', 'Wir haben auf der Startseite keinen Link mit dem Wort „Datenschutz“ gefunden.' );
		}
		if ( empty( $d['datenschutz']['ok'] ) ) {
			$st = isset( $d['datenschutz']['status'] ) ? (int) $d['datenschutz']['status'] : 0;
			if ( ! $st ) {
				return self::np( 'Die Datenschutzerklärung hat nicht rechtzeitig geantwortet.' );
			}
			return self::r( 'kritisch', 'Der Link zur Datenschutzerklärung ist da, aber die Seite lädt nicht (Fehler ' . $st . ').' );
		}
		return self::r( 'gut', 'Ihre Datenschutzerklärung ist von der Startseite aus verlinkt und lädt.' );
	}

	/**
	 * Braucht die Seite eine Einwilligung (Tracking, Einbettungen, Drittdienste)?
	 *
	 * @param array $ctx Kontext.
	 * @return array Gründe.
	 */
	private static function consent_needs( $ctx ) {
		$p    = $ctx['page'];
		$need = array();
		foreach ( $p['trackers'] as $t ) {
			$need[] = $t['name'];
		}
		foreach ( $p['embeds'] as $e ) {
			$need[] = 'youtube' === $e['art'] ? 'YouTube' : ( 'vimeo' === $e['art'] ? 'Vimeo' : 'Google Maps' );
		}
		foreach ( $p['third_parties'] as $t ) {
			if ( 0 !== strpos( $t, 'Externes CDN' ) ) {
				$need[] = $t;
			}
		}
		if ( $p['google_fonts'] ) {
			$need[] = 'Google Fonts';
		}
		return array_values( array_unique( $need ) );
	}

	/**
	 * R04 Einwilligungs-Werkzeug.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_r04( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$tools = $ctx['page']['consent_tools'];
		if ( $tools ) {
			return self::r( 'gut', 'Wir haben ein Werkzeug für Einwilligungen erkannt: ' . self::join_list( $tools ) . '.', array( 'werkzeug' => $tools ) );
		}
		$need = self::consent_needs( $ctx );
		if ( $need ) {
			return self::r( 'verbesserbar', 'Wir haben kein Werkzeug für Einwilligungen erkannt, aber Dienste, die meist eine Einwilligung brauchen: ' . self::join_list( array_slice( $need, 0, 5 ) ) . '.' );
		}
		return self::r( 'gut', 'Wir haben kein Werkzeug für Einwilligungen erkannt, aber auch keine Dienste, die eines erfordern würden.' );
	}

	/**
	 * R05 Google Fonts extern.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_r05( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$found = $ctx['page']['google_fonts'];
		foreach ( isset( $d['css'] ) ? $d['css'] : array() as $c ) {
			if ( ! empty( $c['google_fonts'] ) ) {
				$found[] = 'in ' . basename( (string) wp_parse_url( $c['url'], PHP_URL_PATH ) );
			}
		}
		if ( $found ) {
			return self::r( 'kritisch', 'Wir haben Schriften gefunden, die direkt von Google-Servern geladen werden (' . self::join_list( array_slice( $found, 0, 3 ) ) . '). Dabei wird die IP-Adresse Ihrer Besucher an Google übertragen. Das kann ohne Einwilligung unzulässig sein. Lassen Sie das von einer Fachstelle prüfen.', array( 'fundstellen' => count( $found ) ) );
		}
		$note = $ctx['page']['google_fonts_preconnect'] ? ' Im Quelltext steht nur noch eine Vorab-Verbindung zu Google Fonts, die Sie ebenfalls entfernen können.' : '';
		$css  = isset( $d['css'] ) ? count( $d['css'] ) : 0;
		return self::r( 'gut', 'Wir haben keine extern geladenen Google Fonts gefunden (Startseite und ' . $css . ( 1 === $css ? ' Stylesheet' : ' Stylesheets' ) . ' geprüft).' . $note );
	}

	/**
	 * R06 Tracking ohne Einwilligung.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_r06( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$open   = array();
		$locked = array();
		foreach ( $ctx['page']['trackers'] as $t ) {
			if ( $t['gesichert'] ) {
				$locked[] = $t['name'];
			} else {
				$open[] = $t['name'];
			}
		}
		if ( ! $open ) {
			if ( $locked ) {
				return self::r( 'gut', 'Wir haben ' . self::join_list( $locked ) . ' gefunden. Die Skripte sind so eingebunden, dass sie erst nach Einwilligung starten.' );
			}
			return self::r( 'gut', 'Wir haben kein Tracking gefunden, das ohne Einwilligung startet.' );
		}
		$base = 'Wir haben ' . self::join_list( $open ) . ' gefunden, ' . ( 1 === count( $open ) ? 'das' : 'die' ) . ' direkt beim Aufruf der Seite ' . ( 1 === count( $open ) ? 'startet' : 'starten' ) . '.';
		if ( $ctx['page']['consent_tools'] || $ctx['page']['consent_mode'] ) {
			return self::r( 'verbesserbar', $base . ' Es gibt ' . ( $ctx['page']['consent_mode'] ? 'Hinweise auf den Einwilligungsmodus von Google' : 'ein Einwilligungs-Werkzeug' ) . ', ob es diese Skripte wirklich zurückhält, lässt sich von außen nicht sicher sagen. Lassen Sie das von einer Fachstelle prüfen.' );
		}
		return self::r( 'kritisch', $base . ' Ein Einwilligungs-Werkzeug haben wir nicht erkannt. Das kann bedeuten, dass Daten ohne Einwilligung übertragen werden. Lassen Sie das von einer Fachstelle prüfen.' );
	}

	/**
	 * R07 YouTube und Vimeo.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_r07( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$yt     = 0;
		$yt_nc  = 0;
		$vim    = 0;
		foreach ( $ctx['page']['embeds'] as $e ) {
			if ( 'youtube' === $e['art'] ) {
				if ( $e['datenschutzmodus'] ) {
					++$yt_nc;
				} else {
					++$yt;
				}
			} elseif ( 'vimeo' === $e['art'] ) {
				++$vim;
			}
		}
		if ( $yt ) {
			return self::r( 'kritisch', 'Wir haben ' . ( 1 === $yt ? 'ein YouTube-Video' : $yt . ' YouTube-Videos' ) . ' gefunden, das ohne Datenschutzmodus und ohne Vorschaltbild direkt geladen wird. Dabei gehen Daten an Google, bevor jemand auf Abspielen drückt. Lassen Sie das von einer Fachstelle prüfen.' );
		}
		if ( $vim ) {
			return self::r( 'verbesserbar', 'Wir haben ' . ( 1 === $vim ? 'ein Vimeo-Video' : $vim . ' Vimeo-Videos' ) . ' gefunden, das ohne Vorschaltbild direkt geladen wird. Lassen Sie das von einer Fachstelle prüfen.' );
		}
		if ( $yt_nc ) {
			return self::r( 'gut', 'Ihre YouTube-Videos nutzen den erweiterten Datenschutzmodus. Noch sicherer ist ein Vorschaltbild, das das Video erst nach Klick lädt.' );
		}
		return self::r( 'gut', 'Auf der Startseite sind keine Videos von YouTube oder Vimeo direkt eingebettet.' );
	}

	/**
	 * R08 Google Maps.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_r08( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		foreach ( $ctx['page']['embeds'] as $e ) {
			if ( 'maps' === $e['art'] ) {
				return self::r( 'kritisch', 'Wir haben eine Google-Karte gefunden, die direkt beim Aufruf geladen wird. Dabei gehen Daten an Google, ohne dass Besucher zugestimmt haben. Lassen Sie das von einer Fachstelle prüfen.' );
			}
		}
		if ( in_array( 'Google Maps (Skript)', $ctx['page']['third_parties'], true ) ) {
			return self::r( 'kritisch', 'Wir haben das Kartenskript von Google Maps gefunden, das direkt beim Aufruf geladen wird. Lassen Sie das von einer Fachstelle prüfen.' );
		}
		return self::r( 'gut', 'Auf der Startseite ist keine Google-Karte direkt eingebettet.' );
	}

	/**
	 * R09 Weitere Drittdienste (Hinweis).
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_r09( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$list = array_values(
			array_filter(
				$ctx['page']['third_parties'],
				static function ( $t ) {
					return 'Google Maps (Skript)' !== $t;
				}
			)
		);
		foreach ( isset( $d['css'] ) ? $d['css'] : array() as $c ) {
			if ( ! empty( $c['drittfonts'] ) ) {
				$list[] = 'Webfonts eines anderen Anbieters im Stylesheet';
				break;
			}
		}
		if ( $list ) {
			return self::r( 'hinweis', 'Diese Dienste laden Inhalte von fremden Servern: ' . self::join_list( array_slice( $list, 0, 8 ) ) . '. Prüfen Sie, ob sie in Ihrer Datenschutzerklärung stehen und ob sie eine Einwilligung brauchen.', array( 'dienste' => $list ) );
		}
		return self::r( 'gut', 'Wir haben keine weiteren Dienste gefunden, die Inhalte von fremden Servern laden.' );
	}

	/**
	 * R10 Cookies beim ersten Aufruf (Hinweis).
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_r10( $d, $ctx ) {
		$cookies = isset( $d['home']['cookies'] ) ? $d['home']['cookies'] : array();
		$note    = ' Cookies, die erst per JavaScript im Browser gesetzt werden, erkennen wir auf diesem Weg nicht.';
		if ( ! $cookies ) {
			return self::r( 'gut', 'Ihr Server setzt beim ersten Aufruf keine Cookies.' . $note );
		}
		$tracking  = array();
		$technical = array();
		foreach ( $cookies as $c ) {
			if ( preg_match( '/^(_ga|_gid|_gat|_gcl|_fbp|_fbc|_hj|_uet|_uetsid|_clck|_clsk|_pk_|_ttp|ttclid|li_|bcookie|ide|nid|__utm|_pinterest)/i', $c ) ) {
				$tracking[] = $c;
			} else {
				$technical[] = $c;
			}
		}
		if ( $tracking ) {
			return self::r( 'hinweis', 'Ihr Server setzt schon beim ersten Aufruf Cookies, die nach Tracking aussehen: ' . self::join_list( array_slice( $tracking, 0, 5 ) ) . '. Das kann ohne Einwilligung unzulässig sein. Lassen Sie das von einer Fachstelle prüfen.' . $note );
		}
		return self::r( 'hinweis', 'Ihr Server setzt beim ersten Aufruf ' . ( 1 === count( $technical ) ? 'ein Cookie' : count( $technical ) . ' Cookies' ) . ' (' . self::join_list( array_slice( $technical, 0, 4 ) ) . '). Meist sind das technisch notwendige Cookies, zum Beispiel für die Sitzung.' . $note );
	}

	/**
	 * R11 Barrierefreiheit Grundlagen.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_r11( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$p      = $ctx['page'];
		$ok     = array();
		$missing = array();
		if ( '' !== $p['lang'] ) {
			$ok[] = 'Sprache';
		} else {
			$missing[] = 'Sprachangabe';
		}
		if ( ! $p['img_total'] || $p['img_alt'] / max( 1, $p['img_total'] ) >= 0.9 ) {
			$ok[] = 'Bildbeschreibungen';
		} else {
			$missing[] = 'Beschreibungen für alle Bilder';
		}
		if ( ! $p['inputs_total'] || $p['inputs_labeled'] >= $p['inputs_total'] ) {
			$ok[] = 'Formularbeschriftungen';
		} else {
			$missing[] = 'Beschriftungen für ' . ( $p['inputs_total'] - $p['inputs_labeled'] ) . ' Formularfelder';
		}
		if ( $p['skip_link'] || $p['main_landmark'] ) {
			$ok[] = 'Hauptbereich';
		} else {
			$missing[] = 'ein markierter Hauptbereich oder ein Link „Zum Inhalt springen“';
		}
		$werte = array( 'erfuellt' => count( $ok ) );
		if ( ! $missing ) {
			return self::r( 'gut', 'Die vier Grundlagen sind erfüllt: Sprache, Bildbeschreibungen, Formularbeschriftungen und Hauptbereich. Das ist noch keine vollständige Prüfung auf Barrierefreiheit.', $werte );
		}
		$status = count( $ok ) >= 2 ? 'verbesserbar' : 'kritisch';
		return self::r( $status, 'Es fehlen: ' . self::join_list( $missing ) . '.', $werte );
	}

	/**
	 * R12 PageSpeed Barrierefreiheit.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_r12( $d, $ctx ) {
		if ( ! $ctx['psi'] || null === $ctx['psi']['accessibility'] ) {
			return self::np( self::psi_reason( $d ) );
		}
		$v = (int) $ctx['psi']['accessibility'];
		$w = array( 'wert' => $v );
		$t = 'Google bewertet die Barrierefreiheit Ihrer Startseite mit ' . $v . ' von 100 Punkten.';
		if ( $v >= 90 ) {
			return self::r( 'gut', $t, $w );
		}
		return self::r( $v >= 50 ? 'verbesserbar' : 'kritisch', $t, $w );
	}

	/* ------------------------------------------------------------------
	 * Säule 6: KI-bereit
	 * ---------------------------------------------------------------- */

	/**
	 * KI-Crawler (Agent => Anzeigename).
	 *
	 * @return array
	 */
	public static function ai_bots() {
		return array(
			'gptbot'            => 'GPTBot (ChatGPT)',
			'oai-searchbot'     => 'OAI-SearchBot (ChatGPT-Suche)',
			'chatgpt-user'      => 'ChatGPT-User',
			'claudebot'         => 'ClaudeBot (Claude)',
			'perplexitybot'     => 'PerplexityBot (Perplexity)',
			'google-extended'   => 'Google-Extended (Gemini)',
			'applebot-extended' => 'Applebot-Extended (Apple)',
			'ccbot'             => 'CCBot (Common Crawl)',
		);
	}

	/**
	 * K01 KI-Crawler zugelassen.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_k01( $d, $ctx ) {
		if ( ! isset( $d['robots'] ) ) {
			return self::np( 'Die robots.txt konnte nicht geprüft werden.' );
		}
		if ( empty( $d['robots']['gefunden'] ) ) {
			return self::r( 'gut', 'Es gibt keine robots.txt mit Sperren. KI-Dienste dürfen Ihre Seite lesen.' );
		}
		$blocked = array();
		foreach ( self::ai_bots() as $agent => $label ) {
			if ( OQSC_Parser::robots_blocks_root( $d['robots']['regeln'], $agent ) ) {
				$blocked[] = $label;
			}
		}
		if ( $blocked ) {
			return self::r( 'verbesserbar', 'Ihre robots.txt sperrt ' . count( $blocked ) . ' KI-' . ( 1 === count( $blocked ) ? 'Dienst' : 'Dienste' ) . ': ' . self::join_list( $blocked ) . '.', array( 'gesperrt' => $blocked ) );
		}
		return self::r( 'gut', 'Ihre robots.txt lässt die wichtigen KI-Dienste wie ChatGPT, Perplexity, Claude und Gemini zu.' );
	}

	/**
	 * K02 llms.txt.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_k02( $d, $ctx ) {
		if ( ! isset( $d['llms'] ) ) {
			return self::np( 'Die llms.txt konnte nicht geprüft werden.' );
		}
		if ( ! empty( $d['llms']['gefunden'] ) ) {
			return self::r( 'gut', 'Ihre Website hat eine llms.txt, eine Kurzbeschreibung für KI-Dienste.' );
		}
		return self::r( 'verbesserbar', 'Ihre Website hat noch keine llms.txt.' );
	}

	/**
	 * K03 Strukturierte Daten.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_k03( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$p     = $ctx['page'];
		$valid = $p['jsonld_blocks'] - $p['jsonld_invalid'];
		$types = $p['jsonld_types'];
		$known = array_values( array_intersect( array_merge( array( 'LocalBusiness', 'Organization', 'FAQPage', 'Service', 'Product', 'Article', 'BreadcrumbList', 'WebSite', 'Person', 'Review', 'AggregateRating', 'OpeningHoursSpecification' ), OQSC_Parser::local_business_types() ), $types ) );
		$werte = array(
			'bloecke' => $p['jsonld_blocks'],
			'typen'   => array_slice( $types, 0, 12 ),
		);
		if ( $valid < 1 ) {
			return self::r( 'kritisch', $p['jsonld_invalid'] ? 'Die strukturierten Daten auf Ihrer Seite sind fehlerhaft und nicht lesbar.' : 'Ihre Seite enthält keine strukturierten Daten (JSON-LD).', $werte );
		}
		$strong = array_intersect( $types, array_merge( array( 'Organization', 'FAQPage', 'Service', 'Product' ), OQSC_Parser::local_business_types() ) );
		$list   = self::join_list( array_slice( array_unique( $known ? $known : $types ), 0, 6 ) );
		if ( $p['jsonld_invalid'] ) {
			return self::r( 'verbesserbar', 'Wir haben strukturierte Daten gefunden (' . $list . '), aber ' . $p['jsonld_invalid'] . ' Block ist fehlerhaft.', $werte );
		}
		if ( ! $strong ) {
			return self::r( 'verbesserbar', 'Es gibt strukturierte Daten (' . $list . '), aber keine Angaben zu Ihrem Betrieb oder Ihren Leistungen.', $werte );
		}
		return self::r( 'gut', 'Ihre Seite enthält strukturierte Daten: ' . $list . '.', $werte );
	}

	/**
	 * K04 Fragen und Antworten.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_k04( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$p = $ctx['page'];
		if ( $p['faq_schema'] ) {
			return self::r( 'gut', 'Ihre Seite hat einen Bereich mit Fragen und Antworten, auch maschinenlesbar hinterlegt.' );
		}
		if ( $p['question_headings'] >= 2 ) {
			return self::r( 'gut', 'Ihre Seite beantwortet ' . $p['question_headings'] . ' typische Fragen in Überschriften. Als FAQ-Schema hinterlegt wäre es noch besser.' );
		}
		return self::r( 'verbesserbar', 'Wir haben keinen Bereich mit häufigen Fragen und Antworten gefunden.' );
	}

	/**
	 * K05 Klare Selbstbeschreibung.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_k05( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$para = $ctx['page']['first_para'];
		if ( '' === $para ) {
			return self::r( 'kritisch', 'Wir haben keinen einleitenden Absatz gefunden, der Ihren Betrieb beschreibt.' );
		}
		$has_name = false;
		foreach ( self::name_tokens( $d, $ctx ) as $tok ) {
			if ( false !== mb_stripos( $para, $tok ) ) {
				$has_name = true;
				break;
			}
		}
		$has_svc = '' !== self::find_service( $para, $ctx['branche'] );
		$has_ort = $ctx['ort_kern'] && self::contains_word( $para, $ctx['ort_kern'] );
		$have    = array();
		$miss    = array();
		foreach ( array( 'Firmenname' => $has_name, 'Leistung' => $has_svc, 'Ort' => $has_ort ) as $k => $v ) {
			if ( $v ) {
				$have[] = $k;
			} else {
				$miss[] = $k;
			}
		}
		$werte = array( 'treffer' => count( $have ) );
		if ( ! $miss ) {
			return self::r( 'gut', 'Ihr erster Absatz nennt Firmenname, Leistung und Ort. So können KI-Dienste Sie klar zusammenfassen.', $werte );
		}
		$snippet = mb_substr( $para, 0, 140 ) . ( mb_strlen( $para ) > 140 ? ' …' : '' );
		return self::r( count( $have ) >= 2 ? 'verbesserbar' : 'kritisch', 'Ihr erster Absatz („' . $snippet . '“) nennt nicht: ' . self::join_list( $miss ) . '.', $werte );
	}

	/**
	 * K06 Lesbarkeit.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_k06( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$text = isset( $ctx['page']['para_sample'] ) && $ctx['page']['para_sample'] ? $ctx['page']['para_sample'] : '';
		$f    = self::flesch_amstad( $text );
		if ( $f['woerter'] < 40 ) {
			return self::np( 'Auf der Startseite steht zu wenig Fließtext für eine Bewertung der Lesbarkeit.' );
		}
		$v = $f['wert'];
		$w = array(
			'wert'    => $v,
			'woerter' => $f['woerter'],
		);
		if ( $v >= 50 ) {
			return self::r( 'gut', 'Ihre Texte sind gut lesbar (Lesbarkeitswert ' . $v . ' von 100).', $w );
		}
		return self::r( $v >= 30 ? 'verbesserbar' : 'kritisch', 'Ihre Texte sind schwer lesbar (Lesbarkeitswert ' . $v . ' von 100, gut ist ab 50). Meist liegt das an langen Sätzen und langen Wörtern.', $w );
	}

	/**
	 * K07 Server-Darstellung.
	 *
	 * @param array $d   Daten.
	 * @param array $ctx Kontext.
	 * @return array
	 */
	private static function check_k07( $d, $ctx ) {
		if ( ! self::has_page( $ctx ) ) {
			return self::np( 'Die Startseite konnte nicht gelesen werden.' );
		}
		$p     = $ctx['page'];
		$words = (int) $p['word_count'];
		$heavy = $p['scripts_total'] >= 4 || $p['script_bytes'] > 20000;
		if ( $words < 50 && $heavy ) {
			return self::r( 'verbesserbar', 'Im ausgelieferten HTML stehen nur ' . $words . ' Wörter, der Rest entsteht offenbar erst per JavaScript. Viele KI-Dienste lesen nur das HTML.', array( 'woerter' => $words ) );
		}
		return self::r( 'gut', 'Ihre Inhalte stehen direkt im HTML und sind ohne JavaScript lesbar.', array( 'woerter' => $words ) );
	}
}
