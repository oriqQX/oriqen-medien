<?php
/**
 * Täglicher Aufräumlauf.
 *
 * @package oriqen-check
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Cron: Aufbewahrung, abgelaufene Jobs, Ereignisse.
 */
class OQSC_Cron {

	const HOOK = 'oqsc_cron_daily';

	/**
	 * Täglichen Lauf einplanen.
	 */
	public static function schedule() {
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_event( time() + 600, 'daily', self::HOOK );
		}
	}

	/**
	 * Einplanung entfernen.
	 */
	public static function unschedule() {
		$ts = wp_next_scheduled( self::HOOK );
		while ( $ts ) {
			wp_unschedule_event( $ts, self::HOOK );
			$ts = wp_next_scheduled( self::HOOK );
		}
	}

	/**
	 * Aufräumen. Gibt die Anzahl gelöschter oder geänderter Zeilen zurück.
	 *
	 * @return array
	 */
	public static function run() {
		global $wpdb;
		$s      = OQSC_Plugin::settings();
		$checks = $wpdb->prefix . 'oqsc_checks';
		$leads  = $wpdb->prefix . 'oqsc_leads';
		$events = $wpdb->prefix . 'oqsc_events';
		$out    = array();

		// Hängende Jobs beenden.
		$out['abgebrochen'] = (int) $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$checks} SET status = 'abgebrochen', daten = NULL, updated_at = %s WHERE status IN ('wartet','laeuft') AND updated_at < %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				OQSC_Plugin::now(),
				OQSC_Plugin::now( -3600 )
			)
		);

		// Rohdaten nach Ablauf des Zwischenspeichers entfernen (Ergebnis bleibt).
		$out['rohdaten'] = (int) $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$checks} SET daten = NULL WHERE daten IS NOT NULL AND status IN ('fertig','fehler','abgebrochen') AND created_at < %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				OQSC_Plugin::now( -1 * HOUR_IN_SECONDS * max( 1, (int) $s['cache_stunden'] ) - HOUR_IN_SECONDS )
			)
		);

		// Anfragen nach Frist löschen.
		$lead_cut      = OQSC_Plugin::now( -1 * (int) $s['aufbewahrung_leads'] * 30 * DAY_IN_SECONDS );
		$out['leads']  = (int) $wpdb->query( $wpdb->prepare( "DELETE FROM {$leads} WHERE created_at < %s", $lead_cut ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		// Checks ohne Anfrage nach Frist löschen, Checks mit Anfrage bleiben so lange wie die Anfrage.
		$check_cut     = OQSC_Plugin::now( -1 * (int) $s['aufbewahrung_checks'] * DAY_IN_SECONDS );
		$out['checks'] = (int) $wpdb->query(
			$wpdb->prepare(
				"DELETE c FROM {$checks} c LEFT JOIN {$leads} l ON l.check_id = c.id WHERE l.id IS NULL AND c.created_at < %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$check_cut
			)
		);

		// Ereignisse nach 30 Tagen.
		$out['events'] = (int) $wpdb->query( $wpdb->prepare( "DELETE FROM {$events} WHERE created_at < %s", OQSC_Plugin::now( -30 * DAY_IN_SECONDS ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		// Abgelaufene Transients dieses Plugins (WordPress räumt sonst nur bei Zugriff).
		if ( function_exists( 'delete_expired_transients' ) ) {
			delete_expired_transients();
		}

		return $out;
	}
}
