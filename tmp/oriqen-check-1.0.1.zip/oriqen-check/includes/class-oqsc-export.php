<?php
/**
 * CSV-Export für Checks und Anfragen.
 *
 * @package oriqen-check
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * CSV mit Schutz gegen Formel-Injektion.
 */
class OQSC_Export {

	/**
	 * Zelle absichern: Werte, die mit =, +, -, @, Tab oder Wagenrücklauf beginnen, bekommen ein Hochkomma.
	 *
	 * @param mixed $value Wert.
	 * @return string
	 */
	public static function cell( $value ) {
		$value = (string) $value;
		$value = str_replace( array( "\r\n", "\r" ), "\n", $value );
		if ( '' !== $value && in_array( $value[0], array( '=', '+', '-', '@', "\t", "\r" ), true ) ) {
			$value = "'" . $value;
		}
		return $value;
	}

	/**
	 * Zeilen als CSV (Semikolon, UTF-8 mit BOM für Excel).
	 *
	 * @param array $header Kopfzeile.
	 * @param array $rows   Zeilen.
	 * @return string
	 */
	public static function to_csv( $header, $rows ) {
		$fh = fopen( 'php://temp', 'w+' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- Speicherstrom.
		fwrite( $fh, "\xEF\xBB\xBF" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
		fputcsv( $fh, array_map( array( __CLASS__, 'cell' ), $header ), ';', '"', '\\' );
		foreach ( $rows as $r ) {
			fputcsv( $fh, array_map( array( __CLASS__, 'cell' ), $r ), ';', '"', '\\' );
		}
		rewind( $fh );
		$csv = stream_get_contents( $fh );
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		return (string) $csv;
	}

	/**
	 * Daten für den Export.
	 *
	 * @param string $art checks|leads.
	 * @return array header, rows.
	 */
	public static function data( $art ) {
		$branchen = OQSC_Plugin::branchen();
		$rows     = array();
		if ( 'leads' === $art ) {
			$header = array( 'ID', 'Eingang', 'Name', 'E-Mail', 'Telefon', 'Status', 'Domain', 'Index', 'Nachricht' );
			$page   = 1;
			do {
				$list = OQSC_Admin_Rest::leads_list(
					array(
						'seite' => $page,
						'pro'   => 200,
					)
				);
				foreach ( $list['eintraege'] as $l ) {
					$d      = OQSC_Admin_Rest::lead_detail( $l['id'] );
					$rows[] = array( $l['id'], $l['created_at'], $l['name'], $l['email'], $l['telefon'], $l['status'], $l['domain'], $l['index_wert'], $d ? $d['nachricht'] : '' );
				}
				++$page;
			} while ( count( $list['eintraege'] ) === 200 && $page < 100 );
			return array( $header, $rows );
		}
		$header = array( 'ID', 'Datum', 'Domain', 'URL', 'Index', 'Status', 'Quelle', 'Ort', 'Branche', 'Anfrage', 'Gefunden', 'Vor Ort', 'Schnell', 'Überzeugend', 'Rechtssicher', 'KI-bereit' );
		$page   = 1;
		do {
			$list = OQSC_Admin_Rest::checks_list(
				array(
					'seite' => $page,
					'pro'   => 200,
				)
			);
			foreach ( $list['eintraege'] as $c ) {
				$detail = OQSC_Admin_Rest::check_detail( $c['id'] );
				$vals   = array();
				foreach ( isset( $detail['ergebnis']['saeulen'] ) ? $detail['ergebnis']['saeulen'] : array() as $s ) {
					$vals[ $s['key'] ] = $s['wert'];
				}
				$row = array( $c['id'], $c['created_at'], $c['domain'], $c['url'], $c['index_wert'], $c['status'], $c['quelle'], $c['ort'], isset( $branchen[ $c['branche'] ] ) ? $branchen[ $c['branche'] ] : '', $c['anfrage'] ? 'ja' : 'nein' );
				foreach ( array_keys( OQSC_Checks::pillars() ) as $k ) {
					$row[] = isset( $vals[ $k ] ) ? $vals[ $k ] : '';
				}
				$rows[] = $row;
			}
			++$page;
		} while ( count( $list['eintraege'] ) === 200 && $page < 100 );
		return array( $header, $rows );
	}

	/**
	 * admin-post: Download.
	 */
	public static function handle() {
		if ( ! current_user_can( 'oqsc_manage' ) ) {
			wp_die( 'Keine Berechtigung.' );
		}
		check_admin_referer( 'oqsc_export' );
		$art                   = isset( $_GET['art'] ) && 'leads' === $_GET['art'] ? 'leads' : 'checks';
		list( $header, $rows ) = self::data( $art );
		$csv                   = self::to_csv( $header, $rows );
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="oriqen-check-' . $art . '-' . gmdate( 'Y-m-d' ) . '.csv"' );
		header( 'X-Content-Type-Options: nosniff' );
		echo $csv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CSV-Download, Zellen gegen Formel-Injektion abgesichert.
		exit;
	}
}
