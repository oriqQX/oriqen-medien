<?php
/**
 * Sichere Abrufe fremder Websites nach SICHERHEIT.md.
 *
 * Schutz gegen SSRF: Schema, Port, Host-Regeln, DNS-Prüfung aller Adressen,
 * Festsetzen der geprüften IP (CURLOPT_RESOLVE), Weiterleitungen nur einzeln
 * und geprüft, Größen- und Zeitlimits, Anfragebudget je Check.
 *
 * @package oriqen-check
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Abrufe mit Budget.
 */
class OQSC_Fetcher {

	const MAX_BYTES     = 2097152;
	const TIMEOUT       = 8;
	const MAX_REDIRECTS = 5;

	/**
	 * Verbleibende Anfragen.
	 *
	 * @var int
	 */
	private $budget;

	/**
	 * Verbrauchte Anfragen.
	 *
	 * @var int
	 */
	private $used = 0;

	/**
	 * Aktuelle Festsetzung: host, port, ip.
	 *
	 * @var array|null
	 */
	private $pin = null;

	/**
	 * cURL-Info des letzten Abrufs.
	 *
	 * @var array
	 */
	private $last_info = array();

	/**
	 * Konstruktor.
	 *
	 * @param int $budget Erlaubte Anfragen an die geprüfte Website.
	 */
	public function __construct( $budget = 16 ) {
		$this->budget = max( 0, (int) $budget );
	}

	/**
	 * Verbrauchte Anfragen.
	 *
	 * @return int
	 */
	public function used() {
		return $this->used;
	}

	/**
	 * Noch verfügbare Anfragen.
	 *
	 * @return int
	 */
	public function remaining() {
		return max( 0, $this->budget - $this->used );
	}

	/**
	 * User-Agent, damit Betreiber sehen, wer prüft.
	 *
	 * @return string
	 */
	public static function user_agent() {
		$page = OQSC_Plugin::get( 'check_seite_url', '' );
		if ( ! $page ) {
			$page = 'https://oriqen.de/';
		}
		return 'oriqen-Check/1.0 (+' . $page . ')';
	}

	/**
	 * Eingabe eines Besuchers in eine prüfbare URL wandeln.
	 *
	 * @param string $raw Eingabe.
	 * @return string|WP_Error
	 */
	public static function normalize_input( $raw ) {
		$raw = trim( (string) $raw );
		$raw = preg_replace( '/[\x00-\x20\x7f]+/', '', $raw );
		if ( '' === $raw || strlen( $raw ) > 400 ) {
			return new WP_Error( 'oqsc_ungueltig', 'Bitte geben Sie eine gültige Website-Adresse ein, zum Beispiel ihre-firma.de.' );
		}
		if ( ! preg_match( '#^[a-z][a-z0-9+.\-]*://#i', $raw ) ) {
			$raw = 'https://' . ltrim( $raw, '/' );
		}
		$parts = wp_parse_url( $raw );
		if ( ! $parts || empty( $parts['host'] ) ) {
			return new WP_Error( 'oqsc_ungueltig', 'Bitte geben Sie eine gültige Website-Adresse ein, zum Beispiel ihre-firma.de.' );
		}
		$scheme = strtolower( $parts['scheme'] );
		$host   = self::normalize_host( $parts['host'] );
		if ( '' === $host ) {
			return new WP_Error( 'oqsc_ungueltig', 'Diese Adresse können wir nicht lesen. Bitte prüfen Sie die Schreibweise.' );
		}
		$url = $scheme . '://' . $host;
		if ( isset( $parts['port'] ) ) {
			$url .= ':' . (int) $parts['port'];
		}
		$url .= '/';
		if ( isset( $parts['user'] ) || isset( $parts['pass'] ) ) {
			return new WP_Error( 'oqsc_ungueltig', 'Adressen mit Zugangsdaten prüfen wir nicht.' );
		}
		$valid = self::validate_url( $url );
		if ( is_wp_error( $valid ) ) {
			return $valid;
		}
		return $url;
	}

	/**
	 * Host normalisieren: Kleinbuchstaben, IDN in Punycode, ohne Punkt am Ende.
	 *
	 * @param string $host Host.
	 * @return string
	 */
	public static function normalize_host( $host ) {
		$host = strtolower( trim( (string) $host, " .\t" ) );
		if ( '' === $host ) {
			return '';
		}
		if ( preg_match( '/[^\x20-\x7e]/', $host ) ) {
			if ( ! function_exists( 'idn_to_ascii' ) ) {
				return '';
			}
			$ascii = defined( 'INTL_IDNA_VARIANT_UTS46' ) ? idn_to_ascii( $host, IDNA_DEFAULT, INTL_IDNA_VARIANT_UTS46 ) : idn_to_ascii( $host );
			if ( ! $ascii ) {
				return '';
			}
			$host = strtolower( $ascii );
		}
		return $host;
	}

	/**
	 * Domain-Schlüssel für Limits und Zwischenspeicher (ohne www.).
	 *
	 * @param string $url_or_host URL oder Host.
	 * @return string
	 */
	public static function domain_key( $url_or_host ) {
		$host = false !== strpos( $url_or_host, '/' ) ? wp_parse_url( $url_or_host, PHP_URL_HOST ) : $url_or_host;
		$host = self::normalize_host( (string) $host );
		return preg_replace( '/^www\./', '', $host );
	}

	/**
	 * Testkonstante auswerten: Liste erlaubter "ip:port" oder true für Loopback.
	 *
	 * @return array|bool
	 */
	private static function test_allow() {
		if ( ! OQSC_Plugin::test_local_allowed() ) {
			return false;
		}
		if ( true === OQSC_TEST_ALLOW_LOCAL ) {
			return true;
		}
		return array_filter( array_map( 'trim', explode( ',', (string) OQSC_TEST_ALLOW_LOCAL ) ) );
	}

	/**
	 * Ist ein Port im Testmodus erlaubt?
	 *
	 * @param int $port Port.
	 * @return bool
	 */
	private static function test_port_allowed( $port ) {
		$allow = self::test_allow();
		if ( true === $allow ) {
			return true;
		}
		if ( is_array( $allow ) ) {
			foreach ( $allow as $pair ) {
				if ( substr( $pair, -1 * ( strlen( (string) $port ) + 1 ) ) === ':' . $port ) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Ist eine nicht öffentliche Adresse im Testmodus erlaubt?
	 *
	 * @param string $ip   IP.
	 * @param int    $port Port.
	 * @return bool
	 */
	private static function test_ip_allowed( $ip, $port ) {
		$allow = self::test_allow();
		if ( true === $allow ) {
			return self::ip_in_cidr( $ip, '127.0.0.0/8' );
		}
		return is_array( $allow ) && in_array( $ip . ':' . $port, $allow, true );
	}

	/**
	 * URL-Regeln ohne Netzwerk prüfen.
	 *
	 * @param string $url URL.
	 * @return array|WP_Error Teile der URL.
	 */
	public static function validate_url( $url ) {
		$msg_invalid = 'Diese Adresse können wir nicht prüfen. Bitte geben Sie eine öffentliche Website an, zum Beispiel ihre-firma.de.';
		if ( ! is_string( $url ) || strlen( $url ) > 2000 || preg_match( '/[\x00-\x20\x7f]/', $url ) ) {
			return new WP_Error( 'oqsc_ungueltig', $msg_invalid );
		}
		$p = wp_parse_url( $url );
		if ( ! $p || empty( $p['scheme'] ) || empty( $p['host'] ) ) {
			return new WP_Error( 'oqsc_ungueltig', $msg_invalid );
		}
		$scheme = strtolower( $p['scheme'] );
		if ( 'http' !== $scheme && 'https' !== $scheme ) {
			return new WP_Error( 'oqsc_ungueltig', $msg_invalid );
		}
		if ( isset( $p['user'] ) || isset( $p['pass'] ) ) {
			return new WP_Error( 'oqsc_ungueltig', 'Adressen mit Zugangsdaten prüfen wir nicht.' );
		}
		$port = isset( $p['port'] ) ? (int) $p['port'] : ( 'https' === $scheme ? 443 : 80 );
		if ( 80 !== $port && 443 !== $port && ! self::test_port_allowed( $port ) ) {
			return new WP_Error( 'oqsc_ungueltig', 'Wir prüfen nur Websites auf den üblichen Ports 80 und 443.' );
		}
		$host = self::normalize_host( $p['host'] );
		$bare = trim( $host, '[]' );
		if ( '' === $host || filter_var( $bare, FILTER_VALIDATE_IP ) ) {
			return new WP_Error( 'oqsc_ungueltig', 'Bitte geben Sie einen Domainnamen ein, keine IP-Adresse.' );
		}
		if ( false === strpos( $host, '.' ) || ! preg_match( '/^[a-z0-9]([a-z0-9\-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9\-]*[a-z0-9])?)+$/', $host ) || strlen( $host ) > 253 ) {
			return new WP_Error( 'oqsc_ungueltig', $msg_invalid );
		}
		if ( preg_match( '/^\d+(\.\d+)*$/', $host ) || preg_match( '/^0x/i', $host ) ) {
			return new WP_Error( 'oqsc_ungueltig', 'Bitte geben Sie einen Domainnamen ein, keine IP-Adresse.' );
		}
		foreach ( array( 'localhost', 'local', 'internal', 'lan', 'localdomain', 'home', 'corp', 'intranet', 'arpa', 'onion' ) as $tld ) {
			if ( $host === $tld || substr( $host, -1 * ( strlen( $tld ) + 1 ) ) === '.' . $tld ) {
				return new WP_Error( 'oqsc_intern', 'Interne Adressen prüfen wir nicht.' );
			}
		}
		if ( self::is_blocked_host( $host ) ) {
			return new WP_Error( 'oqsc_gesperrt', 'Diese Website ist vom Check ausgenommen.' );
		}
		return array(
			'scheme' => $scheme,
			'host'   => $host,
			'port'   => $port,
			'path'   => isset( $p['path'] ) ? $p['path'] : '/',
			'query'  => isset( $p['query'] ) ? $p['query'] : '',
		);
	}

	/**
	 * Sperrliste, eigene Domain und Server selbst.
	 *
	 * @param string $host Host.
	 * @return bool
	 */
	public static function is_blocked_host( $host ) {
		$host    = strtolower( $host );
		$blocked = array();
		$own     = wp_parse_url( home_url(), PHP_URL_HOST );
		if ( $own ) {
			$blocked[] = self::domain_key( $own );
		}
		$site = wp_parse_url( site_url(), PHP_URL_HOST );
		if ( $site ) {
			$blocked[] = self::domain_key( $site );
		}
		if ( ! empty( $_SERVER['SERVER_NAME'] ) ) {
			$blocked[] = self::domain_key( sanitize_text_field( wp_unslash( $_SERVER['SERVER_NAME'] ) ) );
		}
		$list = preg_split( '/[\r\n]+/', (string) OQSC_Plugin::get( 'sperrliste', '' ) );
		foreach ( $list as $item ) {
			$item = trim( strtolower( $item ) );
			if ( '' !== $item ) {
				$blocked[] = $item;
			}
		}
		$key = self::domain_key( $host );
		foreach ( array_filter( $blocked ) as $b ) {
			if ( 0 === strpos( $b, '*.' ) ) {
				$suffix = substr( $b, 1 );
				if ( substr( $host, -1 * strlen( $suffix ) ) === $suffix || $host === substr( $b, 2 ) ) {
					return true;
				}
				continue;
			}
			$b = preg_replace( '/^www\./', '', $b );
			if ( $key === $b || $host === $b || substr( $host, -1 * ( strlen( $b ) + 1 ) ) === '.' . $b ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Host auflösen (A und AAAA, dazu der Systemresolver). Alle Adressen müssen öffentlich sein.
	 *
	 * @param string $host Host.
	 * @param int    $port Port.
	 * @return array|WP_Error Liste der IPs, erste ist die bevorzugte.
	 */
	public static function resolve( $host, $port = 443 ) {
		$ips = array();
		if ( function_exists( 'dns_get_record' ) ) {
			$records = @dns_get_record( $host, DNS_A + DNS_AAAA ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- DNS-Fehler werden unten behandelt.
			if ( is_array( $records ) ) {
				foreach ( $records as $r ) {
					if ( isset( $r['ip'] ) ) {
						$ips[] = $r['ip'];
					} elseif ( isset( $r['ipv6'] ) ) {
						$ips[] = $r['ipv6'];
					}
				}
			}
		}
		$sys = @gethostbynamel( $host ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- Fehler werden unten behandelt.
		if ( is_array( $sys ) ) {
			$ips = array_merge( $ips, $sys );
		}
		$ips = array_values( array_unique( array_filter( $ips ) ) );
		if ( empty( $ips ) ) {
			return new WP_Error( 'oqsc_dns', 'Die Adresse ist im Internet nicht auffindbar. Bitte prüfen Sie die Schreibweise.' );
		}
		foreach ( $ips as $ip ) {
			if ( ! self::is_public_ip( $ip ) && ! self::test_ip_allowed( $ip, $port ) ) {
				return new WP_Error( 'oqsc_intern', 'Diese Adresse zeigt auf ein internes Netz. Solche Adressen prüfen wir nicht.' );
			}
		}
		// IPv4 zuerst, das ist auf geteiltem Hosting am verlässlichsten.
		usort(
			$ips,
			static function ( $a, $b ) {
				return (int) ( false !== strpos( $a, ':' ) ) - (int) ( false !== strpos( $b, ':' ) );
			}
		);
		return $ips;
	}

	/**
	 * Ist eine IP öffentlich erreichbar und unbedenklich?
	 *
	 * @param string $ip IP.
	 * @return bool
	 */
	public static function is_public_ip( $ip ) {
		if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) {
			return false;
		}
		if ( ! filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) {
			return false;
		}
		$v4 = array(
			'0.0.0.0/8',
			'10.0.0.0/8',
			'100.64.0.0/10',
			'127.0.0.0/8',
			'169.254.0.0/16',
			'172.16.0.0/12',
			'192.0.0.0/24',
			'192.0.2.0/24',
			'192.88.99.0/24',
			'192.168.0.0/16',
			'198.18.0.0/15',
			'198.51.100.0/24',
			'203.0.113.0/24',
			'224.0.0.0/4',
			'240.0.0.0/4',
		);
		$v6 = array(
			'::/128',
			'::1/128',
			'::ffff:0:0/96',
			'64:ff9b::/96',
			'64:ff9b:1::/48',
			'100::/64',
			'2001::/23',
			'2001:db8::/32',
			'2002::/16',
			'fc00::/7',
			'fe80::/10',
			'fec0::/10',
			'ff00::/8',
		);
		if ( false !== strpos( $ip, ':' ) ) {
			// Eingebettete IPv4 (mapped, NAT64, 6to4) prüfen und grundsätzlich ablehnen.
			foreach ( $v6 as $cidr ) {
				if ( self::ip_in_cidr( $ip, $cidr ) ) {
					return false;
				}
			}
			return true;
		}
		foreach ( $v4 as $cidr ) {
			if ( self::ip_in_cidr( $ip, $cidr ) ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Liegt eine IP in einem Netz?
	 *
	 * @param string $ip   IP.
	 * @param string $cidr Netz.
	 * @return bool
	 */
	public static function ip_in_cidr( $ip, $cidr ) {
		list( $net, $bits ) = explode( '/', $cidr );
		$ip_bin             = @inet_pton( $ip );  // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		$net_bin            = @inet_pton( $net ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		if ( false === $ip_bin || false === $net_bin || strlen( $ip_bin ) !== strlen( $net_bin ) ) {
			return false;
		}
		$bits  = (int) $bits;
		$bytes = intdiv( $bits, 8 );
		if ( substr( $ip_bin, 0, $bytes ) !== substr( $net_bin, 0, $bytes ) ) {
			return false;
		}
		$rest = $bits % 8;
		if ( 0 === $rest ) {
			return true;
		}
		$mask = chr( ( 0xff << ( 8 - $rest ) ) & 0xff );
		return ( $ip_bin[ $bytes ] & $mask ) === ( $net_bin[ $bytes ] & $mask );
	}

	/**
	 * Abruf mit eigener, geprüfter Weiterleitungskette.
	 *
	 * @param string $url  URL.
	 * @param array  $args method (GET|HEAD), follow (bool), max_bytes, timeout, insecure_retry (bool).
	 * @return array Ergebnis mit ok, status, headers, body, final_url, redirects, ttfb, zeit, groesse, gekuerzt, ssl_fehler, fehler, meldung.
	 */
	public function fetch( $url, $args = array() ) {
		$args = array_merge(
			array(
				'method'         => 'GET',
				'follow'         => true,
				'max_bytes'      => self::MAX_BYTES,
				'timeout'        => self::TIMEOUT,
				'insecure_retry' => false,
			),
			$args
		);

		$redirects = array();
		$current   = $url;
		$method    = strtoupper( $args['method'] );
		$hops      = 0;
		$ssl_error = false;

		while ( true ) {
			$res = $this->single( $current, $method, $args );
			if ( ! $res['ok'] && 'ssl' === $res['fehler'] && $args['insecure_retry'] ) {
				$ssl_error = true;
				$insecure  = $args;
				$res       = $this->single( $current, $method, array_merge( $insecure, array( 'sslverify' => false ) ) );
			}
			$res['ssl_fehler'] = $ssl_error || ! empty( $res['ssl_fehler'] );
			if ( ! $res['ok'] ) {
				$res['redirects'] = $redirects;
				$res['final_url'] = $current;
				return $res;
			}
			$status   = (int) $res['status'];
			$location = isset( $res['headers']['location'] ) ? $res['headers']['location'] : '';
			if ( is_array( $location ) ) {
				$location = end( $location );
			}
			if ( $args['follow'] && in_array( $status, array( 301, 302, 303, 307, 308 ), true ) && '' !== $location ) {
				if ( $hops >= self::MAX_REDIRECTS ) {
					$res['ok']        = false;
					$res['fehler']    = 'weiterleitungen';
					$res['meldung']   = 'Die Website leitet zu oft weiter.';
					$res['redirects'] = $redirects;
					$res['final_url'] = $current;
					return $res;
				}
				$next        = WP_Http::make_absolute_url( $location, $current );
				$redirects[] = array(
					'url'    => $current,
					'status' => $status,
					'ziel'   => $next,
				);
				if ( 303 === $status ) {
					$method = 'GET';
				}
				$current = $next;
				++$hops;
				continue;
			}
			$res['redirects'] = $redirects;
			$res['final_url'] = $current;
			return $res;
		}
	}

	/**
	 * Ein einzelner Abruf ohne Weiterleitung.
	 *
	 * @param string $url    URL.
	 * @param string $method GET oder HEAD.
	 * @param array  $args   Optionen.
	 * @return array
	 */
	private function single( $url, $method, $args ) {
		$base = array(
			'ok'         => false,
			'url'        => $url,
			'status'     => 0,
			'headers'    => array(),
			'cookies'    => array(),
			'body'       => '',
			'ttfb'       => null,
			'zeit'       => 0,
			'groesse'    => 0,
			'gekuerzt'   => false,
			'ssl_fehler' => false,
			'ip'         => '',
			'fehler'     => '',
			'meldung'    => '',
		);

		if ( $this->used >= $this->budget ) {
			$base['fehler']  = 'budget';
			$base['meldung'] = 'Abruflimit für diesen Check erreicht.';
			return $base;
		}
		if ( ! function_exists( 'curl_init' ) ) {
			$base['fehler']  = 'kein_curl';
			$base['meldung'] = 'Auf dem Server fehlt cURL.';
			return $base;
		}

		$parts = self::validate_url( $url );
		if ( is_wp_error( $parts ) ) {
			$base['fehler']  = $parts->get_error_code();
			$base['meldung'] = $parts->get_error_message();
			return $base;
		}
		$ips = self::resolve( $parts['host'], $parts['port'] );
		if ( is_wp_error( $ips ) ) {
			$base['fehler']  = $ips->get_error_code();
			$base['meldung'] = $ips->get_error_message();
			return $base;
		}

		++$this->used;
		$this->pin       = array(
			'host' => $parts['host'],
			'port' => $parts['port'],
			'ip'   => $ips[0],
		);
		$this->last_info = array();
		$base['ip']      = $ips[0];

		add_action( 'http_api_curl', array( $this, 'curl_pin' ), 99, 3 );
		add_action( 'requests-curl.after_request', array( $this, 'curl_info' ), 10, 2 );
		$test = OQSC_Plugin::test_local_allowed();
		if ( $test ) {
			add_filter( 'http_request_host_is_external', array( $this, 'test_external' ), 10, 2 );
			add_filter( 'http_allowed_safe_ports', array( $this, 'test_ports' ) );
		}

		$request_args = array(
			'method'              => $method,
			'timeout'             => (int) $args['timeout'],
			'redirection'         => 0,
			'limit_response_size' => (int) $args['max_bytes'],
			'user-agent'          => self::user_agent(),
			'headers'             => array(
				'Accept'          => isset( $args['accept'] ) ? (string) $args['accept'] : 'text/html,application/xhtml+xml,application/xml;q=0.9,text/plain;q=0.8,*/*;q=0.5',
				'Accept-Language' => 'de-DE,de;q=0.9,en;q=0.5',
			),
			'sslverify'           => isset( $args['sslverify'] ) ? (bool) $args['sslverify'] : true,
			'reject_unsafe_urls'  => true,
			'httpversion'         => '1.1',
			'cookies'             => array(),
		);

		$start    = microtime( true );
		$response = wp_safe_remote_request( $url, $request_args );
		$elapsed  = microtime( true ) - $start;

		remove_action( 'http_api_curl', array( $this, 'curl_pin' ), 99 );
		remove_action( 'requests-curl.after_request', array( $this, 'curl_info' ), 10 );
		if ( $test ) {
			remove_filter( 'http_request_host_is_external', array( $this, 'test_external' ), 10 );
			remove_filter( 'http_allowed_safe_ports', array( $this, 'test_ports' ) );
		}
		$this->pin = null;

		$base['zeit'] = round( $elapsed, 3 );

		if ( is_wp_error( $response ) ) {
			$msg = $response->get_error_message();
			if ( preg_match( '/SSL|certificate|TLS/i', $msg ) && false === stripos( $msg, 'timed out' ) ) {
				$base['fehler']     = 'ssl';
				$base['ssl_fehler'] = true;
				$base['meldung']    = 'Das Sicherheitszertifikat der Website ist nicht gültig.';
			} elseif ( preg_match( '/timed out|timeout/i', $msg ) ) {
				$base['fehler']  = 'zeit';
				$base['meldung'] = 'Die Website hat nicht innerhalb von ' . (int) $args['timeout'] . ' Sekunden geantwortet.';
			} else {
				$base['fehler']  = 'verbindung';
				$base['meldung'] = 'Die Website war nicht erreichbar.';
			}
			return $base;
		}

		$headers = array();
		$raw     = wp_remote_retrieve_headers( $response );
		if ( is_object( $raw ) && method_exists( $raw, 'getAll' ) ) {
			$raw = $raw->getAll();
		}
		foreach ( (array) $raw as $k => $v ) {
			$k = strtolower( (string) $k );
			if ( is_array( $v ) ) {
				$v = array_map( 'strval', $v );
				$v = 1 === count( $v ) ? $v[0] : $v;
			}
			$headers[ $k ] = $v;
		}

		$cookies = array();
		foreach ( wp_remote_retrieve_cookies( $response ) as $c ) {
			if ( $c instanceof WP_Http_Cookie ) {
				$cookies[] = substr( (string) $c->name, 0, 100 );
			}
		}

		$body = (string) wp_remote_retrieve_body( $response );

		$base['ok']       = true;
		$base['status']   = (int) wp_remote_retrieve_response_code( $response );
		$base['headers']  = $headers;
		$base['cookies']  = $cookies;
		$base['body']     = $body;
		$base['groesse']  = strlen( $body );
		$base['gekuerzt'] = strlen( $body ) >= (int) $args['max_bytes'];
		if ( isset( $this->last_info['starttransfer_time'] ) && $this->last_info['starttransfer_time'] > 0 ) {
			$base['ttfb'] = round( (float) $this->last_info['starttransfer_time'], 3 );
		} else {
			$base['ttfb'] = round( $elapsed, 3 );
		}
		if ( isset( $this->last_info['size_download'] ) && $this->last_info['size_download'] > 0 ) {
			$base['uebertragen'] = (int) $this->last_info['size_download'];
		}
		return $base;
	}

	/**
	 * Geprüfte IP für cURL festsetzen (gegen DNS-Wechsel zwischen Prüfung und Abruf).
	 *
	 * @param resource|CurlHandle $handle cURL-Handle.
	 * @param array               $r      Argumente.
	 * @param string              $url    URL.
	 */
	public function curl_pin( $handle, $r, $url ) {
		if ( ! $this->pin ) {
			return;
		}
		$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
		if ( $host !== $this->pin['host'] ) {
			return;
		}
		$ip = false !== strpos( $this->pin['ip'], ':' ) ? '[' . $this->pin['ip'] . ']' : $this->pin['ip'];
		// phpcs:disable WordPress.WP.AlternativeFunctions.curl_curl_setopt -- Festsetzen der IP ist nur über cURL möglich.
		curl_setopt( $handle, CURLOPT_RESOLVE, array( $this->pin['host'] . ':' . $this->pin['port'] . ':' . $ip ) );
		curl_setopt( $handle, CURLOPT_FOLLOWLOCATION, false );
		if ( defined( 'CURLOPT_PROTOCOLS' ) ) {
			curl_setopt( $handle, CURLOPT_PROTOCOLS, CURLPROTO_HTTP | CURLPROTO_HTTPS );
		}
		// phpcs:enable
	}

	/**
	 * cURL-Info mitschneiden (Zeit bis zum ersten Byte).
	 *
	 * @param mixed $headers Kopfzeilen.
	 * @param mixed $info    cURL-Info.
	 */
	public function curl_info( $headers, $info = null ) {
		if ( is_array( $info ) ) {
			$this->last_info = $info;
		}
	}

	/**
	 * Testmodus: erlaubte lokale Ziele für wp_safe_remote_request freigeben.
	 *
	 * @param bool   $external Bisher.
	 * @param string $host     Host.
	 * @return bool
	 */
	public function test_external( $external, $host ) {
		if ( $this->pin && $host === $this->pin['host'] && self::test_ip_allowed( $this->pin['ip'], $this->pin['port'] ) ) {
			return true;
		}
		return $external;
	}

	/**
	 * Testmodus: Port der Fixtures zulassen.
	 *
	 * @param array $ports Ports.
	 * @return array
	 */
	public function test_ports( $ports ) {
		if ( $this->pin && self::test_port_allowed( $this->pin['port'] ) ) {
			$ports[] = (int) $this->pin['port'];
		}
		return $ports;
	}
}
