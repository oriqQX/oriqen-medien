<?php
/**
 * Bot-Schutz, Limits, Warteschlange und Not-Aus.
 *
 * @package oriqen-check
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Schutzschicht vor jedem öffentlichen Aufruf.
 */
class OQSC_Guard {

	const TOKEN_TTL       = 1800;
	const BAD_TOKEN_LIMIT = 5;

	/**
	 * IP des Besuchers (nur REMOTE_ADDR, Header sind fälschbar).
	 *
	 * @return string
	 */
	public static function ip() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '0.0.0.0';
	}

	/**
	 * Täglich wechselndes Salz.
	 *
	 * @param int $days_back 0 = heute, 1 = gestern.
	 * @return string
	 */
	private static function salt( $days_back = 0 ) {
		return hash( 'sha256', wp_salt( 'auth' ) . '|oqsc-ip|' . gmdate( 'Y-m-d', time() - $days_back * DAY_IN_SECONDS ) );
	}

	/**
	 * Nicht umkehrbarer Hash der IP mit Tagessalz.
	 *
	 * @param string|null $ip        IP.
	 * @param int         $days_back Tag.
	 * @return string 64 Hex-Zeichen.
	 */
	public static function ip_hash( $ip = null, $days_back = 0 ) {
		if ( null === $ip ) {
			$ip = self::ip();
		}
		return hash_hmac( 'sha256', $ip, self::salt( $days_back ) );
	}

	/**
	 * Schlüssel für Signaturen.
	 *
	 * @return string
	 */
	private static function key() {
		return hash( 'sha256', wp_salt( 'nonce' ) . '|oqsc-token' );
	}

	/**
	 * Ist der Testmodus für den aktuellen Benutzer aktiv?
	 *
	 * @return bool
	 */
	public static function admin_test() {
		return (bool) OQSC_Plugin::get( 'testmodus' ) && current_user_can( 'oqsc_manage' );
	}

	/**
	 * Start-Token ausgeben (Zeitstempel, Zufall, IP-Hash, HMAC).
	 *
	 * @return array
	 */
	public static function issue_token() {
		$payload = time() . '.' . bin2hex( random_bytes( 8 ) ) . '.' . substr( self::ip_hash(), 0, 16 );
		$sig     = hash_hmac( 'sha256', $payload, self::key() );
		return array(
			'token'       => $payload . '.' . $sig,
			'bits'        => (int) OQSC_Plugin::get( 'pow_bits', 16 ),
			'mindestzeit' => self::admin_test() ? 0 : (int) OQSC_Plugin::get( 'mindestzeit', 3 ),
			'gueltig'     => self::TOKEN_TTL,
		);
	}

	/**
	 * Zählt führende Null-Bits eines Hex-Hashes.
	 *
	 * @param string $hex Hash.
	 * @return int
	 */
	public static function leading_zero_bits( $hex ) {
		$bits = 0;
		$len  = strlen( $hex );
		for ( $i = 0; $i < $len; $i++ ) {
			$n = hexdec( $hex[ $i ] );
			if ( 0 === $n ) {
				$bits += 4;
				continue;
			}
			if ( $n < 2 ) {
				$bits += 3;
			} elseif ( $n < 4 ) {
				$bits += 2;
			} elseif ( $n < 8 ) {
				$bits += 1;
			}
			break;
		}
		return $bits;
	}

	/**
	 * Ist die IP gerade gesperrt?
	 *
	 * @return bool
	 */
	public static function is_blocked() {
		return (bool) get_transient( 'oqsc_block_' . substr( self::ip_hash(), 0, 24 ) );
	}

	/**
	 * Token, Rechenbeweis, Honeypot und Mindestzeit prüfen.
	 *
	 * @param string $token    Token.
	 * @param string $pow      Lösung des Rechenbeweises.
	 * @param string $honeypot Inhalt des Honeypot-Felds.
	 * @return true|WP_Error
	 */
	public static function verify( $token, $pow, $honeypot ) {
		if ( self::is_blocked() ) {
			return new WP_Error( 'oqsc_gesperrt', 'Zu viele ungültige Versuche. Bitte versuchen Sie es in einer Stunde erneut.', array( 'status' => 429 ) );
		}
		$fail = static function ( $why ) {
			OQSC_Guard::bad_token( $why );
			return new WP_Error( 'oqsc_token', 'Die Sitzung ist abgelaufen. Bitte laden Sie die Seite neu und versuchen Sie es noch einmal.', array( 'status' => 403 ) );
		};

		if ( '' !== trim( (string) $honeypot ) ) {
			return $fail( 'honeypot' );
		}
		$token = (string) $token;
		if ( strlen( $token ) > 200 || ! preg_match( '/^(\d{10})\.([a-f0-9]{16})\.([a-f0-9]{16})\.([a-f0-9]{64})$/', $token, $m ) ) {
			return $fail( 'format' );
		}
		$payload = $m[1] . '.' . $m[2] . '.' . $m[3];
		if ( ! hash_equals( hash_hmac( 'sha256', $payload, self::key() ), $m[4] ) ) {
			return $fail( 'signatur' );
		}
		$age = time() - (int) $m[1];
		if ( $age > self::TOKEN_TTL || $age < -5 ) {
			return new WP_Error( 'oqsc_token', 'Die Sitzung ist abgelaufen. Bitte laden Sie die Seite neu.', array( 'status' => 403 ) );
		}
		if ( $m[3] !== substr( self::ip_hash(), 0, 16 ) && $m[3] !== substr( self::ip_hash( null, 1 ), 0, 16 ) ) {
			return $fail( 'ip' );
		}
		if ( ! self::admin_test() && $age < (int) OQSC_Plugin::get( 'mindestzeit', 3 ) ) {
			return $fail( 'zu_schnell' );
		}
		$pow = (string) $pow;
		if ( ! preg_match( '/^\d{1,12}$/', $pow ) || self::leading_zero_bits( hash( 'sha256', $token . ':' . $pow ) ) < (int) OQSC_Plugin::get( 'pow_bits', 16 ) ) {
			return $fail( 'rechenbeweis' );
		}
		$used_key = 'oqsc_used_' . substr( $m[4], 0, 32 );
		if ( get_transient( $used_key ) ) {
			return $fail( 'wiederholt' );
		}
		set_transient( $used_key, 1, self::TOKEN_TTL + 60 );
		return true;
	}

	/**
	 * Ungültigen Versuch zählen, nach mehreren eine Stunde sperren.
	 *
	 * @param string $why Grund.
	 */
	public static function bad_token( $why ) {
		global $wpdb;
		$hash = self::ip_hash();
		self::event( 'token_ungueltig', '', $why );
		$count = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->prefix}oqsc_events WHERE art = 'token_ungueltig' AND ip_hash = %s AND created_at > %s",
				$hash,
				OQSC_Plugin::now( -HOUR_IN_SECONDS )
			)
		);
		if ( $count >= self::BAD_TOKEN_LIMIT ) {
			set_transient( 'oqsc_block_' . substr( $hash, 0, 24 ), 1, HOUR_IN_SECONDS );
		}
	}

	/**
	 * Zustand des Tools: Wartung oder Pause?
	 *
	 * @return true|WP_Error
	 */
	public static function available() {
		if ( OQSC_Plugin::get( 'wartung' ) ) {
			return new WP_Error( 'oqsc_wartung', 'Der Check wird gerade gewartet. Bitte versuchen Sie es später noch einmal oder fordern Sie direkt eine persönliche Analyse an.', array( 'status' => 503 ) );
		}
		$pause = (int) get_option( 'oqsc_pause_bis', 0 );
		if ( $pause > time() ) {
			return new WP_Error( 'oqsc_pause', 'Gerade prüfen sehr viele Besucher gleichzeitig. Bitte versuchen Sie es in einigen Minuten noch einmal.', array( 'status' => 503 ) );
		}
		return true;
	}

	/**
	 * Limits je Besucher und global prüfen (Checks, die wirklich abrufen).
	 *
	 * @return true|WP_Error
	 */
	public static function check_limits() {
		global $wpdb;
		if ( self::admin_test() ) {
			return true;
		}
		$s     = OQSC_Plugin::settings();
		$table = $wpdb->prefix . 'oqsc_checks';
		$hash  = self::ip_hash();

		$midnight_local = current_time( 'Y-m-d' ) . ' 00:00:00';
		$midnight_utc   = get_gmt_from_date( $midnight_local );
		$global         = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE quelle <> 'cache' AND created_at >= %s", $midnight_utc ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( $global >= (int) $s['limit_global_tag'] ) {
			self::event( 'limit', '', 'global' );
			return new WP_Error( 'oqsc_limit_global', 'Heute wurden schon sehr viele Websites geprüft. Morgen geht es weiter. Wenn es eilt, schauen wir uns Ihre Website gern persönlich an.', array( 'status' => 429 ) );
		}

		$hour = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE ip_hash = %s AND quelle <> 'cache' AND created_at > %s", $hash, OQSC_Plugin::now( -HOUR_IN_SECONDS ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( $hour >= (int) $s['limit_stunde'] ) {
			self::event( 'limit', '', 'stunde' );
			return new WP_Error( 'oqsc_limit', 'Sie haben in der letzten Stunde schon ' . (int) $s['limit_stunde'] . ' Websites geprüft. Bitte versuchen Sie es später noch einmal.', array( 'status' => 429 ) );
		}
		$day = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE ip_hash = %s AND quelle <> 'cache' AND created_at > %s", $hash, OQSC_Plugin::now( -DAY_IN_SECONDS ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( $day >= (int) $s['limit_tag'] ) {
			self::event( 'limit', '', 'tag' );
			return new WP_Error( 'oqsc_limit', 'Sie haben heute schon ' . (int) $s['limit_tag'] . ' Websites geprüft. Morgen können Sie weitere prüfen.', array( 'status' => 429 ) );
		}
		return true;
	}

	/**
	 * Laufende Checks (aktiv in den letzten 3 Minuten).
	 *
	 * @return int
	 */
	public static function running_count() {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}oqsc_checks WHERE status = 'laeuft' AND updated_at > %s", OQSC_Plugin::now( -180 ) ) );
	}

	/**
	 * Position eines wartenden Jobs (1 = als Nächstes).
	 *
	 * @param int $id Job-ID.
	 * @return int
	 */
	public static function queue_position( $id ) {
		global $wpdb;
		return 1 + (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->prefix}oqsc_checks WHERE status = 'wartet' AND id < %d AND updated_at > %s",
				$id,
				OQSC_Plugin::now( -60 )
			)
		);
	}

	/**
	 * Benannte Sperre (MySQL GET_LOCK, Ersatz per Option).
	 *
	 * @param string $name    Name.
	 * @param int    $timeout Sekunden.
	 * @return bool
	 */
	public static function lock( $name, $timeout = 5 ) {
		global $wpdb;
		$got = $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, %d)', $wpdb->prefix . $name, $timeout ) );
		if ( null !== $got ) {
			return '1' === (string) $got;
		}
		// Ersatz: atomares add_option.
		$deadline = microtime( true ) + $timeout;
		do {
			if ( add_option( 'oqsc_lock_' . $name, time(), '', false ) ) {
				return true;
			}
			$since = (int) get_option( 'oqsc_lock_' . $name );
			if ( $since && $since < time() - 60 ) {
				delete_option( 'oqsc_lock_' . $name );
			}
			usleep( 100000 );
		} while ( microtime( true ) < $deadline );
		return false;
	}

	/**
	 * Sperre freigeben.
	 *
	 * @param string $name Name.
	 */
	public static function unlock( $name ) {
		global $wpdb;
		$res = $wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $wpdb->prefix . $name ) );
		if ( null === $res ) {
			delete_option( 'oqsc_lock_' . $name );
		}
	}

	/**
	 * Schritt für Not-Aus zählen. Bei zu vielen langsamen oder fehlerhaften Schritten pausieren.
	 *
	 * @param float  $seconds Dauer.
	 * @param bool   $failed  Fehler?
	 * @param string $domain  Domain.
	 */
	public static function record_step( $seconds, $failed, $domain = '' ) {
		$s      = OQSC_Plugin::settings();
		$minute = (int) floor( time() / 60 );
		$health = get_option( 'oqsc_health', array() );
		if ( ! is_array( $health ) ) {
			$health = array();
		}
		foreach ( array_keys( $health ) as $m ) {
			if ( $m < $minute - 4 ) {
				unset( $health[ $m ] );
			}
		}
		if ( ! isset( $health[ $minute ] ) ) {
			$health[ $minute ] = array( 0, 0, 0 );
		}
		++$health[ $minute ][0];
		$slow = $seconds > (int) $s['notaus_langsam_sek'];
		if ( $failed ) {
			++$health[ $minute ][1];
			self::event( 'fehler', $domain, 'Schritt fehlgeschlagen' );
		}
		if ( $slow ) {
			++$health[ $minute ][2];
			self::event( 'langsam', $domain, round( $seconds, 1 ) . ' s' );
		}
		update_option( 'oqsc_health', $health, false );

		$steps  = 0;
		$errors = 0;
		$slows  = 0;
		foreach ( $health as $h ) {
			$steps  += $h[0];
			$errors += $h[1];
			$slows  += $h[2];
		}
		$reason = '';
		if ( $slows > (int) $s['notaus_langsam_anzahl'] ) {
			$reason = $slows . ' langsame Schritte in 5 Minuten';
		} elseif ( $steps >= 6 && ( 100 * $errors / $steps ) > (int) $s['notaus_fehlerquote'] ) {
			$reason = round( 100 * $errors / $steps ) . ' % Fehler in 5 Minuten';
		}
		if ( $reason ) {
			update_option( 'oqsc_pause_bis', time() + 60 * (int) $s['notaus_pause_min'], false );
			update_option( 'oqsc_health', array(), false );
			self::event( 'pause', '', $reason );
		}
	}

	/**
	 * Ereignis speichern.
	 *
	 * @param string $art    limit|token_ungueltig|pause|fehler|langsam|gesperrt.
	 * @param string $domain Domain.
	 * @param string $info   Info.
	 */
	public static function event( $art, $domain = '', $info = '' ) {
		global $wpdb;
		$wpdb->insert(
			$wpdb->prefix . 'oqsc_events',
			array(
				'art'        => substr( (string) $art, 0, 30 ),
				'ip_hash'    => self::ip_hash(),
				'domain'     => substr( (string) $domain, 0, 190 ),
				'info'       => substr( (string) $info, 0, 500 ),
				'created_at' => OQSC_Plugin::now(),
			),
			array( '%s', '%s', '%s', '%s', '%s' )
		);
	}
}
