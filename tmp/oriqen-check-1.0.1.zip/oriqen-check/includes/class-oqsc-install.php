<?php
/**
 * Installation, Tabellen, Upgrades und Standardwerte.
 *
 * @package oriqen-check
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Legt Tabellen und Optionen an und hält sie über Updates hinweg aktuell.
 */
class OQSC_Install {

	/**
	 * Aktivierung: Tabellen, Standardwerte, Recht, Cron.
	 */
	public static function activate() {
		self::install();
		OQSC_Cron::schedule();
	}

	/**
	 * Deaktivierung: nur Cron entfernen, keine Daten löschen.
	 */
	public static function deactivate() {
		OQSC_Cron::unschedule();
	}

	/**
	 * Prüft bei jedem Laden günstig, ob ein Upgrade nötig ist.
	 */
	public static function maybe_upgrade() {
		if ( get_option( 'oqsc_db_version' ) !== OQSC_DB_VERSION || get_option( 'oqsc_version' ) !== OQSC_VERSION ) {
			self::install();
		}
	}

	/**
	 * Tabellen anlegen oder angleichen (dbDelta ändert nur, löscht nichts).
	 */
	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset = $wpdb->get_charset_collate();
		$checks  = $wpdb->prefix . 'oqsc_checks';
		$leads   = $wpdb->prefix . 'oqsc_leads';
		$events  = $wpdb->prefix . 'oqsc_events';

		$sql = array();

		$sql[] = "CREATE TABLE {$checks} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			token char(32) NOT NULL,
			domain varchar(190) NOT NULL DEFAULT '',
			url varchar(500) NOT NULL DEFAULT '',
			ort varchar(80) NOT NULL DEFAULT '',
			branche varchar(30) NOT NULL DEFAULT '',
			ip_hash char(64) NOT NULL DEFAULT '',
			status varchar(20) NOT NULL DEFAULT 'wartet',
			schritt tinyint(3) unsigned NOT NULL DEFAULT 0,
			quelle varchar(20) NOT NULL DEFAULT 'neu',
			daten longtext NULL,
			ergebnis longtext NULL,
			index_wert tinyint(3) unsigned NULL,
			fehler text NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			expires_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY token (token),
			KEY domain (domain),
			KEY created_at (created_at),
			KEY status (status),
			KEY ip_hash (ip_hash)
		) {$charset};";

		$sql[] = "CREATE TABLE {$leads} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			check_id bigint(20) unsigned NOT NULL DEFAULT 0,
			name varchar(120) NOT NULL DEFAULT '',
			email varchar(190) NOT NULL DEFAULT '',
			telefon varchar(60) NOT NULL DEFAULT '',
			nachricht text NULL,
			einwilligung_text text NULL,
			einwilligung_zeit datetime NULL,
			ip_hash char(64) NOT NULL DEFAULT '',
			status varchar(20) NOT NULL DEFAULT 'neu',
			notiz text NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY check_id (check_id),
			KEY status (status),
			KEY created_at (created_at)
		) {$charset};";

		$sql[] = "CREATE TABLE {$events} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			art varchar(30) NOT NULL DEFAULT '',
			ip_hash char(64) NOT NULL DEFAULT '',
			domain varchar(190) NOT NULL DEFAULT '',
			info varchar(500) NOT NULL DEFAULT '',
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY art_created (art,created_at),
			KEY ip_hash (ip_hash),
			KEY created_at (created_at)
		) {$charset};";

		foreach ( $sql as $statement ) {
			dbDelta( $statement );
		}

		// Einstellungen: vorhandene Werte bleiben, neue Schlüssel bekommen Standardwerte.
		$current = get_option( 'oqsc_settings', array() );
		if ( ! is_array( $current ) ) {
			$current = array();
		}
		$merged = array_merge( self::defaults(), $current );
		update_option( 'oqsc_settings', $merged, false );

		add_option( 'oqsc_pause_bis', 0, '', false );

		$role = get_role( 'administrator' );
		if ( $role && ! $role->has_cap( 'oqsc_manage' ) ) {
			$role->add_cap( 'oqsc_manage' );
		}

		update_option( 'oqsc_db_version', OQSC_DB_VERSION, false );
		update_option( 'oqsc_version', OQSC_VERSION, false );
	}

	/**
	 * Standardwerte aller Einstellungen.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			// Limits.
			'max_parallel'          => 2,
			'limit_stunde'          => 3,
			'limit_tag'             => 8,
			'limit_global_tag'      => 150,
			'cache_stunden'         => 24,
			'recheck_minuten'       => 60,
			'pow_bits'              => 16,
			'mindestzeit'           => 3,
			// Not-Aus.
			'notaus_langsam_anzahl' => 10,
			'notaus_langsam_sek'    => 25,
			'notaus_fehlerquote'    => 50,
			'notaus_pause_min'      => 15,
			'wartung'               => 0,
			'testmodus'             => 0,
			// PageSpeed.
			'psi_aktiv'             => 1,
			'psi_key'               => '',
			// Anfragen und Links.
			'empfaenger'            => get_option( 'admin_email' ),
			'analyse_url'           => 'https://oriqen.de/seo/seo-analyse/',
			'leistung_basis'        => 'https://oriqen.de',
			'check_seite_url'       => '',
			'einwilligung_text'     => 'Ich bin einverstanden, dass oriqen meine Angaben und das Ergebnis des Checks speichert, um meine Anfrage zu bearbeiten und mich dazu zu kontaktieren. Die Einwilligung kann ich jederzeit per E-Mail widerrufen. Weitere Informationen in der Datenschutzerklärung.',
			'datenschutz_url'       => '',
			// Texte.
			'ueberschrift'          => 'Wie sichtbar ist Ihre Website?',
			'einleitung'            => 'Geben Sie Ihre Adresse ein. In rund einer Minute sehen Sie, ob Google, Ihre Kunden vor Ort und KI-Suchen Sie finden, wie schnell Ihre Seite lädt und wo rechtliche Stolperfallen liegen.',
			'abschluss'             => 'Ein Werkzeug prüft Technik. Ob Ihre Texte überzeugen, Ihr Angebot klar ist und wie Sie gegenüber dem Wettbewerb dastehen, sehen nur Menschen. Genau das schauen wir uns in der persönlichen Analyse für Sie an.',
			// Aufbewahrung.
			'ergebnis_tage'         => 30,
			'aufbewahrung_checks'   => 90,
			'aufbewahrung_leads'    => 12,
			// Sonstiges.
			'sperrliste'            => '',
			'seiten_ids'            => '',
			'daten_loeschen'        => 0,
		);
	}
}
