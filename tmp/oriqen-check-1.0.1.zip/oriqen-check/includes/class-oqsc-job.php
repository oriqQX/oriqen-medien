<?php
/**
 * Ablauf eines Checks in kleinen Schritten. Jeder Aufruf erledigt genau einen Schritt.
 *
 * @package oriqen-check
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Job-Steuerung.
 */
class OQSC_Job {

	const BUDGET_TOTAL = 16;

	/**
	 * Schritte mit Titel und Zeitbudget in Sekunden.
	 *
	 * @return array
	 */
	public static function steps() {
		return array(
			1 => array( 'Erreichbarkeit und Verschlüsselung', 10 ),
			2 => array( 'Startseite lesen', 12 ),
			3 => array( 'Rechtliche Seiten, robots.txt, Sitemap, llms.txt', 20 ),
			4 => array( 'Bilder und Links stichprobenartig', 15 ),
			5 => array( 'Ladezeit und Handyansicht (PageSpeed)', 45 ),
			6 => array( 'Auswertung', 5 ),
		);
	}

	/**
	 * Titel aller Schritte.
	 *
	 * @return array
	 */
	public static function step_titles() {
		$out = array();
		foreach ( self::steps() as $n => $s ) {
			$out[] = array(
				'nr'    => $n,
				'titel' => $s[0],
			);
		}
		return $out;
	}

	/**
	 * Tabelle.
	 *
	 * @return string
	 */
	private static function table() {
		global $wpdb;
		return $wpdb->prefix . 'oqsc_checks';
	}

	/**
	 * Zufälliges Token (32 Zeichen).
	 *
	 * @return string
	 */
	public static function new_token() {
		return bin2hex( random_bytes( 16 ) );
	}

	/**
	 * Job anlegen.
	 *
	 * @param string $url     Normalisierte URL.
	 * @param string $ort     Ort.
	 * @param string $branche Branche.
	 * @param string $quelle  neu|recheck|cache.
	 * @param string $status  wartet|laeuft|fertig.
	 * @param array  $extra   Weitere Spalten.
	 * @return array Zeile.
	 */
	public static function create( $url, $ort, $branche, $quelle = 'neu', $status = 'wartet', $extra = array() ) {
		global $wpdb;
		$now  = OQSC_Plugin::now();
		$days = max( 1, (int) OQSC_Plugin::get( 'ergebnis_tage', 30 ) );
		$row  = array_merge(
			array(
				'token'      => self::new_token(),
				'domain'     => OQSC_Fetcher::domain_key( $url ),
				'url'        => $url,
				'ort'        => $ort,
				'branche'    => $branche,
				'ip_hash'    => OQSC_Guard::ip_hash(),
				'status'     => $status,
				'schritt'    => 0,
				'quelle'     => $quelle,
				'daten'      => wp_json_encode( array( 'start_url' => $url ) ),
				'created_at' => $now,
				'updated_at' => $now,
				'expires_at' => OQSC_Plugin::now( $days * DAY_IN_SECONDS ),
			),
			$extra
		);
		$wpdb->insert( self::table(), $row );
		$row['id'] = (int) $wpdb->insert_id;
		return $row;
	}

	/**
	 * Job per Token.
	 *
	 * @param string $token Token.
	 * @return array|null
	 */
	public static function get( $token ) {
		global $wpdb;
		if ( ! preg_match( '/^[a-f0-9]{32}$/', (string) $token ) ) {
			return null;
		}
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE token = %s', $token ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		return $row ? $row : null;
	}

	/**
	 * Job per ID.
	 *
	 * @param int $id ID.
	 * @return array|null
	 */
	public static function get_by_id( $id ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE id = %d', $id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		return $row ? $row : null;
	}

	/**
	 * Felder speichern.
	 *
	 * @param int   $id     ID.
	 * @param array $fields Felder.
	 */
	public static function update( $id, $fields ) {
		global $wpdb;
		$fields['updated_at'] = OQSC_Plugin::now();
		$wpdb->update( self::table(), $fields, array( 'id' => (int) $id ) );
	}

	/**
	 * Zwischengespeichertes Ergebnis für eine Domain.
	 *
	 * @param string $url Normalisierte URL.
	 * @return array|null
	 */
	public static function find_cached( $url ) {
		global $wpdb;
		$hours = max( 1, (int) OQSC_Plugin::get( 'cache_stunden', 24 ) );
		$key   = OQSC_Fetcher::domain_key( $url );
		$row   = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT * FROM ' . self::table() . " WHERE status = 'fertig' AND quelle <> 'cache' AND (domain = %s OR url = %s) AND created_at > %s AND daten IS NOT NULL ORDER BY id DESC LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
				$key,
				$url,
				OQSC_Plugin::now( -1 * $hours * HOUR_IN_SECONDS )
			),
			ARRAY_A
		);
		return $row ? $row : null;
	}

	/**
	 * Ergebnis aus dem Speicher für neue Angaben (Ort, Branche) auswerten, ohne neue Abrufe.
	 *
	 * @param array  $cached  Gespeicherter Check.
	 * @param string $ort     Ort.
	 * @param string $branche Branche.
	 * @return array Neuer Check (fertig).
	 */
	public static function copy_from_cache( $cached, $ort, $branche ) {
		$row  = self::create(
			$cached['url'],
			$ort,
			$branche,
			'cache',
			'laeuft',
			array(
				'domain'     => $cached['domain'],
				'daten'      => $cached['daten'],
				'schritt'    => 5,
				'created_at' => $cached['created_at'],
			)
		);
		$data = json_decode( (string) $cached['daten'], true );
		self::evaluate( $row, is_array( $data ) ? $data : array() );
		return self::get_by_id( $row['id'] );
	}

	/**
	 * Wartenden Job starten, wenn ein Platz frei ist.
	 *
	 * @param array $row Job.
	 * @return array Zeile (ggf. mit neuem Status) und Position.
	 */
	public static function try_promote( $row ) {
		$max = max( 1, (int) OQSC_Plugin::get( 'max_parallel', 2 ) );
		if ( ! OQSC_Guard::lock( 'oqsc_queue', 3 ) ) {
			return array( $row, OQSC_Guard::queue_position( $row['id'] ) );
		}
		$position = OQSC_Guard::queue_position( $row['id'] );
		if ( 'wartet' === $row['status'] && OQSC_Guard::running_count() < $max && 1 === $position ) {
			self::update( $row['id'], array( 'status' => 'laeuft' ) );
			$row['status'] = 'laeuft';
			$position      = 0;
		} else {
			self::update( $row['id'], array() );
		}
		OQSC_Guard::unlock( 'oqsc_queue' );
		return array( $row, $position );
	}

	/**
	 * Nächsten Schritt ausführen.
	 *
	 * @param array $row Job.
	 * @return array Antwort für den Browser.
	 */
	public static function run_next( $row ) {
		$steps = self::steps();
		if ( 'fertig' === $row['status'] ) {
			return array(
				'fertig' => true,
				'token'  => $row['token'],
				'schritt' => 6,
			);
		}
		if ( 'fehler' === $row['status'] || 'abgebrochen' === $row['status'] ) {
			return array(
				'fehler'  => true,
				'meldung' => $row['fehler'] ? $row['fehler'] : 'Der Check konnte nicht abgeschlossen werden.',
			);
		}
		if ( 'wartet' === $row['status'] ) {
			list( $row, $position ) = self::try_promote( $row );
			if ( 'wartet' === $row['status'] ) {
				return array(
					'warten'   => 10,
					'position' => $position,
				);
			}
		}

		$lock = 'oqsc_job_' . (int) $row['id'];
		if ( ! OQSC_Guard::lock( $lock, 0 ) ) {
			return array(
				'warten'   => 2,
				'position' => 0,
				'laeuft'   => true,
			);
		}
		// Frisch lesen, falls ein paralleler Aufruf schon weiter ist.
		$row  = self::get_by_id( $row['id'] );
		$next = (int) $row['schritt'] + 1;
		if ( $next > 6 || 'fertig' === $row['status'] ) {
			OQSC_Guard::unlock( $lock );
			return array(
				'fertig'  => true,
				'token'   => $row['token'],
				'schritt' => 6,
			);
		}

		$budget = $steps[ $next ][1];
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( $budget + 15 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- auf manchen Hostings gesperrt.
		}
		$data = json_decode( (string) $row['daten'], true );
		if ( ! is_array( $data ) ) {
			$data = array();
		}
		$start  = microtime( true );
		$failed = false;
		$kurz   = '';
		$abort  = '';
		try {
			switch ( $next ) {
				case 1:
					$res   = self::step_reach( $row, $data, $budget );
					$kurz  = $res['kurz'];
					$abort = $res['abbruch'];
					break;
				case 2:
					$kurz = self::step_home( $row, $data );
					break;
				case 3:
					$kurz = self::step_pages( $row, $data, $budget );
					break;
				case 4:
					$kurz = self::step_sample( $row, $data, $budget );
					break;
				case 5:
					$kurz = self::step_psi( $row, $data );
					break;
				case 6:
					$kurz = '';
					break;
			}
		} catch ( Throwable $e ) {
			$failed                    = true;
			$data['fehler'][ $next ] = 'Interner Fehler im Schritt ' . $next;
			$kurz                      = 'Dieser Teil konnte nicht geprüft werden.';
			if ( 1 === $next || 2 === $next ) {
				$abort = 'Bei der Prüfung ist ein Fehler aufgetreten. Bitte versuchen Sie es später noch einmal.';
			}
		}
		$elapsed = microtime( true ) - $start;
		if ( $abort && ! $failed && 1 === $next ) {
			$failed = true;
		}
		$domain = isset( $data['domain'] ) ? $data['domain'] : $row['domain'];
		OQSC_Guard::record_step( $elapsed, $failed, $domain );

		if ( $abort ) {
			self::update(
				$row['id'],
				array(
					'status'  => 'fehler',
					'schritt' => $next,
					'fehler'  => $abort,
					'daten'   => wp_json_encode( self::strip_temp( $data ) ),
				)
			);
			OQSC_Guard::unlock( $lock );
			return array(
				'schritt'    => $next,
				'titel'      => $steps[ $next ][0],
				'kurzbefund' => $abort,
				'fehler'     => true,
				'meldung'    => $abort,
			);
		}

		$fields = array(
			'schritt' => $next,
			'daten'   => wp_json_encode( $data ),
		);
		if ( ! empty( $data['domain'] ) && $data['domain'] !== $row['domain'] ) {
			$fields['domain'] = $data['domain'];
		}
		self::update( $row['id'], $fields );

		$answer = array(
			'schritt'    => $next,
			'titel'      => $steps[ $next ][0],
			'kurzbefund' => $kurz,
			'fertig'     => false,
		);
		if ( 6 === $next ) {
			$row    = self::get_by_id( $row['id'] );
			$result = self::evaluate( $row, $data );
			$answer['kurzbefund'] = 'Sichtbarkeits-Index: ' . $result['index'] . ' von 100';
			$answer['fertig']     = true;
			$answer['token']      = $row['token'];
		}
		OQSC_Guard::unlock( $lock );
		return $answer;
	}

	/**
	 * Temporäre Rohdaten entfernen.
	 *
	 * @param array $data Daten.
	 * @return array
	 */
	private static function strip_temp( $data ) {
		unset( $data['html_gz'] );
		return $data;
	}

	/**
	 * Restzeit für Abrufe innerhalb eines Schrittbudgets.
	 *
	 * @param float $start  Startzeit.
	 * @param int   $budget Budget.
	 * @return int Sekunden (0 = keine Zeit mehr).
	 */
	private static function time_left( $start, $budget ) {
		$left = (int) floor( $budget - ( microtime( true ) - $start ) );
		return $left >= 2 ? min( OQSC_Fetcher::TIMEOUT, $left ) : 0;
	}

	/**
	 * Fetcher mit dem Restbudget des Checks.
	 *
	 * @param array $data Daten.
	 * @param int   $max  Höchstens in diesem Schritt.
	 * @return OQSC_Fetcher
	 */
	private static function fetcher( $data, $max ) {
		$used = isset( $data['abrufe'] ) ? (int) $data['abrufe'] : 0;
		return new OQSC_Fetcher( min( $max, max( 0, self::BUDGET_TOTAL - $used ) ) );
	}

	/**
	 * Relevante Kopfzeilen behalten.
	 *
	 * @param array $headers Kopfzeilen.
	 * @return array
	 */
	private static function keep_headers( $headers ) {
		$keep = array( 'content-type', 'content-encoding', 'x-robots-tag', 'strict-transport-security', 'server', 'x-powered-by', 'cache-control', 'content-length', 'last-modified' );
		$out  = array();
		foreach ( $keep as $k ) {
			if ( isset( $headers[ $k ] ) ) {
				$v         = is_array( $headers[ $k ] ) ? implode( ', ', $headers[ $k ] ) : $headers[ $k ];
				$out[ $k ] = OQSC_Parser::clean( $v, 200 );
			}
		}
		return $out;
	}

	/**
	 * Schritt 1: Erreichbarkeit, HTTPS, Zertifikat, Zeit bis zum ersten Byte.
	 *
	 * @param array $row    Job.
	 * @param array $data   Daten (per Referenz).
	 * @param int   $budget Sekunden.
	 * @return array kurz, abbruch.
	 */
	private static function step_reach( $row, &$data, $budget ) {
		$start = microtime( true );
		$f     = self::fetcher( $data, 7 );
		$host  = wp_parse_url( $row['url'], PHP_URL_HOST );
		$port  = wp_parse_url( $row['url'], PHP_URL_PORT );
		$hp    = $host . ( $port && ! in_array( (int) $port, array( 80, 443 ), true ) ? ':' . $port : '' );

		// HTTP-Version ohne Weiterleitung abrufen.
		$http         = $f->fetch( 'http://' . $host . '/', array( 'follow' => false, 'timeout' => 5 ) );
		$location     = isset( $http['headers']['location'] ) ? $http['headers']['location'] : '';
		$location     = is_array( $location ) ? end( $location ) : $location;
		$data['http'] = array(
			'ok'       => $http['ok'],
			'status'   => $http['status'],
			'location' => OQSC_Parser::clean( $location, 300 ),
			'fehler'   => $http['fehler'],
		);

		// HTTPS mit allen Weiterleitungen.
		$https_url = 0 === strpos( $row['url'], 'https://' ) ? $row['url'] : 'https://' . $hp . '/';
		$timeout   = self::time_left( $start, $budget );
		$home      = $f->fetch(
			$https_url,
			array(
				'insecure_retry' => true,
				'timeout'        => max( 2, $timeout ),
			)
		);
		$https_ok  = $home['ok'];
		if ( ! $home['ok'] && $http['ok'] && self::time_left( $start, $budget ) ) {
			// Ohne HTTPS über HTTP weiter.
			$home = $f->fetch( 'http://' . $hp . '/', array( 'timeout' => self::time_left( $start, $budget ) ) );
		}
		$data['abrufe'] = ( isset( $data['abrufe'] ) ? (int) $data['abrufe'] : 0 ) + $f->used();

		$final        = $home['final_url'];
		$final_https  = 0 === strpos( $final, 'https://' );
		$data['home'] = array(
			'ok'          => $home['ok'],
			'status'      => $home['status'],
			'final_url'   => OQSC_Parser::clean( $final, 500 ),
			'redirects'   => array_slice( $home['redirects'], 0, 6 ),
			'headers'     => self::keep_headers( $home['headers'] ),
			'cookies'     => array_slice( $home['cookies'], 0, 30 ),
			'ttfb'        => $home['ttfb'],
			'zeit'        => $home['zeit'],
			'groesse'     => $home['groesse'],
			'uebertragen' => isset( $home['uebertragen'] ) ? $home['uebertragen'] : null,
			'gekuerzt'    => $home['gekuerzt'],
			'https'       => $final_https,
			'https_ok'    => $https_ok && $final_https,
			'ssl_fehler'  => ! empty( $home['ssl_fehler'] ),
			'fehler'      => $home['fehler'],
			'meldung'     => $home['meldung'],
		);
		$data['domain']   = OQSC_Fetcher::domain_key( $final );
		$data['http']['zu_https'] = ( $http['ok'] && in_array( (int) $http['status'], array( 301, 302, 303, 307, 308 ), true ) && 0 === stripos( (string) $location, 'https://' ) ) || ( ! $http['ok'] && $https_ok );

		if ( ! $home['ok'] ) {
			$msg = $home['meldung'] ? $home['meldung'] : 'Die Website war nicht erreichbar.';
			if ( in_array( $home['fehler'], array( 'oqsc_intern', 'oqsc_gesperrt', 'oqsc_ungueltig' ), true ) ) {
				OQSC_Guard::event( 'gesperrt', $row['domain'], $home['fehler'] );
			}
			return array(
				'kurz'    => '',
				'abbruch' => 'Wir konnten ' . $row['domain'] . ' nicht abrufen. ' . $msg . ' Bitte prüfen Sie die Adresse. Wenn Ihre Website im Browser normal lädt, blockiert sie vielleicht automatische Abrufe. Dann schauen wir sie uns gern persönlich an.',
			);
		}
		$status = (int) $home['status'];
		if ( $status < 200 || $status > 299 ) {
			return array(
				'kurz'    => '',
				'abbruch' => 'Die Startseite von ' . $data['domain'] . ' antwortet mit dem Fehlercode ' . $status . ' statt mit der Seite. ' . ( in_array( $status, array( 401, 403, 429, 503 ), true ) ? 'Wahrscheinlich blockiert ein Schutzsystem automatische Abrufe. Für Ihre Kunden ist die Seite dann meist trotzdem erreichbar. ' : 'Besucher sehen in diesem Moment vermutlich eine Fehlerseite. ' ) . 'Gern schauen wir uns das persönlich an.',
			);
		}
		$ctype = isset( $home['headers']['content-type'] ) ? ( is_array( $home['headers']['content-type'] ) ? end( $home['headers']['content-type'] ) : $home['headers']['content-type'] ) : '';
		if ( $ctype && ! preg_match( '#html|xml#i', $ctype ) ) {
			return array(
				'kurz'    => '',
				'abbruch' => 'Unter ' . $data['domain'] . ' liegt keine Webseite, sondern eine Datei. Bitte geben Sie die Adresse Ihrer Website ein.',
			);
		}
		$data['html_gz'] = base64_encode( gzcompress( $home['body'], 6 ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Zwischenspeicher bis Schritt 2.

		$parts = array();
		$parts[] = $final_https && ! $home['ssl_fehler'] ? 'Erreichbar über HTTPS' : ( $home['ssl_fehler'] ? 'Erreichbar, aber Zertifikat ungültig' : 'Erreichbar, aber ohne Verschlüsselung' );
		if ( $home['ttfb'] ) {
			$parts[] = 'erste Antwort nach ' . OQSC_Plugin::num( $home['ttfb'], 1 ) . ' s';
		}
		if ( count( $home['redirects'] ) ) {
			$parts[] = count( $home['redirects'] ) . ( 1 === count( $home['redirects'] ) ? ' Weiterleitung' : ' Weiterleitungen' );
		}
		return array(
			'kurz'    => implode( ', ', $parts ),
			'abbruch' => '',
		);
	}

	/**
	 * Schritt 2: Startseite analysieren.
	 *
	 * @param array $row  Job.
	 * @param array $data Daten (per Referenz).
	 * @return string Kurzbefund.
	 */
	private static function step_home( $row, &$data ) {
		$html = '';
		if ( ! empty( $data['html_gz'] ) ) {
			$html = (string) @gzuncompress( base64_decode( $data['html_gz'] ) ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- eigener Zwischenspeicher.
		}
		unset( $data['html_gz'] );
		$ctype        = isset( $data['home']['headers']['content-type'] ) ? $data['home']['headers']['content-type'] : '';
		$page         = OQSC_Parser::parse( $html, $data['home']['final_url'], $ctype );
		$data['page'] = $page;
		if ( ! $page['ok'] ) {
			return 'Die Startseite ließ sich nicht lesen.';
		}
		$parts = array();
		$parts[] = $page['title'] ? 'Titel gefunden' : 'kein Titel';
		$parts[] = OQSC_Plugin::num( $page['word_count'] ) . ' Wörter';
		$parts[] = $page['img_total'] . ( 1 === $page['img_total'] ? ' Bild' : ' Bilder' );
		if ( $page['jsonld_blocks'] ) {
			$parts[] = 'strukturierte Daten gefunden';
		}
		return implode( ', ', $parts );
	}

	/**
	 * Schritt 3: Nebenseiten.
	 *
	 * @param array $row    Job.
	 * @param array $data   Daten (per Referenz).
	 * @param int   $budget Sekunden.
	 * @return string Kurzbefund.
	 */
	private static function step_pages( $row, &$data, $budget ) {
		$start = microtime( true );
		$page  = isset( $data['page'] ) ? $data['page'] : array();
		$base  = $data['home']['final_url'];
		$p     = wp_parse_url( $base );
		$root  = $p['scheme'] . '://' . $p['host'] . ( isset( $p['port'] ) ? ':' . $p['port'] : '' );
		// Bis zu 8 Abrufe, damit für die Stichprobe noch Platz bleibt.
		$f     = self::fetcher( $data, 8 );
		$get   = static function ( $url, $max = 1048576 ) use ( $f, $start, $budget ) {
			$t = self::time_left( $start, $budget );
			if ( ! $t ) {
				return array(
					'ok'     => false,
					'fehler' => 'zeit',
					'status' => 0,
				);
			}
			return $f->fetch(
				$url,
				array(
					'timeout'   => $t,
					'max_bytes' => $max,
				)
			);
		};

		// Impressum.
		$data['impressum'] = array( 'url' => isset( $page['impressum_url'] ) ? $page['impressum_url'] : '' );
		if ( $data['impressum']['url'] ) {
			$r                 = $get( $data['impressum']['url'] );
			$data['impressum'] = array_merge( $data['impressum'], self::sub_result( $r ) );
		}
		// Datenschutz (nur Erreichbarkeit, wenige Bytes reichen).
		$data['datenschutz'] = array( 'url' => isset( $page['datenschutz_url'] ) ? $page['datenschutz_url'] : '' );
		if ( $data['datenschutz']['url'] && $data['datenschutz']['url'] !== $data['impressum']['url'] ) {
			$r                   = $get( $data['datenschutz']['url'], 65536 );
			$data['datenschutz'] = array_merge(
				$data['datenschutz'],
				array(
					'ok'     => ! empty( $r['ok'] ) && $r['status'] >= 200 && $r['status'] < 300,
					'status' => isset( $r['status'] ) ? $r['status'] : 0,
					'fehler' => isset( $r['fehler'] ) ? $r['fehler'] : '',
				)
			);
		} elseif ( $data['datenschutz']['url'] ) {
			$data['datenschutz']['ok']     = ! empty( $data['impressum']['ok'] );
			$data['datenschutz']['status'] = isset( $data['impressum']['status'] ) ? $data['impressum']['status'] : 0;
		}

		// robots.txt.
		$r              = $get( $root . '/robots.txt', 262144 );
		$robots_ok      = ! empty( $r['ok'] ) && 200 === (int) $r['status'] && ! preg_match( '/<html|<!doctype/i', substr( (string) $r['body'], 0, 500 ) );
		$data['robots'] = array(
			'gefunden' => $robots_ok,
			'status'   => isset( $r['status'] ) ? $r['status'] : 0,
			'fehler'   => isset( $r['fehler'] ) ? $r['fehler'] : '',
			'regeln'   => $robots_ok ? OQSC_Parser::parse_robots( $r['body'] ) : array(
				'groups'   => array(),
				'sitemaps' => array(),
			),
		);
		// Regeln knapp halten: nur Agenten mit Regeln zu "/" behalten.
		foreach ( $data['robots']['regeln']['groups'] as $agent => $rules ) {
			$data['robots']['regeln']['groups'][ $agent ] = array_slice(
				array_values(
					array_filter(
						$rules,
						static function ( $x ) {
							return in_array( $x[1], array( '/', '/*', '/$' ), true );
						}
					)
				),
				0,
				5
			);
		}
		$data['robots']['regeln']['groups'] = array_slice( $data['robots']['regeln']['groups'], 0, 60, true );

		// Sitemap.
		$candidates = array();
		foreach ( $data['robots']['regeln']['sitemaps'] as $sm ) {
			$host = wp_parse_url( $sm, PHP_URL_HOST );
			if ( $host && OQSC_Parser::same_site( $host, $data['domain'] ) ) {
				$candidates[] = $sm;
			}
		}
		if ( ! $candidates ) {
			$candidates = array( $root . '/sitemap.xml', $root . '/sitemap_index.xml', $root . '/wp-sitemap.xml' );
		}
		$data['sitemap'] = array(
			'gefunden' => false,
			'url'      => '',
			'gueltig'  => false,
		);
		foreach ( array_slice( $candidates, 0, 2 ) as $sm ) {
			$r = $get( $sm, 524288 );
			if ( ! empty( $r['ok'] ) && 200 === (int) $r['status'] ) {
				$body              = ltrim( (string) $r['body'] );
				$valid             = (bool) preg_match( '/<(urlset|sitemapindex)[\s>]/i', substr( $body, 0, 3000 ) );
				$data['sitemap'] = array(
					'gefunden' => true,
					'url'      => OQSC_Parser::clean( $r['final_url'], 300 ),
					'gueltig'  => $valid,
					'eintraege' => $valid ? min( 50000, substr_count( $body, '<loc>' ) ) : 0,
				);
				if ( $valid ) {
					break;
				}
			}
		}

		// llms.txt.
		$r            = $get( $root . '/llms.txt', 65536 );
		$ltype        = isset( $r['headers']['content-type'] ) ? ( is_array( $r['headers']['content-type'] ) ? end( $r['headers']['content-type'] ) : $r['headers']['content-type'] ) : '';
		$lbody        = isset( $r['body'] ) ? (string) $r['body'] : '';
		$is_text      = ! empty( $r['ok'] ) && 200 === (int) $r['status'] && ! preg_match( '/<html|<!doctype|<head/i', substr( $lbody, 0, 1000 ) ) && strlen( trim( $lbody ) ) > 10;
		$data['llms'] = array(
			'gefunden' => $is_text,
			'status'   => isset( $r['status'] ) ? $r['status'] : 0,
			'typ'      => OQSC_Parser::clean( $ltype, 60 ),
			'laenge'   => $is_text ? strlen( $lbody ) : 0,
		);

		// Kontaktseite.
		$data['kontakt'] = array( 'url' => isset( $page['kontakt_url'] ) ? $page['kontakt_url'] : '' );
		if ( $data['kontakt']['url'] && $data['kontakt']['url'] !== $data['impressum']['url'] && rtrim( $data['kontakt']['url'], '/' ) !== rtrim( $base, '/' ) ) {
			$r               = $get( $data['kontakt']['url'] );
			$data['kontakt'] = array_merge( $data['kontakt'], self::sub_result( $r ) );
		}

		$data['abrufe'] = ( isset( $data['abrufe'] ) ? (int) $data['abrufe'] : 0 ) + $f->used();

		$parts = array();
		$parts[] = ! empty( $data['impressum']['ok'] ) ? 'Impressum gefunden' : 'Impressum nicht gefunden';
		$parts[] = ! empty( $data['datenschutz']['ok'] ) ? 'Datenschutz gefunden' : 'Datenschutz nicht gefunden';
		$parts[] = $data['sitemap']['gefunden'] ? 'Sitemap vorhanden' : 'keine Sitemap';
		$parts[] = $data['llms']['gefunden'] ? 'llms.txt vorhanden' : 'keine llms.txt';
		return implode( ', ', $parts );
	}

	/**
	 * Ergebnis einer Nebenseite zusammenfassen.
	 *
	 * @param array $r Abruf.
	 * @return array
	 */
	private static function sub_result( $r ) {
		$ok  = ! empty( $r['ok'] ) && $r['status'] >= 200 && $r['status'] < 300;
		$out = array(
			'ok'     => $ok,
			'status' => isset( $r['status'] ) ? $r['status'] : 0,
			'fehler' => isset( $r['fehler'] ) ? $r['fehler'] : '',
		);
		if ( $ok ) {
			$ctype         = isset( $r['headers']['content-type'] ) ? ( is_array( $r['headers']['content-type'] ) ? end( $r['headers']['content-type'] ) : $r['headers']['content-type'] ) : '';
			$out['inhalt'] = OQSC_Parser::parse_sub( $r['body'], $r['final_url'], $ctype );
		}
		return $out;
	}

	/**
	 * Schritt 4: Stylesheets (Google Fonts) und HEAD-Stichprobe.
	 *
	 * @param array $row    Job.
	 * @param array $data   Daten (per Referenz).
	 * @param int   $budget Sekunden.
	 * @return string Kurzbefund.
	 */
	private static function step_sample( $row, &$data, $budget ) {
		$start  = microtime( true );
		$page   = isset( $data['page'] ) ? $data['page'] : array();
		$domain = $data['domain'];
		$f      = self::fetcher( $data, 8 );

		// Bis zu 3 eigene Stylesheets.
		$css = array();
		foreach ( isset( $page['stylesheets'] ) ? $page['stylesheets'] : array() as $url ) {
			if ( count( $css ) >= 3 ) {
				break;
			}
			$host = wp_parse_url( $url, PHP_URL_HOST );
			if ( ! $host || ! OQSC_Parser::same_site( $host, $domain ) ) {
				continue;
			}
			$t = self::time_left( $start, $budget );
			if ( ! $t ) {
				break;
			}
			$r     = $f->fetch(
				$url,
				array(
					'timeout'   => $t,
					'max_bytes' => 524288,
				)
			);
			$body  = isset( $r['body'] ) ? strtolower( (string) $r['body'] ) : '';
			$css[] = array(
				'url'          => OQSC_Parser::clean( $url, 300 ),
				'ok'           => ! empty( $r['ok'] ) && 200 === (int) $r['status'],
				'google_fonts' => (bool) preg_match( '#fonts\.(googleapis|gstatic)\.com#', $body ),
				'drittfonts'   => (bool) preg_match( '#use\.typekit\.net|fast\.fonts\.net|fonts\.bunny\.net#', $body ),
			);
		}
		$data['css'] = $css;

		// Stichprobe: bis 5 HEAD, Bilder zuerst (höchstens 3), dann Links aus der Navigation.
		$sample = array();
		$seen   = array();
		$images = isset( $page['images'] ) ? $page['images'] : array();
		foreach ( $images as $img ) {
			if ( count( $sample ) >= 3 ) {
				break;
			}
			$host = wp_parse_url( $img['url'], PHP_URL_HOST );
			if ( ! $host || 'svg' === $img['ext'] || isset( $seen[ $img['url'] ] ) || ! OQSC_Parser::same_site( $host, $domain ) && ! preg_match( '/(wp\.com|cloudfront\.net|cdn)/', $host ) ) {
				continue;
			}
			$seen[ $img['url'] ] = true;
			$sample[]            = array(
				'url' => $img['url'],
				'art' => 'bild',
			);
		}
		$links = isset( $page['nav_links'] ) ? $page['nav_links'] : array();
		foreach ( isset( $page['links'] ) ? $page['links'] : array() as $l ) {
			if ( $l['intern'] && ! $l['fuss'] ) {
				$links[] = $l['url'];
			}
		}
		$home_norm = rtrim( preg_replace( '/#.*$/', '', $data['home']['final_url'] ), '/' );
		foreach ( $links as $url ) {
			if ( count( $sample ) >= 5 ) {
				break;
			}
			$clean = preg_replace( '/#.*$/', '', $url );
			if ( ! preg_match( '#^https?://#i', $clean ) || isset( $seen[ $clean ] ) || rtrim( $clean, '/' ) === $home_norm || preg_match( '/\.(pdf|zip|jpe?g|png|gif|webp|svg|mp4|docx?)(\?|$)/i', $clean ) || preg_match( '#/wp-(admin|login)|/feed/?$|[?&](add-to-cart|replytocom)=#i', $clean ) ) {
				continue;
			}
			if ( ! empty( $data['impressum']['url'] ) && $clean === $data['impressum']['url'] || ! empty( $data['kontakt']['url'] ) && $clean === $data['kontakt']['url'] ) {
				continue;
			}
			$seen[ $clean ] = true;
			$sample[]       = array(
				'url' => $clean,
				'art' => 'link',
			);
		}
		$results = array();
		foreach ( $sample as $s ) {
			$t = self::time_left( $start, $budget );
			if ( ! $t ) {
				break;
			}
			$r = $f->fetch(
				$s['url'],
				array(
					'method'  => 'HEAD',
					'timeout' => min( 5, $t ),
					// Wie ein Browser: Server, die WebP oder AVIF aushandeln, liefern dann das moderne Format.
					'accept'  => 'bild' === $s['art'] ? 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8' : 'text/html,application/xhtml+xml,*/*;q=0.8',
				)
			);
			// Manche Server lehnen HEAD ab: dann zählt der Link nicht als kaputt.
			$status    = isset( $r['status'] ) ? (int) $r['status'] : 0;
			$size      = isset( $r['headers']['content-length'] ) ? (int) ( is_array( $r['headers']['content-length'] ) ? end( $r['headers']['content-length'] ) : $r['headers']['content-length'] ) : 0;
			$type      = isset( $r['headers']['content-type'] ) ? ( is_array( $r['headers']['content-type'] ) ? end( $r['headers']['content-type'] ) : $r['headers']['content-type'] ) : '';
			$results[] = array(
				'url'    => OQSC_Parser::clean( $s['url'], 300 ),
				'art'    => $s['art'],
				'ok'     => ! empty( $r['ok'] ),
				'status' => $status,
				'groesse' => $size,
				'typ'    => OQSC_Parser::clean( $type, 60 ),
				'fehler' => isset( $r['fehler'] ) ? $r['fehler'] : '',
			);
		}
		$data['stichprobe'] = $results;
		$data['abrufe']     = ( isset( $data['abrufe'] ) ? (int) $data['abrufe'] : 0 ) + $f->used();

		$broken = 0;
		$big    = 0;
		foreach ( $results as $r ) {
			if ( 'link' === $r['art'] && $r['status'] >= 400 && ! in_array( $r['status'], array( 403, 405, 429 ), true ) ) {
				++$broken;
			}
			if ( 'bild' === $r['art'] && $r['groesse'] > 500 * 1024 ) {
				++$big;
			}
		}
		$parts = array();
		$parts[] = count( $css ) . ( 1 === count( $css ) ? ' Stylesheet' : ' Stylesheets' ) . ' und ' . count( $results ) . ' Stichproben geprüft';
		if ( $broken ) {
			$parts[] = $broken . ( 1 === $broken ? ' kaputter Link' : ' kaputte Links' );
		}
		if ( $big ) {
			$parts[] = $big . ( 1 === $big ? ' sehr großes Bild' : ' sehr große Bilder' );
		}
		return implode( ', ', $parts );
	}

	/**
	 * Schritt 5: PageSpeed.
	 *
	 * @param array $row  Job.
	 * @param array $data Daten (per Referenz).
	 * @return string Kurzbefund.
	 */
	private static function step_psi( $row, &$data ) {
		if ( ! OQSC_Plugin::get( 'psi_aktiv', 1 ) ) {
			$data['psi'] = array(
				'ok'     => false,
				'grund'  => 'aus',
			);
			return 'Ladezeit-Messung ist abgeschaltet.';
		}
		$data['psi'] = OQSC_Psi::run( $data['home']['final_url'] );
		if ( empty( $data['psi']['ok'] ) ) {
			return 'Ladezeit-Messung gerade nicht möglich. Wir werten die übrigen Daten aus.';
		}
		return 'Tempo auf dem Handy: ' . (int) $data['psi']['performance'] . ' von 100';
	}

	/**
	 * Schritt 6: Auswertung speichern.
	 *
	 * @param array $row  Job.
	 * @param array $data Daten.
	 * @return array Ergebnis.
	 */
	public static function evaluate( $row, $data ) {
		$context = array(
			'ort'     => (string) $row['ort'],
			'branche' => (string) $row['branche'],
			'jahr'    => (int) gmdate( 'Y', strtotime( $row['created_at'] . ' UTC' ) ),
		);
		$checks = OQSC_Checks::run_all( $data, $context );
		$result = OQSC_Score::build( $checks, $data, $context );
		$result['domain'] = isset( $data['domain'] ) ? $data['domain'] : $row['domain'];
		$result['url']    = isset( $data['home']['final_url'] ) ? $data['home']['final_url'] : $row['url'];
		$result['datum']  = $row['created_at'];
		self::update(
			$row['id'],
			array(
				'status'     => 'fertig',
				'schritt'    => 6,
				'ergebnis'   => wp_json_encode( $result ),
				'index_wert' => (int) $result['index'],
				'daten'      => wp_json_encode( self::strip_temp( $data ) ),
			)
		);
		return $result;
	}

	/**
	 * Ergebnis für Besucher (ohne interne Felder).
	 *
	 * @param array $row Job.
	 * @return array|null
	 */
	public static function public_result( $row ) {
		$r = json_decode( (string) $row['ergebnis'], true );
		if ( ! is_array( $r ) ) {
			return null;
		}
		unset( $r['intern'] );
		foreach ( $r['pruefungen'] as &$p ) {
			unset( $p['leistung'] );
		}
		unset( $p );
		foreach ( $r['hebel'] as &$h ) {
			unset( $h['leistung'] );
		}
		unset( $h );
		$r['token']   = $row['token'];
		$r['ort']     = $row['ort'];
		$r['branche'] = $row['branche'];
		$r['gueltig_bis'] = $row['expires_at'];
		return $r;
	}
}
