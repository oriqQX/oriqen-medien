<?php
/**
 * Anfragen zur persönlichen Analyse.
 *
 * @package oriqen-check
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Anfragen speichern und an oriqen melden.
 */
class OQSC_Leads {

	const PER_DAY = 3;

	/**
	 * Status mit Bezeichnung.
	 *
	 * @return array
	 */
	public static function status_labels() {
		return array(
			'neu'         => 'neu',
			'kontaktiert' => 'kontaktiert',
			'angebot'     => 'Angebot',
			'gewonnen'    => 'gewonnen',
			'verloren'    => 'verloren',
		);
	}

	/**
	 * Tabelle.
	 *
	 * @return string
	 */
	private static function table() {
		global $wpdb;
		return $wpdb->prefix . 'oqsc_leads';
	}

	/**
	 * Gibt es schon eine Anfrage zu einem Check?
	 *
	 * @param int $check_id Check.
	 * @return bool
	 */
	public static function exists_for_check( $check_id ) {
		global $wpdb;
		return (bool) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . self::table() . ' WHERE check_id = %d LIMIT 1', $check_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
	}

	/**
	 * Status und Notiz ändern.
	 *
	 * @param int    $id     ID.
	 * @param string $status Status.
	 * @param string $notiz  Notiz.
	 * @return bool
	 */
	public static function update( $id, $status, $notiz = null ) {
		global $wpdb;
		$fields = array();
		if ( array_key_exists( $status, self::status_labels() ) ) {
			$fields['status'] = $status;
		}
		if ( null !== $notiz ) {
			$fields['notiz'] = mb_substr( (string) $notiz, 0, 5000 );
		}
		if ( ! $fields || ! $id ) {
			return false;
		}
		return false !== $wpdb->update( self::table(), $fields, array( 'id' => (int) $id ) );
	}

	/**
	 * Fehlerantwort.
	 *
	 * @param string $code    Code.
	 * @param string $message Meldung.
	 * @param int    $status  HTTP-Status.
	 * @return WP_REST_Response
	 */
	private static function error( $code, $message, $status = 400 ) {
		return new WP_REST_Response(
			array(
				'fehler'  => true,
				'code'    => $code,
				'meldung' => $message,
			),
			$status
		);
	}

	/**
	 * POST /lead.
	 *
	 * @param WP_REST_Request $req Anfrage.
	 * @return WP_REST_Response
	 */
	public static function rest_create( WP_REST_Request $req ) {
		global $wpdb;
		if ( OQSC_Plugin::get( 'wartung' ) ) {
			return self::error( 'oqsc_wartung', 'Anfragen sind gerade nicht möglich. Bitte schreiben Sie uns direkt eine E-Mail.', 503 );
		}
		$ok = OQSC_Guard::verify( $req['token'], $req['pow'], $req['website'] );
		if ( is_wp_error( $ok ) ) {
			$data = $ok->get_error_data();
			return self::error( $ok->get_error_code(), $ok->get_error_message(), is_array( $data ) && isset( $data['status'] ) ? $data['status'] : 403 );
		}
		$check = OQSC_Job::get( $req['check'] );
		if ( ! $check || 'fertig' !== $check['status'] ) {
			return self::error( 'oqsc_check', 'Zu dieser Anfrage gibt es kein gültiges Ergebnis.', 404 );
		}

		$name      = mb_substr( trim( sanitize_text_field( (string) $req['name'] ) ), 0, 120 );
		$email     = sanitize_email( (string) $req['email'] );
		$telefon   = mb_substr( preg_replace( '/[^0-9+\/() \-]/', '', (string) $req['telefon'] ), 0, 40 );
		$nachricht = mb_substr( trim( sanitize_textarea_field( (string) $req['nachricht'] ) ), 0, 2000 );

		if ( mb_strlen( $name ) < 2 ) {
			return self::error( 'oqsc_name', 'Bitte geben Sie Ihren Namen an.' );
		}
		if ( ! $email || ! is_email( $email ) ) {
			return self::error( 'oqsc_email', 'Bitte geben Sie eine gültige E-Mail-Adresse an.' );
		}
		if ( empty( $req['einwilligung'] ) ) {
			return self::error( 'oqsc_einwilligung', 'Bitte bestätigen Sie die Einwilligung, damit wir Ihre Anfrage bearbeiten dürfen.' );
		}

		$hash = OQSC_Guard::ip_hash();
		if ( ! OQSC_Guard::admin_test() ) {
			$count = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . self::table() . ' WHERE ip_hash = %s AND created_at > %s', $hash, OQSC_Plugin::now( -DAY_IN_SECONDS ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			if ( $count >= self::PER_DAY ) {
				OQSC_Guard::event( 'limit', $check['domain'], 'anfragen' );
				return self::error( 'oqsc_limit', 'Sie haben heute schon mehrere Anfragen gesendet. Wir melden uns bei Ihnen. Bei Eile erreichen Sie uns direkt per E-Mail.', 429 );
			}
		}
		if ( self::exists_for_check( (int) $check['id'] ) ) {
			return self::error( 'oqsc_doppelt', 'Zu diesem Ergebnis liegt uns schon eine Anfrage vor. Wir melden uns bei Ihnen.', 409 );
		}

		$now = OQSC_Plugin::now();
		$wpdb->insert(
			self::table(),
			array(
				'check_id'          => (int) $check['id'],
				'name'              => $name,
				'email'             => $email,
				'telefon'           => $telefon,
				'nachricht'         => $nachricht,
				'einwilligung_text' => (string) OQSC_Plugin::get( 'einwilligung_text', '' ),
				'einwilligung_zeit' => $now,
				'ip_hash'           => $hash,
				'status'            => 'neu',
				'notiz'             => '',
				'created_at'        => $now,
			)
		);
		$lead_id = (int) $wpdb->insert_id;
		if ( ! $lead_id ) {
			return self::error( 'oqsc_db', 'Die Anfrage konnte nicht gespeichert werden. Bitte schreiben Sie uns direkt eine E-Mail.', 500 );
		}
		// Ergebnis einer Anfrage bleibt so lange abrufbar wie die Anfrage.
		$wpdb->update(
			$wpdb->prefix . 'oqsc_checks',
			array( 'expires_at' => OQSC_Plugin::now( 30 * (int) OQSC_Plugin::get( 'aufbewahrung_leads', 12 ) * DAY_IN_SECONDS ) ),
			array( 'id' => (int) $check['id'] )
		);

		$sent = self::notify( $lead_id );
		return new WP_REST_Response(
			array(
				'ok'      => true,
				'meldung' => 'Danke, ' . $name . '. Ihre Anfrage ist bei uns angekommen. Wir schauen uns Ihre Website persönlich an und melden uns innerhalb von zwei Werktagen bei Ihnen.',
				'mail'    => $sent,
			),
			200
		);
	}

	/**
	 * E-Mail an oriqen (nur Text, alles bereinigt).
	 *
	 * @param int $lead_id Anfrage.
	 * @return bool
	 */
	public static function notify( $lead_id ) {
		global $wpdb;
		$lead = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE id = %d', $lead_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		if ( ! $lead ) {
			return false;
		}
		$check = OQSC_Job::get_by_id( (int) $lead['check_id'] );
		$r     = $check ? json_decode( (string) $check['ergebnis'], true ) : array();
		if ( ! is_array( $r ) ) {
			$r = array();
		}
		$domain = $check ? $check['domain'] : '';
		$index  = isset( $r['index'] ) ? (int) $r['index'] : 0;
		$to     = sanitize_email( (string) OQSC_Plugin::get( 'empfaenger', get_option( 'admin_email' ) ) );
		if ( ! $to ) {
			return false;
		}
		$plain   = static function ( $s ) {
			return trim( preg_replace( '/[\r\n\t]+/', ' ', wp_strip_all_tags( (string) $s ) ) );
		};
		$subject = 'Neue Check-Anfrage: ' . $plain( $domain ) . ' (Index ' . $index . ')';

		$lines   = array();
		$lines[] = 'Neue Anfrage zur persönlichen Analyse über den oriqen Sichtbarkeits-Check.';
		$lines[] = '';
		$lines[] = 'KONTAKT';
		$lines[] = 'Name: ' . $plain( $lead['name'] );
		$lines[] = 'E-Mail: ' . $plain( $lead['email'] );
		$lines[] = 'Telefon: ' . ( $lead['telefon'] ? $plain( $lead['telefon'] ) : 'nicht angegeben' );
		$lines[] = 'Nachricht: ' . ( $lead['nachricht'] ? wp_strip_all_tags( $lead['nachricht'] ) : 'keine' );
		$lines[] = '';
		$lines[] = 'CHECK';
		$lines[] = 'Website: ' . $plain( isset( $r['url'] ) ? $r['url'] : $domain );
		$lines[] = 'Ort: ' . ( $check && $check['ort'] ? $plain( $check['ort'] ) : 'nicht angegeben' ) . ', Branche: ' . ( $check && $check['branche'] ? $plain( OQSC_Plugin::branchen()[ $check['branche'] ] ?? $check['branche'] ) : 'nicht angegeben' );
		$lines[] = 'Sichtbarkeits-Index: ' . $index . ' von 100 (' . $plain( isset( $r['einordnung']['label'] ) ? $r['einordnung']['label'] : '' ) . ')';
		$lines[] = $plain( isset( $r['einordnung']['satz'] ) ? $r['einordnung']['satz'] : '' );
		$lines[] = '';
		$lines[] = 'SÄULEN';
		foreach ( isset( $r['saeulen'] ) ? $r['saeulen'] : array() as $s ) {
			$lines[] = '- ' . $s['name'] . ': ' . ( null === $s['wert'] ? 'nicht prüfbar' : $s['wert'] . ' / 100' );
		}
		$lines[] = '';
		$lines[] = 'TOP-HEBEL';
		foreach ( isset( $r['hebel'] ) ? $r['hebel'] : array() as $i => $h ) {
			$lines[] = ( $i + 1 ) . '. ' . $h['titel'] . ' (' . $h['saeule_name'] . ', Wirkung ' . $h['wirkung'] . ', ' . ( 'selbst' === $h['aufwand'] ? 'selbst machbar' : 'mit Fachhilfe' ) . '): ' . $plain( $h['befund'] );
		}
		$lines[] = '';
		$lines[] = 'KRITISCHE BEFUNDE';
		$any = false;
		foreach ( isset( $r['pruefungen'] ) ? $r['pruefungen'] : array() as $p ) {
			if ( 'kritisch' === $p['status'] ) {
				$lines[] = '- ' . $p['id'] . ' ' . $p['titel'] . ': ' . $plain( $p['befund'] );
				$any     = true;
			}
		}
		if ( ! $any ) {
			$lines[] = 'keine';
		}
		$note = isset( $r['intern']['vertriebsnotiz'] ) ? $r['intern']['vertriebsnotiz'] : null;
		if ( $note ) {
			$lines[] = '';
			$lines[] = 'INTERNE VERTRIEBSNOTIZ';
			$lines[] = 'Auftragspotenzial: ' . $note['potenzial'] . ' (' . $note['begruendung'] . ')';
			foreach ( $note['leistungen'] as $l ) {
				$lines[] = '- ' . $l['name'] . ' ' . esc_url_raw( $l['url'] );
				$lines[] = '  wegen: ' . $plain( implode( ', ', $l['gruende'] ) );
			}
		}
		$lines[] = '';
		$lines[] = 'Im Backend ansehen: ' . admin_url( 'admin.php?page=oqsc-leads&id=' . (int) $lead_id );
		$lines[] = '';
		$lines[] = 'Einwilligung erteilt am ' . wp_date( 'd.m.Y H:i', strtotime( $lead['einwilligung_zeit'] . ' UTC' ) ) . ' Uhr: „' . $plain( $lead['einwilligung_text'] ) . '“';

		$headers = array( 'Content-Type: text/plain; charset=UTF-8' );
		$reply   = sanitize_email( $lead['email'] );
		if ( $reply && is_email( $reply ) ) {
			$headers[] = 'Reply-To: ' . str_replace( array( "\r", "\n", '<', '>', ',' ), '', $plain( $lead['name'] ) ) . ' <' . $reply . '>';
		}
		return (bool) wp_mail( $to, $subject, implode( "\n", $lines ), $headers );
	}
}
