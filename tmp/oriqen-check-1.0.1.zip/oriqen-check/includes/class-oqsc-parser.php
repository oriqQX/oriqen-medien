<?php
/**
 * HTML-Analyse mit DOMDocument. Alles Gelesene ist nicht vertrauenswürdig und wird
 * nur als Text weitergegeben (gekürzt, ohne Markup).
 *
 * @package oriqen-check
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Parser für Startseite und Nebenseiten.
 */
class OQSC_Parser {

	const MAX_LINKS   = 400;
	const MAX_IMAGES  = 200;
	const MAX_SCRIPTS = 150;

	/**
	 * Bekannte Einwilligungs-Werkzeuge: Name => Signaturen (kleingeschrieben).
	 *
	 * @return array
	 */
	public static function consent_tools() {
		return array(
			'Borlabs Cookie'      => array( 'borlabs-cookie', 'borlabscookie', 'brlbs' ),
			'Usercentrics'        => array( 'usercentrics' ),
			'Cookiebot'           => array( 'cookiebot', 'consent.cookiebot.com' ),
			'Complianz'           => array( 'complianz', 'cmplz' ),
			'Real Cookie Banner'  => array( 'real-cookie-banner', 'realcookiebanner' ),
			'CCM19'               => array( 'ccm19' ),
			'Klaro'               => array( 'klaro.js', 'klaro.min.js', 'klaroconfig', 'klaro-' ),
			'consentmanager'      => array( 'consentmanager.net', 'consentmanager.de', 'cmp.consentmanager' ),
			'OneTrust'            => array( 'onetrust', 'otsdkstub', 'cookielaw.org' ),
			'CookieYes'           => array( 'cookieyes', 'cookie-law-info' ),
			'iubenda'             => array( 'iubenda' ),
			'Didomi'              => array( 'didomi' ),
			'Cookie First'        => array( 'cookiefirst' ),
			'Cookie Script'       => array( 'cookie-script.com' ),
			'Termly'              => array( 'termly.io' ),
			'GDPR Cookie Consent' => array( 'moove_gdpr', 'gdpr-cookie-compliance' ),
			'Cookie Notice'       => array( 'cookie-notice', 'cn-cookie' ),
			'eRecht24'            => array( 'erecht24' ),
			'Shopware Cookie'     => array( 'cookie-permission' ),
			'Jimdo/IONOS Consent' => array( 'cookie-consent-banner', 'cmp-consent' ),
		);
	}

	/**
	 * Tracking-Dienste: Name => Muster (Quelle oder Inline-Code).
	 *
	 * @return array
	 */
	public static function trackers() {
		return array(
			'Google Analytics'  => array( 'googletagmanager.com/gtag/js', 'google-analytics.com/analytics.js', 'google-analytics.com/ga.js', "gtag('config'", 'gtag("config"', '_gaq.push', "ga('create'" ),
			'Google Tag Manager' => array( 'googletagmanager.com/gtm.js', "'gtm.start'", '"gtm.start"' ),
			'Meta Pixel'        => array( 'connect.facebook.net/en_us/fbevents.js', 'fbevents.js', "fbq('init'", 'fbq("init"' ),
			'Hotjar'            => array( 'static.hotjar.com', 'hotjar.com/c/hotjar', '_hjsettings' ),
			'Microsoft Clarity' => array( 'clarity.ms/tag', 'www.clarity.ms' ),
			'LinkedIn Insight'  => array( 'snap.licdn.com', '_linkedin_partner_id' ),
			'TikTok Pixel'      => array( 'analytics.tiktok.com', 'ttq.load' ),
		);
	}

	/**
	 * Weitere Drittdienste: Name => Muster in Quellen von Skripten, Iframes, Styles.
	 *
	 * @return array
	 */
	public static function third_parties() {
		return array(
			'Google reCAPTCHA'            => array( 'google.com/recaptcha', 'gstatic.com/recaptcha', 'recaptcha.net' ),
			'Facebook-Plugin'             => array( 'facebook.com/plugins', 'connect.facebook.net/de_de/sdk.js', 'connect.facebook.net/en_us/sdk.js', 'facebook.net/sdk.js' ),
			'Instagram-Einbettung'        => array( 'instagram.com/embed', 'cdninstagram.com' ),
			'X/Twitter-Einbettung'        => array( 'platform.twitter.com', 'platform.x.com' ),
			'Chat-Widget (Tawk.to)'       => array( 'tawk.to' ),
			'Chat-Widget (Crisp)'         => array( 'crisp.chat' ),
			'Chat-Widget (Intercom)'      => array( 'intercom.io', 'intercomcdn.com' ),
			'Chat-Widget (Zendesk)'       => array( 'zdassets.com', 'zopim.com' ),
			'Chat-Widget (Tidio)'         => array( 'tidio.co', 'tidiochat' ),
			'Chat-Widget (Userlike)'      => array( 'userlike' ),
			'Chat-Widget (LiveChat)'      => array( 'livechatinc.com' ),
			'Chat-Widget (HubSpot)'       => array( 'js.hs-scripts.com', 'js.usemessages.com', 'hs-analytics' ),
			'Chat-Widget (Smartsupp)'     => array( 'smartsupp' ),
			'Webfonts (Adobe Typekit)'    => array( 'use.typekit.net', 'p.typekit.net' ),
			'Webfonts (Font Awesome CDN)' => array( 'use.fontawesome.com', 'kit.fontawesome.com' ),
			'Webfonts (Fonts.com)'        => array( 'fast.fonts.net' ),
			'Webfonts (Bunny Fonts)'      => array( 'fonts.bunny.net' ),
			'Google Maps (Skript)'        => array( 'maps.googleapis.com/maps/api/js' ),
			'Externes CDN (jsDelivr)'     => array( 'cdn.jsdelivr.net' ),
			'Externes CDN (cdnjs)'        => array( 'cdnjs.cloudflare.com' ),
			'Externes CDN (unpkg)'        => array( 'unpkg.com' ),
			'Externes CDN (Google)'       => array( 'ajax.googleapis.com' ),
			'Externes CDN (jQuery)'       => array( 'code.jquery.com' ),
			'Calendly'                    => array( 'calendly.com' ),
			'Trustpilot-Widget'           => array( 'widget.trustpilot.com' ),
			'ProvenExpert-Siegel'         => array( 'provenexpert.com' ),
			'Google Translate'            => array( 'translate.google.com/translate_a' ),
			'Doctolib/Terminbuchung'      => array( 'doctolib.de', 'etermin.net', 'jameda.de' ),
		);
	}

	/**
	 * DOM laden: UTF-8, ohne Netzwerk, Fehler unterdrückt.
	 *
	 * @param string $html         HTML.
	 * @param string $content_type Content-Type-Header.
	 * @return DOMDocument|null
	 */
	public static function load( $html, $content_type = '' ) {
		if ( ! class_exists( 'DOMDocument' ) || '' === trim( (string) $html ) ) {
			return null;
		}
		$charset = '';
		if ( preg_match( '/charset=["\']?([a-z0-9_\-]+)/i', (string) $content_type, $m ) ) {
			$charset = $m[1];
		} elseif ( preg_match( '/<meta[^>]+charset=["\']?([a-z0-9_\-]+)/i', substr( $html, 0, 4096 ), $m ) ) {
			$charset = $m[1];
		}
		$charset = strtoupper( $charset );
		if ( $charset && ! in_array( $charset, array( 'UTF-8', 'UTF8' ), true ) && function_exists( 'mb_convert_encoding' ) ) {
			$converted = @mb_convert_encoding( $html, 'UTF-8', $charset ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- unbekannte Zeichensätze ignorieren.
			if ( is_string( $converted ) ) {
				$html = $converted;
			}
		} elseif ( function_exists( 'mb_check_encoding' ) && ! mb_check_encoding( $html, 'UTF-8' ) ) {
			$html = mb_convert_encoding( $html, 'UTF-8', 'Windows-1252' );
		}
		// Kommentare mit bedingten Inhalten entfernen, BOM entfernen.
		$html = preg_replace( '/^\xEF\xBB\xBF/', '', $html );

		$prev = libxml_use_internal_errors( true );
		$dom  = new DOMDocument();
		$ok   = $dom->loadHTML( '<?xml encoding="UTF-8">' . $html, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING | LIBXML_COMPACT | LIBXML_PARSEHUGE );
		libxml_clear_errors();
		libxml_use_internal_errors( $prev );
		return $ok ? $dom : null;
	}

	/**
	 * Text bereinigen und kürzen.
	 *
	 * @param string $text Text.
	 * @param int    $max  Länge.
	 * @return string
	 */
	public static function clean( $text, $max = 300 ) {
		$text = html_entity_decode( (string) $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		$text = preg_replace( '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $text );
		$text = trim( preg_replace( '/\s+/u', ' ', $text ) );
		if ( function_exists( 'mb_substr' ) && mb_strlen( $text ) > $max ) {
			$text = rtrim( mb_substr( $text, 0, $max ) ) . ' …';
		}
		return $text;
	}

	/**
	 * Absolute URL bilden.
	 *
	 * @param string $href Verweis.
	 * @param string $base Basis.
	 * @return string
	 */
	public static function absolute( $href, $base ) {
		$href = trim( (string) $href );
		if ( '' === $href ) {
			return '';
		}
		if ( preg_match( '#^(mailto|tel|javascript|data|callto|whatsapp|sms):#i', $href ) ) {
			return $href;
		}
		if ( 0 === strpos( $href, '//' ) ) {
			$scheme = wp_parse_url( $base, PHP_URL_SCHEME );
			return ( $scheme ? $scheme : 'https' ) . ':' . $href;
		}
		if ( 0 === strpos( $href, '#' ) ) {
			return $base . $href;
		}
		return WP_Http::make_absolute_url( $href, $base );
	}

	/**
	 * Gehört ein Host zur geprüften Website (gleiche Domain oder Subdomain)?
	 *
	 * @param string $host   Host.
	 * @param string $domain Domain-Schlüssel.
	 * @return bool
	 */
	public static function same_site( $host, $domain ) {
		$host = strtolower( (string) $host );
		$host = preg_replace( '/^www\./', '', $host );
		return $host === $domain || substr( $host, -1 * ( strlen( $domain ) + 1 ) ) === '.' . $domain;
	}

	/**
	 * Sichtbaren Text sammeln und dabei Links und Positionen erfassen.
	 *
	 * @param DOMNode $node  Knoten.
	 * @param array   $state Zustand (per Referenz).
	 */
	private static function walk( $node, &$state ) {
		static $skip = array( 'script', 'style', 'noscript', 'template', 'svg', 'iframe', 'head', 'select', 'option', 'object', 'canvas', 'video', 'audio', 'math' );
		static $block = array( 'p', 'div', 'li', 'ul', 'ol', 'br', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'section', 'article', 'header', 'footer', 'nav', 'main', 'aside', 'table', 'tr', 'td', 'th', 'dd', 'dt', 'blockquote', 'figure', 'figcaption', 'address', 'form', 'label', 'button', 'a' );
		foreach ( $node->childNodes as $child ) {
			if ( XML_TEXT_NODE === $child->nodeType ) {
				$t = $child->nodeValue;
				if ( '' !== trim( $t ) ) {
					$state['text'] .= $t;
				}
				continue;
			}
			if ( XML_ELEMENT_NODE !== $child->nodeType ) {
				continue;
			}
			$tag = strtolower( $child->nodeName );
			if ( in_array( $tag, $skip, true ) ) {
				continue;
			}
			if ( $child->hasAttribute( 'hidden' ) || preg_match( '/display\s*:\s*none|visibility\s*:\s*hidden/i', $child->getAttribute( 'style' ) ) || 'true' === $child->getAttribute( 'aria-hidden' ) && 'a' !== $tag ) {
				continue;
			}
			if ( 'a' === $tag ) {
				$state['link_offsets'][ spl_object_id( $child ) ] = strlen( $state['text'] );
			}
			if ( 'button' === $tag || ( 'input' === $tag && in_array( strtolower( $child->getAttribute( 'type' ) ), array( 'submit', 'button' ), true ) ) ) {
				$state['buttons'][] = array(
					'text'   => self::clean( 'input' === $tag ? $child->getAttribute( 'value' ) : $child->textContent, 120 ),
					'offset' => strlen( $state['text'] ),
				);
			}
			if ( in_array( $tag, $block, true ) ) {
				$state['text'] .= ' ';
			}
			self::walk( $child, $state );
			if ( in_array( $tag, $block, true ) ) {
				$state['text'] .= ' ';
			}
		}
	}

	/**
	 * Wörter eines Textes.
	 *
	 * @param string $text Text.
	 * @return array
	 */
	public static function words( $text ) {
		$parts = preg_split( '/\s+/u', trim( (string) $text ) );
		$out   = array();
		foreach ( $parts as $p ) {
			if ( preg_match( '/[\p{L}\p{N}]/u', $p ) ) {
				$out[] = $p;
			}
		}
		return $out;
	}

	/**
	 * Liegt ein Element im Kopfbereich (header, nav, Menü)?
	 *
	 * @param DOMElement $el Element.
	 * @return bool
	 */
	private static function in_header( $el ) {
		$n     = $el->parentNode;
		$depth = 0;
		while ( $n && XML_ELEMENT_NODE === $n->nodeType && $depth < 30 ) {
			$tag = strtolower( $n->nodeName );
			if ( 'body' === $tag || 'html' === $tag || 'main' === $tag ) {
				return false;
			}
			if ( 'header' === $tag || 'nav' === $tag || 'banner' === strtolower( $n->getAttribute( 'role' ) ) || 'navigation' === strtolower( $n->getAttribute( 'role' ) ) ) {
				return true;
			}
			if ( 'footer' === $tag || self::has_token( $n, '(footer|colophon)' ) ) {
				return false;
			}
			if ( self::has_token( $n, '(header|masthead|navbar|navigation|main-menu|menu-main|site-nav|topbar|top-bar)' ) ) {
				return true;
			}
			$n = $n->parentNode;
			++$depth;
		}
		return false;
	}

	/**
	 * Hat ein Element eine Klasse oder ID, die als eigenes Wort den Begriff enthält?
	 * Trennzeichen sind nur Leerzeichen und Bindestrich, damit etwa
	 * „page-template-elementor_header_footer“ am body nicht zählt.
	 *
	 * @param DOMElement $el      Element.
	 * @param string     $pattern Regex-Gruppe.
	 * @return bool
	 */
	private static function has_token( $el, $pattern ) {
		$tokens = preg_split( '/\s+/', strtolower( $el->getAttribute( 'class' ) . ' ' . $el->getAttribute( 'id' ) ) );
		foreach ( $tokens as $t ) {
			if ( '' !== $t && false === strpos( $t, '_' ) && preg_match( '/(^|-)' . $pattern . '(-|$)/', $t ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Liegt ein Element im Fußbereich?
	 *
	 * @param DOMElement $el Element.
	 * @return bool
	 */
	private static function in_footer( $el ) {
		$n     = $el->parentNode;
		$depth = 0;
		while ( $n && XML_ELEMENT_NODE === $n->nodeType && $depth < 30 ) {
			$tag = strtolower( $n->nodeName );
			if ( 'body' === $tag || 'html' === $tag || 'main' === $tag ) {
				return false;
			}
			if ( 'footer' === $tag || 'contentinfo' === strtolower( $n->getAttribute( 'role' ) ) || self::has_token( $n, '(footer|colophon)' ) ) {
				return true;
			}
			$n = $n->parentNode;
			++$depth;
		}
		return false;
	}

	/**
	 * Alle Attribute eines Elements als Kleinbuchstaben-Zeichenkette (für Signaturen).
	 *
	 * @param DOMElement $el Element.
	 * @return string
	 */
	private static function attr_string( $el ) {
		$s = '';
		foreach ( $el->attributes as $a ) {
			$s .= ' ' . strtolower( $a->nodeName ) . '="' . strtolower( substr( $a->nodeValue, 0, 300 ) ) . '"';
		}
		return $s;
	}

	/**
	 * Hat ein Skript oder Iframe ein Kennzeichen eines Consent-Tools?
	 *
	 * @param DOMElement $el Element.
	 * @return bool
	 */
	public static function consent_marked( $el ) {
		$type = strtolower( trim( $el->getAttribute( 'type' ) ) );
		if ( 'script' === strtolower( $el->nodeName ) && '' !== $type && ! in_array( $type, array( 'text/javascript', 'application/javascript', 'module', 'text/ecmascript', 'application/ecmascript' ), true ) ) {
			return true;
		}
		$attrs = self::attr_string( $el );
		return (bool) preg_match( '/data-cookieconsent|data-borlabs|data-category|data-cookiecategory|data-cmp-|data-usercentrics|data-consent|data-service=|data-type="?text\/plain|data-src|data-cmplz|cmplz-|consent-original|data-placeholder|data-rcb|data-ccm|data-name=|klaro|data-cookie-consent|uc-src|data-blocked|data-lazy-type="iframe"|data-iub/', $attrs );
	}

	/**
	 * JSON-LD-Knoten durchlaufen.
	 *
	 * @param mixed $node  Knoten.
	 * @param array $types Typen (per Referenz).
	 * @param array $nodes Knoten mit Typ (per Referenz).
	 * @param int   $depth Tiefe.
	 */
	private static function jsonld_walk( $node, &$types, &$nodes, $depth = 0 ) {
		if ( $depth > 8 || ! is_array( $node ) ) {
			return;
		}
		if ( isset( $node['@type'] ) ) {
			$t = is_array( $node['@type'] ) ? $node['@type'] : array( $node['@type'] );
			foreach ( $t as $one ) {
				if ( is_string( $one ) ) {
					$one     = preg_replace( '#^https?://schema\.org/#', '', $one );
					$types[] = substr( $one, 0, 60 );
				}
			}
			if ( count( $nodes ) < 50 ) {
				$nodes[] = $node;
			}
		}
		foreach ( $node as $k => $v ) {
			if ( is_array( $v ) ) {
				self::jsonld_walk( $v, $types, $nodes, $depth + 1 );
			}
		}
	}

	/**
	 * Untertypen von LocalBusiness (Auswahl, häufig bei Betrieben in Deutschland).
	 *
	 * @return array
	 */
	public static function local_business_types() {
		return array( 'LocalBusiness', 'ProfessionalService', 'HomeAndConstructionBusiness', 'Carpenter', 'Electrician', 'GeneralContractor', 'HVACBusiness', 'HousePainter', 'Locksmith', 'MovingCompany', 'Plumber', 'RoofingContractor', 'AutoRepair', 'AutomotiveBusiness', 'AutoDealer', 'Store', 'FurnitureStore', 'HomeGoodsStore', 'HardwareStore', 'ClothingStore', 'ShoeStore', 'JewelryStore', 'Florist', 'GardenStore', 'Bakery', 'FoodEstablishment', 'Restaurant', 'CafeOrCoffeeShop', 'BarOrPub', 'Brewery', 'FastFoodRestaurant', 'IceCreamShop', 'Winery', 'MedicalBusiness', 'Dentist', 'Physician', 'MedicalClinic', 'Optician', 'Pharmacy', 'Physiotherapy', 'HealthAndBeautyBusiness', 'BeautySalon', 'HairSalon', 'DaySpa', 'NailSalon', 'TattooParlor', 'LegalService', 'Attorney', 'Notary', 'AccountingService', 'FinancialService', 'InsuranceAgency', 'RealEstateAgent', 'TravelAgency', 'EmploymentAgency', 'LodgingBusiness', 'Hotel', 'BedAndBreakfast', 'SportsActivityLocation', 'ExerciseGym', 'ChildCare', 'DryCleaningOrLaundry', 'EntertainmentBusiness', 'InternetCafe', 'Library', 'SelfStorage', 'ShoppingCenter', 'EmergencyService', 'GovernmentOffice', 'AnimalShelter', 'VeterinaryCare', 'CleaningService', 'Electrician', 'ComputerStore', 'ElectronicsStore', 'BikeStore', 'BookStore', 'PetStore', 'SportingGoodsStore', 'ToyStore', 'WholesaleStore', 'OutletStore', 'MobilePhoneStore', 'MusicStore', 'OfficeEquipmentStore', 'TireShop', 'LiquorStore', 'ConvenienceStore', 'DepartmentStore', 'GroceryStore', 'HobbyShop', 'PawnShop' );
	}

	/**
	 * Telefonnummer auf Ziffern normalisieren (+49 und 0049 zu 0).
	 *
	 * @param string $raw Nummer.
	 * @return string
	 */
	public static function norm_phone( $raw ) {
		$raw = (string) $raw;
		$raw = preg_replace( '/\(0\)/', '', $raw );
		$d   = preg_replace( '/\D/', '', $raw );
		if ( 0 === strpos( $d, '0049' ) ) {
			$d = '0' . substr( $d, 4 );
		} elseif ( 0 === strpos( $d, '49' ) && false !== strpos( $raw, '+' ) ) {
			$d = '0' . substr( $d, 2 );
		}
		return $d;
	}

	/**
	 * Telefonnummern im Text finden (deutsche Formate, mit Kontextwort oder klarer Vorwahl).
	 *
	 * @param string $text Text.
	 * @return array Normalisierte Nummern.
	 */
	public static function find_phones( $text ) {
		$out = array();
		if ( preg_match_all( '/(?:tel(?:efon)?|fon|phone|mobil|handy|ruf(?:en sie)?(?: uns)?(?: an)?)[\s.:\/]*((?:\+49|0049|0)[\s\-\/().]*[1-9](?:[\s\-\/().]*\d){4,13})/iu', $text, $m ) ) {
			foreach ( $m[1] as $n ) {
				$out[] = self::norm_phone( $n );
			}
		}
		if ( preg_match_all( '/(?<![\d\/.,])((?:\+49|0049)[\s\-\/().]*[1-9](?:[\s\-\/().]*\d){5,13}|0[1-9]\d{1,5}[\s\-\/]+\d(?:[\s\-]?\d){3,9})(?![\d.,])/u', $text, $m ) ) {
			foreach ( $m[1] as $n ) {
				$out[] = self::norm_phone( $n );
			}
		}
		$out = array_values(
			array_unique(
				array_filter(
					$out,
					static function ( $n ) {
						return strlen( $n ) >= 7 && strlen( $n ) <= 15;
					}
				)
			)
		);
		return array_slice( $out, 0, 10 );
	}

	/**
	 * Adressen (Straße mit Hausnummer und Postleitzahl mit Ort) finden.
	 *
	 * @param string $text Text.
	 * @return array Liste mit plz, ort, strasse (bool).
	 */
	public static function find_addresses( $text ) {
		$out = array();
		if ( preg_match_all( '/(?<![\d\-])(\d{5})\s+([A-ZÄÖÜ][a-zäöüß]+(?:[\- ](?:an der |am |im |bei |\(|)?[A-ZÄÖÜ][a-zäöüß.)]+)?)/u', $text, $m, PREG_OFFSET_CAPTURE ) ) {
			foreach ( $m[1] as $i => $plz ) {
				$code = (int) $plz[0];
				if ( $code < 1001 || $code > 99998 ) {
					continue;
				}
				$before   = substr( $text, max( 0, $plz[1] - 90 ), min( 90, $plz[1] ) );
				$has_road = (bool) preg_match( '/(stra(ß|ss)e|str\.|weg|allee|platz|ring|gasse|damm|ufer|chaussee|steig|pfad|markt|hof|berg|feld|park|kamp|wall|graben|tor|stieg|bogen|garten|anger|höhe|zeile|promenade|brücke|land|busch|heide|wiese|aue|grund|mühle|siedlung|winkel|kirchplatz)\s*\d+\s?[a-z]?\b/iu', $before )
					|| (bool) preg_match( '/\b[A-ZÄÖÜ][a-zäöüß]+(?:[\- ][A-ZÄÖÜ]?[a-zäöüß]+)*\s+\d{1,4}\s?[a-z]?\s*[,|·\-]?\s*$/u', $before );
				$ort      = trim( preg_replace( '/[^\p{L}\- ().]/u', '', $m[2][ $i ][0] ) );
				$ort      = preg_replace( '/\s+(Tel|Telefon|Fon|Fax|E|Mail|Email|Deutschland|Germany|DE)$/u', '', $ort );
				if ( in_array( $ort, array( 'Euro', 'Mitarbeiter', 'Kunden', 'Besucher', 'Einwohner', 'Quadratmeter', 'Stück', 'Projekte', 'Bewertungen' ), true ) ) {
					continue;
				}
				$out[] = array(
					'plz'     => $plz[0],
					'ort'     => self::clean( $ort, 60 ),
					'strasse' => $has_road,
				);
				if ( count( $out ) >= 10 ) {
					break;
				}
			}
		}
		return $out;
	}

	/**
	 * Startseite vollständig analysieren.
	 *
	 * @param string $html         HTML.
	 * @param string $base_url     Endgültige URL.
	 * @param string $content_type Content-Type.
	 * @return array
	 */
	public static function parse( $html, $base_url, $content_type = '' ) {
		$dom    = self::load( $html, $content_type );
		$domain = OQSC_Fetcher::domain_key( $base_url );
		$https  = 0 === strpos( $base_url, 'https://' );
		$lower  = strtolower( $html );

		$out = array(
			'ok'            => (bool) $dom,
			'html_bytes'    => strlen( $html ),
			'title'         => '',
			'title_count'   => 0,
			'description'   => '',
			'robots_meta'   => '',
			'viewport'      => '',
			'canonical'     => '',
			'lang'          => '',
			'og_title'      => '',
			'og_image'      => '',
			'og_site_name'  => '',
			'favicon'       => false,
			'headings'      => array(),
			'h1'            => array(),
			'word_count'    => 0,
			'first_words'   => '',
			'first_area'    => '',
			'first_para'    => '',
			'para_sample'   => '',
			'header_text'   => '',
			'text_sample'   => '',
			'links'         => array(),
			'internal_count' => 0,
			'tel_links'     => array(),
			'mail_links'    => array(),
			'phones_text'   => array(),
			'addresses'     => array(),
			'images'        => array(),
			'img_total'     => 0,
			'img_alt'       => 0,
			'img_modern'    => 0,
			'stylesheets'   => array(),
			'scripts_total' => 0,
			'script_bytes'  => 0,
			'jsonld_types'  => array(),
			'jsonld_blocks' => 0,
			'jsonld_invalid' => 0,
			'business'      => array(),
			'has_review_schema' => false,
			'faq_schema'    => false,
			'question_headings' => 0,
			'forms'         => 0,
			'form_email'    => false,
			'inputs_total'  => 0,
			'inputs_labeled' => 0,
			'skip_link'     => false,
			'main_landmark' => false,
			'copyright_year' => 0,
			'newest_date'   => '',
			'google_fonts'  => array(),
			'google_fonts_preconnect' => false,
			'consent_tools' => array(),
			'trackers'      => array(),
			'consent_mode'  => false,
			'embeds'        => array(),
			'third_parties' => array(),
			'mixed_content' => array(),
			'buttons'       => array(),
			'about_signal'  => false,
			'review_signal' => false,
			'area_signal'   => false,
			'hours_signal'  => false,
			'contact_cta'   => array(),
			'impressum_url' => '',
			'datenschutz_url' => '',
			'kontakt_url'   => '',
			'nav_links'     => array(),
		);
		if ( ! $dom ) {
			return $out;
		}
		$xp = new DOMXPath( $dom );

		// Kopf.
		$titles             = $xp->query( '//title' );
		$out['title_count'] = $titles->length;
		if ( $titles->length ) {
			$out['title'] = self::clean( $titles->item( 0 )->textContent, 300 );
		}
		foreach ( $xp->query( '//meta' ) as $meta ) {
			$name    = strtolower( trim( $meta->getAttribute( 'name' ) ) );
			$prop    = strtolower( trim( $meta->getAttribute( 'property' ) ) );
			$content = $meta->getAttribute( 'content' );
			if ( 'description' === $name && '' === $out['description'] ) {
				$out['description'] = self::clean( $content, 400 );
			} elseif ( 'robots' === $name || 'googlebot' === $name ) {
				$out['robots_meta'] .= ' ' . strtolower( self::clean( $content, 100 ) );
			} elseif ( 'viewport' === $name ) {
				$out['viewport'] = self::clean( $content, 200 );
			} elseif ( 'og:title' === $prop ) {
				$out['og_title'] = self::clean( $content, 200 );
			} elseif ( 'og:image' === $prop ) {
				$out['og_image'] = self::clean( $content, 300 );
			} elseif ( 'og:site_name' === $prop ) {
				$out['og_site_name'] = self::clean( $content, 120 );
			} elseif ( in_array( $prop, array( 'article:published_time', 'article:modified_time' ), true ) || 'date' === $name ) {
				$d = substr( self::clean( $content, 40 ), 0, 10 );
				if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d ) && $d > $out['newest_date'] ) {
					$out['newest_date'] = $d;
				}
			}
		}
		$out['robots_meta'] = trim( $out['robots_meta'] );
		$html_el            = $xp->query( '//html' )->item( 0 );
		if ( $html_el ) {
			$out['lang'] = self::clean( $html_el->getAttribute( 'lang' ) ? $html_el->getAttribute( 'lang' ) : $html_el->getAttribute( 'xml:lang' ), 20 );
		}
		foreach ( $xp->query( '//link[@rel]' ) as $link ) {
			$rel  = strtolower( $link->getAttribute( 'rel' ) );
			$href = $link->getAttribute( 'href' );
			if ( 'canonical' === trim( $rel ) && '' === $out['canonical'] ) {
				$out['canonical'] = self::clean( self::absolute( $href, $base_url ), 400 );
			}
			if ( false !== strpos( $rel, 'icon' ) ) {
				$out['favicon'] = true;
			}
			$abs = self::absolute( $href, $base_url );
			if ( preg_match( '/(^|\s)stylesheet(\s|$)/', $rel ) || ( 'preload' === trim( $rel ) && 'style' === strtolower( $link->getAttribute( 'as' ) ) ) ) {
				if ( count( $out['stylesheets'] ) < 40 ) {
					$out['stylesheets'][] = self::clean( $abs, 500 );
				}
				if ( preg_match( '#fonts\.(googleapis|gstatic)\.com#i', $href ) && ! self::consent_marked( $link ) ) {
					$out['google_fonts'][] = 'Stylesheet: ' . self::clean( $href, 200 );
				}
				if ( $https && 0 === stripos( $abs, 'http://' ) ) {
					$out['mixed_content'][] = self::clean( $abs, 200 );
				}
			}
			if ( preg_match( '/preconnect|dns-prefetch/', $rel ) && preg_match( '#fonts\.(googleapis|gstatic)\.com#i', $href ) ) {
				$out['google_fonts_preconnect'] = true;
			}
		}

		// Überschriften.
		foreach ( $xp->query( '//h1|//h2|//h3|//h4|//h5|//h6' ) as $h ) {
			$level = (int) substr( strtolower( $h->nodeName ), 1 );
			$text  = self::clean( $h->textContent, 200 );
			if ( count( $out['headings'] ) < 80 ) {
				$out['headings'][] = array( $level, $text, self::in_header( $h ) || self::in_footer( $h ) );
			}
			if ( 1 === $level ) {
				$out['h1'][] = $text;
			}
			if ( '' !== $text && '?' === mb_substr( rtrim( $text ), -1 ) ) {
				++$out['question_headings'];
			}
		}

		// Sichtbarer Text mit Positionen der Links.
		$body  = $xp->query( '//body' )->item( 0 );
		$state = array(
			'text'         => '',
			'link_offsets' => array(),
			'buttons'      => array(),
		);
		if ( $body ) {
			self::walk( $body, $state );
		}
		$text_raw           = $state['text'];
		$text               = self::clean( $text_raw, 200000 );
		$words              = self::words( $text );
		$out['word_count']  = count( $words );
		$out['first_words'] = self::clean( implode( ' ', array_slice( $words, 0, 200 ) ), 2500 );
		$out['text_sample'] = self::clean( implode( ' ', array_slice( $words, 0, 300 ) ), 3500 );
		$total_len          = max( 1, strlen( $text_raw ) );

		// Kopfbereich und erster Absatz.
		$header_text = '';
		foreach ( $xp->query( '//header|//*[@role="banner"]' ) as $hd ) {
			$header_text .= ' ' . $hd->textContent;
			if ( strlen( $header_text ) > 2000 ) {
				break;
			}
		}
		$out['header_text'] = self::clean( $header_text, 600 );
		$scope              = $xp->query( '//main' )->item( 0 );
		if ( ! $scope ) {
			$scope = $body;
		}
		$first_para = '';
		$para_words = array();
		if ( $scope ) {
			foreach ( $xp->query( './/p|.//li', $scope ) as $p ) {
				if ( self::in_footer( $p ) || self::in_header( $p ) ) {
					continue;
				}
				$pt = self::clean( $p->textContent, 4000 );
				$pw = self::words( $pt );
				if ( count( $pw ) >= 8 ) {
					if ( '' === $first_para && 'p' === strtolower( $p->nodeName ) ) {
						$first_para = $pt;
					}
					if ( count( $para_words ) < 300 ) {
						$pt = rtrim( $pt );
						if ( ! preg_match( '/[.!?:]$/u', $pt ) ) {
							$pt .= '.';
						}
						$para_words = array_merge( $para_words, self::words( $pt ) );
					}
				}
			}
		}
		$out['para_sample'] = self::clean( implode( ' ', array_slice( $para_words, 0, 300 ) ), 4000 );
		$out['first_para'] = self::clean( implode( ' ', array_slice( self::words( $first_para ), 0, 120 ) ), 1200 );
		$area              = trim( $out['header_text'] . ' ' . ( isset( $out['h1'][0] ) ? $out['h1'][0] : '' ) . ' ' . implode( ' ', array_slice( self::words( $first_para ), 0, 60 ) ) );
		$out['first_area'] = self::clean( $area, 1500 );

		// Links.
		$i = 0;
		foreach ( $xp->query( '//a[@href]' ) as $a ) {
			$href = trim( $a->getAttribute( 'href' ) );
			$abs  = self::absolute( $href, $base_url );
			$txt  = self::clean( $a->textContent . ' ' . $a->getAttribute( 'aria-label' ) . ' ' . $a->getAttribute( 'title' ), 150 );
			foreach ( $a->getElementsByTagName( 'img' ) as $img ) {
				$txt = self::clean( $txt . ' ' . $img->getAttribute( 'alt' ), 150 );
			}
			$lower_href = strtolower( $abs );
			if ( 0 === strpos( $lower_href, 'tel:' ) || 0 === strpos( $lower_href, 'callto:' ) ) {
				$out['tel_links'][] = self::norm_phone( rawurldecode( substr( $abs, strpos( $abs, ':' ) + 1 ) ) );
			} elseif ( 0 === strpos( $lower_href, 'mailto:' ) ) {
				$out['mail_links'][] = self::clean( substr( $abs, 7, 120 ), 120 );
			}
			$host     = wp_parse_url( $abs, PHP_URL_HOST );
			$internal = $host && self::same_site( $host, $domain );
			$id       = spl_object_id( $a );
			$offset   = isset( $state['link_offsets'][ $id ] ) ? $state['link_offsets'][ $id ] : $total_len;
			$header   = self::in_header( $a );
			$entry    = array(
				'url'      => self::clean( $abs, 500 ),
				'text'     => $txt,
				'intern'   => $internal,
				'kopf'     => $header,
				'fuss'     => self::in_footer( $a ),
				'oben'     => $offset <= 0.25 * $total_len,
			);
			if ( $i < self::MAX_LINKS ) {
				$out['links'][] = $entry;
			}
			++$i;
			if ( $internal ) {
				++$out['internal_count'];
			}
			$lt = strtolower( $txt . ' ' . (string) wp_parse_url( $abs, PHP_URL_PATH ) . ' ' . (string) wp_parse_url( $abs, PHP_URL_QUERY ) );
			if ( $internal ) {
				if ( '' === $out['impressum_url'] && preg_match( '/impressum|imprint|legal-notice|anbieterkennzeichnung/', $lt ) ) {
					$out['impressum_url'] = $entry['url'];
				}
				if ( '' === $out['datenschutz_url'] && preg_match( '/datenschutz|privacy|data-protection|dsgvo/', $lt ) ) {
					$out['datenschutz_url'] = $entry['url'];
				}
				if ( '' === $out['kontakt_url'] && preg_match( '/kontakt|contact/', $lt ) && 0 !== strpos( $lower_href, 'mailto:' ) && false === strpos( $abs, '#' ) ) {
					$out['kontakt_url'] = $entry['url'];
				}
				if ( $header && count( $out['nav_links'] ) < 30 && ! in_array( $entry['url'], $out['nav_links'], true ) ) {
					$out['nav_links'][] = $entry['url'];
				}
			}
			if ( preg_match( '/über uns|ueber-uns|uber-uns|about|unser team|das team|\bteam\b|inhaber|wer wir sind|wir über uns|philosophie|geschichte|unternehmen/u', $lt ) ) {
				$out['about_signal'] = true;
			}
			if ( preg_match( '/bewertung|kundenstimme|referenz|projekte|rezension|erfahrungen|testimonial|google-?bewertung|kundenmeinung/u', $lt ) ) {
				$out['review_signal'] = true;
			}
			$is_skip = 0 === strpos( $href, '#' ) && preg_match( '/springen|skip|zum inhalt/u', strtolower( $txt ) );
			if ( ! $is_skip && ( $header || $entry['oben'] ) && preg_match( '/kontakt|anfrage|anfragen|angebot|termin|anrufen|beratung|rückruf|rueckruf|buchen|reservier|jetzt.*(anrufen|schreiben)|schreiben sie|^tel:|e-?mail schreiben|whatsapp/u', strtolower( $txt ) . ' ' . ( 0 === strpos( $lower_href, 'tel:' ) ? 'tel:' : '' ) ) ) {
				if ( count( $out['contact_cta'] ) < 5 ) {
					$out['contact_cta'][] = $txt ? $txt : 'Telefon-Link';
				}
			}
		}
		$out['tel_links']  = array_values( array_unique( array_filter( $out['tel_links'] ) ) );
		$out['mail_links'] = array_values( array_unique( $out['mail_links'] ) );
		foreach ( $state['buttons'] as $b ) {
			if ( $b['offset'] <= 0.25 * $total_len && preg_match( '/kontakt|anfrage|angebot|termin|anrufen|beratung|rückruf|buchen|reservier/iu', $b['text'] ) && count( $out['contact_cta'] ) < 5 ) {
				$out['contact_cta'][] = $b['text'];
			}
		}

		// Telefon und Adresse im Text.
		$out['phones_text'] = self::find_phones( $text );
		$out['addresses']   = self::find_addresses( $text );

		// Bilder.
		$total = 0;
		foreach ( $xp->query( '//img' ) as $img ) {
			++$total;
			$src = $img->getAttribute( 'src' );
			foreach ( array( 'data-src', 'data-lazy-src', 'data-original', 'data-lazy' ) as $lazy ) {
				if ( ( '' === $src || 0 === strpos( $src, 'data:' ) ) && $img->getAttribute( $lazy ) ) {
					$src = $img->getAttribute( $lazy );
				}
			}
			$abs     = self::absolute( $src, $base_url );
			$has_alt = $img->hasAttribute( 'alt' );
			$alt     = self::clean( $img->getAttribute( 'alt' ), 150 );
			$path    = strtolower( (string) wp_parse_url( $abs, PHP_URL_PATH ) );
			$ext     = pathinfo( $path, PATHINFO_EXTENSION );
			$modern  = in_array( $ext, array( 'webp', 'avif' ), true );
			$parent  = $img->parentNode;
			if ( $parent && 'picture' === strtolower( $parent->nodeName ) ) {
				foreach ( $parent->getElementsByTagName( 'source' ) as $source ) {
					if ( preg_match( '#image/(webp|avif)#i', $source->getAttribute( 'type' ) ) || preg_match( '/\.(webp|avif)(\?|\s|$)/i', $source->getAttribute( 'srcset' ) ) ) {
						$modern = true;
					}
				}
			}
			if ( ! $modern && preg_match( '/\.(webp|avif)(\?|\s|,|$)/i', $img->getAttribute( 'srcset' ) ) ) {
				$modern = true;
			}
			// Dekorative Bilder mit leerem alt gelten als beschriftet.
			if ( $has_alt ) {
				++$out['img_alt'];
			}
			if ( $modern ) {
				++$out['img_modern'];
			}
			if ( $https && 0 === stripos( $abs, 'http://' ) ) {
				$out['mixed_content'][] = self::clean( $abs, 200 );
			}
			if ( count( $out['images'] ) < self::MAX_IMAGES && 0 !== strpos( $abs, 'data:' ) && '' !== $abs ) {
				$out['images'][] = array(
					'url'    => self::clean( $abs, 500 ),
					'alt'    => $has_alt,
					'ext'    => substr( $ext, 0, 5 ),
					'modern' => $modern,
					'kopf'   => self::in_header( $img ),
				);
			}
		}
		$out['img_total'] = $total;

		// Skripte: Tracking, Consent, Drittdienste, Fonts.
		$names_consent = array();
		foreach ( self::consent_tools() as $name => $sigs ) {
			foreach ( $sigs as $sig ) {
				if ( false !== strpos( $lower, $sig ) ) {
					$names_consent[] = $name;
					break;
				}
			}
		}
		$out['consent_tools'] = $names_consent;
		if ( preg_match( '/gtag\(\s*[\'"]consent[\'"]\s*,\s*[\'"]default[\'"]/', $lower ) ) {
			$out['consent_mode'] = true;
		}

		$trackers = array();
		$third    = array();
		$scripts  = $xp->query( '//script' );
		foreach ( $scripts as $s ) {
			++$out['scripts_total'];
			$type = strtolower( trim( $s->getAttribute( 'type' ) ) );
			if ( 'application/ld+json' === $type ) {
				continue;
			}
			$src    = strtolower( $s->getAttribute( 'src' ) );
			$inline = $src ? '' : strtolower( substr( $s->textContent, 0, 20000 ) );
			if ( ! $src ) {
				$out['script_bytes'] += strlen( $s->textContent );
			}
			$blocked = self::consent_marked( $s );
			$hay     = $src . ' ' . $inline;
			foreach ( self::trackers() as $name => $sigs ) {
				foreach ( $sigs as $sig ) {
					if ( false !== strpos( $hay, $sig ) ) {
						if ( ! isset( $trackers[ $name ] ) || $trackers[ $name ] ) {
							$trackers[ $name ] = $blocked;
						}
						break;
					}
				}
			}
			if ( ! $blocked && $src ) {
				foreach ( self::third_parties() as $name => $sigs ) {
					foreach ( $sigs as $sig ) {
						if ( false !== strpos( $src, $sig ) ) {
							$third[ $name ] = true;
							break;
						}
					}
				}
				if ( false !== strpos( $src, 'ajax.googleapis.com/ajax/libs/webfont' ) && preg_match( '/google\s*:\s*\{/', $lower ) ) {
					$out['google_fonts'][] = 'Web Font Loader mit Google Fonts';
				}
				if ( $https && 0 === strpos( $src, 'http://' ) ) {
					$out['mixed_content'][] = self::clean( $s->getAttribute( 'src' ), 200 );
				}
			}
			if ( ! $blocked && $inline && preg_match( '#fonts\.googleapis\.com/css#', $inline ) ) {
				$out['google_fonts'][] = 'Skript lädt Google Fonts';
			}
		}
		$out['trackers'] = array();
		foreach ( $trackers as $name => $blocked ) {
			$out['trackers'][] = array(
				'name'      => $name,
				'gesichert' => (bool) $blocked,
			);
		}

		// Inline-Styles mit Google Fonts.
		foreach ( $xp->query( '//style' ) as $st ) {
			$css = strtolower( substr( $st->textContent, 0, 200000 ) );
			if ( preg_match( '#fonts\.(googleapis|gstatic)\.com#', $css ) ) {
				$out['google_fonts'][] = 'Eingebettetes CSS';
			}
		}
		foreach ( $xp->query( '//link[@rel]' ) as $link ) {
			$href = strtolower( $link->getAttribute( 'href' ) );
			if ( preg_match( '/(^|\s)stylesheet(\s|$)/', strtolower( $link->getAttribute( 'rel' ) ) ) && ! self::consent_marked( $link ) ) {
				foreach ( self::third_parties() as $name => $sigs ) {
					foreach ( $sigs as $sig ) {
						if ( false !== strpos( $href, $sig ) ) {
							$third[ $name ] = true;
						}
					}
				}
			}
		}

		// Iframes: YouTube, Vimeo, Maps, Drittdienste.
		foreach ( $xp->query( '//iframe' ) as $f ) {
			$src = strtolower( trim( $f->getAttribute( 'src' ) ) );
			if ( '' === $src || 0 === strpos( $src, 'about:' ) || 0 === strpos( $src, 'data:' ) ) {
				continue;
			}
			$entry = null;
			if ( preg_match( '#youtube-nocookie\.com#', $src ) ) {
				$entry = array( 'art' => 'youtube', 'datenschutzmodus' => true );
			} elseif ( preg_match( '#(youtube\.com|youtu\.be)/#', $src ) ) {
				$entry = array( 'art' => 'youtube', 'datenschutzmodus' => false );
			} elseif ( false !== strpos( $src, 'player.vimeo.com' ) ) {
				$entry = array( 'art' => 'vimeo', 'datenschutzmodus' => (bool) preg_match( '/[?&]dnt=(1|true)/', $src ) );
			} elseif ( preg_match( '#google\.[a-z.]+/maps|maps\.google\.|/maps/embed#', $src ) ) {
				$entry = array( 'art' => 'maps', 'datenschutzmodus' => false );
			}
			if ( $entry ) {
				$entry['url']   = self::clean( $src, 200 );
				$out['embeds'][] = $entry;
			}
			foreach ( self::third_parties() as $name => $sigs ) {
				foreach ( $sigs as $sig ) {
					if ( false !== strpos( $src, $sig ) ) {
						$third[ $name ] = true;
					}
				}
			}
			if ( $https && 0 === strpos( $src, 'http://' ) ) {
				$out['mixed_content'][] = self::clean( $f->getAttribute( 'src' ), 200 );
			}
		}
		foreach ( $xp->query( '//source[@src]|//video[@src]|//audio[@src]' ) as $m ) {
			if ( $https && 0 === stripos( trim( $m->getAttribute( 'src' ) ), 'http://' ) ) {
				$out['mixed_content'][] = self::clean( $m->getAttribute( 'src' ), 200 );
			}
		}
		$out['third_parties'] = array_keys( $third );
		$out['google_fonts']  = array_values( array_unique( $out['google_fonts'] ) );
		$out['mixed_content'] = array_slice( array_values( array_unique( $out['mixed_content'] ) ), 0, 10 );

		// JSON-LD.
		$types = array();
		$nodes = array();
		foreach ( $xp->query( '//script[@type="application/ld+json"]' ) as $ld ) {
			++$out['jsonld_blocks'];
			$raw  = trim( $ld->textContent );
			$raw  = preg_replace( '#^\s*(<!--|//\s*<!\[CDATA\[|<!\[CDATA\[)|(-->|//\s*\]\]>|\]\]>)\s*$#', '', $raw );
			$data = json_decode( trim( $raw ), true );
			if ( null === $data ) {
				++$out['jsonld_invalid'];
				continue;
			}
			self::jsonld_walk( $data, $types, $nodes );
		}
		$out['jsonld_types'] = array_values( array_unique( $types ) );
		$local               = self::local_business_types();
		$best                = null;
		foreach ( $nodes as $node ) {
			$t = is_array( $node['@type'] ) ? $node['@type'] : array( $node['@type'] );
			$t = array_map(
				static function ( $x ) {
					return is_string( $x ) ? preg_replace( '#^https?://schema\.org/#', '', $x ) : '';
				},
				$t
			);
			$is_local = (bool) array_intersect( $t, $local );
			$is_org   = in_array( 'Organization', $t, true ) || in_array( 'Corporation', $t, true );
			if ( $is_local || ( $is_org && isset( $node['address'] ) ) ) {
				if ( ! $best || ( $is_local && ! $best['local'] ) ) {
					$best = array(
						'local' => $is_local,
						'node'  => $node,
						'type'  => implode( ', ', array_filter( $t ) ),
					);
				}
			}
			if ( array_intersect( $t, array( 'Review', 'AggregateRating' ) ) || isset( $node['aggregateRating'] ) || isset( $node['review'] ) ) {
				$out['has_review_schema'] = true;
			}
			if ( in_array( 'FAQPage', $t, true ) ) {
				$out['faq_schema'] = true;
			}
		}
		if ( $best ) {
			$n    = $best['node'];
			$addr = isset( $n['address'] ) ? $n['address'] : array();
			if ( isset( $addr[0] ) && is_array( $addr[0] ) ) {
				$addr = $addr[0];
			}
			$addr            = is_array( $addr ) ? $addr : array( 'streetAddress' => (string) $addr );
			$tel             = isset( $n['telephone'] ) ? $n['telephone'] : '';
			$tel             = is_array( $tel ) ? (string) reset( $tel ) : (string) $tel;
			$plz             = isset( $addr['postalCode'] ) && is_scalar( $addr['postalCode'] ) ? (string) $addr['postalCode'] : '';
			$out['business'] = array(
				'typ'         => self::clean( $best['type'], 80 ),
				'lokal'       => $best['local'],
				'name'        => isset( $n['name'] ) && is_scalar( $n['name'] ) ? self::clean( $n['name'], 120 ) : '',
				'telefon'     => self::clean( $tel, 40 ),
				'telefon_norm' => self::norm_phone( $tel ),
				'strasse'     => isset( $addr['streetAddress'] ) && is_scalar( $addr['streetAddress'] ) ? self::clean( $addr['streetAddress'], 120 ) : '',
				'plz'         => self::clean( $plz, 10 ),
				'ort'         => isset( $addr['addressLocality'] ) && is_scalar( $addr['addressLocality'] ) ? self::clean( $addr['addressLocality'], 80 ) : '',
				'oeffnungszeiten' => isset( $n['openingHours'] ) || isset( $n['openingHoursSpecification'] ),
			);
		}

		// Formulare und Beschriftungen.
		$labels_for = array();
		foreach ( $xp->query( '//label[@for]' ) as $l ) {
			$labels_for[ $l->getAttribute( 'for' ) ] = true;
		}
		$out['forms'] = $xp->query( '//form' )->length;
		foreach ( $xp->query( '//input|//textarea|//select' ) as $in ) {
			$type = strtolower( $in->getAttribute( 'type' ) );
			if ( in_array( $type, array( 'hidden', 'submit', 'button', 'image', 'reset' ), true ) ) {
				continue;
			}
			if ( 'email' === $type || preg_match( '/e-?mail/i', $in->getAttribute( 'name' ) . ' ' . $in->getAttribute( 'id' ) ) ) {
				$out['form_email'] = true;
			}
			++$out['inputs_total'];
			$id      = $in->getAttribute( 'id' );
			$labeled = ( $id && isset( $labels_for[ $id ] ) ) || $in->getAttribute( 'aria-label' ) || $in->getAttribute( 'aria-labelledby' ) || $in->getAttribute( 'title' );
			$p       = $in->parentNode;
			for ( $d = 0; ! $labeled && $p && $d < 4; $d++ ) {
				if ( 'label' === strtolower( $p->nodeName ) ) {
					$labeled = true;
				}
				$p = $p->parentNode;
			}
			if ( $labeled ) {
				++$out['inputs_labeled'];
			}
		}

		// Barrierefreiheit: Überspringen-Link, Hauptbereich.
		foreach ( $xp->query( '//a[starts-with(@href, "#")]' ) as $a ) {
			$t = strtolower( $a->textContent . ' ' . $a->getAttribute( 'class' ) );
			if ( preg_match( '/skip|springen|zum inhalt|zum hauptinhalt|direkt zum/', $t ) ) {
				$out['skip_link'] = true;
				break;
			}
		}
		$out['main_landmark'] = $xp->query( '//main|//*[@role="main"]' )->length > 0;

		// Aktualität: Jahreszahl im Copyright, neueste Datumsangabe.
		if ( preg_match_all( '/(?:©|&copy;|\(c\)|copyright)[^0-9]{0,40}((?:19|20)\d{2})(?:\s*[\-–—]\s*((?:19|20)\d{2}))?/iu', $text, $m ) ) {
			foreach ( $m[1] as $k => $y ) {
				$year = max( (int) $y, (int) $m[2][ $k ] );
				if ( $year <= (int) gmdate( 'Y' ) + 1 ) {
					$out['copyright_year'] = max( $out['copyright_year'], $year );
				}
			}
		}
		foreach ( $xp->query( '//time[@datetime]' ) as $tm ) {
			$d = substr( $tm->getAttribute( 'datetime' ), 0, 10 );
			if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d ) && $d > $out['newest_date'] && $d <= gmdate( 'Y-m-d', time() + DAY_IN_SECONDS ) ) {
				$out['newest_date'] = $d;
			}
		}

		// Inhaltliche Signale im Text.
		$lt = mb_strtolower( $text );
		if ( preg_match( '/über uns|unser team|das team|inhaber|inhaberin|geschäftsführer|wer wir sind|familienbetrieb|meisterbetrieb|ihr ansprechpartner|ihre ansprechpartnerin/u', $lt ) ) {
			$out['about_signal'] = true;
		}
		foreach ( $out['headings'] as $h ) {
			if ( preg_match( '/über uns|team|wer wir sind|inhaber/iu', $h[1] ) ) {
				$out['about_signal'] = true;
			}
			if ( preg_match( '/bewertung|kundenstimme|referenz|projekte|rezension|erfahrung|das sagen/iu', $h[1] ) ) {
				$out['review_signal'] = true;
			}
		}
		if ( preg_match( '/kundenstimmen|bewertungen|rezensionen|referenzen|★|⭐|sterne bei google|google-bewertung/u', $lt ) ) {
			$out['review_signal'] = true;
		}
		if ( preg_match( '/öffnungszeit|geöffnet|sprechzeit|sprechstunde|(mo|di|mi|do|fr|sa|montag|dienstag|freitag)\.?\s*(-|–|bis)\s*(mo|di|mi|do|fr|sa|so|freitag|samstag|sonntag)|\d{1,2}[:.]\d{2}\s*(-|–|bis)\s*\d{1,2}[:.]\d{2}\s*uhr|\d{1,2}\s*(-|–|bis)\s*\d{1,2}\s*uhr/u', $lt ) ) {
			$out['hours_signal'] = true;
		}
		if ( preg_match( '/umgebung|umland|region|landkreis|kreis [a-zäöü]|umkreis|einzugsgebiet|im raum|ganz owl|ostwestfalen|und umgebung|in der nähe|nachbarorte|bundesweit|deutschlandweit/u', $lt ) ) {
			$out['area_signal'] = true;
		}

		// Speicher sparen.
		$out['headings'] = array_slice( $out['headings'], 0, 60 );
		return $out;
	}

	/**
	 * Nebenseite (Impressum, Kontakt) leicht analysieren.
	 *
	 * @param string $html         HTML.
	 * @param string $base_url     URL.
	 * @param string $content_type Content-Type.
	 * @return array
	 */
	public static function parse_sub( $html, $base_url, $content_type = '' ) {
		$dom = self::load( $html, $content_type );
		$out = array(
			'ok'         => (bool) $dom,
			'title'      => '',
			'text'       => '',
			'word_count' => 0,
			'tel_links'  => array(),
			'phones'     => array(),
			'addresses'  => array(),
			'emails'     => false,
			'form_email' => false,
			'forms'      => 0,
		);
		if ( ! $dom ) {
			return $out;
		}
		$xp    = new DOMXPath( $dom );
		$title = $xp->query( '//title' )->item( 0 );
		if ( $title ) {
			$out['title'] = self::clean( $title->textContent, 200 );
		}
		$body  = $xp->query( '//body' )->item( 0 );
		$state = array(
			'text'         => '',
			'link_offsets' => array(),
			'buttons'      => array(),
		);
		if ( $body ) {
			self::walk( $body, $state );
		}
		$text              = self::clean( $state['text'], 60000 );
		$out['word_count'] = count( self::words( $text ) );
		$out['text']       = self::clean( $text, 6000 );
		foreach ( $xp->query( '//a[@href]' ) as $a ) {
			$href = strtolower( trim( $a->getAttribute( 'href' ) ) );
			if ( 0 === strpos( $href, 'tel:' ) ) {
				$out['tel_links'][] = self::norm_phone( rawurldecode( substr( $href, 4 ) ) );
			}
			if ( 0 === strpos( $href, 'mailto:' ) ) {
				$out['emails'] = true;
			}
		}
		if ( preg_match( '/[a-z0-9._%+\-]+(?:@|\s?\[at\]\s?|\s?\(at\)\s?)[a-z0-9.\-]+(?:\.|\s?\[dot\]\s?)[a-z]{2,}/i', $text ) ) {
			$out['emails'] = true;
		}
		$out['phones']    = self::find_phones( $text );
		$out['addresses'] = self::find_addresses( $text );
		$out['forms']     = $xp->query( '//form' )->length;
		foreach ( $xp->query( '//input' ) as $in ) {
			if ( 'email' === strtolower( $in->getAttribute( 'type' ) ) || preg_match( '/e-?mail/i', $in->getAttribute( 'name' ) ) ) {
				$out['form_email'] = true;
			}
		}
		$out['tel_links'] = array_values( array_unique( array_filter( $out['tel_links'] ) ) );
		return $out;
	}

	/**
	 * robots.txt auswerten.
	 *
	 * @param string $txt Inhalt.
	 * @return array Gruppen (Agent => Regeln) und Sitemaps.
	 */
	public static function parse_robots( $txt ) {
		$groups   = array();
		$sitemaps = array();
		$current  = array();
		$in_rules = false;
		foreach ( preg_split( '/\r\n|\r|\n/', substr( (string) $txt, 0, 100000 ) ) as $line ) {
			$line = trim( preg_replace( '/#.*$/', '', $line ) );
			if ( '' === $line || false === strpos( $line, ':' ) ) {
				continue;
			}
			list( $key, $val ) = array_map( 'trim', explode( ':', $line, 2 ) );
			$key               = strtolower( $key );
			if ( 'user-agent' === $key ) {
				if ( $in_rules ) {
					$current  = array();
					$in_rules = false;
				}
				$current[] = strtolower( $val );
				foreach ( $current as $agent ) {
					if ( ! isset( $groups[ $agent ] ) ) {
						$groups[ $agent ] = array();
					}
				}
			} elseif ( 'allow' === $key || 'disallow' === $key ) {
				$in_rules = true;
				foreach ( $current as $agent ) {
					$groups[ $agent ][] = array( $key, $val );
				}
			} elseif ( 'sitemap' === $key && count( $sitemaps ) < 10 ) {
				$sitemaps[] = $val;
			}
		}
		return array(
			'groups'   => $groups,
			'sitemaps' => $sitemaps,
		);
	}

	/**
	 * Sperrt robots.txt die Startseite für einen Agenten?
	 *
	 * @param array  $robots Ergebnis von parse_robots.
	 * @param string $agent  Agent (Kleinbuchstaben).
	 * @param bool   $exact  Nur eigene Gruppe, nicht auf * zurückfallen.
	 * @return bool
	 */
	public static function robots_blocks_root( $robots, $agent, $exact = false ) {
		$groups = isset( $robots['groups'] ) ? $robots['groups'] : array();
		$rules  = null;
		if ( isset( $groups[ $agent ] ) ) {
			$rules = $groups[ $agent ];
		} elseif ( ! $exact && isset( $groups['*'] ) ) {
			$rules = $groups['*'];
		}
		if ( null === $rules ) {
			return false;
		}
		$blocked = false;
		$len_dis = -1;
		$len_all = -1;
		foreach ( $rules as $r ) {
			$path = $r[1];
			if ( 'disallow' === $r[0] && ( '/' === $path || '/*' === $path ) ) {
				$len_dis = max( $len_dis, strlen( $path ) );
			}
			if ( 'allow' === $r[0] && ( '/' === $path || '/*' === $path || '/$' === $path ) ) {
				$len_all = max( $len_all, strlen( $path ) );
			}
		}
		if ( $len_dis >= 0 && $len_all < $len_dis ) {
			$blocked = true;
		}
		return $blocked;
	}
}
