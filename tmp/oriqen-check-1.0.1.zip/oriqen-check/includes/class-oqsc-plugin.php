<?php
/**
 * Zentrale: Hooks, Shortcode, Assets, Rechte, Einstellungen.
 *
 * @package oriqen-check
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Plugin-Hauptklasse.
 */
class OQSC_Plugin {

	/**
	 * Einzige Instanz.
	 *
	 * @var OQSC_Plugin|null
	 */
	private static $instance = null;

	/**
	 * Zwischenspeicher der Einstellungen.
	 *
	 * @var array|null
	 */
	private static $settings = null;

	/**
	 * Wurde das Frontend auf dieser Seite schon eingebunden?
	 *
	 * @var bool
	 */
	private $assets_loaded = false;

	/**
	 * Branchen der Auswahl (Schlüssel => Bezeichnung).
	 *
	 * @return array
	 */
	public static function branchen() {
		return array(
			'handwerk'       => 'Handwerk',
			'kueche'         => 'Küche und Einrichtung',
			'bau'            => 'Bau und Ausbau',
			'gesundheit'     => 'Gesundheit und Praxis',
			'gastronomie'    => 'Gastronomie',
			'handel'         => 'Handel',
			'dienstleistung' => 'Dienstleistung',
			'sonstiges'      => 'Sonstiges',
		);
	}

	/**
	 * Instanz holen.
	 *
	 * @return OQSC_Plugin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Hooks registrieren.
	 */
	public function init() {
		OQSC_Install::maybe_upgrade();

		add_shortcode( 'oriqen_check', array( $this, 'shortcode' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'maybe_enqueue_for_page' ), 20 );
		add_action( 'rest_api_init', array( 'OQSC_Rest', 'register' ) );
		add_action( 'rest_api_init', array( 'OQSC_Admin_Rest', 'register' ) );
		add_filter( 'rest_post_dispatch', array( $this, 'rest_no_store' ), 10, 3 );
		add_filter( 'wp_robots', array( $this, 'robots_for_result' ) );
		add_action( 'template_redirect', array( $this, 'no_cache_for_result' ), 1 );
		add_action( OQSC_Cron::HOOK, array( 'OQSC_Cron', 'run' ) );
		add_filter( 'script_loader_tag', array( $this, 'script_tag' ), 10, 2 );

		if ( is_admin() ) {
			OQSC_Admin::instance()->init();
		}
	}

	/**
	 * Alle Einstellungen mit Standardwerten.
	 *
	 * @return array
	 */
	public static function settings() {
		if ( null === self::$settings ) {
			$stored = get_option( 'oqsc_settings', array() );
			if ( ! is_array( $stored ) ) {
				$stored = array();
			}
			self::$settings = array_merge( OQSC_Install::defaults(), $stored );
		}
		return self::$settings;
	}

	/**
	 * Eine Einstellung.
	 *
	 * @param string $key     Schlüssel.
	 * @param mixed  $fallback Ersatzwert.
	 * @return mixed
	 */
	public static function get( $key, $fallback = null ) {
		$s = self::settings();
		return array_key_exists( $key, $s ) ? $s[ $key ] : $fallback;
	}

	/**
	 * Einstellungen speichern (bereinigt).
	 *
	 * @param array $new Neue Werte (Teilmenge).
	 * @return array Gespeicherte Werte.
	 */
	public static function save_settings( array $new ) {
		$current = self::settings();
		$clean   = self::sanitize_settings( $new, $current );
		update_option( 'oqsc_settings', $clean, false );
		self::$settings = null;
		return self::settings();
	}

	/**
	 * Einstellungen bereinigen. Unbekannte Schlüssel werden verworfen.
	 *
	 * @param array $input   Eingabe.
	 * @param array $current Aktuelle Werte.
	 * @return array
	 */
	public static function sanitize_settings( array $input, array $current ) {
		$defaults = OQSC_Install::defaults();
		$out      = $current;

		$ints = array(
			'max_parallel'          => array( 1, 10 ),
			'limit_stunde'          => array( 1, 100 ),
			'limit_tag'             => array( 1, 500 ),
			'limit_global_tag'      => array( 1, 5000 ),
			'cache_stunden'         => array( 1, 168 ),
			'recheck_minuten'       => array( 5, 1440 ),
			'pow_bits'              => array( 8, 22 ),
			'mindestzeit'           => array( 0, 30 ),
			'notaus_langsam_anzahl' => array( 1, 100 ),
			'notaus_langsam_sek'    => array( 5, 60 ),
			'notaus_fehlerquote'    => array( 10, 100 ),
			'notaus_pause_min'      => array( 1, 240 ),
			'ergebnis_tage'         => array( 1, 365 ),
			'aufbewahrung_checks'   => array( 1, 730 ),
			'aufbewahrung_leads'    => array( 1, 60 ),
		);
		foreach ( $ints as $key => $range ) {
			if ( isset( $input[ $key ] ) ) {
				$out[ $key ] = max( $range[0], min( $range[1], (int) $input[ $key ] ) );
			}
		}

		foreach ( array( 'wartung', 'testmodus', 'psi_aktiv', 'daten_loeschen' ) as $key ) {
			if ( array_key_exists( $key, $input ) ) {
				$out[ $key ] = empty( $input[ $key ] ) ? 0 : 1;
			}
		}

		// API-Schlüssel: leer lassen heißt behalten, "-" löscht.
		if ( isset( $input['psi_key'] ) ) {
			$key = trim( (string) $input['psi_key'] );
			if ( '-' === $key ) {
				$out['psi_key'] = '';
			} elseif ( '' !== $key && false === strpos( $key, '•' ) ) {
				$out['psi_key'] = preg_replace( '/[^A-Za-z0-9_\-]/', '', $key );
			}
		}

		if ( isset( $input['empfaenger'] ) ) {
			$mail              = sanitize_email( $input['empfaenger'] );
			$out['empfaenger'] = $mail ? $mail : $current['empfaenger'];
		}

		foreach ( array( 'analyse_url', 'leistung_basis', 'check_seite_url', 'datenschutz_url' ) as $key ) {
			if ( isset( $input[ $key ] ) ) {
				$out[ $key ] = esc_url_raw( trim( (string) $input[ $key ] ), array( 'http', 'https' ) );
			}
		}
		if ( '' === $out['leistung_basis'] ) {
			$out['leistung_basis'] = $defaults['leistung_basis'];
		}

		foreach ( array( 'ueberschrift' ) as $key ) {
			if ( isset( $input[ $key ] ) ) {
				$out[ $key ] = mb_substr( sanitize_text_field( $input[ $key ] ), 0, 200 );
			}
		}
		foreach ( array( 'einleitung', 'abschluss', 'einwilligung_text' ) as $key ) {
			if ( isset( $input[ $key ] ) ) {
				$out[ $key ] = mb_substr( sanitize_textarea_field( $input[ $key ] ), 0, 1500 );
			}
		}

		if ( isset( $input['sperrliste'] ) ) {
			$lines = preg_split( '/[\r\n,]+/', strtolower( (string) $input['sperrliste'] ) );
			$hosts = array();
			foreach ( $lines as $line ) {
				$line = trim( preg_replace( '#^https?://#', '', trim( $line ) ), "/ \t" );
				$line = preg_replace( '/[^a-z0-9.\-*]/', '', $line );
				if ( '' !== $line ) {
					$hosts[] = $line;
				}
			}
			$out['sperrliste'] = implode( "\n", array_unique( array_slice( $hosts, 0, 500 ) ) );
		}

		if ( isset( $input['seiten_ids'] ) ) {
			$ids               = array_filter( array_map( 'absint', preg_split( '/[\s,]+/', (string) $input['seiten_ids'] ) ) );
			$out['seiten_ids'] = implode( ',', array_unique( $ids ) );
		}

		return array_intersect_key( $out, $defaults );
	}

	/**
	 * Aktuelle Zeit im MySQL-Format (UTC).
	 *
	 * @param int $offset Sekunden Versatz.
	 * @return string
	 */
	public static function now( $offset = 0 ) {
		return gmdate( 'Y-m-d H:i:s', time() + (int) $offset );
	}

	/**
	 * Zahl im deutschen Format.
	 *
	 * @param float $value Wert.
	 * @param int   $dec   Nachkommastellen.
	 * @return string
	 */
	public static function num( $value, $dec = 0 ) {
		return number_format( (float) $value, $dec, ',', '.' );
	}

	/**
	 * Ist der Testmodus für lokale Ziele aktiv? Nur per Konstante in einer Testinstanz.
	 *
	 * @return bool
	 */
	public static function test_local_allowed() {
		return defined( 'OQSC_TEST_ALLOW_LOCAL' ) && OQSC_TEST_ALLOW_LOCAL;
	}

	/**
	 * Skripte und Styles registrieren (nur geladen, wenn gebraucht).
	 */
	public function register_assets() {
		wp_register_style( 'oqsc-app', OQSC_URL . 'assets/app.css', array(), OQSC_VERSION );
		wp_register_style( 'oqsc-print', OQSC_URL . 'assets/print.css', array( 'oqsc-app' ), OQSC_VERSION, 'print' );
		wp_register_script( 'oqsc-app', OQSC_URL . 'assets/app.js', array(), OQSC_VERSION, true );
	}

	/**
	 * Einbindung ohne Shortcode für ausgewählte Seiten (HTML-Block mit div.oqsc-app).
	 */
	public function maybe_enqueue_for_page() {
		$ids = array_filter( array_map( 'absint', explode( ',', (string) self::get( 'seiten_ids', '' ) ) ) );
		if ( $ids && is_singular() && in_array( (int) get_queried_object_id(), $ids, true ) ) {
			$this->enqueue();
			add_action( 'wp_footer', array( $this, 'print_config' ), 5 );
		}
	}

	/**
	 * Assets einreihen.
	 */
	public function enqueue() {
		if ( ! wp_script_is( 'oqsc-app', 'registered' ) ) {
			$this->register_assets();
		}
		wp_enqueue_style( 'oqsc-app' );
		wp_enqueue_style( 'oqsc-print' );
		wp_enqueue_script( 'oqsc-app' );
		$this->assets_loaded = true;
	}

	/**
	 * Skript-Tag kennzeichnen, damit Optimierer es erkennen können.
	 *
	 * @param string $tag    HTML.
	 * @param string $handle Handle.
	 * @return string
	 */
	public function script_tag( $tag, $handle ) {
		if ( 'oqsc-app' === $handle && false === strpos( $tag, 'data-no-optimize' ) ) {
			$tag = str_replace( '<script ', '<script data-no-optimize="1" data-no-defer="1" ', $tag );
		}
		return $tag;
	}

	/**
	 * Konfiguration für das Frontend.
	 *
	 * @param string $variante voll|kompakt.
	 * @param string $ziel     Ziel-URL für kompakt.
	 * @return array
	 */
	public function frontend_config( $variante = 'voll', $ziel = '' ) {
		$s = self::settings();
		return array(
			'rest'         => esc_url_raw( rest_url( 'oriqen-check/v1/' ) ),
			'variante'     => $variante,
			'ziel'         => $ziel,
			'ueberschrift' => $s['ueberschrift'],
			'einleitung'   => $s['einleitung'],
			'abschluss'    => $s['abschluss'],
			'analyseUrl'   => $s['analyse_url'],
			'datenschutz'  => $s['datenschutz_url'] ? $s['datenschutz_url'] : get_privacy_policy_url(),
			'einwilligung' => $s['einwilligung_text'],
			'branchen'     => self::branchen(),
			'logo'         => OQSC_URL . 'assets/brand/oriqen-logo-schwarz.webp',
			'logoHell'     => OQSC_URL . 'assets/brand/oriqen-logo-weiss.webp',
			'kontakt'      => 'oriqen · Digitalstudio aus Paderborn · oriqen.de',
			// Nonce nur für angemeldete Verwalter (Testmodus), solche Seiten landen nicht im Seiten-Cache.
			'nonce'        => is_user_logged_in() && current_user_can( 'oqsc_manage' ) ? wp_create_nonce( 'wp_rest' ) : '',
		);
	}

	/**
	 * Konfiguration als JSON in den Footer (für die Einbindung per HTML-Block).
	 */
	public function print_config() {
		echo '<script type="application/json" id="oqsc-config">' . wp_json_encode( $this->frontend_config(), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ) . '</script>' . "\n";
	}

	/**
	 * Shortcode [oriqen_check variante="voll|kompakt" ziel="/website-check/"].
	 *
	 * @param array $atts Attribute.
	 * @return string
	 */
	public function shortcode( $atts ) {
		$atts     = shortcode_atts(
			array(
				'variante' => 'voll',
				'ziel'     => '',
			),
			$atts,
			'oriqen_check'
		);
		$variante = 'kompakt' === $atts['variante'] ? 'kompakt' : 'voll';
		$ziel     = '';
		if ( 'kompakt' === $variante ) {
			$ziel = $atts['ziel'] ? $atts['ziel'] : self::get( 'check_seite_url', '' );
			$ziel = $ziel ? esc_url_raw( 0 === strpos( $ziel, '/' ) ? home_url( $ziel ) : $ziel ) : '';
		}
		$this->enqueue();
		$config = $this->frontend_config( $variante, $ziel );

		$out  = '<div class="oqsc-app oqsc-variante-' . esc_attr( $variante ) . '" data-variante="' . esc_attr( $variante ) . '" data-oqsc-config="' . esc_attr( wp_json_encode( $config ) ) . '">';
		$out .= '<noscript><p class="oqsc-noscript">Der oriqen Sichtbarkeits-Check braucht JavaScript. Bitte aktivieren Sie JavaScript oder fordern Sie direkt eine <a href="' . esc_url( $config['analyseUrl'] ) . '">persönliche Analyse</a> an.</p></noscript>';
		$out .= '</div>';
		return $out;
	}

	/**
	 * REST-Antworten des Plugins nie zwischenspeichern.
	 *
	 * @param WP_HTTP_Response $result  Antwort.
	 * @param WP_REST_Server   $server  Server.
	 * @param WP_REST_Request  $request Anfrage.
	 * @return WP_HTTP_Response
	 */
	public function rest_no_store( $result, $server, $request ) {
		if ( 0 === strpos( $request->get_route(), '/oriqen-check/v1' ) && $result instanceof WP_HTTP_Response ) {
			$result->header( 'Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0' );
			$result->header( 'Pragma', 'no-cache' );
			$result->header( 'X-Robots-Tag', 'noindex, nofollow' );
		}
		return $result;
	}

	/**
	 * Ergebnis-Aufrufe (?oqcheck=) nicht indexieren.
	 *
	 * @param array $robots Robots-Direktiven.
	 * @return array
	 */
	public function robots_for_result( $robots ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- nur lesender Abgleich, kein Formular.
		if ( isset( $_GET['oqcheck'] ) ) {
			$robots['noindex']  = true;
			$robots['nofollow'] = true;
			unset( $robots['max-image-preview'] );
		}
		return $robots;
	}

	/**
	 * Ergebnis-Aufrufe nie im Seiten-Cache ablegen.
	 */
	public function no_cache_for_result() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- nur lesender Abgleich, kein Formular.
		if ( isset( $_GET['oqcheck'] ) ) {
			if ( ! defined( 'DONOTCACHEPAGE' ) ) {
				define( 'DONOTCACHEPAGE', true );
			}
			nocache_headers();
			header( 'X-Robots-Tag: noindex, nofollow' );
		}
	}
}
