<?php
/**
 * PageSpeed Insights API v5 (serverseitig, mobile Messung, Bildschirmfoto).
 *
 * @package oriqen-check
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PageSpeed-Abfrage und Auswertung.
 */
class OQSC_Psi {

	const ENDPOINT = 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed';
	const TIMEOUT  = 40;

	/**
	 * Adresse der Abfrage (Schlüssel nur serverseitig).
	 *
	 * @param string $url Geprüfte URL.
	 * @return string
	 */
	public static function request_url( $url ) {
		$query = 'url=' . rawurlencode( $url ) . '&strategy=mobile&locale=de';
		foreach ( array( 'performance', 'accessibility', 'best-practices', 'seo' ) as $cat ) {
			$query .= '&category=' . $cat;
		}
		$key = (string) OQSC_Plugin::get( 'psi_key', '' );
		if ( '' !== $key ) {
			$query .= '&key=' . rawurlencode( $key );
		}
		return self::ENDPOINT . '?' . $query;
	}

	/**
	 * Messung durchführen.
	 *
	 * @param string $url Geprüfte URL.
	 * @return array ok, grund, performance, accessibility, best_practices, seo, lcp, cls, tbt, fcp, si, bytes, screenshot.
	 */
	public static function run( $url ) {
		$start    = microtime( true );
		$response = wp_remote_get(
			self::request_url( $url ),
			array(
				'timeout'             => self::TIMEOUT,
				'redirection'         => 0,
				'limit_response_size' => 15 * 1048576,
				'user-agent'          => OQSC_Fetcher::user_agent(),
				'headers'             => array( 'Accept' => 'application/json' ),
			)
		);
		$elapsed = round( microtime( true ) - $start, 1 );
		if ( is_wp_error( $response ) ) {
			$timeout = (bool) preg_match( '/timed out|timeout/i', $response->get_error_message() );
			return array(
				'ok'    => false,
				'grund' => $timeout ? 'zeit' : 'fehler',
				'dauer' => $elapsed,
			);
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		if ( 429 === $code || ( 403 === $code && is_array( $body ) && false !== stripos( wp_json_encode( $body ), 'quota' ) ) ) {
			return array(
				'ok'    => false,
				'grund' => 'kontingent',
				'dauer' => $elapsed,
			);
		}
		if ( 200 !== $code || ! is_array( $body ) || empty( $body['lighthouseResult'] ) ) {
			return array(
				'ok'    => false,
				'grund' => 'fehler',
				'code'  => $code,
				'dauer' => $elapsed,
			);
		}
		$out          = self::parse( $body['lighthouseResult'] );
		$out['dauer'] = $elapsed;
		return $out;
	}

	/**
	 * Lighthouse-Ergebnis auswerten.
	 *
	 * @param array $lh lighthouseResult.
	 * @return array
	 */
	public static function parse( $lh ) {
		$cat   = isset( $lh['categories'] ) ? $lh['categories'] : array();
		$aud   = isset( $lh['audits'] ) ? $lh['audits'] : array();
		$score = static function ( $key ) use ( $cat ) {
			return isset( $cat[ $key ]['score'] ) && is_numeric( $cat[ $key ]['score'] ) ? (int) round( 100 * $cat[ $key ]['score'] ) : null;
		};
		$num   = static function ( $key ) use ( $aud ) {
			return isset( $aud[ $key ]['numericValue'] ) && is_numeric( $aud[ $key ]['numericValue'] ) ? (float) $aud[ $key ]['numericValue'] : null;
		};
		$out = array(
			'ok'             => null !== $score( 'performance' ),
			'grund'          => '',
			'performance'    => $score( 'performance' ),
			'accessibility'  => $score( 'accessibility' ),
			'best_practices' => $score( 'best-practices' ),
			'seo'            => $score( 'seo' ),
			'lcp'            => $num( 'largest-contentful-paint' ),
			'cls'            => $num( 'cumulative-layout-shift' ),
			'tbt'            => $num( 'total-blocking-time' ),
			'fcp'            => $num( 'first-contentful-paint' ),
			'si'             => $num( 'speed-index' ),
			'bytes'          => $num( 'total-byte-weight' ),
			'screenshot'     => '',
		);
		if ( ! $out['ok'] ) {
			$out['grund'] = 'fehler';
		}
		if ( isset( $aud['final-screenshot']['details']['data'] ) ) {
			$out['screenshot'] = self::shrink_screenshot( (string) $aud['final-screenshot']['details']['data'] );
		}
		return $out;
	}

	/**
	 * Bildschirmfoto auf höchstens 400 px Breite verkleinern, als WebP (sonst JPEG) speichern.
	 *
	 * @param string $data_uri data:image/...;base64,...
	 * @return string data-URI oder leer.
	 */
	public static function shrink_screenshot( $data_uri ) {
		if ( ! preg_match( '#^data:image/(jpeg|png|webp);base64,([A-Za-z0-9+/=\s]+)$#', $data_uri, $m ) ) {
			return '';
		}
		$bin = base64_decode( $m[2], true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Bilddaten von Google.
		if ( false === $bin || strlen( $bin ) > 5 * 1048576 ) {
			return '';
		}
		// Nur echte Bilddaten akzeptieren.
		$info = function_exists( 'getimagesizefromstring' ) ? @getimagesizefromstring( $bin ) : false; // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- ungültige Daten werden verworfen.
		if ( ! $info || $info[0] < 10 || $info[1] < 10 || $info[0] > 4000 || $info[1] > 8000 ) {
			return '';
		}
		$tmp = trailingslashit( get_temp_dir() ) . 'oqsc-shot-' . wp_generate_password( 12, false, false );
		file_put_contents( $tmp, $bin ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- temporäre Datei.
		$editor = wp_get_image_editor( $tmp );
		$result = '';
		if ( ! is_wp_error( $editor ) ) {
			$size = $editor->get_size();
			if ( $size['width'] > 400 ) {
				$editor->resize( 400, null, false );
			}
			$webp = wp_image_editor_supports( array( 'mime_type' => 'image/webp' ) );
			$mime = $webp ? 'image/webp' : 'image/jpeg';
			$editor->set_quality( $webp ? 62 : 65 );
			$saved = $editor->save( $tmp . ( $webp ? '.webp' : '.jpg' ), $mime );
			if ( ! is_wp_error( $saved ) && ! empty( $saved['path'] ) && is_readable( $saved['path'] ) ) {
				$result = 'data:' . $mime . ';base64,' . base64_encode( file_get_contents( $saved['path'] ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode,WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- eigene temporäre Datei.
				wp_delete_file( $saved['path'] );
			}
		}
		wp_delete_file( $tmp );
		return $result;
	}
}
