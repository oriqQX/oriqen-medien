<?php
/**
 * Öffentliche REST-Routen unter oriqen-check/v1.
 *
 * @package oriqen-check
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Öffentliche Routen. Alle Antworten mit Cache-Control: no-store (siehe OQSC_Plugin::rest_no_store).
 */
class OQSC_Rest {

	const NS = 'oriqen-check/v1';

	/**
	 * Routen registrieren.
	 */
	public static function register() {
		register_rest_route(
			self::NS,
			'/token',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'token' ),
				'permission_callback' => '__return_true',
			)
		);
		register_rest_route(
			self::NS,
			'/start',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'start' ),
				'permission_callback' => '__return_true',
				'args'                => self::guard_args(
					array(
						'url'     => array(
							'type'     => 'string',
							'required' => true,
						),
						'ort'     => array(
							'type'    => 'string',
							'default' => '',
						),
						'branche' => array(
							'type'    => 'string',
							'default' => '',
						),
					)
				),
			)
		);
		register_rest_route(
			self::NS,
			'/step',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'step' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'job' => array(
						'type'     => 'string',
						'required' => true,
					),
				),
			)
		);
		register_rest_route(
			self::NS,
			'/result/(?P<token>[a-f0-9]{32})',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'result' ),
				'permission_callback' => '__return_true',
			)
		);
		register_rest_route(
			self::NS,
			'/lead',
			array(
				'methods'             => 'POST',
				'callback'            => array( 'OQSC_Leads', 'rest_create' ),
				'permission_callback' => '__return_true',
				'args'                => self::guard_args(
					array(
						'check'        => array(
							'type'     => 'string',
							'required' => true,
						),
						'name'         => array(
							'type'     => 'string',
							'required' => true,
						),
						'email'        => array(
							'type'     => 'string',
							'required' => true,
						),
						'telefon'      => array(
							'type'    => 'string',
							'default' => '',
						),
						'nachricht'    => array(
							'type'    => 'string',
							'default' => '',
						),
						'einwilligung' => array(
							'type'    => 'boolean',
							'default' => false,
						),
					)
				),
			)
		);
		register_rest_route(
			self::NS,
			'/recheck',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'recheck' ),
				'permission_callback' => '__return_true',
				'args'                => self::guard_args(
					array(
						'check' => array(
							'type'     => 'string',
							'required' => true,
						),
					)
				),
			)
		);
	}

	/**
	 * Gemeinsame Argumente für geschützte Routen.
	 *
	 * @param array $args Weitere Argumente.
	 * @return array
	 */
	private static function guard_args( $args ) {
		return array_merge(
			array(
				'token'   => array(
					'type'     => 'string',
					'required' => true,
				),
				'pow'     => array(
					'type'     => 'string',
					'required' => true,
				),
				'website' => array(
					'type'    => 'string',
					'default' => '',
				),
			),
			$args
		);
	}

	/**
	 * Fehler als REST-Antwort.
	 *
	 * @param WP_Error $e Fehler.
	 * @return WP_REST_Response
	 */
	private static function error( WP_Error $e ) {
		$data   = $e->get_error_data();
		$status = is_array( $data ) && isset( $data['status'] ) ? (int) $data['status'] : 400;
		return new WP_REST_Response(
			array(
				'fehler'  => true,
				'code'    => $e->get_error_code(),
				'meldung' => $e->get_error_message(),
			),
			$status
		);
	}

	/**
	 * GET /token.
	 *
	 * @return WP_REST_Response
	 */
	public static function token() {
		$avail = OQSC_Guard::available();
		$out   = OQSC_Guard::issue_token();
		$out['verfuegbar'] = ! is_wp_error( $avail );
		if ( is_wp_error( $avail ) ) {
			$out['meldung'] = $avail->get_error_message();
		}
		return new WP_REST_Response( $out, 200 );
	}

	/**
	 * Ort bereinigen.
	 *
	 * @param string $ort Eingabe.
	 * @return string
	 */
	public static function clean_ort( $ort ) {
		$ort = sanitize_text_field( (string) $ort );
		$ort = preg_replace( '/[^\p{L}\p{N} .\-()\/]/u', '', $ort );
		return trim( mb_substr( $ort, 0, 60 ) );
	}

	/**
	 * Branche nur aus der Liste.
	 *
	 * @param string $branche Eingabe.
	 * @return string
	 */
	public static function clean_branche( $branche ) {
		$branche = sanitize_key( (string) $branche );
		return array_key_exists( $branche, OQSC_Plugin::branchen() ) ? $branche : '';
	}

	/**
	 * POST /start.
	 *
	 * @param WP_REST_Request $req Anfrage.
	 * @return WP_REST_Response
	 */
	public static function start( WP_REST_Request $req ) {
		$avail = OQSC_Guard::available();
		if ( is_wp_error( $avail ) ) {
			return self::error( $avail );
		}
		$ok = OQSC_Guard::verify( $req['token'], $req['pow'], $req['website'] );
		if ( is_wp_error( $ok ) ) {
			return self::error( $ok );
		}
		$url = OQSC_Fetcher::normalize_input( $req['url'] );
		if ( is_wp_error( $url ) ) {
			if ( in_array( $url->get_error_code(), array( 'oqsc_intern', 'oqsc_gesperrt' ), true ) ) {
				OQSC_Guard::event( 'gesperrt', '', $url->get_error_code() );
			}
			return self::error( $url );
		}
		$ort     = self::clean_ort( $req['ort'] );
		$branche = self::clean_branche( $req['branche'] );

		// Zwischenspeicher: gleiche Domain in den letzten 24 Stunden.
		$cached = OQSC_Job::find_cached( $url );
		if ( $cached ) {
			if ( $cached['ort'] === $ort && $cached['branche'] === $branche ) {
				return new WP_REST_Response(
					array(
						'job'       => $cached['token'],
						'fertig'    => true,
						'gespeichert' => true,
					),
					200
				);
			}
			$copy = OQSC_Job::copy_from_cache( $cached, $ort, $branche );
			return new WP_REST_Response(
				array(
					'job'         => $copy['token'],
					'fertig'      => true,
					'gespeichert' => true,
				),
				200
			);
		}

		$limits = OQSC_Guard::check_limits();
		if ( is_wp_error( $limits ) ) {
			return self::error( $limits );
		}
		return self::create_job( $url, $ort, $branche, 'neu' );
	}

	/**
	 * Job anlegen und gleich einreihen.
	 *
	 * @param string $url     URL.
	 * @param string $ort     Ort.
	 * @param string $branche Branche.
	 * @param string $quelle  Quelle.
	 * @return WP_REST_Response
	 */
	private static function create_job( $url, $ort, $branche, $quelle ) {
		$row                    = OQSC_Job::create( $url, $ort, $branche, $quelle, 'wartet' );
		list( $row, $position ) = OQSC_Job::try_promote( $row );
		$out                    = array(
			'job'      => $row['token'],
			'schritte' => OQSC_Job::step_titles(),
			'domain'   => $row['domain'],
		);
		if ( 'wartet' === $row['status'] ) {
			$out['warten']   = 10;
			$out['position'] = $position;
		}
		return new WP_REST_Response( $out, 200 );
	}

	/**
	 * POST /step.
	 *
	 * @param WP_REST_Request $req Anfrage.
	 * @return WP_REST_Response
	 */
	public static function step( WP_REST_Request $req ) {
		$row = OQSC_Job::get( $req['job'] );
		if ( ! $row ) {
			return self::error( new WP_Error( 'oqsc_job', 'Diesen Check gibt es nicht mehr. Bitte starten Sie neu.', array( 'status' => 404 ) ) );
		}
		if ( in_array( $row['status'], array( 'wartet', 'laeuft' ), true ) ) {
			$avail = OQSC_Guard::available();
			if ( is_wp_error( $avail ) ) {
				return self::error( $avail );
			}
		}
		$answer = OQSC_Job::run_next( $row );
		$status = ! empty( $answer['fehler'] ) && empty( $answer['schritt'] ) ? 409 : 200;
		return new WP_REST_Response( $answer, $status );
	}

	/**
	 * GET /result/{token}.
	 *
	 * @param WP_REST_Request $req Anfrage.
	 * @return WP_REST_Response
	 */
	public static function result( WP_REST_Request $req ) {
		$row = OQSC_Job::get( $req['token'] );
		if ( ! $row ) {
			return self::error( new WP_Error( 'oqsc_result', 'Dieses Ergebnis gibt es nicht oder nicht mehr.', array( 'status' => 404 ) ) );
		}
		if ( strtotime( $row['expires_at'] . ' UTC' ) < time() ) {
			return self::error( new WP_Error( 'oqsc_result', 'Dieses Ergebnis ist abgelaufen. Ergebnisse sind 30 Tage abrufbar. Starten Sie gern einen neuen Check.', array( 'status' => 410 ) ) );
		}
		if ( in_array( $row['status'], array( 'wartet', 'laeuft' ), true ) ) {
			return new WP_REST_Response(
				array(
					'status'   => $row['status'],
					'schritt'  => (int) $row['schritt'],
					'schritte' => OQSC_Job::step_titles(),
					'domain'   => $row['domain'],
					'job'      => $row['token'],
				),
				200
			);
		}
		if ( 'fertig' !== $row['status'] ) {
			return new WP_REST_Response(
				array(
					'status'  => $row['status'],
					'fehler'  => true,
					'meldung' => $row['fehler'] ? $row['fehler'] : 'Der Check wurde nicht abgeschlossen.',
					'domain'  => $row['domain'],
				),
				200
			);
		}
		$result = OQSC_Job::public_result( $row );
		if ( ! $result ) {
			return self::error( new WP_Error( 'oqsc_result', 'Dieses Ergebnis ist nicht lesbar.', array( 'status' => 500 ) ) );
		}
		$result['status']        = 'fertig';
		$result['erneut_ab']     = self::recheck_time( $row['domain'] );
		$result['anfrage_offen'] = ! OQSC_Leads::exists_for_check( (int) $row['id'] );
		return new WP_REST_Response( $result, 200 );
	}

	/**
	 * Ab wann darf eine Domain erneut geprüft werden (Unix-Zeit, 0 = sofort)?
	 *
	 * @param string $domain Domain.
	 * @return int
	 */
	public static function recheck_time( $domain ) {
		global $wpdb;
		$last = $wpdb->get_var( $wpdb->prepare( "SELECT MAX(created_at) FROM {$wpdb->prefix}oqsc_checks WHERE domain = %s AND quelle <> 'cache' AND status IN ('fertig','laeuft','wartet')", $domain ) );
		if ( ! $last ) {
			return 0;
		}
		$at = strtotime( $last . ' UTC' ) + 60 * (int) OQSC_Plugin::get( 'recheck_minuten', 60 );
		return $at > time() ? $at : 0;
	}

	/**
	 * POST /recheck.
	 *
	 * @param WP_REST_Request $req Anfrage.
	 * @return WP_REST_Response
	 */
	public static function recheck( WP_REST_Request $req ) {
		$avail = OQSC_Guard::available();
		if ( is_wp_error( $avail ) ) {
			return self::error( $avail );
		}
		$ok = OQSC_Guard::verify( $req['token'], $req['pow'], $req['website'] );
		if ( is_wp_error( $ok ) ) {
			return self::error( $ok );
		}
		$row = OQSC_Job::get( $req['check'] );
		if ( ! $row ) {
			return self::error( new WP_Error( 'oqsc_result', 'Dieses Ergebnis gibt es nicht mehr.', array( 'status' => 404 ) ) );
		}
		$at = self::recheck_time( $row['domain'] );
		if ( $at && ! OQSC_Guard::admin_test() ) {
			return self::error( new WP_Error( 'oqsc_recheck', 'Diese Website wurde gerade erst geprüft. Eine neue Prüfung ist ab ' . wp_date( 'H:i', $at ) . ' Uhr möglich.', array( 'status' => 429 ) ) );
		}
		$limits = OQSC_Guard::check_limits();
		if ( is_wp_error( $limits ) ) {
			return self::error( $limits );
		}
		return self::create_job( $row['url'], $row['ort'], $row['branche'], 'recheck' );
	}
}
