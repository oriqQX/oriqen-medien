<?php
/**
 * Säulen, Index, Einordnung, Top-3-Hebel und interne Vertriebsnotiz.
 *
 * @package oriqen-check
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Auswertung.
 */
class OQSC_Score {

	/**
	 * Punkte je Status.
	 *
	 * @param string $status Status.
	 * @return int|null
	 */
	public static function points( $status ) {
		$map = array(
			'gut'          => 100,
			'verbesserbar' => 50,
			'kritisch'     => 0,
		);
		return isset( $map[ $status ] ) ? $map[ $status ] : null;
	}

	/**
	 * Bezeichnung eines Status.
	 *
	 * @param string $status Status.
	 * @return string
	 */
	public static function status_label( $status ) {
		$map = array(
			'gut'            => 'gut',
			'verbesserbar'   => 'verbesserbar',
			'kritisch'       => 'kritisch',
			'hinweis'        => 'Hinweis',
			'nicht_pruefbar' => 'nicht prüfbar',
		);
		return isset( $map[ $status ] ) ? $map[ $status ] : $status;
	}

	/**
	 * Einordnung zu einem Indexwert.
	 *
	 * @param int $index Index.
	 * @return string
	 */
	public static function band( $index ) {
		foreach ( OQSC_Texts::bands() as $min => $label ) {
			if ( $index >= $min ) {
				return $label;
			}
		}
		return '';
	}

	/**
	 * Ergebnis bauen.
	 *
	 * @param array $checks  Rohergebnisse aus OQSC_Checks::run_all.
	 * @param array $data    Gesammelte Daten.
	 * @param array $context ort, branche, jahr.
	 * @return array
	 */
	public static function build( $checks, $data, $context ) {
		$texts   = OQSC_Texts::all();
		$tips    = OQSC_Texts::branch_tips();
		$ptexts  = OQSC_Texts::pillars();
		$pillars = OQSC_Checks::pillars();
		$prep    = OQSC_Checks::prepare( $data, $context );
		$fillctx = array( 'ort' => $prep['ort_kern'] ? $prep['ort_kern'] : '' );
		$branche = isset( $context['branche'] ) && $context['branche'] ? $context['branche'] : 'sonstiges';

		// Texte anhängen.
		$list = array();
		foreach ( $checks as $id => $c ) {
			$t       = isset( $texts[ $id ] ) ? $texts[ $id ] : array();
			$good    = 'gut' === $c['status'];
			$entry   = array(
				'id'             => $id,
				'saeule'         => $c['saeule'],
				'gewicht'        => $c['gewicht'],
				'status'         => $c['status'],
				'punkte'         => $c['gewicht'] > 0 ? self::points( $c['status'] ) : null,
				'titel'          => isset( $t['titel'] ) ? $t['titel'] : $id,
				'befund'         => (string) $c['befund'],
				'text'           => OQSC_Texts::fill( $good ? $t['text_gut'] : $t['text_schlecht'], $fillctx ),
				'was_heisst_das' => OQSC_Texts::fill( $t['was_heisst_das'], $fillctx ),
				'warum'          => OQSC_Texts::fill( $t['warum'], $fillctx ),
				'so_beheben'     => array_map(
					static function ( $s ) use ( $fillctx ) {
						return OQSC_Texts::fill( $s, $fillctx );
					},
					$t['so_beheben']
				),
				'aufwand'        => $t['aufwand'],
				'leistung'       => $t['leistung'],
				'werte'          => $c['werte'],
			);
			if ( isset( $tips[ $id ][ $branche ] ) && in_array( $c['status'], array( 'verbesserbar', 'kritisch', 'hinweis' ), true ) ) {
				$entry['branchentipp'] = OQSC_Texts::fill( $tips[ $id ][ $branche ], $fillctx );
			}
			$list[ $id ] = $entry;
		}

		// Säulenwerte.
		$saeulen = array();
		foreach ( $pillars as $key => $p ) {
			$sum_w = 0;
			$sum_p = 0;
			$counts = array(
				'gut'            => 0,
				'verbesserbar'   => 0,
				'kritisch'       => 0,
				'hinweis'        => 0,
				'nicht_pruefbar' => 0,
			);
			foreach ( $list as $e ) {
				if ( $e['saeule'] !== $key ) {
					continue;
				}
				++$counts[ $e['status'] ];
				if ( $e['gewicht'] > 0 && null !== $e['punkte'] ) {
					$sum_w += $e['gewicht'];
					$sum_p += $e['gewicht'] * $e['punkte'];
				}
			}
			$value = $sum_w ? (int) round( $sum_p / $sum_w ) : null;
			$pt    = $ptexts[ $key ];
			if ( null === $value ) {
				$satz = 'Diese Säule konnten wir diesmal nicht bewerten.';
			} elseif ( $value >= 85 ) {
				$satz = $pt['stark'];
			} elseif ( $value >= 50 ) {
				$satz = $pt['mittel'];
			} else {
				$satz = $pt['schwach'];
			}
			$saeulen[] = array(
				'key'     => $key,
				'name'    => $p[0],
				'frage'   => $pt['frage'],
				'gewicht' => $p[1],
				'wert'    => $value,
				'satz'    => $satz,
				'anzahl'  => $counts,
			);
		}

		// Gesamtindex (gewichtet, Säulen ohne Wert fallen heraus).
		$sum_w = 0;
		$sum_v = 0;
		$weak  = null;
		foreach ( $saeulen as $s ) {
			if ( null === $s['wert'] ) {
				continue;
			}
			$sum_w += $s['gewicht'];
			$sum_v += $s['gewicht'] * $s['wert'];
			if ( null === $weak || $s['wert'] < $weak['wert'] ) {
				$weak = $s;
			}
		}
		$index = $sum_w ? (int) round( $sum_v / $sum_w ) : 0;

		$einordnung = array(
			'label'   => self::band( $index ),
			'satz'    => OQSC_Texts::verdict( $index, $weak ? $weak['key'] : '', $weak ? $weak['wert'] : 100 ),
			'schwach' => $weak ? $weak['key'] : '',
		);

		// Top-3-Hebel.
		$hebel = self::levers( $list, $pillars );

		// Google-Vorschau und Handy-Bild.
		$page    = $prep['page'];
		$final   = isset( $data['home']['final_url'] ) ? $data['home']['final_url'] : '';
		$preview = array(
			'titel'        => isset( $page['title'] ) ? $page['title'] : '',
			'beschreibung' => isset( $page['description'] ) && '' !== $page['description'] ? $page['description'] : ( isset( $page['first_para'] ) ? mb_substr( $page['first_para'], 0, 300 ) : '' ),
			'beschreibung_fehlt' => empty( $page['description'] ),
			'url'          => $final,
			'name'         => ! empty( $page['og_site_name'] ) ? $page['og_site_name'] : ( ! empty( $page['business']['name'] ) ? $page['business']['name'] : '' ),
		);
		$psi     = isset( $data['psi'] ) && is_array( $data['psi'] ) ? $data['psi'] : array( 'ok' => false );

		$result = array(
			'version'    => OQSC_VERSION,
			'index'      => $index,
			'einordnung' => $einordnung,
			'saeulen'    => $saeulen,
			'hebel'      => $hebel,
			'pruefungen' => array_values( $list ),
			'vorschau'   => $preview,
			'screenshot' => ! empty( $psi['screenshot'] ) ? $psi['screenshot'] : '',
			'pagespeed'  => array(
				'ok'             => ! empty( $psi['ok'] ),
				'grund'          => isset( $psi['grund'] ) ? $psi['grund'] : '',
				'performance'    => isset( $psi['performance'] ) ? $psi['performance'] : null,
				'accessibility'  => isset( $psi['accessibility'] ) ? $psi['accessibility'] : null,
				'best_practices' => isset( $psi['best_practices'] ) ? $psi['best_practices'] : null,
				'seo'            => isset( $psi['seo'] ) ? $psi['seo'] : null,
			),
			'ort'        => $prep['ort'],
			'ort_quelle' => $prep['ort_quelle'],
			'abrufe'     => isset( $data['abrufe'] ) ? (int) $data['abrufe'] : 0,
		);

		$result['intern'] = array(
			'vertriebsnotiz' => self::sales_note( $list, $index ),
		);
		return $result;
	}

	/**
	 * Top-3-Hebel: gewicht × (100 − punkte), bei Gleichstand selbst vor Fachhilfe, höchstens einer je Säule.
	 *
	 * @param array $list    Prüfungen.
	 * @param array $pillars Säulen.
	 * @return array
	 */
	public static function levers( $list, $pillars ) {
		$cands = array();
		foreach ( $list as $e ) {
			if ( $e['gewicht'] <= 0 || null === $e['punkte'] || $e['punkte'] >= 100 ) {
				continue;
			}
			$e['score'] = $e['gewicht'] * ( 100 - $e['punkte'] );
			$cands[]    = $e;
		}
		usort(
			$cands,
			static function ( $a, $b ) {
				if ( $a['score'] !== $b['score'] ) {
					return $b['score'] - $a['score'];
				}
				$sa = 'selbst' === $a['aufwand'] ? 0 : 1;
				$sb = 'selbst' === $b['aufwand'] ? 0 : 1;
				if ( $sa !== $sb ) {
					return $sa - $sb;
				}
				return strcmp( $a['id'], $b['id'] );
			}
		);
		$out  = array();
		$used = array();
		foreach ( $cands as $c ) {
			if ( isset( $used[ $c['saeule'] ] ) ) {
				continue;
			}
			$used[ $c['saeule'] ] = true;
			$out[]                = array(
				'id'          => $c['id'],
				'titel'       => $c['titel'],
				'saeule'      => $c['saeule'],
				'saeule_name' => $pillars[ $c['saeule'] ][0],
				'status'      => $c['status'],
				'befund'      => $c['befund'],
				'wirkung'     => $c['score'] >= 300 ? 'hoch' : ( $c['score'] >= 150 ? 'mittel' : 'gering' ),
				'aufwand'     => $c['aufwand'],
				'was_tun'     => array_slice( $c['so_beheben'], 0, 2 ),
				'leistung'    => $c['leistung'],
			);
			if ( count( $out ) >= 3 ) {
				break;
			}
		}
		return $out;
	}

	/**
	 * Interne Vertriebsnotiz.
	 *
	 * @param array $list  Prüfungen.
	 * @param int   $index Index.
	 * @return array
	 */
	public static function sales_note( $list, $index ) {
		$base   = untrailingslashit( (string) OQSC_Plugin::get( 'leistung_basis', 'https://oriqen.de' ) );
		$names  = OQSC_Texts::leistungen();
		$groups = array();
		$krit   = 0;
		$add    = static function ( $key, $reason ) use ( &$groups ) {
			if ( ! isset( $groups[ $key ] ) ) {
				$groups[ $key ] = array();
			}
			if ( ! in_array( $reason, $groups[ $key ], true ) ) {
				$groups[ $key ][] = $reason;
			}
		};
		foreach ( $list as $e ) {
			$bad = in_array( $e['status'], array( 'verbesserbar', 'kritisch' ), true ) || ( 'hinweis' === $e['status'] && 'rechtssicher' === $e['saeule'] );
			if ( ! $bad ) {
				continue;
			}
			if ( 'kritisch' === $e['status'] ) {
				++$krit;
			}
			$label = $e['id'] . ' ' . $e['titel'] . ( 'kritisch' === $e['status'] ? ' (kritisch)' : '' );
			$id    = $e['id'];
			$first = $id[0];
			if ( 'G' === $first || 'K' === $first ) {
				$add( 'seo', $label );
			} elseif ( 'L' === $first ) {
				$add( 'google', $label );
				if ( 'L07' === $id ) {
					$add( 'social', $label );
				}
			} elseif ( 'S' === $first ) {
				$add( 'betreuung', $label );
				if ( 'S08' === $id ) {
					$add( 'webdesign', $label );
				}
			} elseif ( 'U' === $first ) {
				if ( in_array( $id, array( 'U06', 'U07', 'U08', 'U09' ), true ) ) {
					$add( 'betreuung', $label );
				} else {
					$add( 'webdesign', $label );
				}
				if ( 'U04' === $id ) {
					$add( 'google', $label );
					$add( 'social', $label );
				}
			} elseif ( 'R' === $first ) {
				$add( 'recht', $label );
			}
		}
		if ( $index < 50 ) {
			$add( 'webdesign', 'schwacher Gesamtindex (' . $index . ')' );
		}
		$order      = array( 'webdesign', 'google', 'seo', 'betreuung', 'recht', 'social' );
		$leistungen = array();
		foreach ( $order as $key ) {
			if ( empty( $groups[ $key ] ) ) {
				continue;
			}
			$leistungen[] = array(
				'key'     => $key,
				'name'    => $names[ $key ][0],
				'url'     => $base . $names[ $key ][1],
				'gruende' => $groups[ $key ],
			);
		}
		if ( $index < 50 || $krit >= 5 ) {
			$pot = 'hoch';
		} elseif ( $index < 70 || $krit >= 2 ) {
			$pot = 'mittel';
		} else {
			$pot = 'gering';
		}
		return array(
			'potenzial'   => $pot,
			'begruendung' => 'Index ' . $index . ', ' . $krit . ( 1 === $krit ? ' kritischer Befund' : ' kritische Befunde' ),
			'kritisch'    => $krit,
			'leistungen'  => $leistungen,
		);
	}
}
