=== oriqen Sichtbarkeits-Check ===
Contributors: oriqen
Tags: seo, check, sichtbarkeit, dsgvo, lokal
Requires at least: 6.4
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Selbstcheck für Besucher von oriqen.de: prüft eine Website in sechs Säulen und führt zur persönlichen Analyse.

== Description ==

Besucher geben ihre Website ein und sehen in rund einer Minute, wo sie Kunden verlieren:

* Gefunden: Google versteht und indexiert die Seite
* Vor Ort: Adresse, Telefon, Ort, strukturierte Firmendaten, Google-Profil
* Schnell: Ladezeit und Handyansicht (PageSpeed Insights, serverseitig)
* Überzeugend: 5-Sekunden-Test, Weg zur Anfrage, Bewertungen, HTTPS
* Rechtssicher: Impressum, Datenschutz, Einwilligung, Google Fonts, Tracking, Einbettungen, Barrierefreiheit (Hinweise, keine Rechtsberatung)
* KI-bereit: KI-Crawler, llms.txt, strukturierte Daten, klare Selbstbeschreibung

Ergebnis mit Sichtbarkeits-Index (0 bis 100), den drei wichtigsten Hebeln, Google-Vorschau, Handy-Bildschirmfoto, allen Einzelprüfungen, Ergebnis-Link (30 Tage), Druckansicht und Anfrageformular. Backend mit Übersicht, Checks, Anfragen, CSV-Export und Einstellungen.

Sicherheit: SSRF-Schutz mit DNS-Prüfung und IP-Festsetzung, höchstens 16 Abrufe je Check, Limits je Besucher, Domain und Tag, Warteschlange, automatischer Not-Aus, Bot-Schutz ohne Cookies und ohne externe Dienste.

== Installation ==

1. ZIP unter Plugins, Installieren, Plugin hochladen auswählen und aktivieren.
2. Seite anlegen (Vorschlag: /website-check/) und den Shortcode [oriqen_check] einsetzen.
3. Unter oriqen Check, Einstellungen die Adresse der Seite, den Empfänger und optional den PageSpeed-Schlüssel eintragen.

Kompakte Variante für Startseite oder Footer: [oriqen_check variante="kompakt" ziel="/website-check/"]

== Frequently Asked Questions ==

= Setzt das Plugin Cookies? =

Nein. Es lädt im Browser keine externen Dateien und braucht deshalb keine Einwilligung.

= Werden IP-Adressen gespeichert? =

Nein, nur ein täglich wechselnder, nicht umkehrbarer Hash für die Limits.

== Changelog ==

= 1.0.1 =
* Beispiel für die Hauptüberschrift ohne Branchenannahme.

= 1.0.0 =
* Erste Version.
