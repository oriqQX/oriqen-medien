<?php
/**
 * Deinstallation: Daten nur löschen, wenn in den Einstellungen ausdrücklich gewählt.
 *
 * @package oriqen-check
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$oqsc_ts = wp_next_scheduled( 'oqsc_cron_daily' );
while ( $oqsc_ts ) {
	wp_unschedule_event( $oqsc_ts, 'oqsc_cron_daily' );
	$oqsc_ts = wp_next_scheduled( 'oqsc_cron_daily' );
}

$oqsc_settings = get_option( 'oqsc_settings', array() );
if ( empty( $oqsc_settings['daten_loeschen'] ) ) {
	// Standard: Checks, Anfragen und Einstellungen bleiben für eine spätere Neuinstallation erhalten.
	return;
}

global $wpdb;
foreach ( array( 'oqsc_checks', 'oqsc_leads', 'oqsc_events' ) as $oqsc_table ) {
	$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . $oqsc_table ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.DirectDatabaseQuery.SchemaChange -- feste Tabellennamen.
}
foreach ( array( 'oqsc_settings', 'oqsc_db_version', 'oqsc_version', 'oqsc_pause_bis', 'oqsc_health' ) as $oqsc_option ) {
	delete_option( $oqsc_option );
}
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\_transient\_oqsc\_%' OR option_name LIKE '\_transient\_timeout\_oqsc\_%' OR option_name LIKE 'oqsc\_lock\_%'" );
foreach ( wp_roles()->roles as $oqsc_role_name => $oqsc_role ) {
	$oqsc_r = get_role( $oqsc_role_name );
	if ( $oqsc_r && $oqsc_r->has_cap( 'oqsc_manage' ) ) {
		$oqsc_r->remove_cap( 'oqsc_manage' );
	}
}
