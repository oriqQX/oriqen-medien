<?php
/**
 * Plugin Name: oriqen Formulare
 * Description: Markenstil, Icons und Formular-Definitionen für die Fluent-Forms-Formulare von oriqen (Projektanfrage, SEO-Analyse). Leitet alte Teilen-Adressen auf die echten Seiten um.
 * Version: 1.0.3
 * Author: oriqen
 * Author URI: https://oriqen.de/
 * Requires PHP: 7.4
 * Text Domain: oriqen-formulare
 */

defined( 'ABSPATH' ) || exit;

define( 'OQFF_VERSION', '1.0.3' );
define( 'OQFF_DIR', plugin_dir_path( __FILE__ ) );
define( 'OQFF_URL', plugin_dir_url( __FILE__ ) );

/**
 * Formular-IDs in Fluent Forms. Schlüssel = Datei in assets/forms/.
 */
function oqff_form_ids() {
	$ids = get_option( 'oqff_form_ids' );
	if ( ! is_array( $ids ) ) {
		$ids = array( 'projekt' => 6, 'seo' => 7 );
	}
	return apply_filters( 'oqff_form_ids', $ids );
}

/**
 * Alte Teilen-Adressen (?fluent-form=ID) => echte Seite.
 */
function oqff_redirects() {
	$ids = oqff_form_ids();
	$map = array( 4 => '/seo/seo-analyse/anfordern/' );
	if ( ! empty( $ids['seo'] ) ) {
		$map[ (int) $ids['seo'] ] = '/seo/seo-analyse/anfordern/';
	}
	if ( ! empty( $ids['projekt'] ) ) {
		$map[ (int) $ids['projekt'] ] = '/kontakt/';
	}
	return apply_filters( 'oqff_redirects', $map );
}

/* ------------------------------------------------------------------ */
/* 1. Weiterleitung der Teilen-Adressen                               */
/* ------------------------------------------------------------------ */
add_action( 'wp', function () {
	// Fluent Forms gibt die Teilen-Seite auf "wp" mit Priorität 100 aus, wir greifen vorher.
	if ( is_admin() || wp_doing_ajax() || ! isset( $_GET['fluent-form'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}
	$form_id = absint( wp_unslash( $_GET['fluent-form'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
	$map     = oqff_redirects();
	if ( ! isset( $map[ $form_id ] ) ) {
		return;
	}
	// Ausnahmen: Einbettung per iframe und eingeloggte Redakteure (Formular-Vorschau im Backend).
	if ( isset( $_GET['embedded'] ) || current_user_can( 'edit_pages' ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}
	wp_safe_redirect( home_url( $map[ $form_id ] ), 301, 'oriqen Formulare' );
	exit;
}, 1 );

/* ------------------------------------------------------------------ */
/* 2. Markenstil nach dem Formular laden                              */
/* ------------------------------------------------------------------ */
$GLOBALS['oqff_needs_css'] = false;

add_filter( 'do_shortcode_tag', function ( $output, $tag, $attr ) {
	if ( 'fluentform' === $tag && is_array( $attr ) && isset( $attr['type'] ) && 'conversational' === $attr['type'] ) {
		$GLOBALS['oqff_needs_css'] = true;
	}
	return $output;
}, 10, 3 );

add_action( 'wp_footer', function () {
	if ( empty( $GLOBALS['oqff_needs_css'] ) && ! wp_script_is( 'fluent_forms_conversational_form', 'enqueued' ) && ! wp_script_is( 'fluent_forms_conversational_form', 'done' ) ) {
		return;
	}
	$href = OQFF_URL . 'assets/oriqen-formulare.css?ver=' . OQFF_VERSION;
	echo '<link rel="stylesheet" id="oqff-css" href="' . esc_url( $href ) . '" media="all">' . "\n"; // phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet
}, 999 );

/* ------------------------------------------------------------------ */
/* 3. Formular-Definitionen einspielen (REST, nur Administratoren)    */
/* ------------------------------------------------------------------ */
add_action( 'rest_api_init', function () {
	register_rest_route( 'oriqen-formulare/v1', '/status', array(
		'methods'             => 'GET',
		'permission_callback' => function () { return current_user_can( 'manage_options' ); },
		'callback'            => function () {
			return array(
				'version'   => OQFF_VERSION,
				'ids'       => oqff_form_ids(),
				'redirects' => oqff_redirects(),
				'forms'     => array_map( 'basename', glob( OQFF_DIR . 'assets/forms/*.json' ) ?: array() ),
			);
		},
	) );

	register_rest_route( 'oriqen-formulare/v1', '/sync', array(
		'methods'             => 'POST',
		'permission_callback' => function () { return current_user_can( 'manage_options' ); },
		'args'                => array(
			'dry_run' => array( 'type' => 'boolean', 'default' => false ),
			'only'    => array( 'type' => 'string', 'default' => '' ),
		),
		'callback'            => 'oqff_sync',
	) );
} );

/**
 * Spielt die Definitionen aus assets/forms/*.json in die Fluent-Forms-Formulare ein.
 * Einträge (Anfragen) bleiben unberührt, ersetzt werden nur Felder und Einstellungen.
 */
function oqff_sync( WP_REST_Request $req ) {
	global $wpdb;
	$forms_table = $wpdb->prefix . 'fluentform_forms';
	$meta_table  = $wpdb->prefix . 'fluentform_form_meta';
	$dry         = (bool) $req->get_param( 'dry_run' );
	$only        = sanitize_key( (string) $req->get_param( 'only' ) );
	$report      = array();

	foreach ( oqff_form_ids() as $key => $form_id ) {
		if ( $only && $only !== $key ) {
			continue;
		}
		$file = OQFF_DIR . 'assets/forms/' . sanitize_file_name( $key ) . '.json';
		if ( ! is_readable( $file ) ) {
			$report[ $key ] = 'Datei fehlt';
			continue;
		}
		$def = json_decode( (string) file_get_contents( $file ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		if ( ! is_array( $def ) || empty( $def['fields']['fields'] ) ) {
			$report[ $key ] = 'Datei ungültig';
			continue;
		}
		$exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$forms_table} WHERE id = %d", $form_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( ! $exists ) {
			$report[ $key ] = 'Formular ' . (int) $form_id . ' nicht gefunden';
			continue;
		}

		$metas = array(
			'formSettings'             => wp_json_encode( $def['formSettings'] ),
			'is_conversion_form'       => 'yes',
			'template_name'            => 'conversational',
			'_primary_email_field'     => 'email',
			'ffc_form_settings_meta'   => wp_json_encode( array(
				'title' => $def['meta_title'], 'description' => '', 'featured_image' => '', 'share_key' => '',
				'google_font_href' => '', 'font_css' => '', 'i18n' => $def['i18n'],
			) ),
			'ffc_form_settings_design' => wp_json_encode( $def['design'] ),
		);

		$report[ $key ] = array(
			'form_id'       => (int) $form_id,
			'fields'        => count( $def['fields']['fields'] ),
			'notifications' => count( $def['notifications'] ),
			'dry_run'       => $dry,
		);
		if ( $dry ) {
			continue;
		}

		$wpdb->update( $forms_table, array( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			'title'       => $def['title'],
			'status'      => 'published',
			'form_fields' => wp_json_encode( $def['fields'] ),
			'updated_at'  => current_time( 'mysql' ),
		), array( 'id' => $form_id ) );

		foreach ( $metas as $meta_key => $value ) {
			$meta_id = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$meta_table} WHERE form_id = %d AND meta_key = %s LIMIT 1", $form_id, $meta_key ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			if ( $meta_id ) {
				$wpdb->update( $meta_table, array( 'value' => $value ), array( 'id' => $meta_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			} else {
				$wpdb->insert( $meta_table, array( 'form_id' => $form_id, 'meta_key' => $meta_key, 'value' => $value ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.SlowDBQuery
			}
		}

		$wpdb->delete( $meta_table, array( 'form_id' => $form_id, 'meta_key' => 'notifications' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.SlowDBQuery
		foreach ( $def['notifications'] as $n ) {
			$wpdb->insert( $meta_table, array( 'form_id' => $form_id, 'meta_key' => 'notifications', 'value' => wp_json_encode( $n ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.SlowDBQuery
		}
		do_action( 'fluentform/form_updated', $form_id ); // Fluent und Cache-Plugins mitbekommen lassen.
	}

	return array( 'version' => OQFF_VERSION, 'result' => $report );
}
