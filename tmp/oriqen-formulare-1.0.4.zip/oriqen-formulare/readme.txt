=== oriqen Formulare ===
Contributors: oriqen
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 1.0.4
License: proprietary

Markenstil, Icons und Formular-Definitionen für die Fluent-Forms-Formulare von oriqen.de.

== Was das Plugin macht ==
* Lädt den oriqen-Markenstil für eingebettete Conversational Forms im Footer, also nach dem Standard-CSS von Fluent Forms.
* Liefert die Icons der Bildkacheln aus (assets/icons, PNG 400 x 300).
* Leitet alte Teilen-Adressen wie /?fluent-form=4 per 301 auf die echten Seiten um. Eingeloggte Redakteure und Einbettungen per iframe bleiben unberührt.
* Enthält die Formular-Definitionen (assets/forms/*.json). POST /wp-json/oriqen-formulare/v1/sync spielt sie in die Formulare ein (nur Administratoren, mit dry_run testbar). Anfragen bleiben erhalten.

== Formulare ==
* projekt: Fluent-Forms-Formular 6, eingebunden auf /kontakt/
* seo: Fluent-Forms-Formular 7, eingebunden auf /seo/seo-analyse/anfordern/

Einbindung: Shortcode [fluentform type="conversational" id="ID"] in einem Elementor-Shortcode-Widget.

== Wichtig ==
Bildkacheln lassen sich im Fluent-Editor der Gratis-Version nicht bearbeiten. Änderungen an Fragen und Antworten daher in assets/forms/*.json vornehmen und per sync einspielen, nicht im Fluent-Editor speichern.

== Changelog ==
= 1.0.4 =
* Kürzere Betreffzeilen der Benachrichtigungen, Bestätigungsmail an Interessenten abgeschaltet (bleibt hinterlegt), Dankestext ohne Hinweis auf Bestätigungsmail.
= 1.0.3 =
* Weiches Trennzeichen in „Google-Unternehmensprofil“, keine Silbentrennung mitten im Wort mehr.
= 1.0.2 =
* Kacheln als festes Raster (keine verrutschten Reihen), Handy mit zwei Spalten und weniger Innenabstand, Datenschutz-Schritt als normaler Text, lange Wörter werden umbrochen.
= 1.0.1 =
* Breitere Fragen (900 px), Kachelraster je Frage (Bausteine 5, Branche und Ziele 3 pro Reihe), Beschriftungen mittig.

= 1.0.0 =
* Erste Version: Projektanfrage und SEO-Analyse mit 41 Icons, Markenstil, Weiterleitungen, Sync-Schnittstelle.
