/* [oq_demo type="feed"] */
document.querySelectorAll('[data-oq-demo="feed"]').forEach(el => {
  const feed = el.querySelector('.oq-feed'), knoepfe = el.querySelectorAll('[data-oq-feed]');
  knoepfe.forEach(k => k.addEventListener('click', () => { feed.dataset.stil = k.dataset.oqFeed; knoepfe.forEach(x => x.setAttribute('aria-pressed', String(x === k))); }));
});
