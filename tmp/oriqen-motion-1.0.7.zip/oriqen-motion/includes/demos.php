<?php
/**
 * Interaktive Bausteine: serverseitiges Grund-HTML je Typ. Der Text ist ohne JavaScript lesbar,
 * das zugehörige Skript macht den Baustein bedienbar. Nichts wird gespeichert.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Hülle mit Kennzeichnung. */
function oq_demo_rahmen( $type, $titel, $inhalt, $hinweis ) {
	return '<figure class="oq-demo oq-demo--' . esc_attr( $type ) . '" data-oq-demo="' . esc_attr( $type ) . '">'
		. '<p class="oq-demo__marke">Zum Ausprobieren</p>'
		. '<p class="oq-demo__titel">' . esc_html( $titel ) . '</p>'
		. $inhalt
		. '<figcaption class="oq-demo__hinweis">' . esc_html( $hinweis ) . '</figcaption></figure>';
}

/** Radio-Gruppe als Chips. */
function oq_demo_chips( $name, $legende, $werte, $aktiv ) {
	$h = '<fieldset class="oq-demo__gruppe"><legend>' . esc_html( $legende ) . '</legend><div class="oq-demo__chips">';
	foreach ( $werte as $wert => $label ) {
		$h .= '<label class="oq-demo__chip"><input type="radio" name="' . esc_attr( $name ) . '" value="' . esc_attr( $wert ) . '"' . checked( $wert, $aktiv, false ) . '><span>' . esc_html( $label ) . '</span></label>';
	}
	return $h . '</div></fieldset>';
}

/** Kleines Website-Mockup, das mehrere Bausteine nutzen. */
function oq_demo_mock( $name = 'Tischlerei Eichenwerk', $domain = 'tischlerei-eichenwerk.de' ) {
	return '<div class="oq-mock" data-stil="ruhig" data-farbe="violett">'
		. '<div class="oq-mock__leiste"><i></i><i></i><i></i><span data-oq="domain">' . esc_html( $domain ) . '</span></div>'
		. '<div class="oq-mock__seite"><div class="oq-mock__kopf"><b data-oq="name">' . esc_html( $name ) . '</b><span class="oq-mock__nav">Leistungen · Über uns · Kontakt</span><span class="oq-mock__burger" aria-hidden="true"></span></div>'
		. '<div class="oq-mock__hero"><div><p class="oq-mock__kicker" data-oq="kicker">Tischlerei in Paderborn</p><p class="oq-mock__h" data-oq="h">Möbel nach Maß, gebaut in Paderborn.</p><p class="oq-mock__p" data-oq="p">Küchen, Einbauschränke und Innenausbau aus unserer Werkstatt.</p><span class="oq-mock__knopf" data-oq="cta">Termin anfragen</span></div><div class="oq-mock__bild"></div></div>'
		. '<div class="oq-mock__karten"><span data-oq="l1">Küchen</span><span data-oq="l2">Einbaumöbel</span><span data-oq="l3">Innenausbau</span></div></div></div>';
}

function oq_demo_html_configurator( $atts ) {
	$in = '<form class="oq-demo__form" onsubmit="return false">'
		. oq_demo_chips( 'oq-typ', 'Welche Art von Website?', array( 'onepager' => 'One-Pager', 'klein' => 'Kleine Website', 'magazin' => 'Magazin oder Blog' ), 'klein' )
		. oq_demo_chips( 'oq-branche', 'Ihre Branche', array( 'handwerk' => 'Handwerk', 'gastro' => 'Gastronomie', 'praxis' => 'Praxis', 'handel' => 'Handel vor Ort' ), 'handwerk' )
		. oq_demo_chips( 'oq-stil', 'Stil', array( 'ruhig' => 'Ruhig', 'kuehn' => 'Kühn', 'klassisch' => 'Klassisch' ), 'ruhig' )
		. oq_demo_chips( 'oq-farbe', 'Farbstimmung', array( 'violett' => 'Violett', 'wald' => 'Waldgrün', 'ozean' => 'Ozean', 'terrakotta' => 'Terrakotta' ), 'violett' )
		. '</form><div class="oq-demo__vorschau">' . oq_demo_mock() . '<p class="oq-demo__ergebnis" aria-live="polite" data-oq="paket">Passender Einstieg: <strong>Starter ab 279 EUR</strong>. Bis zu fünf Seiten, für Smartphone, Tablet und Desktop gebaut.</p></div>';
	return oq_demo_rahmen( 'configurator', 'Ihre Website in vier Entscheidungen', '<div class="oq-demo__zwei">' . $in . '</div>', 'Beispielbetriebe sind erfunden. Die Vorschau zeigt die Richtung, kein fertiges Design. Preise sind Orientierungswerte, den verbindlichen Preis legen wir nach dem Erstgespräch fest.' );
}

function oq_demo_html_wireframe( $atts ) {
	$in = '<div class="oq-demo__schalter" role="group" aria-label="Ansicht wählen"><button type="button" class="oq-demo__knopf" data-oq-wire="1" aria-pressed="false">Wireframe</button><button type="button" class="oq-demo__knopf" data-oq-wire="0" aria-pressed="true">Gestaltet</button></div>' . oq_demo_mock();
	return oq_demo_rahmen( 'wireframe', 'Erst die Struktur, dann die Gestaltung', $in, 'Ein Wireframe zeigt nur, was wohin gehört: graue Kästen statt Bilder, Balken statt Text. Beispielbetrieb erfunden.' );
}

function oq_demo_html_responsive( $atts ) {
	$in = '<div class="oq-demo__schalter" role="group" aria-label="Bildschirmbreite"><button type="button" class="oq-demo__knopf" data-oq-breite="1200" aria-pressed="true">Desktop</button><button type="button" class="oq-demo__knopf" data-oq-breite="800" aria-pressed="false">Tablet</button><button type="button" class="oq-demo__knopf" data-oq-breite="390" aria-pressed="false">Smartphone</button></div>'
		. '<div class="oq-demo__buehne"><div class="oq-demo__geraet">' . oq_demo_mock() . '</div></div><p class="oq-demo__ergebnis" aria-live="polite"><span data-oq="breite">1200</span> Pixel breit</p>';
	return oq_demo_rahmen( 'responsive', 'Dieselbe Seite auf jedem Gerät', $in, 'Keine Bilder, sondern dieselbe Seite, die live umbricht: Spalten werden zu Zeilen, die Navigation wird zum Menü. Beispielbetrieb erfunden.' );
}

function oq_demo_html_speed( $atts ) {
	$handy = '<div class="oq-handy" aria-hidden="true"><div class="oq-handy__seite">'
		. '<div class="oq-handy__kopf"><i>TE</i><span>Tischlerei Eichenwerk</span><em></em></div>'
		. '<div class="oq-handy__bild"></div>'
		. '<div class="oq-handy__text"><p class="oq-handy__k">Tischlerei in Paderborn</p><p class="oq-handy__h">Möbel nach Maß, gebaut in Paderborn.</p><p class="oq-handy__p">Küchen, Einbauschränke und Innenausbau aus unserer Werkstatt. Beratung bei Ihnen vor Ort.</p><span class="oq-handy__knopf">Termin anfragen</span><span class="oq-handy__knopf oq-handy__knopf--2">05251 000 000</span></div>'
		. '</div><div class="oq-handy__lade"><span></span></div></div>';
	$bahn = function ( $name, $sub, $fcp, $lcp, $cls ) use ( $handy ) {
		return '<div class="oq-demo__bahn" data-phase="2" data-fcp="' . esc_attr( $fcp ) . '" data-lcp="' . esc_attr( $lcp ) . '" data-cls="' . esc_attr( $cls ) . '"><b>' . esc_html( $name ) . '</b><small>' . esc_html( $sub ) . '</small>' . $handy . '<p class="oq-demo__uhr"><span>' . esc_html( str_replace( '.', ',', $lcp ) ) . '</span> s<i class="oq-demo__ok" aria-hidden="true">✓</i></p></div>';
	};
	$in = '<div class="oq-demo__rennen" data-zustand="bereit">' . $bahn( 'Schwer gebaut', 'große Bilder, viele Skripte', '2.9', '5.8', '0.24' ) . $bahn( 'Schlank gebaut', 'optimierte Bilder, wenig Skripte', '0.9', '1.7', '0.02' ) . '</div>'
		. '<p><button type="button" class="oq-demo__start">Rennen starten <span class="oq-pfeil" aria-hidden="true">→</span></button></p>'
		. '<p class="oq-demo__ergebnis" aria-live="polite">Starten Sie das Rennen: Beide Fassungen derselben Seite werden gleichzeitig aufgerufen.</p>'
		. '<table class="oq-demo__tabelle"><caption class="screen-reader-text">Simulierte Messwerte der beiden Fassungen</caption><thead><tr><th scope="col">Simulierter Wert</th><th scope="col">Schwer</th><th scope="col">Schlank</th></tr></thead><tbody>'
		. '<tr><th scope="row">Erster Inhalt sichtbar</th><td>2,9 s</td><td>0,9 s</td></tr>'
		. '<tr><th scope="row">LCP, größtes Element</th><td>5,8 s <span class="oq-ampel oq-ampel--rot">schlecht</span></td><td>1,7 s <span class="oq-ampel oq-ampel--gruen">gut</span></td></tr>'
		. '<tr><th scope="row">CLS, Springen</th><td>0,24 <span class="oq-ampel oq-ampel--gelb">mittel</span></td><td>0,02 <span class="oq-ampel oq-ampel--gruen">gut</span></td></tr>'
		. '</tbody></table>';
	return oq_demo_rahmen( 'speed', 'Ladezeit-Rennen: dieselbe Seite, zweimal gebaut', $in, 'Simulation, keine Messung. Typische Größenordnungen für ein Smartphone im Mobilfunknetz, ausgerichtet an den Schwellenwerten von Google. Ihre echten Werte zeigen PageSpeed Insights und die Google Search Console.' );
}

function oq_demo_html_serp( $atts ) {
	$ohne = '<div class="oq-serp__eintrag oq-serp__eintrag--ohne"><p class="oq-serp__quelle"><span class="oq-serp__favicon" aria-hidden="true">·</span><span><b class="oq-serp__name" data-oq="domain">tischlerei-eichenwerk.de</b><span class="oq-serp__url">https://www.<span data-oq="domain2">tischlerei-eichenwerk.de</span> › <span data-oq="ohneurl">index.php?id=3</span></span></span></p>'
		. '<p class="oq-serp__titel" data-oq="ohnetitel">Startseite</p><p class="oq-serp__text" data-oq="ohnetext">Herzlich Willkommen auf unserer Homepage! Wir freuen uns über Ihren Besuch. Hier finden Sie alle Informationen rund um unser Unternehmen und unser umfangreiches …</p></div>';
	$mit = '<div class="oq-serp__eintrag oq-serp__eintrag--mit"><p class="oq-serp__quelle"><span class="oq-serp__favicon oq-serp__favicon--marke" aria-hidden="true" data-oq="ini">TE</span><span><b class="oq-serp__name" data-oq="name">Tischlerei Eichenwerk</b><span class="oq-serp__url">https://<span data-oq="domain3">tischlerei-eichenwerk.de</span> › <span data-oq="slug">leistungen</span></span></span></p>'
		. '<p class="oq-serp__titel" data-oq="titel">Tischler in Paderborn: Möbel nach Maß, Küchen, Innenausbau</p><p class="oq-serp__text" data-oq="text">Möbel und Küchen nach Maß aus unserer Werkstatt. Beratung vor Ort im Raum Paderborn, Delbrück und Salzkotten. Jetzt Termin anfragen.</p></div>';
	$fremd = '<div class="oq-serp__fremd" aria-hidden="true"><i></i><i></i><i></i></div>';
	$checks = '<ul class="oq-serp__checks" aria-live="polite">'
		. '<li data-oq-check="titel"><b>Titel</b><span>„Startseite“ sagt nichts über Leistung und Ort.</span></li>'
		. '<li data-oq-check="adresse"><b>Adresse</b><span>Eine Parameter-Adresse statt lesbarer Wörter.</span></li>'
		. '<li data-oq-check="text"><b>Beschreibung</b><span>Eine Begrüßung, die mitten im Satz abbricht.</span></li>'
		. '<li data-oq-check="marke"><b>Name und Symbol</b><span>Kein Website-Name, kein eigenes Symbol.</span></li></ul>';
	$in = oq_demo_chips( 'oq-serp-betrieb', 'Beispielbetrieb', array( 'tischlerei' => 'Tischlerei', 'physio' => 'Physiotherapie', 'steuer' => 'Steuerberatung' ), 'tischlerei' )
		. '<div class="oq-demo__schalter" role="group" aria-label="Darstellung"><button type="button" class="oq-demo__knopf" data-oq-modus="ohne" aria-pressed="true">Ohne Optimierung</button><button type="button" class="oq-demo__knopf" data-oq-modus="mit" aria-pressed="false">Mit Optimierung</button><button type="button" class="oq-demo__knopf" data-oq-modus="selbst" aria-pressed="false">Selbst schreiben</button></div>'
		. '<div class="oq-demo__zwei oq-serp__raster"><div class="oq-serp" data-modus="ohne"><p class="oq-serp__suche"><span aria-hidden="true">⌕</span> <span data-oq="such">tischler paderborn</span></p>' . $fremd . $ohne . $mit . $fremd . '</div>'
		. '<div class="oq-serp__seite"><p class="oq-serp__zustand" data-oq="zustand">Ohne Optimierung</p>' . $checks
		. '<div class="oq-serp__selbst" hidden><label for="oq-serp-titel">Ihr Seitentitel</label><input id="oq-serp-titel" type="text" maxlength="120" value="Tischler in Paderborn: Möbel nach Maß, Küchen, Innenausbau"><p class="oq-demo__info" data-oq="titelinfo" aria-live="polite"></p><label for="oq-serp-text">Ihre Beschreibung</label><textarea id="oq-serp-text" rows="3" maxlength="300">Möbel und Küchen nach Maß aus unserer Werkstatt. Beratung vor Ort im Raum Paderborn. Jetzt Termin anfragen.</textarea><p class="oq-demo__info" data-oq="textinfo" aria-live="polite"></p></div></div></div>';
	return oq_demo_rahmen( 'serp', 'Ihr Eintrag in der Ergebnisliste', $in, 'Vereinfachte Nachbildung mit erfundenen Beispielbetrieben, keine echte Google-Darstellung. Google kürzt Titel und Beschreibungen nach verfügbarer Breite und schreibt sie um, wenn sie nicht zur Suchanfrage passen. Ein guter Titel erhöht die Chance auf einen Klick, eine Position sagt er nicht voraus.' );
}

function oq_demo_html_crawler( $atts ) {
	$seiten = array(
		array( '/', 0, '' ), array( '/leistungen', 0, '' ), array( '/leistungen/kuechen', 1, '' ), array( '/leistungen/einbaumoebel', 1, '' ), array( '/leistungen/innenausbau', 1, '' ),
		array( '/ueber-uns', 0, '' ), array( '/ratgeber', 0, '' ), array( '/ratgeber/kueche-planen', 1, '' ), array( '/kontakt', 0, '' ), array( '/danke', 1, 'noindex' ), array( '/aktion-2019', 0, 'waise' ),
	);
	$baum = '<ol class="oq-crawler__baum">';
	foreach ( $seiten as $s ) {
		$zusatz = 'noindex' === $s[2] ? ' <em>noindex</em>' : ( 'waise' === $s[2] ? ' <em>nirgends verlinkt</em>' : '' );
		$baum .= '<li data-tiefe="' . (int) $s[1] . '"' . ( $s[2] ? ' data-art="' . esc_attr( $s[2] ) . '"' : '' ) . '><span class="oq-crawler__pfad">' . esc_html( $s[0] ) . $zusatz . '</span><span class="oq-crawler__status">unbekannt</span></li>';
	}
	$baum .= '</ol>';
	$in = '<div class="oq-crawler" data-p="0"><div class="oq-crawler__kopf"><span class="oq-crawler__bot" aria-hidden="true"></span><span>Crawler besucht <b>tischlerei-eichenwerk.de</b></span></div>' . $baum
		. '<div class="oq-crawler__stufen"><div class="oq-crawler__stufe" data-stufe="1"><small><b>1</b> Sammeln</small><span data-oq="gefunden">0</span></div><div class="oq-crawler__stufe" data-stufe="2"><small><b>2</b> Ordnen</small><span data-oq="index">0</span></div><div class="oq-crawler__stufe" data-stufe="3"><small><b>3</b> Ausspielen</small><span data-oq="treffer">0</span></div></div></div>'
		. '<div class="oq-crawler__steuer"><button type="button" class="oq-demo__start">Crawler starten <span class="oq-pfeil" aria-hidden="true">→</span></button><label class="oq-demo__zeile"><input type="checkbox" data-oq="sitemap"> Sitemap bei Google einreichen</label></div>'
		. '<p class="oq-demo__ergebnis" aria-live="polite" data-oq="status">Der Crawler folgt allen Links ab der Startseite. Starten Sie ihn und achten Sie auf die letzten beiden Adressen.</p>';
	return oq_demo_rahmen( 'crawler', 'So liest Google Ihre Website', $in, 'Vereinfachtes Modell mit einem erfundenen Beispielbetrieb. Echte Crawler arbeiten über Tage und Wochen und entscheiden selbst, was sie aufnehmen. Eine Aufnahme in den Index garantiert Google nicht.' );
}

function oq_demo_html_maps( $atts ) {
	$karte = '<svg class="oq-maps__karte" viewBox="0 0 400 300" role="img" aria-label="Kartenausschnitt mit der suchenden Person und vier Betrieben">'
		. '<rect width="400" height="300" rx="14" fill="#F6F1FC"/>'
		. '<path d="M-10 214C70 186 128 246 204 206S330 152 410 178" fill="none" stroke="#cfe3f7" stroke-width="16"/>'
		. '<path d="M40-10L118 310M-10 92L410 122M262-10L300 310M-10 262L410 236M150-10L180 120" fill="none" stroke="#fff" stroke-width="9"/>'
		. '<g class="oq-maps__gebiete" font-family="Arial" font-size="11" fill="#9b8fb0"><text x="150" y="176">Zentrum</text><text x="150" y="40">Nord</text><text x="350" y="86">Ost</text></g>'
		. '<circle class="oq-maps__radius" data-oq="radius" cx="200" cy="150" r="70"/>'
		. '<g data-oq="pins"></g><g data-oq="person"><circle class="oq-maps__puls" cx="200" cy="150" r="9"/><circle cx="200" cy="150" r="7" fill="#1a73e8" stroke="#fff" stroke-width="3"/></g></svg>';
	$liste = '<div class="oq-maps__pack"><p class="oq-maps__suche"><span aria-hidden="true">⌕</span> <span data-oq="such">heizungsbauer in der nähe</span></p>'
		. '<ol class="oq-maps__liste" aria-live="polite" data-oq="liste"><li class="ist-ich"><b>Ihr Betrieb (Beispiel)</b><small>4,2 ★ (12) · Heizungsbau</small></li><li><b>Mitbewerber A</b></li><li><b>Mitbewerber B</b></li></ol>'
		. '<p class="oq-maps__rest" data-oq="rest"></p></div>';
	$faktoren = '<div class="oq-maps__faktoren" aria-hidden="true"><p>So steht Ihr Betrieb in den drei Faktoren</p>'
		. '<div><span>Relevanz</span><i><b data-oq="f-rel"></b></i></div><div><span>Entfernung</span><i><b data-oq="f-ent"></b></i></div><div><span>Bekanntheit</span><i><b data-oq="f-bek"></b></i></div></div>';
	$steuer = '<div class="oq-demo__form oq-maps__steuer">'
		. oq_demo_chips( 'oq-maps-branche', 'Beispielbetrieb', array( 'heizung' => 'Heizungsbau', 'physio' => 'Physiotherapie', 'steuer' => 'Steuerberatung' ), 'heizung' )
		. oq_demo_chips( 'oq-maps-ort', 'Wo steht die suchende Person?', array( 'zentrum' => 'Zentrum', 'nord' => 'Nord', 'ost' => 'Ost' ), 'zentrum' )
		. '<label class="oq-demo__zeile"><input type="checkbox" data-oq="kategorie" checked> Hauptkategorie passt zur Suche</label>'
		. '<label class="oq-demo__zeile"><input type="checkbox" data-oq="profil"> Profil gepflegt: Fotos, Öffnungszeiten, Beiträge</label>'
		. '<label for="oq-maps-anzahl">Bewertungen: <output data-oq="anzahlwert">12</output></label><input id="oq-maps-anzahl" type="range" min="0" max="150" value="12" data-oq="anzahl">'
		. '<label for="oq-maps-schnitt">Durchschnitt: <output data-oq="schnittwert">4,2</output> Sterne</label><input id="oq-maps-schnitt" type="range" min="30" max="50" value="42" data-oq="schnitt"></div>';
	$in = '<div class="oq-maps"><div class="oq-maps__links">' . $karte . $faktoren . '</div><div class="oq-maps__rechts">' . $liste . $steuer . '</div></div>'
		. '<p class="oq-demo__ergebnis" aria-live="polite" data-oq="status">Ihr Betrieb ist der violette Pin, der blaue Punkt ist die suchende Person. Ändern Sie Standort, Kategorie oder Bewertungen und beobachten Sie die drei sichtbaren Einträge.</p>';
	return oq_demo_rahmen( 'maps', 'Die lokale Ergebnisliste: Was die Reihenfolge verschiebt', $in, 'Spielmodell mit erfundenen Betrieben. Google nennt Relevanz, Entfernung und Bekanntheit als Hauptfaktoren, veröffentlicht aber keine Gewichtung. Die Gewichtung hier ist eine eigene Annahme und sagt keine echte Position voraus.' );
}

function oq_demo_html_reviews( $atts ) {
	$in = oq_demo_chips( 'oq-rev-fall', 'Welche Bewertung?', array( 'lob' => 'Fünf Sterne', 'kritik' => 'Berechtigte Kritik', 'unfair' => 'Unfair oder falsch' ), 'kritik' )
		. '<div class="oq-demo__schalter" role="group" aria-label="Antwort"><button type="button" class="oq-demo__knopf" data-oq-antwort="schwach" aria-pressed="false">Schwache Antwort</button><button type="button" class="oq-demo__knopf" data-oq-antwort="gut" aria-pressed="true">Gute Antwort</button></div>'
		. '<div class="oq-rev"><div class="oq-rev__karte"><p class="oq-rev__kopf"><span class="oq-rev__avatar" data-oq="ini" aria-hidden="true">MK</span><span><b data-oq="autor">M. Krüger</b><small><span class="oq-rev__sterne" data-oq="sterne" role="img" aria-label="2 von 5 Sternen">★★☆☆☆</span> vor 2 Wochen</small></span></p><p class="oq-rev__text" data-oq="text">Termin wurde zweimal verschoben, ohne dass sich jemand gemeldet hat. Die Arbeit selbst war in Ordnung.</p>'
		. '<div class="oq-rev__antwort"><p class="oq-rev__von">Antwort des Inhabers</p><p data-oq="antwort">Guten Tag Herr Krüger, danke für die offenen Worte. Dass wir uns bei der zweiten Verschiebung nicht gemeldet haben, war unser Fehler. Wir haben die Terminplanung umgestellt, damit Sie und andere Kunden künftig rechtzeitig informiert werden. Gern sprechen wir persönlich: 05251 000 000.</p></div></div>'
		. '<ul class="oq-rev__punkte" aria-live="polite" data-oq="punkte"></ul></div>';
	return oq_demo_rahmen( 'reviews', 'Antworten auf Bewertungen: Wer hier mitliest', $in, 'Erfundene Beispiele. Antworten lesen vor allem spätere Interessenten. Falsche Bewertungen lassen sich bei Google melden, ob sie entfernt werden, entscheidet Google.' );
}

function oq_demo_html_care( $atts ) {
	$in = '<svg class="oq-care__svg" viewBox="0 0 600 300" role="img" aria-label="Modellkurven mit und ohne Pflege"><g class="oq-care__gitter"></g><path class="oq-care__ohne" d=""/><path class="oq-care__mit" d=""/><line class="oq-care__marke" y1="20" y2="270"/></svg>'
		. '<div class="oq-demo__form"><label for="oq-care-monat">Monate nach dem Launch: <output data-oq="monatwert">12</output></label><input id="oq-care-monat" type="range" min="0" max="24" value="12" data-oq="monat">'
		. oq_demo_chips( 'oq-care-stufe', 'Pflege pro Monat', array( 'selten' => 'Gelegentlich', 'regel' => 'Regelmäßig', 'aktiv' => 'Aktiv mit Inhalten' ), 'regel' ) . '</div>'
		. '<p class="oq-demo__ergebnis" aria-live="polite" data-oq="status">Mit laufender Pflege wächst eine Website mit ihrem Umfeld. Ohne Pflege bleibt sie stehen, während Mitbewerber nachziehen.</p>';
	return oq_demo_rahmen( 'care', 'Pflege-Modell: Ihre Website nach dem Launch', $in, 'Modell, keine Prognose. Die Kurven sind vereinfacht und beruhen nicht auf Messdaten. Sie zeigen die Richtung.' );
}

function oq_demo_html_pricefinder( $atts ) {
	$in = '<form class="oq-demo__form" onsubmit="return false">'
		. oq_demo_chips( 'oq-pf-1', '1. Was brauchen Sie?', array( 'neu' => 'Eine neue Website', 'pflege' => 'Betreuung einer bestehenden Website' ), 'neu' )
		. oq_demo_chips( 'oq-pf-2', '2. Wie umfangreich?', array( 'klein' => 'Bis fünf Seiten', 'gross' => 'Viele Unterseiten, Blog oder Shop-Anbindung' ), 'klein' )
		. oq_demo_chips( 'oq-pf-3', '3. Wie wichtig ist Google?', array( 'basis' => 'Grundlagen reichen', 'strategie' => 'Sichtbarkeit ist ein Hauptziel' ), 'basis' )
		. '</form><div class="oq-pf__ergebnis" aria-live="polite" data-oq="ergebnis"><p class="oq-pf__paket">Starter</p><p class="oq-pf__preis">ab 279 EUR</p><p>Bis zu fünf Seiten, für Smartphone, Tablet und Desktop gebaut, mit SEO-Basis und Search Console.</p></div>'
		. '<p><a class="oq-demo__start oq-magnetic" href="https://oriqen.de/kontakt/" target="_blank" rel="noopener">Erstgespräch vereinbaren <span class="oq-pfeil" aria-hidden="true">→</span><span class="oq-sr"> (öffnet in neuem Tab)</span></a></p>';
	return oq_demo_rahmen( 'pricefinder', 'Welches Paket passt?', $in, 'Orientierungswerte: Starter ab 279 EUR, Professional ab 599 EUR, Betreuung ab 149 EUR monatlich. Den verbindlichen Preis legen wir nach dem Erstgespräch fest.' );
}

function oq_demo_html_checklist( $atts ) {
	$fragen = array( 'Ihre Website ist älter als drei Jahre.', 'Sie wissen nicht, für welche Suchbegriffe Sie gefunden werden.', 'Auf dem Smartphone wirkt die Seite eng oder lädt langsam.', 'Ihr Google-Unternehmensprofil ist unvollständig oder lange nicht gepflegt.', 'Über die Website kommen kaum Anfragen.', 'Seitentitel und Beschreibungen haben Sie nie bewusst geschrieben.', 'Mitbewerber erscheinen vor Ihnen, obwohl Sie mehr Erfahrung haben.', 'Sie haben keine Search Console eingerichtet oder schauen nie hinein.' );
	$in = '<ol class="oq-check__liste">';
	foreach ( $fragen as $i => $f ) {
		$in .= '<li><label class="oq-demo__zeile"><input type="checkbox" data-oq="frage"> ' . esc_html( $f ) . '</label></li>';
	}
	$label = $atts['label'] ? $atts['label'] : 'Kostenlose Analyse anfordern';
	$in .= '</ol><p class="oq-demo__ergebnis" aria-live="polite" data-oq="ergebnis">Kreuzen Sie an, was auf Ihre Website zutrifft. Ab drei Treffern lohnt sich ein genauer Blick.</p><p><a class="oq-demo__start oq-magnetic" href="https://oriqen.de/seo/seo-analyse/" target="_blank" rel="noopener">' . esc_html( $label ) . ' <span class="oq-pfeil" aria-hidden="true">→</span><span class="oq-sr"> (öffnet in neuem Tab)</span></a></p>';
	return oq_demo_rahmen( 'checklist', 'Selbstcheck: Lohnt sich die kostenlose Analyse?', $in, 'Ein grober Selbstcheck, keine Analyse. Nichts wird gespeichert oder übertragen.' );
}

function oq_demo_html_brand( $atts ) {
	$in = '<div class="oq-demo__form"><label for="oq-brand-name">Name Ihres Betriebs</label><input id="oq-brand-name" type="text" maxlength="32" value="Tischlerei Eichenwerk" data-oq="name">'
		. oq_demo_chips( 'oq-brand-farbe', 'Farbpaar', array( 'violett' => 'Violett', 'wald' => 'Waldgrün', 'ozean' => 'Ozean', 'terrakotta' => 'Terrakotta' ), 'violett' ) . '</div>'
		. '<div class="oq-brand" data-farbe="violett"><div class="oq-brand__zeichen" data-oq="mono">TE</div><div class="oq-brand__farben"><i></i><i></i></div>'
		. '<div class="oq-brand__karte"><b data-oq="name2">Tischlerei Eichenwerk</b><span>Inhaber · Paderborn</span></div><div class="oq-brand__schild"><span data-oq="mono2">TE</span><b data-oq="name3">Tischlerei Eichenwerk</b></div></div>';
	return oq_demo_rahmen( 'brand', 'Die Grundausstattung einer Beispielmarke', $in, 'Automatisch aus Name und Farbe erzeugt. Eine echte Marke entsteht nicht per Knopfdruck, sondern aus Gesprächen, Skizzen und Tests. Beispielname erfunden.' );
}

function oq_demo_html_feed( $atts ) {
	$posts = array( 'Einblick in die Werkstatt', 'Tipp der Woche', 'Vorher und nachher', 'Unser Team', 'Kundenstimme, mit Erlaubnis', 'Neu im Programm', 'Hinter den Kulissen', 'Häufige Frage', 'Termine frei' );
	$in = '<div class="oq-demo__schalter" role="group" aria-label="Stil des Feeds"><button type="button" class="oq-demo__knopf" data-oq-feed="ruhig" aria-pressed="true">Ruhig</button><button type="button" class="oq-demo__knopf" data-oq-feed="kontrast" aria-pressed="false">Kontrast</button><button type="button" class="oq-demo__knopf" data-oq-feed="bunt" aria-pressed="false">Wechselnd</button></div>'
		. '<div class="oq-feed" data-stil="ruhig"><p class="oq-feed__kopf"><b>@beispielbetrieb</b> · erfundenes Profil</p><ol class="oq-feed__raster">';
	foreach ( $posts as $p ) {
		$in .= '<li><span>' . esc_html( $p ) . '</span></li>';
	}
	$in .= '</ol></div>';
	return oq_demo_rahmen( 'feed', 'So wirkt ein Feed mit System', $in, 'Vorschau eines erfundenen Profils. Ein einheitlicher Stil macht einen Feed auf einen Blick wiedererkennbar.' );
}

function oq_demo_html_beforeafter( $atts ) {
	$vor = esc_url( $atts['before'] );
	$nach = esc_url( $atts['after'] );
	if ( ! $vor || ! $nach ) {
		return '';
	}
	$label = $atts['label'] ? $atts['label'] : 'Vorher und nachher';
	$in = '<div class="oq-ba" style="--oq-ba:50%"><img src="' . $nach . '" alt="' . esc_attr( $label . ': nachher' ) . '" loading="lazy"><div class="oq-ba__vorher"><img src="' . $vor . '" alt="' . esc_attr( $label . ': vorher' ) . '" loading="lazy"></div><span class="oq-ba__griff" aria-hidden="true"></span><span class="oq-ba__tag oq-ba__tag--l">Vorher</span><span class="oq-ba__tag oq-ba__tag--r">Nachher</span></div>'
		. '<label class="oq-sr" for="oq-ba-' . esc_attr( md5( $vor . $nach ) ) . '">Anteil Vorher</label><input class="oq-ba__regler" id="oq-ba-' . esc_attr( md5( $vor . $nach ) ) . '" type="range" min="0" max="100" value="50">';
	return oq_demo_rahmen( 'beforeafter', $label, $in, 'Regler ziehen oder mit den Pfeiltasten bewegen.' );
}
