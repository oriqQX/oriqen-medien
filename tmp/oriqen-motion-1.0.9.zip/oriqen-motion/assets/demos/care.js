/* [oq_demo type="care"] · vereinfachtes Modell, keine Messdaten */
document.querySelectorAll('[data-oq-demo="care"]').forEach(el => {
  const q = s => el.querySelector(`[data-oq="${s}"]`), svg = el.querySelector('svg'), ZIEL = { selten: 52, regel: 74, aktiv: 90 };
  const ohne = m => 30 + 16 * (1 - Math.exp(-m / 2)) - Math.max(0, m - 4) * 1.05;
  const mit = (m, st) => 30 + 16 * (1 - Math.exp(-m / 2)) + (ZIEL[st] - 46) * (1 - Math.exp(-Math.max(0, m - 2) / 9));
  const X = m => 50 + m * (530 / 24), Y = v => 270 - v * 2.4;
  svg.querySelector('.oq-care__gitter').innerHTML = [0, 6, 12, 18, 24].map(m => `<line x1="${X(m)}" x2="${X(m)}" y1="20" y2="270"/><text x="${X(m)}" y="290" text-anchor="middle">${m ? m + ' Mon.' : 'Launch'}</text>`).join('');
  const pfad = (f, bis) => { let d = ''; for (let m = 0; m <= bis; m += .25) d += `${m ? 'L' : 'M'}${X(m).toFixed(1)},${Y(f(m)).toFixed(1)}`; return d; };
  const zeichnen = () => {
    const bis = +q('monat').value, st = el.querySelector('input[name="oq-care-stufe"]:checked').value;
    q('monatwert').textContent = bis;
    svg.querySelector('.oq-care__ohne').setAttribute('d', pfad(ohne, bis));
    svg.querySelector('.oq-care__mit').setAttribute('d', pfad(m => mit(m, st), bis));
    const l = svg.querySelector('.oq-care__marke'); l.setAttribute('x1', X(bis)); l.setAttribute('x2', X(bis));
    q('status').textContent = `Monat ${bis}: Modellwert mit Pflege ${Math.round(mit(bis, st))}, ohne Pflege ${Math.round(ohne(bis))} von 100. Ein Modell, keine Prognose.`;
  };
  el.addEventListener('input', zeichnen); el.addEventListener('change', zeichnen); zeichnen();
});
