/* [oq_demo type="brand"] · Monogramm aus den Initialen */
document.querySelectorAll('[data-oq-demo="brand"]').forEach(el => {
  const q = s => el.querySelector(`[data-oq="${s}"]`), marke = el.querySelector('.oq-brand');
  const neu = () => {
    const name = q('name').value.trim() || 'Ihr Betrieb', w = name.split(/\s+/);
    const ini = (w.length > 1 ? w[0][0] + w[1][0] : name.slice(0, 2)).toUpperCase();
    q('mono').textContent = q('mono2').textContent = ini; q('name2').textContent = q('name3').textContent = name;
    marke.dataset.farbe = el.querySelector('input[name="oq-brand-farbe"]:checked').value;
  };
  el.addEventListener('input', neu); el.addEventListener('change', neu); neu();
});
