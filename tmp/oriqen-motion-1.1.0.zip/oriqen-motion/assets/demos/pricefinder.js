/* [oq_demo type="pricefinder"] · nur Preise wie auf oriqen.de */
document.querySelectorAll('[data-oq-demo="pricefinder"]').forEach(el => {
  const aus = el.querySelector('[data-oq="ergebnis"]'), w = n => el.querySelector(`input[name="${n}"]:checked`)?.value;
  const E = {
    starter: ['Starter', 'ab 279 EUR', 'Bis zu fünf Seiten, für Smartphone, Tablet und Desktop gebaut, mit SEO-Basis und Search Console.'],
    pro: ['Professional', 'ab 599 EUR', 'Mit Unterseiten-Architektur, strategischem SEO-Konzept und Einrichtung des Google-Unternehmensprofils.'],
    pflege: ['Langfristige Betreuung', 'ab 149 EUR monatlich', 'Technik, Sicherheit, Inhalte und Sichtbarkeit laufend im Blick. Für bestehende Websites der passende Einstieg.']
  };
  const neu = () => {
    const k = w('oq-pf-1') === 'pflege' ? 'pflege' : (w('oq-pf-2') === 'gross' || w('oq-pf-3') === 'strategie') ? 'pro' : 'starter';
    aus.innerHTML = `<p class="oq-pf__paket">${E[k][0]}</p><p class="oq-pf__preis">${E[k][1]}</p><p>${E[k][2]}</p>`;
  };
  el.addEventListener('change', neu); neu();
});
