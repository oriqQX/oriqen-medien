/* [oq_demo type="bericht"] · Beispielauswertung, erfundener Betrieb, nichts wird übertragen */
document.querySelectorAll('[data-oq-demo="bericht"]').forEach(el => {
  const q = s => el.querySelector(`[data-oq="${s}"]`);
  let D = {};
  try { D = JSON.parse(q('daten').dataset.json || '{}'); } catch (e) { return; }
  const SR = { gruen: 'Gut', gelb: 'Mit Luft nach oben', rot: 'Größter Hebel' };
  const PLAN = {
    grund: [['finden'], ['begriffe'], ['inhalte']],
    erweitert: [['finden', 'klein'], ['begriffe', 'mittel'], ['technik', 'klein'], ['inhalte', 'mittel']]
  };
  const box = el.querySelector('.oq-ber'), tiles = el.querySelectorAll('[data-oq-bereich]');
  let umfang = 'grund', aktiv = 'finden';
  const esc = t => t.replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  function zeigen() {
    const b = D[aktiv]; if (!b) return;
    const det = q('detail');
    det.dataset.ampel = b[1];
    q('titel').textContent = b[0];
    q('badge').textContent = SR[b[1]];
    q('befund').textContent = b[2];
    q('empfehlung').textContent = b[3];
    let li = b[4].map(p => `<li>${esc(p)}</li>`).join('');
    if (umfang === 'erweitert') li += b[5].map(p => `<li class="ist-plus">${esc(p)} <small>erweitert</small></li>`).join('');
    q('pp').innerHTML = li;
    tiles.forEach(t => t.setAttribute('aria-pressed', String(t.dataset.oqBereich === aktiv)));
  }

  function umfangSetzen(u) {
    umfang = u; box.dataset.umfang = u;
    el.querySelectorAll('[data-oq-umfang]').forEach(k => k.setAttribute('aria-pressed', String(k.dataset.oqUmfang === u)));
    let n = 0, bereiche = 0;
    tiles.forEach(t => {
      const b = D[t.dataset.oqBereich], nur = !b[4].length, an = u === 'erweitert' || !nur;
      t.disabled = !an;
      t.dataset.ampel = an ? b[1] : 'aus';
      t.querySelector('[data-oq-status]').textContent = an ? SR[b[1]] : 'nur in der erweiterten Analyse';
      if (an) { bereiche++; n += b[4].length + (u === 'erweitert' ? b[5].length : 0); }
    });
    q('bilanz').textContent = `${bereiche} Bereiche · ${n} Prüfpunkte`;
    q('plan').innerHTML = PLAN[u].map(([id, a]) => `<li>${esc(D[id][0])}${a ? ` <small>Aufwand ${a}</small>` : ''}</li>`).join('');
    q('satz').textContent = u === 'erweitert'
      ? `Erweiterte Analyse: ${bereiche} Bereiche mit ${n} Prüfpunkten, dazu Technik und Tempo und eine Reihenfolge mit Aufwand. Für alle, die tiefer einsteigen oder selbst umsetzen wollen.`
      : 'Grundanalyse: ein ehrlicher Überblick über fünf Bereiche mit den wichtigsten Hebeln und einer klaren Reihenfolge.';
    if (!D[aktiv][4].length && u === 'grund') aktiv = 'finden';
    zeigen();
  }

  el.querySelectorAll('[data-oq-umfang]').forEach(k => k.addEventListener('click', () => umfangSetzen(k.dataset.oqUmfang)));
  tiles.forEach(t => t.addEventListener('click', () => { if (t.disabled) return; aktiv = t.dataset.oqBereich; zeigen(); }));
  umfangSetzen('grund');
});
