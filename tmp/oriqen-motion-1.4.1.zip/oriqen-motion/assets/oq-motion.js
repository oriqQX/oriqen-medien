/* oriqen Motion · Kern
 * IntersectionObserver für Einflüge, requestAnimationFrame nur für sichtbare Parallax-, Fortschritts- und Maus-Effekte.
 * Bei reduzierter Bewegung und im Elementor-Editor bleibt alles im Endzustand. Nichts wird gespeichert. */
(() => {
  'use strict';
  const d = document, root = d.documentElement;
  const $$ = (s, r = d) => [...r.querySelectorAll(s)];
  const ruhig = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const fein = matchMedia('(pointer: fine) and (hover: hover)').matches;

  function start() {
    const editor = d.body.classList.contains('elementor-editor-active') || d.body.classList.contains('elementor-editor-preview');
    const bewegt = !ruhig && !editor && 'IntersectionObserver' in window;

    /* Wortweise Überschriften: Text bleibt im HTML, aria-label trägt den ganzen Satz */
    $$('.oq-split').forEach(el => {
      const ziel = el.querySelector('.elementor-heading-title') || el;
      if (ziel.dataset.oqGeteilt || !bewegt) return;
      ziel.dataset.oqGeteilt = '1';
      ziel.setAttribute('aria-label', ziel.textContent.trim().replace(/\s+/g, ' '));
      let i = 0;
      const teilen = knoten => [...knoten.childNodes].forEach(k => {
        if (k.nodeType === 3) {
          const frag = d.createDocumentFragment();
          k.textContent.split(/(\s+)/).forEach(t => {
            if (!t) return;
            if (/^\s+$/.test(t)) { frag.append(t); return; }
            const w = d.createElement('span'); w.className = 'oq-w'; w.setAttribute('aria-hidden', 'true');
            const s = d.createElement('span'); s.textContent = t; s.style.setProperty('--oq-i', Math.min(i++, 12)); w.append(s); frag.append(w);
          });
          k.replaceWith(frag);
        } else if (k.nodeType === 1 && k.tagName !== 'BR') teilen(k);
      });
      teilen(ziel);
      ziel.style.setProperty('--oq-stagger', '55ms');
    });

    /* Gestaffelte Kinder: Index als CSS-Variable */
    $$('.oq-stagger').forEach(el => {
      const box = el.querySelector(':scope > .e-con-inner') || el;
      [...box.children].forEach((k, i) => k.style.setProperty('--oq-i', Math.min(i, 8)));
    });

    /* Laufband: Inhalt einmal verdoppeln (Kopie für Screenreader verborgen) */
    $$('.oq-marquee').forEach(el => {
      if (el.querySelector('.oq-marquee-spur')) return;
      const box = el.querySelector(':scope > .e-con-inner') || el;
      const spur = d.createElement('div'); spur.className = 'oq-marquee-spur';
      const teil = d.createElement('div'); teil.className = 'oq-marquee-spur'; teil.style.animation = 'none';
      [...box.children].forEach(k => teil.append(k));
      const kopie = teil.cloneNode(true); kopie.classList.add('oq-marquee-kopie'); kopie.setAttribute('aria-hidden', 'true');
      kopie.querySelectorAll('a, button, input, [tabindex]').forEach(x => x.setAttribute('tabindex', '-1'));
      spur.append(teil, kopie); box.append(spur);
    });

    /* Zähler: Endwert steht im HTML; nur bei Bewegung von 0 hochzählen */
    const zahl = (el, v) => { el.textContent = Math.round(v).toLocaleString('de-DE'); };
    const zaehlen = el => {
      const ziel = parseFloat(el.dataset.to || el.textContent.replace(/\./g, '').replace(',', '.')) || 0, t0 = performance.now(), dauer = 750;
      const tick = t => { const p = Math.min(1, (t - t0) / dauer); zahl(el, ziel * (1 - Math.pow(1 - p, 3))); if (p < 1) requestAnimationFrame(tick); };
      requestAnimationFrame(tick);
    };

    const einflug = '.oq-reveal-up,.oq-reveal-left,.oq-reveal-right,.oq-reveal-scale,.oq-reveal-blur,.oq-stagger,.oq-mask,.oq-split,.oq-highlight,.oq-count';
    if (!bewegt) { $$(einflug).forEach(el => el.classList.add('oq-in')); }
    else {
      $$('.oq-count').forEach(el => { if (el.getBoundingClientRect().top > innerHeight) zahl(el, 0); });
      // Der Bereich reicht weit nach oben: Wird ein Element beim schnellen Scrollen übersprungen, steht es sofort im Endzustand
      const io = new IntersectionObserver(eintraege => eintraege.forEach(e => {
        if (!e.isIntersecting) return;
        const el = e.target; io.unobserve(el);
        if (e.boundingClientRect.bottom < 0) { el.classList.add('oq-in'); if (el.classList.contains('oq-count')) el.textContent = Math.round(parseFloat(el.dataset.to) || 0).toLocaleString('de-DE'); return; }
        el.classList.add('oq-in');
        if (el.classList.contains('oq-count')) zaehlen(el);
      }), { rootMargin: '400000px 0px -8% 0px' });
      $$(einflug).forEach(el => io.observe(el));
    }

    /* Scrollgebundene Effekte: Parallax, Fortschritt, Lesefortschritt. Nur sichtbare Elemente, ein rAF pro Frame. */
    const parallax = bewegt ? $$('.oq-parallax-slow,.oq-parallax-fast') : [];
    const fortschritt = $$('.oq-progress'), balken = $$('.oq-scroll-bar').slice(0, 1);
    if (!bewegt) fortschritt.forEach(el => el.style.setProperty('--oq-p', 1));
    const sichtbar = new Set();
    if ('IntersectionObserver' in window) {
      const sio = new IntersectionObserver(es => es.forEach(e => (e.isIntersecting ? sichtbar.add(e.target) : sichtbar.delete(e.target))), { rootMargin: '100px 0px' });
      [...parallax, ...(bewegt ? fortschritt : [])].forEach(el => sio.observe(el));
    }
    let frame = 0;
    const malen = () => {
      frame = 0; const vh = innerHeight;
      sichtbar.forEach(el => {
        const r = el.getBoundingClientRect();
        if (el.classList.contains('oq-progress')) {
          const p = Math.min(1, Math.max(0, (vh * .7 - r.top) / Math.max(1, r.height)));
          el.style.setProperty('--oq-p', p.toFixed(3));
        } else {
          const f = el.classList.contains('oq-parallax-fast') ? -.14 : -.06;
          el.style.transform = `translate3d(0,${((r.top + r.height / 2 - vh / 2) * f).toFixed(1)}px,0)`;
        }
      });
      if (balken[0]) { const max = root.scrollHeight - vh; balken[0].style.transform = `scaleX(${max > 0 ? (scrollY / max).toFixed(4) : 0})`; }
    };
    const anfordern = () => { if (!frame) frame = requestAnimationFrame(malen); };
    if (parallax.length || fortschritt.length || balken.length) { addEventListener('scroll', anfordern, { passive: true }); addEventListener('resize', anfordern); anfordern(); }

    /* Maus: Neigung, Licht, Magnet. Nur feine Zeiger, nicht auf Touch. */
    if (fein && bewegt) {
      $$('.oq-tilt').forEach(el => {
        el.addEventListener('pointermove', e => { if (e.pointerType !== 'mouse') return; const r = el.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5; el.style.transform = `perspective(900px) rotateX(${(-y * 7).toFixed(2)}deg) rotateY(${(x * 9).toFixed(2)}deg)`; });
        el.addEventListener('pointerleave', () => { el.style.transform = ''; });
      });
      $$('.oq-magnetic').forEach(el => {
        el.addEventListener('pointermove', e => { if (e.pointerType !== 'mouse') return; const r = el.getBoundingClientRect(); el.style.transform = `translate3d(${((e.clientX - r.left - r.width / 2) * .18).toFixed(1)}px,${((e.clientY - r.top - r.height / 2) * .25).toFixed(1)}px,0)`; });
        el.addEventListener('pointerleave', () => { el.style.transform = ''; });
      });
    }
    if (fein) $$('.oq-glow').forEach(el => el.addEventListener('pointermove', e => { const r = el.getBoundingClientRect(); el.style.setProperty('--oq-x', `${e.clientX - r.left}px`); el.style.setProperty('--oq-y', `${e.clientY - r.top}px`); }));

    /* Horizontal wischbar: Mausrad scrollt quer, bis das Ende erreicht ist; dann geht die Seite normal weiter */
    $$('.oq-hscroll').forEach(el => {
      const box = el.querySelector(':scope > .e-con-inner') || el;
      if (!box.hasAttribute('tabindex')) box.setAttribute('tabindex', '0');
      if (!box.getAttribute('aria-label')) box.setAttribute('aria-label', 'Wischbare Liste, mit Pfeiltasten oder Mausrad bewegen');
      box.addEventListener('wheel', e => {
        if (Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
        const max = box.scrollWidth - box.clientWidth;
        if ((e.deltaY > 0 && box.scrollLeft < max - 1) || (e.deltaY < 0 && box.scrollLeft > 0)) { e.preventDefault(); box.scrollLeft += e.deltaY; }
      }, { passive: false });
    });
  }
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', start); else start();
})();
