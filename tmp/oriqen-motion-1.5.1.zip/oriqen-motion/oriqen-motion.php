<?php
/**
 * Plugin Name: oriqen Motion
 * Description: Design- und Bewegungssystem für oriqen.de. CSS-Klassen für Elementor-Elemente (Bewegung, Layout-Muster) und interaktive Bausteine per Shortcode [oq_demo]. Keine externen Requests, keine Cookies, keine Einstellungen.
 * Version: 1.5.1
 * Author: oriqen Digital Studio
 * Author URI: https://oriqen.de/
 * Requires at least: 6.3
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 * Text Domain: oriqen-motion
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'OQ_MOTION_VERSION', '1.5.1' );
define( 'OQ_MOTION_URL', plugin_dir_url( __FILE__ ) );
define( 'OQ_MOTION_DIR', plugin_dir_path( __FILE__ ) );

/**
 * Setzt die Klasse oq-js auf <html>, bevor etwas gerendert wird.
 * Nur dann starten Elemente versteckt. Ohne JavaScript bleibt alles sofort sichtbar.
 */
function oq_motion_head_flag() {
	echo "<script>document.documentElement.classList.add('oq-js');</script>\n";
}
add_action( 'wp_head', 'oq_motion_head_flag', 1 );

/** Kern: auf jeder Seite, klein, defer. */
function oq_motion_enqueue_core() {
	wp_enqueue_style( 'oq-motion', OQ_MOTION_URL . 'assets/oq-motion.css', array(), OQ_MOTION_VERSION );
	wp_enqueue_script( 'oq-motion', OQ_MOTION_URL . 'assets/oq-motion.js', array(), OQ_MOTION_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
}
add_action( 'wp_enqueue_scripts', 'oq_motion_enqueue_core' );

/** Erlaubte Bausteine. Jeder hat eine eigene JS-Datei, die nur geladen wird, wenn der Shortcode auf der Seite steht. */
function oq_motion_demo_types() {
	return array( 'configurator', 'wireframe', 'responsive', 'speed', 'serp', 'maps', 'care', 'pricefinder', 'checklist', 'brand', 'feed', 'beforeafter', 'crawler', 'reviews', 'plan', 'caption', 'notfall', 'logotest', 'kosten', 'bericht' );
}

/**
 * Shortcode [oq_demo type="..."]. Liefert serverseitig lesbares HTML; das Skript macht es bedienbar.
 */
function oq_motion_shortcode( $atts ) {
	$atts = shortcode_atts(
		array(
			'type'   => '',
			'before' => '',
			'after'  => '',
			'label'  => '',
			'ziel'   => '',
		),
		$atts,
		'oq_demo'
	);
	$type = sanitize_key( $atts['type'] );
	if ( ! in_array( $type, oq_motion_demo_types(), true ) ) {
		return '';
	}
	require_once OQ_MOTION_DIR . 'includes/demos.php';
	$fn = 'oq_demo_html_' . $type;
	if ( ! function_exists( $fn ) ) {
		return '';
	}
	wp_enqueue_style( 'oq-demos', OQ_MOTION_URL . 'assets/demos/oq-demos.css', array( 'oq-motion' ), OQ_MOTION_VERSION );
	wp_enqueue_script( 'oq-demo-' . $type, OQ_MOTION_URL . 'assets/demos/' . $type . '.js', array(), OQ_MOTION_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
	return call_user_func( $fn, $atts );
}
add_shortcode( 'oq_demo', 'oq_motion_shortcode' );

/** Blog: [oq_blog] für Übersicht und Archive, [oq_blog_mehr] unter Beiträgen. */
function oq_motion_blog( $atts ) {
	require_once OQ_MOTION_DIR . 'includes/blog.php';
	return oq_blog_shortcode( $atts );
}
function oq_motion_blog_mehr( $atts ) {
	require_once OQ_MOTION_DIR . 'includes/blog.php';
	return oq_blog_mehr_shortcode( $atts );
}
add_shortcode( 'oq_blog', 'oq_motion_blog' );
add_shortcode( 'oq_blog_mehr', 'oq_motion_blog_mehr' );
function oq_motion_archiv_titel() {
	require_once OQ_MOTION_DIR . 'includes/blog.php';
	return oq_archiv_titel_shortcode();
}
add_shortcode( 'oq_archiv_titel', 'oq_motion_archiv_titel' );
