<?php
/**
 * Plugin Name: oriqen Motion
 * Description: Design- und Bewegungssystem für oriqen.de. CSS-Klassen für Elementor-Elemente (Bewegung, Layout-Muster) und interaktive Bausteine per Shortcode [oq_demo]. Keine externen Requests, keine Cookies, keine Einstellungen.
 * Version: 1.7.2
 * Author: oriqen Digital Studio
 * Author URI: https://oriqen.de/
 * Requires at least: 6.3
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 * Text Domain: oriqen-motion
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'OQ_MOTION_VERSION', '1.7.2' );
define( 'OQ_MOTION_URL', plugin_dir_url( __FILE__ ) );
define( 'OQ_MOTION_DIR', plugin_dir_path( __FILE__ ) );

/**
 * Setzt die Klasse oq-js auf <html>, bevor etwas gerendert wird.
 * Nur dann starten Elemente versteckt. Ohne JavaScript bleibt alles sofort sichtbar.
 */
function oq_motion_head_flag() {
	echo "<script>document.documentElement.classList.add('oq-js');</script>\n";
}
add_action( 'wp_head', 'oq_motion_head_flag', 1 );

/** Kern: auf jeder Seite, klein, defer. */
function oq_motion_enqueue_core() {
	wp_enqueue_style( 'oq-motion', OQ_MOTION_URL . 'assets/oq-motion.css', array(), OQ_MOTION_VERSION );
	wp_enqueue_script( 'oq-motion', OQ_MOTION_URL . 'assets/oq-motion.js', array(), OQ_MOTION_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
}
add_action( 'wp_enqueue_scripts', 'oq_motion_enqueue_core' );

/** Startseiten-Bausteine (oq-h-*): nur laden, wenn die Elementor-Daten der Seite sie enthalten. */
function oq_motion_enqueue_home() {
	if ( ! is_singular() ) {
		return;
	}
	$daten = get_post_meta( get_queried_object_id(), '_elementor_data', true );
	if ( ! is_string( $daten ) || false === strpos( $daten, 'oq-h-' ) ) {
		return;
	}
	wp_enqueue_style( 'oq-home', OQ_MOTION_URL . 'assets/home/oq-home.css', array( 'oq-motion' ), OQ_MOTION_VERSION );
	wp_enqueue_script( 'oq-home', OQ_MOTION_URL . 'assets/home/oq-home.js', array(), OQ_MOTION_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
}
add_action( 'wp_enqueue_scripts', 'oq_motion_enqueue_home' );

/** Erlaubte Bausteine. Jeder hat eine eigene JS-Datei, die nur geladen wird, wenn der Shortcode auf der Seite steht. */
function oq_motion_demo_types() {
	return array( 'configurator', 'wireframe', 'responsive', 'speed', 'serp', 'maps', 'care', 'pricefinder', 'checklist', 'brand', 'feed', 'beforeafter', 'crawler', 'reviews', 'plan', 'caption', 'notfall', 'logotest', 'kosten', 'bericht' );
}

/**
 * Shortcode [oq_demo type="..."]. Liefert serverseitig lesbares HTML; das Skript macht es bedienbar.
 */
function oq_motion_shortcode( $atts ) {
	$atts = shortcode_atts(
		array(
			'type'   => '',
			'before' => '',
			'after'  => '',
			'label'  => '',
			'ziel'   => '',
		),
		$atts,
		'oq_demo'
	);
	$type = sanitize_key( $atts['type'] );
	if ( ! in_array( $type, oq_motion_demo_types(), true ) ) {
		return '';
	}
	require_once OQ_MOTION_DIR . 'includes/demos.php';
	$fn = 'oq_demo_html_' . $type;
	if ( ! function_exists( $fn ) ) {
		return '';
	}
	wp_enqueue_style( 'oq-demos', OQ_MOTION_URL . 'assets/demos/oq-demos.css', array( 'oq-motion' ), OQ_MOTION_VERSION );
	wp_enqueue_script( 'oq-demo-' . $type, OQ_MOTION_URL . 'assets/demos/' . $type . '.js', array(), OQ_MOTION_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
	return call_user_func( $fn, $atts );
}
add_shortcode( 'oq_demo', 'oq_motion_shortcode' );

/** Blog: [oq_blog] für Übersicht und Archive, [oq_blog_mehr] unter Beiträgen. */
function oq_motion_blog( $atts ) {
	require_once OQ_MOTION_DIR . 'includes/blog.php';
	return oq_blog_shortcode( $atts );
}
function oq_motion_blog_mehr( $atts ) {
	require_once OQ_MOTION_DIR . 'includes/blog.php';
	return oq_blog_mehr_shortcode( $atts );
}
add_shortcode( 'oq_blog', 'oq_motion_blog' );
add_shortcode( 'oq_blog_mehr', 'oq_motion_blog_mehr' );
function oq_motion_archiv_titel() {
	require_once OQ_MOTION_DIR . 'includes/blog.php';
	return oq_archiv_titel_shortcode();
}
add_shortcode( 'oq_archiv_titel', 'oq_motion_archiv_titel' );

/** Portfolio-Archiv und -Kategorien: 12 Projekte pro Seite, passend zum Dreier-Raster. */
function oq_motion_portfolio_anzahl( $q ) {
	if ( ! is_admin() && $q->is_main_query() && ( $q->is_post_type_archive( 'dt_portfolio' ) || $q->is_tax( 'dt_portfolio_category' ) ) ) {
		$q->set( 'posts_per_page', 12 );
	}
}
add_action( 'pre_get_posts', 'oq_motion_portfolio_anzahl' );

/** Felder fürs Portfolio-Highlight, per REST pflegbar (meta). */
function oq_motion_highlight_felder() {
	if ( ! post_type_exists( 'dt_portfolio' ) ) {
		return;
	}
	add_post_type_support( 'dt_portfolio', 'custom-fields' );
	$recht = function () {
		return current_user_can( 'edit_posts' );
	};
	register_post_meta( 'dt_portfolio', 'oq_highlight', array( 'type' => 'string', 'single' => true, 'show_in_rest' => true, 'default' => '', 'auth_callback' => $recht ) );
	foreach ( array( 'oq_highlight_zitat', 'oq_highlight_person', 'oq_highlight_punkte', 'oq_highlight_kicker', 'oq_highlight_label' ) as $k ) {
		register_post_meta( 'dt_portfolio', $k, array( 'type' => 'string', 'single' => true, 'show_in_rest' => true, 'default' => '', 'sanitize_callback' => 'sanitize_text_field', 'auth_callback' => $recht ) );
	}
}
add_action( 'init', 'oq_motion_highlight_felder', 20 );

/** V2-Bänder (Projektkopf mit Netz, gespiegeltes Band vor dem Erleben-Banner): false = nur für Eingeloggte (Vorschau), true = für alle. */
if ( ! defined( 'OQ_MOTION_V2_LIVE' ) ) {
	define( 'OQ_MOTION_V2_LIVE', false );
}
add_filter( 'body_class', function ( $k ) {
	if ( OQ_MOTION_V2_LIVE ) {
		$k[] = 'oq-v2-live';
	}
	return $k;
} );
