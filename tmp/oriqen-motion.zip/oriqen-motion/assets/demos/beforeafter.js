/* [oq_demo type="beforeafter"] · Regler ist ein echtes range-Feld (Tastatur: Pfeiltasten) */
document.querySelectorAll('[data-oq-demo="beforeafter"]').forEach(el => {
  const ba = el.querySelector('.oq-ba'), r = el.querySelector('.oq-ba__regler');
  const setzen = v => ba.style.setProperty('--oq-ba', v + '%');
  r.addEventListener('input', () => setzen(r.value));
  ba.addEventListener('pointermove', e => { if (e.buttons !== 1) return; const b = ba.getBoundingClientRect(); r.value = Math.round((e.clientX - b.left) / b.width * 100); setzen(r.value); });
  ba.addEventListener('pointerdown', e => { const b = ba.getBoundingClientRect(); r.value = Math.round((e.clientX - b.left) / b.width * 100); setzen(r.value); });
});
