/* [oq_demo type="brand"] · Markenwelt: Name, Charakter und Grundton ergeben ein System. Nur Systemschriften, keine externen Requests. */
document.querySelectorAll('[data-oq-demo="brand"]').forEach(el => {
  const q = s => el.querySelector(`[data-oq="${s}"]`);
  const esc = t => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const mw = el.querySelector('.oq-mw');
  const B = {
    handwerk: { name: 'Tischlerei Eichenwerk', claim: 'Möbel nach Maß aus Paderborn', schild: 'Werkstatt und Ausstellung', post: ['Neu in der Werkstatt', 'Esstisch aus Eiche'], nav: 'Küchen · Möbel · Kontakt' },
    cafe: { name: 'Café Lindenblüte', claim: 'Frühstück und Kuchen in Paderborn', schild: 'Täglich ab 8 Uhr', post: ['Kuchen der Woche', 'Apfel-Streusel'], nav: 'Karte · Frühstück · Feiern' },
    kanzlei: { name: 'Kanzlei Weidenfeld', claim: 'Steuern für Handwerk und Mittelstand', schild: 'Steuerberatung', post: ['Kurz erklärt', 'Belege digital einreichen'], nav: 'Leistungen · Team · Termin' },
    salon: { name: 'Salon Haarwerk', claim: 'Schnitt, Farbe und Pflege in Paderborn', schild: 'Termine nach Vereinbarung', post: ['Neu im Salon', 'Herbstfarben'], nav: 'Leistungen · Preise · Termin' }
  };
  const TON = { wald: [150, 1], ozean: [205, 1], terrakotta: [16, 1], violett: [272, 1], anthrazit: [220, .25] };
  const SERIF_K = '"Palatino Linotype", Palatino, "Book Antiqua", Georgia, serif', SERIF = 'Georgia, "Times New Roman", serif';
  const SANS_H = '"Trebuchet MS", "Segoe UI", sans-serif', SANS = 'Arial, Helvetica, sans-serif', VERD = 'Verdana, Geneva, sans-serif';
  /* Typografie je Charakterstufe: [Überschrift, Name, Großschrift, Sperrung, Gewicht, Text, Name] */
  const TYP = [
    [SERIF_K, 'Palatino', true, '.16em', 400, SANS, 'Arial'],
    [SERIF, 'Georgia', false, '.01em', 700, SANS, 'Arial'],
    [SANS_H, 'Trebuchet MS', true, '.12em', 400, SERIF, 'Georgia'],
    [SANS_H, 'Trebuchet MS', false, '0', 700, VERD, 'Verdana'],
    [SANS, 'Arial', false, '-.02em', 700, VERD, 'Verdana']
  ];
  const TRA = ['traditionell', 'eher traditionell', 'ausgewogen', 'eher modern', 'modern'];
  const LEB = ['ruhig', 'eher ruhig', 'ausgewogen', 'eher lebendig', 'lebendig'];
  /* Farben */
  const hsl2rgb = (h, s, l) => { s /= 100; l /= 100; const k = n => (n + h / 30) % 12, a = s * Math.min(l, 1 - l), f = n => l - a * Math.max(-1, Math.min(k(n) - 3, 9 - k(n), 1)); return [f(0), f(8), f(4)].map(v => Math.round(v * 255)); };
  const hex = rgb => '#' + rgb.map(v => v.toString(16).padStart(2, '0')).join('').toUpperCase();
  const lum = rgb => { const c = rgb.map(v => { v /= 255; return v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); }); return .2126 * c[0] + .7152 * c[1] + .0722 * c[2]; };
  const kon = (a, b) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + .05) / (Math.min(x, y) + .05); };
  const palette = (ton, leb) => {
    const [h, f] = TON[ton], s = Math.round((20 + leb * 13) * f);
    const n = hsl2rgb(h, Math.round(28 * f) + 4, 95);
    let L = 46, p = hsl2rgb(h, s, L);
    while (kon(p, n) < 4.6 && L > 10) { L -= 1; p = hsl2rgb(h, s, L); }
    const a = hsl2rgb((h + 20 + leb * 6) % 360, Math.min(80, Math.round((30 + leb * 10) * Math.max(f, .7))), 55);
    return { p, a, n };
  };
  /* Signet je Charakterstufe, Initialen in der Überschriftenschrift */
  const signet = (ini, typ, tra, leb, farbe, text, deko) => {
    const form = [
      `<path d="M50 6 L90 18 V52 C90 76 70 90 50 96 C30 90 10 76 10 52 V18 Z" fill="${farbe}"/><path d="M50 13 L83 23 V52 C83 72 66 84 50 89 C34 84 17 72 17 52 V23 Z" fill="none" stroke="${text}" stroke-width="1.5" opacity=".55"/>`,
      `<circle cx="50" cy="50" r="44" fill="${farbe}"/><circle cx="50" cy="50" r="37" fill="none" stroke="${text}" stroke-width="1.5" opacity=".55"/>`,
      `<path d="M14 94 V46 A36 36 0 0 1 86 46 V94 Z" fill="${farbe}"/>`,
      `<rect x="8" y="8" width="84" height="84" rx="22" fill="${farbe}"/>`,
      `<circle cx="50" cy="50" r="44" fill="${farbe}"/>`
    ][tra];
    const d = leb >= 3 ? `<circle cx="${tra === 2 ? 72 : 78}" cy="${tra === 2 ? 30 : 22}" r="${leb === 4 ? 9 : 7}" fill="${deko}"/>` : leb === 2 ? `<rect x="30" y="74" width="40" height="5" rx="2.5" fill="${deko}"/>` : '';
    const gr = ini.length > 1 ? 34 : 44, y = tra === 2 ? 72 : 63;
    return `<svg viewBox="0 0 100 100" role="presentation">${form}${d}<text x="50" y="${y}" text-anchor="middle" font-family='${typ[0]}' font-weight="${typ[4]}" font-size="${gr}" letter-spacing="${typ[2] ? 1 : 0}" fill="${text}">${esc(ini)}</text></svg>`;
  };
  /* Ohne System: jeder Kontaktpunkt hat seine eigene Notlösung */
  const CHAOS = {
    karte: { f: '"Courier New", monospace', bg: '#ffffff', c: '#B71C1C', sig: [0, '#1565C0', '#ffffff'], up: false },
    schild: { f: '"Arial Black", Impact, sans-serif', bg: '#F9A825', c: '#111111', sig: null, up: true },
    post: { f: '"Comic Sans MS", "Chalkboard SE", cursive', bg: 'linear-gradient(135deg,#EC407A,#42A5F5)', c: '#ffffff', sig: [4, '#7B1FA2', '#FFEB3B'], up: false },
    web: { f: 'Verdana, Geneva, sans-serif', bg: '#0D47A1', c: '#ffffff', sig: [2, '#43A047', '#ffffff'], up: false }
  };
  let branche = 'handwerk', modus = 'mit', eigenName = false;
  const zeigen = () => {
    const b = B[branche];
    const name = (q('name').value.trim() || b.name).slice(0, 28);
    const tra = +q('tra').value, leb = +q('leb').value, ton = (el.querySelector('input[name="oq-mw-ton"]:checked') || {}).value || 'wald';
    const typ = TYP[tra], pal = palette(ton, leb), P = hex(pal.p), A = hex(pal.a), N = hex(pal.n);
    const w = name.replace(/^(Café|Cafe|Salon|Kanzlei|Tischlerei|Glaserei|Bäckerei|Praxis)\s+/i, '').split(/\s+/).filter(Boolean);
    const ini = ((w.length > 1 ? w[0][0] + w[1][0] : (w[0] || name)[0]) || '?').toUpperCase();
    q('trawert').textContent = TRA[tra]; q('lebwert').textContent = LEB[leb];
    mw.dataset.modus = modus;
    mw.style.cssText = `--p:${P};--a:${A};--n:${N};--fh:${typ[0]};--fb:${typ[5]};--up:${typ[2] ? 'uppercase' : 'none'};--ls:${typ[3]};--fw:${typ[4]}`;
    const sigMit = signet(ini, typ, tra, leb, P, '#ffffff', A);
    const gross = el.querySelector('.oq-mw__sig--gross'), aa = el.querySelector('.oq-mw__aa');
    if (modus === 'mit') { gross.classList.remove('ist-vier'); gross.innerHTML = sigMit; aa.innerHTML = 'Aa'; }
    else {
      gross.classList.add('ist-vier');
      gross.innerHTML = Object.values(CHAOS).map(c => c.sig ? signet(ini, [c.f, '', false, 0, 700], c.sig[0], 0, c.sig[1], c.sig[2], c.sig[2]) : `<svg viewBox="0 0 100 100" role="presentation"><rect x="4" y="22" width="92" height="56" rx="4" fill="#F9A825"/><text x="50" y="60" text-anchor="middle" font-family='"Arial Black",Impact,sans-serif' font-size="30" fill="#111">${esc(ini)}</text></svg>`).join('');
      aa.innerHTML = Object.values(CHAOS).map(c => `<span style="font-family:${c.f.replace(/"/g, "'")}">Aa</span>`).join('');
    }
    q('wort').textContent = name; q('claim').textContent = b.claim;
    const txt = { karte: [name, b.claim], schild: [name, b.schild], post: b.post, web: [name, b.nav] };
    el.querySelectorAll('[data-oq-ort]').forEach(li => {
      const o = li.dataset.oqOrt, f = li.querySelector('.oq-mw__flaeche'), c = CHAOS[o];
      li.querySelector('.oq-mw__t1').textContent = txt[o][0];
      li.querySelector('.oq-mw__t2').textContent = txt[o][1];
      const s = li.querySelector('.oq-mw__sig');
      if (modus === 'mit') { f.removeAttribute('style'); s.innerHTML = sigMit; s.hidden = false; }
      else {
        f.style.cssText = `background:${c.bg};color:${c.c};--fh:${c.f};--fb:${c.f};--up:${c.up ? 'uppercase' : 'none'};--ls:0;--fw:700`;
        s.hidden = !c.sig;
        if (c.sig) s.innerHTML = signet(ini, [c.f, '', false, 0, 700], c.sig[0], 0, c.sig[1], c.sig[2], c.sig[2]);
      }
    });
    const lis = q('farben').children, farben = modus === 'mit' ? [[P, 'Primär'], [A, 'Akzent'], [N, 'Hell']] : [['#B71C1C', 'Rot'], ['#F9A825', 'Gelb'], ['#0D47A1', 'Blau']];
    [...lis].forEach((li, i) => { li.querySelector('i').style.background = farben[i][0]; li.querySelector('span').textContent = `${farben[i][1]} ${farben[i][0]}`; });
    if (modus === 'mit') {
      const k1 = kon(pal.p, [255, 255, 255]), k2 = kon(pal.p, pal.n);
      q('kontrast').textContent = `Weiß auf Primär ${k1.toFixed(1).replace('.', ',')} : 1, Primär auf Hell ${k2.toFixed(1).replace('.', ',')} : 1. Beides erfüllt die Barrierefreiheits-Norm WCAG AA.`;
      q('schriften').textContent = `Überschrift: ${typ[1]} · Text: ${typ[6]}`;
      q('status').textContent = `Mit Markensystem: ein Zeichen, zwei Schriften, drei Farben. Wer Ihr Schild gesehen hat, erkennt auch Ihren Beitrag und Ihre Website wieder.`;
    } else {
      q('kontrast').textContent = 'Dazu Grün, Lila, Pink und Hellblau. Sieben Farben im Umlauf, Kontraste nie geprüft.';
      q('schriften').textContent = 'Fünf Schriften im Umlauf: Courier, Arial Black, Comic Sans, Verdana und was das Schild gerade hatte.';
      q('status').textContent = 'Ohne Markensystem: vier Logo-Varianten, fünf Schriften, sieben Farben. Derselbe Betrieb, aber jeder Kontakt wirkt wie ein anderer.';
    }
  };
  el.addEventListener('change', e => {
    if (e.target.name === 'oq-mw-branche') { branche = e.target.value; if (!eigenName) q('name').value = B[branche].name; }
    zeigen();
  });
  q('name').addEventListener('input', () => { eigenName = q('name').value.trim() !== ''; zeigen(); });
  el.addEventListener('input', e => { if (e.target.type === 'range') zeigen(); });
  el.querySelectorAll('[data-oq-sys]').forEach(k => k.addEventListener('click', () => {
    modus = k.dataset.oqSys;
    el.querySelectorAll('[data-oq-sys]').forEach(x => x.setAttribute('aria-pressed', String(x === k)));
    zeigen();
  }));
  zeigen();
});
