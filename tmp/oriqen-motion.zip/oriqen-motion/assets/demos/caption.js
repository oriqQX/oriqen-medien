/* [oq_demo type="caption"] · Bildunterschrift: Schnitt bei ~125 Zeichen, Hashtag-Grenze, einfache Textregeln */
document.querySelectorAll('[data-oq-demo="caption"]').forEach(el => {
  const q = s => el.querySelector(`[data-oq="${s}"]`);
  const SCHNITT = 125;
  const B = {
    handwerk: {
      name: 'tischlerei.holm', ini: 'TH', farbe: '#a8794f', bild: 'Esstisch aus Eiche',
      schwach: 'Wieder ein tolles Projekt fertig 😍🔥 Danke an alle! #tischler #holz #handwerk #handmade #interior #design #love #instagood',
      gut: 'Eiche, geölt, 2,40 Meter: Dieser Esstisch steht jetzt in einem Altbau in Paderborn. Die Platte stammt aus einem einzigen Stamm, die Kanten haben wir bewusst natürlich gelassen. Sie planen etwas Ähnliches? Schreiben Sie uns eine Nachricht oder rufen Sie an. #tischlerei #paderborn #massivholz'
    },
    cafe: {
      name: 'cafe.lindenbluete', ini: 'CL', farbe: '#8aa37b', bild: 'Apfel-Streuselkuchen',
      schwach: 'Heute wieder lecker 😋☕ Kommt vorbei!!! #cafe #coffee #kuchen #foodie #yummy #instafood #sweet',
      gut: 'Neu ab Samstag: Apfel-Streuselkuchen nach dem Rezept unserer Oma, mit Äpfeln vom Hof nebenan. Jeden Samstag ab 9 Uhr bei uns in Paderborn, solange der Vorrat reicht. Für Gruppen ab sechs Personen reservieren Sie am besten per Nachricht. #paderborn #cafe #kuchen'
    },
    beratung: {
      name: 'kanzlei.weidenfeld', ini: 'KW', farbe: '#5b7bb5', bild: 'Belege digital',
      schwach: 'Steuern sind kompliziert? Wir helfen! 📊 Mehr Infos im Link. #steuern #steuerberater #finanzen #business #tipps #erfolg',
      gut: 'Belege digital einreichen statt im Schuhkarton sammeln: So kommt Ihre Buchhaltung ohne Rückfragen durch den Monat. In vier Bildern zeigen wir, wie der Upload bei uns funktioniert. Fragen dazu beantworten wir in Paderborn gern am Telefon oder per Nachricht. #steuerberatung #paderborn #buchhaltung'
    }
  };
  const ORT = /paderborn|owl|ostwestfalen|bielefeld|lippstadt|salzkotten|delbrück|bad lippspringe|büren|schloß neuhaus|schloss neuhaus|elsen|gütersloh|detmold|in der region|bei uns vor ort/i;
  const HANDLUNG = /schreib|nachricht|ruf(en)? sie|anruf|termin|whatsapp|link in der bio|link im profil|bewirb|bewerb|vorbei|reservier|buch(en|ung)|meld(en|et) sie|frag(en)? sie/i;
  const knoepfe = el.querySelectorAll('[data-oq-cap]'), feld = q('eingabe');
  let offen = false, branche = 'handwerk', art = 'schwach';
  const woerter = t => t.replace(/#[\p{L}\p{N}_]+/gu, ' ').replace(/[^\p{L}\p{N}\s,.:;!?-]/gu, ' ').split(/\s+/).filter(w => /[\p{L}\p{N}]/u.test(w)).length;
  const pruefen = () => {
    const t = feld.value, b = B[branche];
    const tags = (t.match(/#[\p{L}\p{N}_]+/gu) || []).length, vorne = [...t].slice(0, SCHNITT).join('');
    const lang = [...t].length > SCHNITT;
    q('sichtbar').textContent = lang && !offen ? vorne.replace(/\s+\S*$/, '') : t;
    q('rest').hidden = true;
    q('mehr').hidden = !lang;
    q('mehr').textContent = offen ? 'weniger' : '… mehr';
    q('zaehler').innerHTML = `${[...t].length} von 2.200 Zeichen · <span class="${tags > 5 ? 'zu-lang' : ''}">${tags} ${tags === 1 ? 'Hashtag' : 'Hashtags'}${tags > 5 ? ', Instagram nimmt höchstens fünf' : ''}</span>`;
    const p = [
      [woerter(vorne) >= 10, 'Konkrete Aussage vor „… mehr“', 'Vor dem Schnitt steht kaum Inhalt. Was zeigt das Bild, warum ist es interessant?'],
      [ORT.test(t), 'Ort oder Region genannt', 'Kein Ort genannt. Für lokale Betriebe hilft der Ortsname, auch in der Suche.'],
      [HANDLUNG.test(t), 'Klarer nächster Schritt für den Leser', 'Kein nächster Schritt: Anruf, Nachricht oder Termin fehlen.'],
      [tags <= 5, 'Höchstens fünf passende Hashtags', 'Mehr als fünf Hashtags. Instagram lässt seit Ende 2025 nur noch fünf zu.'],
      [!/^\s*#/.test(t) && !/[!?]{2,}/.test(t), 'Ruhiger Ton ohne Zeichenketten', 'Hashtag am Anfang oder Zeichenketten wie „!!!“ wirken unruhig.']
    ];
    q('punkte').innerHTML = p.map(([ok, ja, nein]) => `<li class="${ok ? 'ist-ok' : 'ist-nein'}">${ok ? ja : nein}</li>`).join('');
    q('name').textContent = b.name; q('name2').textContent = b.name; q('avatar').textContent = b.ini;
    q('bild').style.setProperty('--f', b.farbe); q('bildtext').textContent = b.bild;
  };
  const laden = () => { feld.value = B[branche][art]; offen = false; knoepfe.forEach(k => k.setAttribute('aria-pressed', String(k.dataset.oqCap === art))); pruefen(); };
  knoepfe.forEach(k => k.addEventListener('click', () => { art = k.dataset.oqCap; laden(); }));
  el.querySelectorAll('input[name="oq-cap-branche"]').forEach(r => r.addEventListener('change', () => { branche = r.value; laden(); }));
  q('mehr').addEventListener('click', () => { offen = !offen; pruefen(); });
  feld.addEventListener('input', () => { knoepfe.forEach(k => k.setAttribute('aria-pressed', 'false')); pruefen(); });
  laden();
});
