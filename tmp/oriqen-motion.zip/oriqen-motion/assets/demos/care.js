/* [oq_demo type="care"] · Wartungs-Cockpit. Vereinfachtes Modell, erfundene Beispielwebsite, keine Messdaten */
document.querySelectorAll('[data-oq-demo="care"]').forEach(el => {
  const q = s => el.querySelector(`[data-oq="${s}"]`);
  const sek = v => v.toFixed(1).replace('.', ',') + ' s';
  const monate = m => m === 1 ? 'einem Monat' : `${m} Monaten`;
  /* Jede Kachel liefert [Ampel, Wert, Notiz] für Monat m */
  const K = {
    updates: {
      ohne: m => { const n = Math.min(23, Math.ceil(m * 1.4)); return m < 2 ? ['gruen', 'Alles aktuell', 'WordPress, Theme und Plugins'] : [m >= 5 ? 'rot' : 'gelb', `${n} Updates offen`, m >= 5 ? 'Darunter mindestens ein Sicherheitsupdate' : 'Liegen bereit, niemand spielt sie ein']; },
      mit: () => ['gruen', 'Alles aktuell', 'Nach Sicherung eingespielt und geprüft']
    },
    sicher: {
      ohne: m => m < 5 ? ['gruen', 'Keine bekannte Lücke', 'Bisher Glück gehabt'] : ['rot', 'Bekannte Lücke offen', 'Ein Plugin ist angreifbar, das Update wäre da'],
      mit: () => ['gruen', 'Lücken geschlossen', 'Login geschützt, Dateien überwacht']
    },
    backup: {
      ohne: m => m < 1 ? ['gelb', 'Vom Hosting', 'Wiederherstellung nie getestet'] : ['gelb', 'Ungeprüft', `Seit ${monate(m)} hat niemand eine Wiederherstellung versucht`],
      mit: () => ['gruen', 'Extern gesichert', 'Wiederherstellung regelmäßig getestet']
    },
    php: {
      ohne: m => m < 12 ? ['gruen', 'Unterstützte Version', 'Basis, auf der WordPress läuft'] : m < 18 ? ['gelb', 'Nur noch Sicherheitskorrekturen', 'Umstieg sollte geplant werden'] : ['rot', 'Ohne Sicherheitsupdates', 'Die Version wird nicht mehr gepflegt'],
      mit: m => m < 18 ? ['gruen', 'Unterstützte Version', 'Umstieg rechtzeitig geplant'] : ['gruen', 'Aktuelle Version', 'Umstieg nach Test erledigt']
    },
    ssl: {
      ohne: m => m < 8 ? ['gruen', 'Gültig', 'Verlängert sich automatisch'] : ['gelb', 'Unbeobachtet', 'Hakt die Verlängerung, merkt es zuerst ein Besucher'],
      mit: () => ['gruen', 'Gültig', 'Ablauf von Zertifikat und Domain im Blick']
    },
    speed: {
      ohne: m => { const v = 1.9 + m * 0.075; return [v > 4 ? 'rot' : v > 2.5 ? 'gelb' : 'gruen', sek(v), v > 2.5 ? 'Neue Bilder unkomprimiert, alte Skripte bremsen' : 'Größtes Element auf dem Smartphone']; },
      mit: m => ['gruen', sek(1.9 - Math.min(m, 6) * 0.03), 'Bilder komprimiert, Ballast entfernt']
    },
    inhalt: {
      ohne: m => m <= 3 ? ['gruen', 'Aktuell', 'Texte, Zeiten, Team, Angebote'] : [m >= 12 ? 'rot' : 'gelb', `Seit ${monate(m)} unverändert`, m >= 12 ? 'Öffnungszeiten und Team stimmen nicht mehr' : 'Neues aus dem Betrieb fehlt'],
      mit: () => ['gruen', 'Diesen Monat aktualisiert', 'Neues Projekt, aktuelle Zeiten']
    },
    monitor: {
      ohne: () => ['gelb', 'Niemand schaut zu', 'Ausfälle fallen zuerst Kunden auf'],
      mit: () => ['gruen', 'Läuft rund um die Uhr', 'Erreichbarkeit wird laufend geprüft']
    }
  };
  const LOG = [
    [2, 'Erste Plugin-Updates liegen bereit. Niemand spielt sie ein.', 'Updates nach Sicherung eingespielt, Seiten geprüft.'],
    [5, 'Für ein Formular-Plugin wird eine Sicherheitslücke bekannt. Das Update wäre da.', 'Lücke im Formular-Plugin zeitnah geschlossen, vorher gesichert.'],
    [8, 'Die Öffnungszeiten auf der Website stimmen nicht mehr.', 'Öffnungszeiten und Teamseite aktualisiert.'],
    [11, 'Ein Plugin wird vom Entwickler eingestellt und bekommt keine Updates mehr.', 'Eingestelltes Plugin durch eine gepflegte Alternative ersetzt.'],
    [14, 'Neue Fotos wurden unkomprimiert hochgeladen. Auf dem Smartphone lädt die Seite spürbar langsamer.', 'Neue Fotos komprimiert, Ladezeit bleibt im grünen Bereich.'],
    [18, 'Die PHP-Version auf dem Server bekommt keine Sicherheitsupdates mehr.', 'Umstieg auf eine aktuelle PHP-Version, vorher in Ruhe getestet.'],
    [21, 'Ein Theme-Update passt nicht mehr zu den alten Plugins. Jedes Update wird zum Risiko.', 'Saisonale Angebotsseite veröffentlicht, Google-Profil verlinkt.'],
    [24, 'Die Website wirkt veraltet. Ein teurer Neustart steht im Raum.', 'Zwei Jahre nach dem Launch: technisch aktuell, inhaltlich gewachsen.']
  ];
  const TEXT = {
    ohne: [
      [0, 'Zum Launch ist alles grün. Ab jetzt beginnt die Website zu altern, wenn sich niemand kümmert.'],
      [5, 'Noch sieht man von außen kaum etwas. Hinter den Kulissen sammeln sich offene Updates.'],
      [12, 'Jetzt sind die Baustellen auch für Besucher spürbar: alte Inhalte, langsamere Ladezeit, eine offene Lücke.'],
      [18, 'Viele kleine Versäumnisse sind zu einem großen Risiko geworden. Aufräumen kostet jetzt deutlich mehr als laufende Pflege.']
    ],
    mit: [
      [0, 'Mit Betreuung bleibt das Cockpit grün. Nicht weil nichts passiert, sondern weil jemand rechtzeitig reagiert.'],
      [12, 'Die gleichen Ereignisse wie ohne Betreuung, nur ohne Folgen. Und die Website wächst nebenbei mit Ihrem Betrieb.']
    ]
  };
  let modus = 'ohne';
  const zeigen = () => {
    const m = +q('monat').value;
    q('monatwert').textContent = m;
    el.querySelector('.oq-cock').dataset.modus = modus;
    const n = { gruen: 0, gelb: 0, rot: 0 };
    el.querySelectorAll('[data-oq-kachel]').forEach(li => {
      const [a, w, t] = K[li.dataset.oqKachel][modus](m);
      n[a]++;
      if (li.dataset.ampel !== a) { li.dataset.ampel = a; li.classList.remove('ist-neu'); void li.offsetWidth; li.classList.add('ist-neu'); }
      li.querySelector('.oq-cock__wert').textContent = w;
      li.querySelector('.oq-cock__notiz').textContent = t;
      li.querySelector('[data-oq-ampel]').textContent = `Status: ${a === 'gruen' ? 'grün' : a}`;
    });
    q('bilanz').textContent = `${n.gruen} grün · ${n.gelb} gelb · ${n.rot} rot`;
    const ev = LOG.filter(e => e[0] <= m).slice(-4).reverse();
    q('log').innerHTML = ev.length ? ev.map(e => `<li class="${modus === 'mit' ? 'ist-ok' : 'ist-nein'}"><b>Monat ${e[0]}</b> ${modus === 'mit' ? e[2] : e[1]}</li>`).join('') : '<li><b>Launch</b> Die Website ist online. Alles frisch.</li>';
    const t = TEXT[modus].filter(e => e[0] <= m).pop()[1];
    q('status').textContent = `Monat ${m}, ${modus === 'mit' ? 'mit' : 'ohne'} Betreuung: ${t}`;
  };
  el.querySelectorAll('[data-oq-modus]').forEach(b => b.addEventListener('click', () => {
    modus = b.dataset.oqModus;
    el.querySelectorAll('[data-oq-modus]').forEach(x => x.setAttribute('aria-pressed', String(x === b)));
    zeigen();
  }));
  q('monat').addEventListener('input', zeigen);
  zeigen();
});
