/* [oq_demo type="checklist"] · grober Selbstcheck, nichts wird übertragen */
document.querySelectorAll('[data-oq-demo="checklist"]').forEach(el => {
  const aus = el.querySelector('[data-oq="ergebnis"]'), boxen = el.querySelectorAll('[data-oq="frage"]');
  el.addEventListener('change', () => {
    const n = [...boxen].filter(b => b.checked).length;
    aus.textContent = n === 0 ? 'Kreuzen Sie an, was auf Ihre Website zutrifft. Ab drei Treffern lohnt sich ein genauer Blick.'
      : n < 3 ? `${n} von 8 Punkten treffen zu. Ihre Website steht vermutlich solide da; die kostenlose Analyse zeigt, wo noch Luft ist.`
      : `${n} von 8 Punkten treffen zu. Die kostenlose Analyse lohnt sich: Sie sehen, welche Stellen am meisten bewirken.`;
  });
});
