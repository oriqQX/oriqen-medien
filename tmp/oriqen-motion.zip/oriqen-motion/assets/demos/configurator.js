/* [oq_demo type="configurator"] · alle Betriebe sind erfundene Beispiele */
(() => {
  const B = {
    handwerk: { n: 'Tischlerei Eichenwerk', k: 'Tischlerei in Paderborn', h: 'Möbel nach Maß, gebaut in Paderborn.', p: 'Küchen, Einbauschränke und Innenausbau aus unserer Werkstatt.', c: 'Termin anfragen', l: ['Küchen', 'Einbaumöbel', 'Innenausbau'] },
    gastro: { n: 'Café Lindgrün', k: 'Café in Paderborn', h: 'Frühstück, Kuchen und Zeit für Gespräche.', p: 'Hausgemachter Kuchen, Frühstück bis 14 Uhr, Raum für Ihre Feier.', c: 'Tisch reservieren', l: ['Frühstück', 'Kuchen', 'Feiern'] },
    praxis: { n: 'Physio Lindenhof', k: 'Physiotherapie in Paderborn', h: 'Wieder schmerzfrei bewegen.', p: 'Krankengymnastik, manuelle Therapie und Hausbesuche.', c: 'Termin vereinbaren', l: ['Krankengymnastik', 'Manuelle Therapie', 'Hausbesuche'] },
    handel: { n: 'Radhaus Speiche', k: 'Fahrradladen in Paderborn', h: 'Räder, Werkstatt und Beratung unter einem Dach.', p: 'E-Bikes, Stadträder und Kinderräder. Reparatur oft am selben Tag.', c: 'Werkstatttermin', l: ['E-Bikes', 'Werkstatt', 'Leasing'] }
  };
  const R = {
    handwerk: ['Massivholz oder Furnier?', 'Küche planen: fünf Fragen vorab', 'So pflegen Sie Arbeitsplatten'],
    gastro: ['Unser Kuchen der Woche', 'Frühstück für Gruppen', 'Feiern im Café: so geht es'],
    praxis: ['Rückenübungen fürs Büro', 'Was passiert beim ersten Termin?', 'Hausbesuch: wann er möglich ist'],
    handel: ['E-Bike-Akku richtig laden', 'Fahrrad winterfest machen', 'Leasing in drei Schritten']
  };
  const NAV = { onepager: 'Start · Leistungen · Ablauf · Kontakt', klein: 'Leistungen · Über uns · Kontakt', magazin: 'Leistungen · Ratgeber · Kontakt' };
  const P = { onepager: '<strong>Starter ab 279 EUR</strong>. Eine lange Seite mit allen Abschnitten, für jedes Gerät gebaut.', klein: '<strong>Starter ab 279 EUR</strong>. Bis zu fünf Seiten, für Smartphone, Tablet und Desktop gebaut.', magazin: '<strong>Professional ab 599 EUR</strong>. Mit Unterseiten-Architektur und strategischem SEO-Konzept.' };
  const dom = n => n.toLowerCase().replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/ß/g, 'ss').replace(/é/g, 'e').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') + '.de';
  document.querySelectorAll('[data-oq-demo="configurator"]').forEach(el => {
    const mock = el.querySelector('.oq-mock'), q = s => el.querySelector(`[data-oq="${s}"]`);
    const wert = n => el.querySelector(`input[name="${n}"]:checked`)?.value;
    /* Zusatzbereiche für One-Pager (weitere Abschnitte auf derselben Seite) und Magazin (Ratgeber-Beiträge) */
    const seite = mock.querySelector('.oq-mock__seite') || mock;
    const blog = document.createElement('div'); blog.className = 'oq-mock__blog';
    blog.innerHTML = '<p>Ratgeber</p><div>' + [1, 2, 3].map(i => `<span><i></i><b data-oq="r${i}"></b><small>${['12.', '05.', '28.'][i - 1]}${['10.', '10.', '09.'][i - 1]}2026</small></span>`).join('') + '</div>';
    const teile = document.createElement('div'); teile.className = 'oq-mock__abschnitte';
    teile.innerHTML = ['Über uns', 'So arbeiten wir', 'Stimmen und Fotos', 'Kontaktformular'].map(t => `<span>${t}</span>`).join('');
    seite.append(blog, teile);
    const neu = () => {
      const b = B[wert('oq-branche')] || B.handwerk, typ = wert('oq-typ');
      mock.dataset.stil = wert('oq-stil'); mock.dataset.farbe = wert('oq-farbe'); mock.dataset.typ = typ;
      const nav = mock.querySelector('.oq-mock__nav'); if (nav) nav.textContent = NAV[typ] || NAV.klein;
      (R[wert('oq-branche')] || R.handwerk).forEach((t, i) => { q('r' + (i + 1)).textContent = t; });
      q('name').textContent = b.n + ' (Beispiel)'; q('domain').textContent = dom(b.n);
      ['k', 'h', 'p', 'c'].forEach((k, i) => { q(['kicker', 'h', 'p', 'cta'][i]).textContent = b[k]; });
      b.l.forEach((t, i) => { q('l' + (i + 1)).textContent = t; });
      q('paket').innerHTML = 'Passender Einstieg: ' + P[typ];
    };
    el.addEventListener('change', neu); neu();
  });
})();
