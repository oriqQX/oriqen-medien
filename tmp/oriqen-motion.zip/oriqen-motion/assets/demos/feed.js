/* [oq_demo type="feed"] · erfundene Profile: Bio, Link, Highlights und Raster einzeln zuschalten */
document.querySelectorAll('[data-oq-demo="feed"]').forEach(el => {
  const q = s => el.querySelector(`[data-oq="${s}"]`);
  const esc = t => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const B = {
    handwerk: {
      name: 'tischlerei.holm', ini: 'TH', farben: ['#3b2a1e', '#a8794f', '#efe4d6'],
      bio: ['Tischlerei Holm · Paderborn', 'Küchen, Einbaumöbel und Innenausbau nach Maß', 'Beratung in der Werkstatt, Termin per Nachricht'],
      link: 'tischlerei-holm.de · Impressum', high: ['Projekte', 'Ablauf', 'Team', 'Kontakt'],
      mit: [['Projekt', 'Esstisch Eiche'], ['Wissen', 'Welches Holz?'], ['Team', 'Neu: Jonas'], ['Vorher', 'Altbau-Küche'], ['Projekt', 'Einbauschrank'], ['Stimme', 'Kundin, mit Erlaubnis'], ['Wissen', 'Öl oder Lack?'], ['Einblick', 'Neue Maschine'], ['Termine', 'Frühjahr frei']],
      ohne: ['Stockfoto Werkzeug', 'ANGEBOT!!!', 'Text zu klein zum Lesen', 'Bild von 2021', 'Werbeplakat abfotografiert', 'Schief zugeschnitten', 'Fremdes Meme', 'Unscharf', 'Logo riesig']
    },
    cafe: {
      name: 'cafe.lindenbluete', ini: 'CL', farben: ['#2f3b2c', '#8aa37b', '#f4efe3'],
      bio: ['Café Lindenblüte · Paderborn', 'Frühstück, hausgemachter Kuchen, Kaffee aus der Region', 'Täglich 8 bis 18 Uhr, Reservierung per Nachricht'],
      link: 'cafe-lindenbluete.de · Impressum', high: ['Karte', 'Kuchen', 'Team', 'Feiern'],
      mit: [['Neu', 'Apfel-Streusel'], ['Einblick', 'Backstube, 6 Uhr'], ['Team', 'Unsere Baristas'], ['Karte', 'Frühstück'], ['Wissen', 'Guter Kaffee'], ['Stimme', 'Gast, mit Erlaubnis'], ['Einblick', 'Terrasse fertig'], ['Neu', 'Kuchen der Woche'], ['Feiern', 'Herbst anfragen']],
      ohne: ['Stockfoto Latte Art', 'Filter-Overkill', 'Speisekarte als Foto', 'Bild von 2022', 'Gewinnspiel?!', 'Dunkel und unscharf', 'Fremdes Zitat', 'Text abgeschnitten', 'Logo riesig']
    },
    beratung: {
      name: 'kanzlei.weidenfeld', ini: 'KW', farben: ['#1d2a44', '#5b7bb5', '#eef1f7'],
      bio: ['Steuerkanzlei Weidenfeld · Paderborn', 'Steuern und Buchhaltung für Handwerk und Mittelstand', 'Erstgespräch per Nachricht oder Telefon'],
      link: 'kanzlei-weidenfeld.de · Impressum', high: ['Team', 'Ablauf', 'Wissen', 'Kontakt'],
      mit: [['Wissen', 'Belege digital'], ['Team', 'Wer Sie betreut'], ['Wissen', 'Fristen im Blick'], ['Einblick', 'Ein Tag bei uns'], ['Wissen', 'Gründen: zuerst'], ['Stimme', 'Mandant, mit Erlaubnis'], ['Termine', 'Sprechstunde'], ['Wissen', 'Lohn: häufige Fragen'], ['Team', 'Ausbildung 2027']],
      ohne: ['Stockfoto Handschlag', 'Paragrafen-Wüste', 'Clipart Taschenrechner', 'Bild von 2020', 'Text zu klein', 'Schief zugeschnitten', 'Fremder Spruch', 'Grau in grau', 'Logo riesig']
    }
  };
  const PUNKTE = {
    bio: ['Die Bio nennt Leistung, Ort und den Weg zum Kontakt', 'Die Bio sagt nichts über Leistung und Ort'],
    link: ['Website und Impressum sind in zwei Klicks erreichbar', 'Kein Link, kein Impressum: rechtlich und für Besucher eine Lücke'],
    high: ['Highlights führen zu Projekten, Ablauf und Kontakt', 'Keine Highlights: Besucher finden keinen Einstieg'],
    raster: ['Einheitliche Farben und feste Formate, im 3:4-Raster gestaltet', 'Zufällige Bilder, abgeschnittene Schrift, kein Wiedererkennungswert']
  };
  const HINWEIS = ['Ein Besucher entscheidet in Sekunden, ob er bleibt. So wirkt das Profil eher verlassen.', 'Ein Anfang. Besucher sehen, dass es den Betrieb gibt, aber noch nicht, warum sie bleiben sollten.', 'Halb gepflegt. Das Profil wirkt aktiv, aber noch nicht wie aus einem Guss.', 'Fast fertig. Ein Punkt fehlt noch, damit das Profil professionell wirkt.', 'Wer jetzt auf das Profil kommt, erkennt in Sekunden, was Sie machen, wo und wie man Sie erreicht.'];
  const teile = [...el.querySelectorAll('[data-oq-teil]')];
  const zeigen = () => {
    const b = B[(el.querySelector('input[name="oq-feed-branche"]:checked') || {}).value || 'handwerk'];
    const an = Object.fromEntries(teile.map(t => [t.dataset.oqTeil, t.checked]));
    const prof = q('profil');
    prof.style.setProperty('--f1', b.farben[0]); prof.style.setProperty('--f2', b.farben[1]); prof.style.setProperty('--f3', b.farben[2]);
    prof.dataset.raster = an.raster ? 'mit' : 'ohne';
    q('name').textContent = b.name;
    q('avatar').textContent = an.bio || an.raster ? b.ini : '?';
    q('avatar').classList.toggle('ist-marke', an.bio || an.raster);
    q('bio').innerHTML = an.bio ? b.bio.map(esc).join('<br>') : 'Willkommen auf unserer Seite!';
    q('link').hidden = !an.link; q('link').textContent = '↗ ' + b.link;
    q('high').innerHTML = an.high ? b.high.map(h => `<li><span aria-hidden="true"></span>${esc(h)}</li>`).join('') : '';
    q('high').hidden = !an.high;
    [...q('raster').children].forEach((li, i) => {
      if (an.raster) { const [f, t] = b.mit[i]; li.innerHTML = `<span><small>${esc(f)}</small>${esc(t)}</span>`; li.className = 'f' + ((i + Math.floor(i / 3)) % 3); }
      else { li.innerHTML = `<span>${esc(b.ohne[i])}</span>`; li.className = 'z' + (i % 5); }
    });
    const n = Object.values(an).filter(Boolean).length;
    q('punkte').innerHTML = Object.keys(PUNKTE).map(k => `<li class="${an[k] ? 'ist-ok' : 'ist-nein'}">${PUNKTE[k][an[k] ? 0 : 1]}</li>`).join('');
    q('status').textContent = `${n} von 4 Punkten gepflegt. ${HINWEIS[n]}`;
  };
  el.addEventListener('change', zeigen);
  zeigen();
});
