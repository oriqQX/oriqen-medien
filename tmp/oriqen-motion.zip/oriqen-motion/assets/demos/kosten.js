/* [oq_demo type="kosten"] · Kostenplan: Wer bekommt welchen Euro? · Preise wie auf oriqen.de, Drittkosten als Spannen · Startzustand identisch mit demos.php */
document.querySelectorAll('[data-oq-demo="kosten"]').forEach(el => {
  const q = s => el.querySelector(s), w = n => el.querySelector(`input[name="${n}"]:checked`)?.value;
  /* oriqen: Untergrenzen. einmalig in EUR, monatlich in EUR */
  const WEB = { keine: 0, starter: 279, pro: 599 }, MARKE = { keins: 0, logo: 29, cd: 149 }, SOCIAL = { nichts: 0, mini: 59, profil: 129 };
  /* Drittkosten pro Jahr: [min, max] */
  const DRITT = { hosting: [60, 180], domain: [15, 20], consent: [49, 49], recht: [71, 119] };
  const fmt = n => n.toLocaleString('de-DE') + ' EUR';
  let jahr = 1;
  const neu = () => {
    const einmal = jahr === 1 ? WEB[w('oq-ko-web')] + MARKE[w('oq-ko-marke')] + SOCIAL[w('oq-ko-social')] : 0;
    const lfd = w('oq-ko-pflege') === 'mit' ? 149 * 12 : 0;
    let dmin = 0, dmax = 0;
    el.querySelectorAll('[data-oq-dritt]').forEach(c => { if (c.checked) { dmin += DRITT[c.dataset.oqDritt][0]; dmax += DRITT[c.dataset.oqDritt][1]; } });
    const summe = einmal + lfd + dmin;
    const dtxt = dmin === dmax ? (dmin ? 'ab ' + fmt(dmin) : '0 EUR') : `${dmin.toLocaleString('de-DE')} bis ${fmt(dmax)}`;
    q('[data-oq="zeitraum"]').textContent = jahr === 1 ? 'Erstes Jahr, Richtwert' : 'Jedes weitere Jahr, Richtwert';
    q('[data-oq="summe"]').textContent = summe ? 'ab ' + fmt(summe) : '0 EUR';
    q('[data-oq="einmal"]').textContent = einmal ? 'ab ' + fmt(einmal) : '0 EUR';
    q('[data-oq="lfd"]').textContent = lfd ? 'ab ' + fmt(lfd) : '0 EUR';
    q('[data-oq="dritt"]').textContent = dtxt;
    q('.oq-ko__balken .ist-einmal').style.flexGrow = einmal;
    q('.oq-ko__balken .ist-lfd').style.flexGrow = lfd;
    q('.oq-ko__balken .ist-dritt').style.flexGrow = dmin;
    let satz;
    if (!summe) satz = 'Nichts ausgewählt. Wählen Sie links, was Sie planen.';
    else if (jahr === 1) satz = `Im ersten Jahr fallen ab ${fmt(summe)} an.` + (dmin ? ` Davon gehen ${dtxt} direkt an Hoster und Anbieter, nicht an uns.` : '');
    else satz = `Ab dem zweiten Jahr entfallen die einmaligen Kosten. Es bleiben ab ${fmt(summe)} im Jahr` + (lfd ? ', davon ab ' + fmt(lfd) + ' für die Betreuung.' : ', alles direkt an Hoster und Anbieter.');
    if (jahr === 1 && w('oq-ko-web') !== 'keine' && w('oq-ko-marke') === 'logo') satz += ' Tipp: Bei einer neuen Website ist eine Logo-Anpassung oft schon enthalten.';
    q('[data-oq="satz"]').textContent = satz;
  };
  el.addEventListener('change', neu);
  el.querySelectorAll('[data-oq-jahr]').forEach(b => b.addEventListener('click', () => {
    jahr = +b.dataset.oqJahr;
    el.querySelectorAll('[data-oq-jahr]').forEach(x => x.setAttribute('aria-pressed', x === b ? 'true' : 'false'));
    el.querySelector('.oq-demo__form').toggleAttribute('data-folgejahr', jahr === 2);
    neu();
  }));
  neu();
});
