/* [oq_demo type="logotest"] · drei erfundene Logos einer erfundenen Glaserei im Alltagstest */
document.querySelectorAll('[data-oq-demo="logotest"]').forEach((el, nr) => {
  const id = 'oqlt' + nr;
  const LOGO = {
    detail: (v) => `<svg viewBox="0 0 240 90" width="100%" role="presentation"${v === 'mono' ? ' style="filter:grayscale(1)"' : ''}><defs><linearGradient id="${id}d" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#bfe3f5"/><stop offset=".5" stop-color="#6aa9d6"/><stop offset="1" stop-color="#2b4f7e"/></linearGradient></defs><rect x="12" y="12" width="56" height="66" rx="3" fill="url(#${id}d)" stroke="#1d2a44" stroke-width=".8"/><path d="M40 12V78M12 45H68" stroke="#1d2a44" stroke-width=".6"/><path d="M18 18l14 14M22 18l10 10M50 52l12 12M54 52l8 8" stroke="#fff" stroke-width=".5" opacity=".8"/><text x="80" y="44" font-family="Georgia,serif" font-style="italic" font-size="18" fill="#1d2a44">Glaserei Klarsicht</text><path d="M80 51H228" stroke="#1d2a44" stroke-width=".4"/><text x="80" y="62" font-family="Georgia,serif" font-size="6.4" fill="#4a5a78">Seit 1987 · Glas · Spiegel · Fenster · Duschen</text></svg>`,
    generator: (v) => `<svg viewBox="0 0 240 90" width="100%" role="presentation"${v === 'mono' ? ' style="filter:grayscale(1)"' : ''}><defs><linearGradient id="${id}g" x1="0" x2="1"><stop offset="0" stop-color="#1e88e5"/><stop offset="1" stop-color="#26c6da"/></linearGradient></defs><path d="M20 46C50 6 104 6 128 34" fill="none" stroke="url(#${id}g)" stroke-width="11" stroke-linecap="round"/><circle cx="140" cy="40" r="6" fill="#26c6da"/><text x="20" y="76" font-family="Arial,sans-serif" font-weight="700" font-size="17" fill="#263238">GLASEREI KLARSICHT</text></svg>`,
    klar: (v) => {
      const f = v === 'hell' ? '#ffffff' : v === 'mono' ? '#111111' : '#0F5A8A', k = v === 'hell' ? '#0F5A8A' : '#ffffff', fe = v === 'mono' ? '#ffffff' : v === 'hell' ? '#8FD3F4' : '#8FD3F4';
      return `<svg viewBox="0 0 240 90" width="100%" role="presentation"><rect x="8" y="15" width="60" height="60" rx="14" fill="${f}"/><text x="33" y="60" text-anchor="middle" font-family="'Trebuchet MS',Arial,sans-serif" font-weight="700" font-size="40" fill="${k}">K</text><rect x="45" y="25" width="13" height="13" rx="2.5" fill="${fe}"/><path d="M51.5 25V38M45 31.5H58" stroke="${f}" stroke-width="1.6"/><text x="80" y="52" font-family="'Trebuchet MS',Arial,sans-serif" font-weight="700" font-size="27" fill="${f}">Klarsicht</text><text x="81" y="69" font-family="Arial,sans-serif" font-size="9.5" letter-spacing="3.2" fill="${f}">GLASEREI</text></svg>`;
    }
  };
  const SYM = {
    detail: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect x="18" y="10" width="64" height="80" rx="3" fill="#6aa9d6" stroke="#1d2a44" stroke-width="1"/><path d="M50 10V90M18 50H82" stroke="#1d2a44" stroke-width=".8"/><path d="M24 16l18 18M58 56l16 16" stroke="#fff" stroke-width=".7"/></svg>`,
    generator: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><path d="M10 70C30 20 70 16 90 46" fill="none" stroke="#1e88e5" stroke-width="16" stroke-linecap="round"/></svg>`,
    klar: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect x="0" y="0" width="100" height="100" rx="22" fill="#0F5A8A"/><text x="42" y="78" text-anchor="middle" font-family="Trebuchet MS,Arial,sans-serif" font-weight="700" font-size="74" fill="#fff">K</text><rect x="66" y="12" width="22" height="22" rx="4" fill="#8FD3F4"/></svg>`
  };
  const U = {
    detail: { favicon: [0, 'Die feinen Linien verschwimmen zu einem grauen Fleck.'], karte: [1, 'Auf der Visitenkarte wirkt es edel, der kleine Zusatz ist gerade noch lesbar.'], fassade: [0, 'Der Name ist zu dünn, der Zusatz aus der Entfernung nicht lesbar.'], mono: [0, 'Der Farbverlauf wird zu einer grauen Fläche, feine Linien laufen zu.'], dunkel: [0, 'Dunkle Schrift auf dunklem Grund: Der Name verschwindet. Eine helle Fassung gibt es nicht.'], eigen: [1, 'Eigenständig, so sieht niemand sonst aus.'] },
    generator: { favicon: [0, 'Der Bogen wird zu einem blauen Fleck, nichts erinnert an den Betrieb.'], karte: [1, 'Funktioniert, wirkt aber beliebig.'], fassade: [1, 'Kräftige Schrift, aus der Entfernung lesbar.'], mono: [0, 'Nur als Bilddatei mit Verlauf geliefert, eine einfarbige Fassung fehlt.'], dunkel: [0, 'Der Bogen bleibt sichtbar, der dunkle Name nicht.'], eigen: [0, 'Den gleichen Bogen nutzen auch andere Betriebe. Austauschbar.'] },
    klar: { favicon: [1, 'Das Zeichen bleibt auch mit 16 Pixeln erkennbar.'], karte: [1, 'Klar, ruhig und mit Luft.'], fassade: [1, 'Kräftige Formen, aus 20 Metern lesbar.'], mono: [1, 'Eine einfarbige Fassung gehört zum Paket: Stempel, Fax, Gravur.'], dunkel: [1, 'Helle Fassung für dunkle Flächen, Fahrzeuge und Arbeitskleidung.'], eigen: [1, 'Eigenes Zeichen mit Bezug zum Handwerk: das Fenster im K.'] }
  };
  const STATUS = {
    detail: 'Schön auf dem Bildschirm, im Alltag kaum zu gebrauchen.',
    generator: 'Schnell gemacht, aber austauschbar und ohne die Fassungen, die man später braucht.',
    klar: 'Ein gutes Logo ist einfach, eigenständig und kommt mit allen Fassungen, die der Alltag verlangt.'
  };
  const NAME = { detail: 'Detailverliebt', generator: 'Aus dem Logo-Generator', klar: 'Klar entwickelt' };
  const andere = (t) => `<svg viewBox="0 0 240 90" width="100%" role="presentation"><path d="M20 46C50 6 104 6 128 34" fill="none" stroke="#1e88e5" stroke-width="11" stroke-linecap="round"/><circle cx="140" cy="40" r="6" fill="#26c6da"/><text x="20" y="76" font-family="Arial,sans-serif" font-weight="700" font-size="17" fill="#263238">${t}</text></svg>`;
  const favicon = (wahl, ziele) => {
    const img = new Image();
    img.onload = () => ziele.forEach(c => { const x = c.getContext('2d'); x.clearRect(0, 0, 16, 16); x.drawImage(img, 0, 0, 16, 16); });
    img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(SYM[wahl]);
  };
  const B = s => el.querySelector(`[data-oq-test="${s}"] .oq-lt__buehne`);
  const zeigen = () => {
    const w = (el.querySelector('input[name="oq-lt-logo"]:checked') || {}).value || 'detail';
    B('favicon').innerHTML = '<div><div class="oq-lt__tab"><canvas width="16" height="16"></canvas><span>Glaserei Klarsicht</span></div><div class="oq-lt__lupe" style="background:#fff;padding:10px 14px;border-radius:0 0 10px 10px"><canvas width="16" height="16"></canvas><small>So groß ist das Zeichen im Tab, vierfach vergrößert</small></div></div>';
    favicon(w, [...B('favicon').querySelectorAll('canvas')]);
    B('karte').innerHTML = `<div class="oq-lt__karte">${LOGO[w]('farbe')}</div>`;
    B('fassade').innerHTML = `<div class="oq-lt__haus"><div style="width:64px">${LOGO[w]('farbe')}</div></div>`;
    B('mono').innerHTML = `<div class="oq-lt__stempel" style="width:150px">${LOGO[w]('mono')}</div>`;
    B('dunkel').innerHTML = `<div style="width:180px">${LOGO[w](w === 'klar' ? 'hell' : 'farbe')}</div>`;
    const reihe = w === 'generator' ? [andere('FENSTER NORD'), LOGO.generator('farbe'), andere('GLAS-TEAM WEBER')] : [andere('FENSTER NORD'), LOGO[w]('farbe'), andere('GLAS-TEAM WEBER')];
    B('eigen').innerHTML = reihe.map((s, i) => `<div class="${i === 1 ? 'ist-dieses' : ''}" style="width:84px">${s}</div>`).join('');
    let n = 0;
    el.querySelectorAll('[data-oq-test]').forEach(li => {
      const [ok, t] = U[w][li.dataset.oqTest]; n += ok;
      li.dataset.ok = ok ? 'ja' : 'nein';
      li.querySelector('.oq-lt__urteil').textContent = t;
      li.querySelector('[data-oq-urteil-sr]').textContent = ok ? 'Bestanden: ' : 'Nicht bestanden: ';
    });
    el.querySelector('[data-oq="status"]').textContent = `${NAME[w]}: ${n} von 6 Tests bestanden. ${STATUS[w]}`;
  };
  el.addEventListener('change', zeigen);
  zeigen();
});
