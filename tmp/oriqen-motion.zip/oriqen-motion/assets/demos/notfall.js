/* [oq_demo type="notfall"] · beispielhafte Abläufe mit und ohne Betreuung, keine garantierten Reaktionszeiten */
document.querySelectorAll('[data-oq-demo="notfall"]').forEach(el => {
  const q = s => el.querySelector(`[data-oq="${s}"]`);
  const F = {
    update: {
      ohne: ['Eine Kundin ruft an: Auf dem Smartphone sei die Seite verrutscht. Seit wann, weiß niemand.', 'Welches Update war es? Ohne Protokoll beginnt die Suche. Die Zugänge liegen irgendwo in alten E-Mails.', 'Ein Dienstleister muss sich erst einarbeiten. Ein Backup gibt es, ob es funktioniert, weiß niemand.', 'Aus Sorge vor dem nächsten Fehler werden Updates gar nicht mehr eingespielt. Die Lücken wachsen.'],
      mit: ['Vor dem Update sichern wir die Website, danach prüfen wir die wichtigsten Seiten. Der Fehler fällt uns auf, nicht Ihren Kunden.', 'Das Protokoll zeigt, welches Plugin gerade aktualisiert wurde.', 'Zurück auf den Stand vor dem Update. Die Lösung suchen wir in Ruhe, die Seite läuft weiter.', 'Das Update kommt wieder, sobald der Hersteller nachgebessert hat. Dokumentiert, nachvollziehbar.'],
      dauer: ['Tage, manchmal Wochen', 'Stunden, je nach Schwere']
    },
    hack: {
      ohne: ['Google warnt vor der Seite, oder Besucher landen auf fremden Angeboten. Bis das jemandem auffällt, vergehen oft Tage.', 'Wie kamen die Angreifer hinein? Ohne Kenntnis der Website wird geraten.', 'Neu aufsetzen oder aufwendig säubern lassen. Ob das letzte Backup schon befallen ist, bleibt offen.', 'Die eigentliche Lücke ist oft noch da. Die nächste Infektion ist eine Frage der Zeit.'],
      mit: ['Die Überwachung meldet veränderte Dateien und auffälliges Verhalten.', 'Betroffene Bereiche werden isoliert, alle Zugänge sofort geändert.', 'Wiederherstellung aus einem geprüften, sauberen Backup.', 'Härtung gegen genau diesen Angriffsweg und ein kurzer Bericht, was passiert ist.'],
      dauer: ['Tage bis Wochen, teils mit Datenverlust', 'Stunden bis wenige Tage, je nach Befall']
    },
    ssl: {
      ohne: ['Besucher sehen „Nicht sicher“ oder eine ganzseitige Warnung im Browser. Viele gehen sofort wieder.', 'Wer ist zuständig: der Hoster, die Agentur von damals oder der Bekannte, der die Seite gebaut hat?', 'Das Zertifikat wird neu ausgestellt, sobald jemand Zugriff auf das Hosting hat.', 'Bis zur nächsten Verlängerung schaut wieder niemand hin. Die Laufzeiten werden ab 2027 deutlich kürzer.'],
      mit: ['Wir sehen das Ablaufdatum lange vorher. Hakt die automatische Verlängerung, fällt es uns zuerst auf.', 'Die Ursache ist meist schnell klar, die Zugänge liegen dokumentiert vor.', 'Neues Zertifikat, bevor ein Besucher eine Warnung sieht.', 'Ablauf von Zertifikat und Domain bleiben dauerhaft im Blick.'],
      dauer: ['Stunden bis Tage mit Warnseite', 'Meist bevor es jemand bemerkt']
    },
    formular: {
      ohne: ['Wochenlang kommen keine Anfragen. Man denkt, es ist eben gerade ruhig.', 'Irgendwann ein Testversand: Die E-Mails landen im Spam oder kommen gar nicht an.', 'Der Mailversand wird neu eingerichtet. Die Anfragen der letzten Wochen sind verloren.', 'Ob es wieder passiert, merkt erneut niemand.'],
      mit: ['Wir prüfen Ihre Formulare regelmäßig mit Testanfragen.', 'Eingrenzen: Mailserver, Spamfilter oder Plugin.', 'Versand über einen sauber eingerichteten Mailweg, die Testanfrage kommt an.', 'Anfragen kommen zuverlässig an, auf Wunsch zusätzlich als Kopie in ein zweites Postfach.'],
      dauer: ['Unbemerkt über Wochen', 'Fällt bei der nächsten Prüfung auf']
    },
    offline: {
      ohne: ['Ein Bekannter sagt Bescheid, dass die Seite nicht lädt. Seit wann, ist unklar.', 'Hoster, Domain oder Datenbank? Ohne Zugänge und Erfahrung dauert die Suche.', 'Die Hotline des Hosters ist überlastet, die Wiederherstellung zieht sich.', 'Keine Ursachenanalyse, kein Plan für das nächste Mal.'],
      mit: ['Die laufende Prüfung der Erreichbarkeit meldet den Ausfall, meist bevor er jemand anderem auffällt.', 'Eingrenzen: Server, Domain, Datenbank oder ein Plugin.', 'Kontakt zum Hoster mit allen Angaben, oder Wiederherstellung aus dem Backup.', 'Ursache dokumentiert, Vorkehrung gegen eine Wiederholung getroffen.'],
      dauer: ['Stunden bis Tage', 'Meist wenige Stunden']
    }
  };
  const ruhig = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const spalten = [...el.querySelectorAll('.oq-not__spalte')];
  let timer = [];
  const setzen = () => {
    const f = F[(el.querySelector('input[name="oq-not-fall"]:checked') || {}).value || 'update'];
    spalten.forEach((sp, i) => {
      const art = i ? 'mit' : 'ohne';
      sp.querySelectorAll('.oq-not__schritt > span:last-child').forEach((s, j) => { s.textContent = f[art][j]; });
      sp.querySelector('.oq-not__dauer b').textContent = f.dauer[i];
    });
  };
  const abspielen = () => {
    timer.forEach(clearTimeout); timer = [];
    const schritte = spalten.map(sp => [...sp.querySelectorAll('.oq-not__schritt, .oq-not__dauer')]);
    if (ruhig) { schritte.flat().forEach(s => s.classList.remove('ist-wartend')); return; }
    schritte.flat().forEach(s => s.classList.add('ist-wartend'));
    for (let j = 0; j < 5; j++) {
      schritte.forEach((liste, i) => timer.push(setTimeout(() => liste[j] && liste[j].classList.remove('ist-wartend'), 250 + j * 700 + i * (j < 4 ? 120 : 0))));
    }
  };
  el.addEventListener('change', () => { setzen(); abspielen(); });
  q('abspielen').addEventListener('click', abspielen);
  setzen();
});
