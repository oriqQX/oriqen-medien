/* [oq_demo type="plan"] · Redaktionsplan für vier Wochen: Branche, Ziel und Takt bestimmen die Mischung. Gewichtung ist eine Faustregel. */
document.querySelectorAll('[data-oq-demo="plan"]').forEach(el => {
  const q = s => el.querySelector(`[data-oq="${s}"]`);
  const esc = t => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const ARTEN = {
    einblick: ['Einblick', 'Reel'], wissen: ['Wissen', 'Karussell'], team: ['Team', 'Bild'], vorher: ['Vorher und nachher', 'Karussell'],
    stimme: ['Stimme', 'Bild'], angebot: ['Angebot', 'Bild'], stelle: ['Stelle', 'Reel']
  };
  const T = {
    handwerk: {
      einblick: ['Ein Projekt von der Skizze bis zur Montage', 'Neue Maschine in der Werkstatt', 'Ein Tag auf der Baustelle', 'So entsteht eine Schublade'],
      wissen: ['Welches Holz für welchen Raum?', 'Öl oder Lack: was hält länger?', 'Küche planen: die häufigsten Fehler', 'Möbel richtig pflegen'],
      team: ['Wer bei uns was macht', 'Neu im Team: Jonas', 'Unser Meister über sein Lieblingsholz', 'Zehn Jahre dabei: Petra'],
      vorher: ['Altbau-Küche, vorher und nachher', 'Einbauschrank unter der Dachschräge', 'Treppe aufgearbeitet', 'Badmöbel nach Maß'],
      stimme: ['Kundenstimme, mit Erlaubnis', 'Was Familie K. über ihre Küche sagt', 'Rückblick einer Bauherrin, mit Erlaubnis', 'Kundenstimme zum Ablauf'],
      angebot: ['Termine für das Frühjahr frei', 'Beratung in der Werkstatt: so läuft sie ab', 'Küchenplanung: jetzt Termin sichern', 'Reparaturservice für Holzmöbel'],
      stelle: ['Wir suchen eine Tischlerin oder einen Tischler', 'Ausbildung 2027: so sieht dein Tag aus', 'Was uns als Arbeitgeber ausmacht', 'Praktikum in den Ferien']
    },
    cafe: {
      einblick: ['Morgens um sechs in der Backstube', 'Woher unser Kaffee kommt', 'So entsteht der Kuchen der Woche', 'Ein Samstag hinter der Theke'],
      wissen: ['Was macht guten Kaffee aus?', 'Filter oder Siebträger?', 'Warum Sauerteig Zeit braucht', 'Kaffee richtig lagern'],
      team: ['Unser Team stellt sich vor', 'Neu an der Theke: Mia', 'Die Bäckerin hinter den Torten', 'Lieblingsgetränke im Team'],
      vorher: ['Die Terrasse ist fertig', 'Neue Sitzecke, vorher und nachher', 'Vom Teig zur Torte', 'Frühstückstisch für zwölf'],
      stimme: ['Gästestimme, mit Erlaubnis', 'Was Stammgäste bestellen', 'Feedback zur neuen Karte, mit Erlaubnis', 'Gästestimme zur Geburtstagsfeier'],
      angebot: ['Kuchen der Woche', 'Neue Frühstückskarte', 'Feiern im Herbst: jetzt anfragen', 'Mittagstisch ab Montag'],
      stelle: ['Aushilfe für das Wochenende gesucht', 'Ausbildung im Café: so läuft sie', 'Warum wir gern hier arbeiten', 'Barista-Schulung für das Team']
    },
    beratung: {
      einblick: ['Ein Tag in der Kanzlei', 'So läuft ein Erstgespräch ab', 'Unser Weg zur digitalen Buchhaltung', 'Wie eine Jahresplanung entsteht'],
      wissen: ['Belege digital einreichen', 'Fristen im Blick behalten', 'Was Gründer zuerst klären sollten', 'Häufige Fragen zur Lohnabrechnung'],
      team: ['Wer Sie bei uns betreut', 'Neu im Team: Lea', 'Fortbildung im Team', 'Was uns an der Arbeit gefällt'],
      vorher: ['Vom Schuhkarton zur digitalen Ablage', 'Ordnung in der Lohnabrechnung', 'Neue Abläufe für einen Handwerksbetrieb', 'Belegflut, vorher und nachher'],
      stimme: ['Mandantenstimme, mit Erlaubnis', 'Was ein Gründer über den Start sagt', 'Rückmeldung zur Videosprechstunde, mit Erlaubnis', 'Mandantenstimme zur Umstellung'],
      angebot: ['Sprechstunde per Video', 'Erstgespräch für Gründer', 'Freie Termine im Frühjahr', 'Neue Mandate im Handwerk'],
      stelle: ['Steuerfachangestellte gesucht', 'Ausbildung bei uns: drei Gründe', 'So arbeiten wir: flexibel und digital', 'Werkstudent für die Buchhaltung']
    }
  };
  const ZIEL = {
    bekannt: { g: { einblick: 3, wissen: 3, team: 2, vorher: 2, stimme: 1, angebot: 1, stelle: 0 }, satz: 'Für Bekanntheit tragen Einblicke und Wissen den Plan: Inhalte, die man gern weiterschickt.' },
    anfragen: { g: { vorher: 3, angebot: 3, stimme: 2, wissen: 2, einblick: 1, team: 1, stelle: 0 }, satz: 'Für Anfragen zeigen Ergebnisse und Stimmen, was Sie können, und jeder Angebots-Beitrag endet mit einem klaren Weg zum Kontakt.' },
    team: { g: { team: 3, stelle: 3, einblick: 2, wissen: 1, vorher: 1, stimme: 1, angebot: 0 }, satz: 'Für Mitarbeitende zeigen Sie den Arbeitsalltag und das Team. Stellenbeiträge lassen sich zusätzlich als Anzeige in der Region ausspielen.' }
  };
  const wert = n => (el.querySelector(`input[name="${n}"]:checked`) || {}).value;
  const folge = (g, anzahl) => {
    const keys = Object.keys(g).filter(k => g[k] > 0), cur = Object.fromEntries(keys.map(k => [k, 0])), sum = keys.reduce((a, k) => a + g[k], 0), out = [];
    while (out.length < anzahl) {
      keys.forEach(k => { cur[k] += g[k]; });
      let best = keys.filter(k => k !== out[out.length - 1]).sort((a, b) => cur[b] - cur[a])[0];
      cur[best] -= sum; out.push(best);
    }
    return out;
  };
  const rechnen = () => {
    const b = T[wert('oq-plan-branche') || 'handwerk'], z = ZIEL[wert('oq-plan-ziel') || 'bekannt'], takt = +q('takt').value;
    q('taktwert').textContent = takt;
    const seq = folge(z.g, takt * 4), zaehl = {};
    const posts = seq.map(art => { const i = zaehl[art] = (zaehl[art] || 0) + 1; return [art, b[art][(i - 1) % b[art].length]]; });
    let html = '';
    for (let w = 0; w < 4; w++) {
      html += `<li class="oq-plan__woche"><b>Woche ${w + 1}</b>` + posts.slice(w * takt, w * takt + takt).map(([art, t]) => `<span class="oq-plan__post" data-art="${art}"><small>${ARTEN[art][0]} · ${ARTEN[art][1]}</small>${esc(t)}</span>`).join('') + '</li>';
    }
    q('plan').innerHTML = html;
    const anteile = {}; seq.forEach(a => { anteile[a] = (anteile[a] || 0) + 1; });
    const arten = Object.keys(ARTEN).filter(a => anteile[a]);
    q('mix').innerHTML = arten.map(a => `<span data-art="${a}" style="flex:${anteile[a]}"></span>`).join('');
    q('legende').innerHTML = arten.map(a => `<li data-art="${a}"><span aria-hidden="true"></span>${ARTEN[a][0]}: ${anteile[a]}</li>`).join('');
    const reels = seq.filter(a => ARTEN[a][1] === 'Reel').length, kar = seq.filter(a => ARTEN[a][1] === 'Karussell').length;
    const zahl = ['null', 'ein', 'zwei', 'drei', 'vier', 'fünf', 'sechs', 'sieben', 'acht', 'neun', 'zehn', 'elf', 'zwölf'];
    q('status').textContent = `${zahl[takt * 4].replace(/^./, c => c.toUpperCase())} Beiträge im Monat, davon ${reels} Reels und ${kar} Karussells. ${z.satz} ${takt === 1 ? 'Ein Beitrag pro Woche reicht, wenn er verlässlich kommt.' : takt === 3 ? 'Drei pro Woche lohnen sich nur, wenn genug Material da ist. Sonst lieber zwei gute.' : 'Zwei pro Woche sind für viele Betriebe ein Takt, der auch im Alltag hält.'}`;
  };
  el.addEventListener('input', rechnen); el.addEventListener('change', rechnen); rechnen();
});
