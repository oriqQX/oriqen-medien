/* [oq_demo type="pricefinder"] · Paketfinder · nur Preise wie auf oriqen.de · Startzustand identisch mit demos.php */
document.querySelectorAll('[data-oq-demo="pricefinder"]').forEach(el => {
  const aus = el.querySelector('[data-oq="ergebnis"]'), w = n => el.querySelector(`input[name="${n}"]:checked`)?.value;
  const U = 'https://oriqen.de/';
  const P = {
    starter: { n: 'Starter', p: 'ab 279 EUR', z: 'einmalig', l: 'Passender Einstieg',
      t: 'Der professionelle Einstieg für kleinere Betriebe und Selbstständige, die solide auftreten wollen.',
      i: ['Individuelle Website mit bis zu fünf Seiten', 'Für Smartphone, Tablet und Desktop gebaut', 'SEO-Basis und Anbindung an die Google Search Console', 'DSGVO-Einrichtung mit Cookie-Consent', 'Übergabe mit kurzer Einweisung'],
      m: ['webdesign/', 'Mehr zum Webdesign'] },
    pro: { n: 'Professional', p: 'ab 599 EUR', z: 'einmalig', l: 'Passender Einstieg',
      t: 'Für Betriebe, die ihre Website strategisch aufstellen und bei Google wachsen wollen.',
      i: ['Unterseiten-Architektur für Ihre Hauptleistungen', 'SEO-Konzept mit Keyword-Mapping und sauberer Überschriften-Struktur', 'Einrichtung und Optimierung des Google-Unternehmensprofils', 'Content-Strategie für Startseite und Hauptbereiche', 'Tracking-Einrichtung, DSGVO-konform'],
      m: ['webdesign/', 'Mehr zum Webdesign'] },
    pflege: { n: 'Langfristige Betreuung', p: 'ab 149 EUR', z: 'monatlich', l: 'Passender Einstieg',
      t: 'Technik, Sicherheit und Inhalte laufend im Blick, mit festem Ansprechpartner.',
      i: ['Updates, Backups und technische Wartung', 'Sicherheit und Überwachung im Hintergrund', 'Kleinere Änderungen an Texten und Bildern', 'SEO-Aufbau Schritt für Schritt', 'Monatlich kündbar, ohne Mindestlaufzeit'],
      m: ['webdesign/webseiten-betreuung/', 'Mehr zur Betreuung'] },
    analyse: { n: 'SEO-Analyse', p: 'kostenlos', z: 'erweitert 29 EUR', l: 'Erster Schritt',
      t: 'Erst die Bestandsaufnahme, dann die Entscheidung: überarbeiten, neu aufbauen oder laufend betreuen.',
      i: ['Technik, Geschwindigkeit und mobile Darstellung', 'SEO-Grundlagen Ihrer wichtigsten Seiten', 'Ihr Google-Unternehmensprofil', 'Suchbegriffe und Wettbewerber in Ihrer Region', 'Klare Empfehlung für den nächsten Schritt'],
      m: ['seo/seo-analyse/', 'Zur SEO-Analyse'] }
  };
  const esc = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;');
  const neu = anim => {
    const a = w('oq-pf-1'), gross = w('oq-pf-2') === 'gross', google = w('oq-pf-3') === 'strategie', marke = w('oq-pf-4');
    const k = a === 'pflege' ? 'pflege' : a === 'besser' ? 'analyse' : (gross || google) ? 'pro' : 'starter';
    const x = P[k], extra = [];
    if (marke === 'logo') extra.push('<b>Passt dazu:</b> Logo-Projekt für 29 bis 99 EUR.' + (k === 'starter' || k === 'pro' ? ' Bei einer neuen Website sind Farben, Schriften und eine Logo-Anpassung oft schon enthalten.' : ''));
    if (marke === 'cd') extra.push('<b>Passt dazu:</b> Corporate Design für 149 bis 498 EUR, mit Logo, Farben, Schriften und Geschäftsausstattung.');
    if (k === 'starter' || k === 'pro') extra.push('<b>Danach optional:</b> Betreuung ab 149 EUR monatlich, monatlich kündbar.');
    if (k === 'pflege' && google) extra.push('<b>Für mehr Sichtbarkeit:</b> Google-Unternehmensprofil und SEO-Arbeit lassen sich als Wachstumsbausteine in die Betreuung aufnehmen.');
    if (k === 'analyse') extra.push('<b>Danach:</b> ' + (gross || google ? 'Bei größerem Umfang oft ein Neuaufbau als Professional ab 599 EUR.' : 'Oft reicht eine Überarbeitung oder die laufende Betreuung ab 149 EUR monatlich.'));
    aus.innerHTML = `<p class="oq-pf__label">${x.l}</p><p class="oq-pf__paket">${x.n}</p><p class="oq-pf__preis">${x.p} <small>${x.z}</small></p>`
      + `<p class="oq-pf__text">${esc(x.t)}</p><ul class="oq-pf__liste">${x.i.map(i => `<li>${esc(i)}</li>`).join('')}</ul>`
      + extra.map(e => `<p class="oq-pf__extra">${e}</p>`).join('')
      + `<p class="oq-pf__wege"><a class="oq-demo__start oq-magnetic" href="${U}kontakt/">Erstgespräch vereinbaren <span class="oq-pfeil" aria-hidden="true">→</span></a><a class="oq-pf__mehr" href="${U}${x.m[0]}">${x.m[1]}</a></p>`;
    if (anim) { aus.classList.remove('ist-neu'); void aus.offsetWidth; aus.classList.add('ist-neu'); }
  };
  el.addEventListener('change', () => neu(true)); neu(false);
});
