/* [oq_demo type="responsive"] · die Vorschau wird schmaler, das Mockup bricht per Container Query um */
document.querySelectorAll('[data-oq-demo="responsive"]').forEach(el => {
  const geraet = el.querySelector('.oq-demo__geraet'), anzeige = el.querySelector('[data-oq="breite"]'), knoepfe = el.querySelectorAll('[data-oq-breite]');
  knoepfe.forEach(k => k.addEventListener('click', () => {
    const b = +k.dataset.oqBreite, voll = el.querySelector('.oq-demo__buehne').clientWidth - 32;
    // Desktop volle Bühne, Tablet rund 60 %, Smartphone 300 px. Der Umbruch im Mockup läuft über Container Queries.
    const w = b >= 1200 ? voll : b >= 700 ? Math.max(Math.min(voll, 520), Math.round(voll * 0.6)) : Math.min(voll, 300);
    geraet.style.setProperty('--oq-breite', b >= 1200 ? '100%' : w + 'px');
    geraet.dataset.geraet = b >= 1200 ? 'desktop' : b >= 700 ? 'tablet' : 'phone';
    anzeige.textContent = b;
    knoepfe.forEach(x => x.setAttribute('aria-pressed', String(x === k)));
  }));
});
