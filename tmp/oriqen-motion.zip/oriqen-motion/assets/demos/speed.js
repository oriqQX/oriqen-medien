/* [oq_demo type="speed"] · simulierte Werte, Beispielbetrieb erfunden */
document.querySelectorAll('[data-oq-demo="speed"]').forEach(el => {
  const start = el.querySelector('.oq-demo__start'), status = el.querySelector('.oq-demo__ergebnis'), rennen = el.querySelector('.oq-demo__rennen');
  const bahnen = [...el.querySelectorAll('.oq-demo__bahn')].map(b => ({ b, uhr: b.querySelector('.oq-demo__uhr span'), fcp: +b.dataset.fcp, lcp: +b.dataset.lcp, cls: +b.dataset.cls }));
  const de = n => n.toFixed(1).replace('.', ',');
  const ruhig = matchMedia('(prefers-reduced-motion: reduce)').matches;
  let raf = 0;
  start.addEventListener('click', () => {
    cancelAnimationFrame(raf);
    rennen.dataset.zustand = 'laeuft'; start.disabled = true; start.firstChild.textContent = 'Läuft … ';
    status.textContent = 'Das Rennen läuft. Beide Fassungen derselben Seite werden gleichzeitig aufgerufen.';
    bahnen.forEach(x => { x.b.dataset.phase = '0'; x.b.classList.remove('ist-fertig', 'ist-springend'); x.uhr.textContent = '0,0'; });
    const t0 = performance.now(), ende = Math.max(...bahnen.map(x => x.lcp)) + .3, tempo = ruhig ? 4 : 1;
    const tick = t => {
      const s = (t - t0) / 1000 * tempo;
      bahnen.forEach(x => {
        if (!x.b.classList.contains('ist-fertig')) x.uhr.textContent = de(Math.min(s, x.lcp));
        if (s >= x.fcp && x.b.dataset.phase === '0') x.b.dataset.phase = '1';
        x.b.classList.toggle('ist-springend', x.cls > .1 && s >= x.lcp && s < x.lcp + .5);
        if (s >= x.lcp && !x.b.classList.contains('ist-fertig')) { x.b.dataset.phase = '2'; x.b.classList.add('ist-fertig'); }
      });
      if (s < ende) raf = requestAnimationFrame(tick);
      else {
        rennen.dataset.zustand = 'fertig'; start.disabled = false; start.firstChild.textContent = 'Noch einmal ';
        const [a, b] = bahnen;
        status.textContent = `Die schlanke Fassung war nach ${de(b.lcp)} Sekunden vollständig sichtbar, die schwere nach ${de(a.lcp)} Sekunden. Bei der schweren ist zusätzlich der Text gesprungen, als das Bild nachgeladen wurde. Simulierte Werte.`;
      }
    };
    raf = requestAnimationFrame(tick);
  });
});
