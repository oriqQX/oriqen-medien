/* [oq_demo type="wireframe"] */
document.querySelectorAll('[data-oq-demo="wireframe"]').forEach(el => {
  const mock = el.querySelector('.oq-mock'), knoepfe = el.querySelectorAll('[data-oq-wire]');
  knoepfe.forEach(k => k.addEventListener('click', () => {
    mock.classList.toggle('ist-wire', k.dataset.oqWire === '1');
    knoepfe.forEach(x => x.setAttribute('aria-pressed', String(x === k)));
  }));
});
