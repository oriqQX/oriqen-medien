/* oriqen Motion · Startseite (oq-h-*), ab 1.6.0
 * oq-h-live: Bereich ist sichtbar und der Tab aktiv, nur dann laufen Endlos-Animationen.
 * oq-h-seen: Bereich war einmal sichtbar, startet einmalige Animationen (Ring, Balken, Pfad).
 * Ohne JS oder bei reduzierter Bewegung steht alles im Endzustand. Nichts wird gespeichert. */
(() => {
  'use strict';
  const d = document;
  const ruhig = matchMedia('(prefers-reduced-motion: reduce)').matches;
  function start() {
    /* Website-Wand: Spalten aus data-spalten bauen (rein dekorativ, jede Spalte doppelt für die Endlosschleife) */
    d.querySelectorAll('.oq-h-wand[data-spalten]').forEach(w => {
      const ziel = w.querySelector('.oq-h-wand__spalten'); if (!ziel || ziel.children.length) return;
      const basis = w.dataset.basis || '';
      w.dataset.spalten.split('|').forEach(sp => {
        const nr = sp.split(',').filter(Boolean), s = d.createElement('div'); s.className = 'oq-h-wand__spalte';
        nr.concat(nr).forEach(n => {
          const f = d.createElement('div'), i = new Image(640, 320); f.className = 'oq-h-frame';
          i.alt = ''; i.loading = 'lazy'; i.decoding = 'async'; i.src = basis + 'oq-muster-' + String(n).padStart(2, '0') + '.webp';
          f.append(i); s.append(f);
        });
        ziel.append(s);
      });
    });
    const bereiche = [...d.querySelectorAll('.oq-h, .e-con.oq-h-check, .e-con.oq-h-proj')];
    const auf = [...d.querySelectorAll('.oq-h-auf')];
    d.querySelectorAll('.oq-h-ablauf__pfad, .oq-h-bento, .oq-h-preise__raster, .oq-h-zahlen, .oq-h-werte__liste').forEach(l => [...l.children].forEach((k, i) => k.style.setProperty('--oq-i', i)));
    if (ruhig || !('IntersectionObserver' in window)) {
      bereiche.forEach(b => b.classList.add('oq-h-seen'));
      auf.forEach(a => a.classList.add('oq-in'));
      return;
    }
    const sichtbar = new Set();
    const live = () => bereiche.forEach(b => b.classList.toggle('oq-h-live', !d.hidden && sichtbar.has(b)));
    const io1 = new IntersectionObserver(es => {
      es.forEach(e => { e.isIntersecting ? sichtbar.add(e.target) : sichtbar.delete(e.target); });
      live();
    }, { rootMargin: '80px 0px' });
    bereiche.forEach(b => io1.observe(b));
    const io2 = new IntersectionObserver(es => es.forEach(e => {
      if (!e.isIntersecting) return;
      e.target.classList.add(e.target.classList.contains('oq-h-auf') ? 'oq-in' : 'oq-h-seen');
      io2.unobserve(e.target);
    }), { rootMargin: '0px 0px -15% 0px' });
    [...bereiche, ...auf].forEach(x => io2.observe(x));
    d.addEventListener('visibilitychange', live);
    if (matchMedia('(pointer: fine)').matches) d.querySelectorAll('.oq-h-kachel').forEach(k => k.addEventListener('pointermove', e => {
      const r = k.getBoundingClientRect(); k.style.setProperty('--oq-x', (e.clientX - r.left) + 'px'); k.style.setProperty('--oq-y', (e.clientY - r.top) + 'px');
    }));
  }
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', start); else start();
})();
