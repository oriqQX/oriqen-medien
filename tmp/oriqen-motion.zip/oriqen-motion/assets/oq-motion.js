/* oriqen Motion · Kern
 * IntersectionObserver für Einflüge, requestAnimationFrame nur für sichtbare Parallax-, Fortschritts- und Maus-Effekte.
 * Bei reduzierter Bewegung und im Elementor-Editor bleibt alles im Endzustand. Nichts wird gespeichert. */
(() => {
  'use strict';
  const d = document, root = d.documentElement;
  const $$ = (s, r = d) => [...r.querySelectorAll(s)];
  const ruhig = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const fein = matchMedia('(pointer: fine) and (hover: hover)').matches;

  function start() {
    const editor = d.body.classList.contains('elementor-editor-active') || d.body.classList.contains('elementor-editor-preview');
    const bewegt = !ruhig && !editor && 'IntersectionObserver' in window;

    /* Wortweise Überschriften: Text bleibt im HTML, aria-label trägt den ganzen Satz */
    $$('.oq-split').forEach(el => {
      const ziel = el.querySelector('.elementor-heading-title') || el;
      if (ziel.dataset.oqGeteilt || !bewegt) return;
      ziel.dataset.oqGeteilt = '1';
      ziel.setAttribute('aria-label', ziel.textContent.trim().replace(/\s+/g, ' '));
      let i = 0;
      const teilen = knoten => [...knoten.childNodes].forEach(k => {
        if (k.nodeType === 3) {
          const frag = d.createDocumentFragment();
          k.textContent.split(/(\s+)/).forEach(t => {
            if (!t) return;
            if (/^\s+$/.test(t)) { frag.append(t); return; }
            const w = d.createElement('span'); w.className = 'oq-w'; w.setAttribute('aria-hidden', 'true');
            const s = d.createElement('span'); s.textContent = t; s.style.setProperty('--oq-i', Math.min(i++, 12)); w.append(s); frag.append(w);
          });
          k.replaceWith(frag);
        } else if (k.nodeType === 1 && k.tagName !== 'BR') teilen(k);
      });
      teilen(ziel);
      ziel.style.setProperty('--oq-stagger', '55ms');
    });

    /* Gestaffelte Kinder: Index als CSS-Variable */
    $$('.oq-stagger').forEach(el => {
      const box = el.querySelector(':scope > .e-con-inner') || el;
      [...box.children].forEach((k, i) => k.style.setProperty('--oq-i', Math.min(i, 8)));
    });

    /* Laufband: Inhalt einmal verdoppeln (Kopie für Screenreader verborgen) */
    $$('.oq-marquee').forEach(el => {
      if (el.querySelector('.oq-marquee-spur')) return;
      const box = el.querySelector(':scope > .e-con-inner') || el;
      const spur = d.createElement('div'); spur.className = 'oq-marquee-spur';
      const teil = d.createElement('div'); teil.className = 'oq-marquee-spur'; teil.style.animation = 'none';
      [...box.children].forEach(k => teil.append(k));
      const kopie = teil.cloneNode(true); kopie.classList.add('oq-marquee-kopie'); kopie.setAttribute('aria-hidden', 'true');
      kopie.querySelectorAll('a, button, input, [tabindex]').forEach(x => x.setAttribute('tabindex', '-1'));
      spur.append(teil, kopie); box.append(spur);
    });

    /* Zähler: Endwert steht im HTML; nur bei Bewegung von 0 hochzählen */
    const zahl = (el, v) => { el.textContent = Math.round(v).toLocaleString('de-DE'); };
    const zaehlen = el => {
      const ziel = parseFloat(el.dataset.to || el.textContent.replace(/\./g, '').replace(',', '.')) || 0, t0 = performance.now(), dauer = 750;
      const tick = t => { const p = Math.min(1, (t - t0) / dauer); zahl(el, ziel * (1 - Math.pow(1 - p, 3))); if (p < 1) requestAnimationFrame(tick); };
      requestAnimationFrame(tick);
    };

    const einflug = '.oq-reveal-up,.oq-reveal-left,.oq-reveal-right,.oq-reveal-scale,.oq-reveal-blur,.oq-stagger,.oq-mask,.oq-split,.oq-highlight,.oq-count';
    if (!bewegt) { $$(einflug).forEach(el => el.classList.add('oq-in')); }
    else {
      $$('.oq-count').forEach(el => { if (el.getBoundingClientRect().top > innerHeight) zahl(el, 0); });
      // Der Bereich reicht weit nach oben: Wird ein Element beim schnellen Scrollen übersprungen, steht es sofort im Endzustand
      const io = new IntersectionObserver(eintraege => eintraege.forEach(e => {
        if (!e.isIntersecting) return;
        const el = e.target; io.unobserve(el);
        if (e.boundingClientRect.bottom < 0) { el.classList.add('oq-in'); if (el.classList.contains('oq-count')) el.textContent = Math.round(parseFloat(el.dataset.to) || 0).toLocaleString('de-DE'); return; }
        el.classList.add('oq-in');
        if (el.classList.contains('oq-count')) zaehlen(el);
      }), { rootMargin: '400000px 0px -8% 0px' });
      $$(einflug).forEach(el => io.observe(el));
    }

    /* Scrollgebundene Effekte: Parallax, Fortschritt, Lesefortschritt. Nur sichtbare Elemente, ein rAF pro Frame. */
    const parallax = bewegt ? $$('.oq-parallax-slow,.oq-parallax-fast') : [];
    const fortschritt = $$('.oq-progress'), balken = $$('.oq-scroll-bar').slice(0, 1);
    if (!bewegt) fortschritt.forEach(el => el.style.setProperty('--oq-p', 1));
    const sichtbar = new Set();
    if ('IntersectionObserver' in window) {
      const sio = new IntersectionObserver(es => es.forEach(e => (e.isIntersecting ? sichtbar.add(e.target) : sichtbar.delete(e.target))), { rootMargin: '100px 0px' });
      [...parallax, ...(bewegt ? fortschritt : [])].forEach(el => sio.observe(el));
    }
    let frame = 0;
    const malen = () => {
      frame = 0; const vh = innerHeight;
      sichtbar.forEach(el => {
        const r = el.getBoundingClientRect();
        if (el.classList.contains('oq-progress')) {
          const p = Math.min(1, Math.max(0, (vh * .7 - r.top) / Math.max(1, r.height)));
          el.style.setProperty('--oq-p', p.toFixed(3));
        } else {
          const f = el.classList.contains('oq-parallax-fast') ? -.14 : -.06;
          el.style.transform = `translate3d(0,${((r.top + r.height / 2 - vh / 2) * f).toFixed(1)}px,0)`;
        }
      });
      if (balken[0]) { const max = root.scrollHeight - vh; balken[0].style.transform = `scaleX(${max > 0 ? (scrollY / max).toFixed(4) : 0})`; }
    };
    const anfordern = () => { if (!frame) frame = requestAnimationFrame(malen); };
    if (parallax.length || fortschritt.length || balken.length) { addEventListener('scroll', anfordern, { passive: true }); addEventListener('resize', anfordern); anfordern(); }

    /* Maus: Neigung, Licht, Magnet. Nur feine Zeiger, nicht auf Touch. */
    if (fein && bewegt) {
      $$('.oq-tilt').forEach(el => {
        el.addEventListener('pointermove', e => { if (e.pointerType !== 'mouse') return; const r = el.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5; el.style.transform = `perspective(900px) rotateX(${(-y * 7).toFixed(2)}deg) rotateY(${(x * 9).toFixed(2)}deg)`; });
        el.addEventListener('pointerleave', () => { el.style.transform = ''; });
      });
      $$('.oq-magnetic').forEach(el => {
        el.addEventListener('pointermove', e => { if (e.pointerType !== 'mouse') return; const r = el.getBoundingClientRect(); el.style.transform = `translate3d(${((e.clientX - r.left - r.width / 2) * .18).toFixed(1)}px,${((e.clientY - r.top - r.height / 2) * .25).toFixed(1)}px,0)`; });
        el.addEventListener('pointerleave', () => { el.style.transform = ''; });
      });
    }
    if (fein) $$('.oq-glow').forEach(el => el.addEventListener('pointermove', e => { const r = el.getBoundingClientRect(); el.style.setProperty('--oq-x', `${e.clientX - r.left}px`); el.style.setProperty('--oq-y', `${e.clientY - r.top}px`); }));

    /* Horizontal wischbar: Mausrad scrollt quer, bis das Ende erreicht ist; dann geht die Seite normal weiter */
    $$('.oq-hscroll').forEach(el => {
      const box = el.querySelector(':scope > .e-con-inner') || el;
      if (!box.hasAttribute('tabindex')) box.setAttribute('tabindex', '0');
      if (!box.getAttribute('aria-label')) box.setAttribute('aria-label', 'Wischbare Liste, mit Pfeiltasten oder Mausrad bewegen');
      box.addEventListener('wheel', e => {
        if (Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
        const max = box.scrollWidth - box.clientWidth;
        if ((e.deltaY > 0 && box.scrollLeft < max - 1) || (e.deltaY < 0 && box.scrollLeft > 0)) { e.preventDefault(); box.scrollLeft += e.deltaY; }
      }, { passive: false });
    });
  }
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', start); else start();
})();

/* oq-net: bewegtes Netz aus Lichtpunkten auf dunklen Bändern (1.5.0).
 * Läuft nur sichtbar und im aktiven Tab, mobil mit weniger Punkten, bei reduzierter Bewegung als Standbild. */
(() => {
  'use strict';
  const ruhig = matchMedia('(prefers-reduced-motion: reduce)').matches;
  function netz(s) {
    if (s.querySelector(':scope > .oq-net-canvas')) return;
    const c = document.createElement('canvas');
    c.className = 'oq-net-canvas'; c.setAttribute('aria-hidden', 'true');
    s.insertBefore(c, s.firstChild);
    const x = c.getContext('2d'); if (!x) return;
    const dichte = parseFloat(s.dataset.oqNetDichte || '1');
    let W = 0, H = 0, P = [], lauf = false, raf = 0, mx = -1e4, my = -1e4, L = 140, lw = 0, iv = false;
    function groesse() {
      const r = s.getBoundingClientRect(), D = Math.min(devicePixelRatio || 1, innerWidth < 768 ? 1 : 1.5);
      W = r.width; H = r.height; c.width = Math.round(W * D); c.height = Math.round(H * D); x.setTransform(D, 0, 0, D, 0, 0);
      if (Math.abs(W - lw) < 2 && P.length) return;
      lw = W; L = W < 768 ? 100 : 140;
      const n = Math.round(Math.min(80, Math.max(18, W * H / 26000)) * dichte);
      P = [];
      for (let i = 0; i < n; i++) P.push({ x: Math.random() * W, y: Math.random() * H, vx: (Math.random() - .5) * .22, vy: (Math.random() - .5) * .22, r: Math.random() * 1.5 + .7, p: Math.random() * 6.283 });
    }
    function bild(t) {
      t = t || 0; x.clearRect(0, 0, W, H);
      for (let i = 0; i < P.length; i++) {
        const a = P[i];
        if (!ruhig) {
          a.x += a.vx; a.y += a.vy;
          if (a.x < -20) a.x = W + 20; else if (a.x > W + 20) a.x = -20;
          if (a.y < -20) a.y = H + 20; else if (a.y > H + 20) a.y = -20;
          const dx = mx - a.x, dy = my - a.y; if (dx * dx + dy * dy < 36000) { a.x += dx * .0016; a.y += dy * .0016; }
        }
        for (let j = i + 1; j < P.length; j++) {
          const b = P[j], ex = a.x - b.x, ey = a.y - b.y, q = ex * ex + ey * ey;
          if (q < L * L) { x.strokeStyle = 'rgba(203,168,255,' + ((1 - Math.sqrt(q) / L) * .3).toFixed(3) + ')'; x.lineWidth = 1; x.beginPath(); x.moveTo(a.x, a.y); x.lineTo(b.x, b.y); x.stroke(); }
        }
      }
      for (const a of P) { const g = .5 + .5 * Math.sin(t / 1500 + a.p); x.fillStyle = 'rgba(255,255,255,' + (.28 + .42 * g).toFixed(3) + ')'; x.beginPath(); x.arc(a.x, a.y, a.r, 0, 6.283); x.fill(); }
      if (lauf) raf = requestAnimationFrame(bild);
    }
    const an = () => { if (lauf || ruhig) return; lauf = true; raf = requestAnimationFrame(bild); };
    const aus = () => { lauf = false; cancelAnimationFrame(raf); };
    groesse(); bild(0); c.classList.add('ist-an');
    if ('IntersectionObserver' in window) new IntersectionObserver(e => { iv = e[0].isIntersecting; (iv && !document.hidden) ? an() : aus(); }).observe(s);
    document.addEventListener('visibilitychange', () => { document.hidden ? aus() : (iv && an()); });
    let to; addEventListener('resize', () => { clearTimeout(to); to = setTimeout(() => { groesse(); if (!lauf) bild(0); }, 200); });
    s.addEventListener('pointermove', e => { const r = s.getBoundingClientRect(); mx = e.clientX - r.left; my = e.clientY - r.top; }, { passive: true });
    s.addEventListener('pointerleave', () => { mx = my = -1e4; });
  }
  const los = () => document.querySelectorAll('.oq-net').forEach(netz);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', los); else los();
})();
