<?php
/**
 * Blog-Übersicht [oq_blog] und Weiterlesen [oq_blog_mehr].
 * Alles kommt aus WordPress selbst: neue Beiträge, Kategorien und Beitragsbilder erscheinen automatisch.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Kurztext: gepflegter Auszug, sonst Anfang des Inhalts ohne doppelten Titel. */
function oq_blog_kurztext( $post, $woerter = 26 ) {
	if ( has_excerpt( $post ) ) {
		return wp_trim_words( get_the_excerpt( $post ), $woerter, ' …' );
	}
	$text  = wp_strip_all_tags( strip_shortcodes( $post->post_content ), true );
	$text  = trim( preg_replace( '/\s+/u', ' ', $text ) );
	$titel = trim( wp_strip_all_tags( get_the_title( $post ) ) );
	$titel = html_entity_decode( $titel, ENT_QUOTES, 'UTF-8' );
	if ( '' !== $titel && 0 === mb_stripos( $text, $titel ) ) {
		$text = trim( mb_substr( $text, mb_strlen( $titel ) ) );
	}
	return wp_trim_words( $text, $woerter, ' …' );
}

function oq_blog_lesezeit( $post ) {
	$w = str_word_count( wp_strip_all_tags( strip_shortcodes( $post->post_content ) ) );
	$w = max( $w, (int) ( mb_strlen( wp_strip_all_tags( $post->post_content ) ) / 7 ) );
	return max( 1, (int) round( $w / 200 ) );
}

/** Eine Karte. $gross: breite Karte für den neuesten Beitrag. */
function oq_blog_karte( $post, $gross = false, $titel_tag = 'h2' ) {
	$link  = get_permalink( $post );
	$titel = get_the_title( $post );
	$bild  = '';
	if ( has_post_thumbnail( $post ) ) {
		$bild = '<a class="oq-karte__bild" href="' . esc_url( $link ) . '" tabindex="-1" aria-hidden="true">'
			. get_the_post_thumbnail( $post, $gross ? 'large' : 'medium_large', array( 'loading' => $gross ? 'eager' : 'lazy', 'alt' => '' ) ) . '</a>';
	}
	$kat = '';
	if ( 'post' === get_post_type( $post ) ) {
		$kats = get_the_category( $post->ID );
		if ( $kats ) {
			$kat = '<a class="oq-karte__kat" href="' . esc_url( get_category_link( $kats[0] ) ) . '">' . esc_html( $kats[0]->name ) . '</a>';
		}
	}
	$meta = '<p class="oq-karte__meta">' . $kat . '<time datetime="' . esc_attr( get_the_date( 'c', $post ) ) . '">' . esc_html( get_the_date( 'j. F Y', $post ) ) . '</time>'
		. ( 'post' === get_post_type( $post ) ? '<span>' . oq_blog_lesezeit( $post ) . ' Min. Lesezeit</span>' : '' ) . '</p>';
	$tag = in_array( $titel_tag, array( 'h2', 'h3' ), true ) ? $titel_tag : 'h2';
	return '<article class="oq-karte' . ( $gross ? ' oq-karte--gross' : '' ) . '">' . $bild
		. '<div class="oq-karte__body">' . $meta
		. '<' . $tag . ' class="oq-karte__titel"><a href="' . esc_url( $link ) . '">' . esc_html( wp_strip_all_tags( $titel ) ) . '</a></' . $tag . '>'
		. '<p class="oq-karte__text">' . esc_html( oq_blog_kurztext( $post, $gross ? 40 : 24 ) ) . '</p>'
		. '<span class="oq-karte__mehr" aria-hidden="true">Weiterlesen →</span></div></article>';
}

/** Kategorie-Leiste: nur für Beiträge, nur Kategorien mit Beiträgen. */
function oq_blog_chips() {
	$blog  = (int) get_option( 'page_for_posts' );
	$alle  = $blog ? get_permalink( $blog ) : home_url( '/' );
	$aktiv = is_category() ? (int) get_queried_object_id() : 0;
	$sum   = (int) wp_count_posts( 'post' )->publish;
	$h     = '<nav aria-label="Kategorien"><ul class="oq-blog__chips">';
	$h    .= '<li><a href="' . esc_url( $alle ) . '"' . ( ( is_home() && ! $aktiv ) ? ' aria-current="page"' : '' ) . '>Alle <small>' . $sum . '</small></a></li>';
	foreach ( get_categories( array( 'hide_empty' => true, 'orderby' => 'count', 'order' => 'DESC' ) ) as $k ) {
		$h .= '<li><a href="' . esc_url( get_category_link( $k ) ) . '"' . ( $aktiv === (int) $k->term_id ? ' aria-current="page"' : '' ) . '>' . esc_html( $k->name ) . ' <small>' . (int) $k->count . '</small></a></li>';
	}
	return $h . '</ul></nav>';
}

function oq_blog_shortcode( $atts ) {
	$atts    = shortcode_atts( array( 'anzahl' => 9 ), $atts, 'oq_blog' );
	$archiv  = is_home() || is_archive() || is_search();
	global $wp_query;
	if ( $archiv ) {
		$q = $wp_query;
	} else {
		$seite = max( 1, (int) get_query_var( 'paged' ), (int) get_query_var( 'page' ) );
		$q     = new WP_Query( array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => max( 1, (int) $atts['anzahl'] ), 'paged' => $seite, 'ignore_sticky_posts' => true ) );
	}
	$beitraege = ! $archiv || is_home() || is_category() || is_tag() || is_date() || is_author() || is_search();
	$h         = '<div class="oq-blog">';
	if ( is_category() || is_tag() ) {
		$beschr = term_description();
		if ( $beschr ) {
			$h .= '<div class="oq-blog__intro">' . wp_kses_post( $beschr ) . '</div>';
		}
	} elseif ( is_home() || ! $archiv ) {
		$h .= '<p class="oq-blog__intro">Ratgeber, Einordnungen und Neues aus dem Studio: verständlich erklärt für Handwerk, Dienstleister und Mittelstand in Paderborn und Ostwestfalen-Lippe.</p>';
	}
	if ( $beitraege ) {
		$h .= oq_blog_chips();
	}
	if ( ! $q->have_posts() ) {
		return $h . '<p class="oq-blog__leer">Hier erscheinen bald die ersten Beiträge.</p></div>';
	}
	$erste = ( is_home() || ! $archiv ) && (int) max( 1, $q->get( 'paged' ) ) === 1;
	$h    .= '<div class="oq-blog__raster">';
	$i     = 0;
	foreach ( $q->posts as $p ) {
		$h .= oq_blog_karte( $p, $erste && 0 === $i );
		$i++;
	}
	$h    .= '</div>';
	$links = paginate_links( array( 'total' => (int) $q->max_num_pages, 'current' => max( 1, (int) $q->get( 'paged' ) ), 'prev_text' => '← Neuere', 'next_text' => 'Ältere →', 'type' => 'plain' ) );
	if ( $links ) {
		$h .= '<nav class="oq-blog__seiten" aria-label="Seiten">' . $links . '</nav>';
	}
	if ( ! $archiv ) {
		wp_reset_postdata();
	}
	return $h . '</div>';
}

/** Weiterlesen unter einem Beitrag: zuerst gleiche Kategorie, aufgefüllt mit den neuesten. */
function oq_blog_mehr_shortcode( $atts ) {
	$atts   = shortcode_atts( array( 'anzahl' => 3, 'titel' => 'Das könnte Sie auch interessieren' ), $atts, 'oq_blog_mehr' );
	$n      = max( 1, min( 6, (int) $atts['anzahl'] ) );
	$jetzt  = get_queried_object_id();
	$ids    = array();
	$kats   = $jetzt ? wp_get_post_categories( $jetzt ) : array();
	$basis  = array( 'post_type' => 'post', 'post_status' => 'publish', 'ignore_sticky_posts' => true, 'no_found_rows' => true, 'fields' => 'ids' );
	if ( $kats ) {
		$ids = get_posts( $basis + array( 'category__in' => $kats, 'post__not_in' => array( $jetzt ), 'posts_per_page' => $n ) );
	}
	if ( count( $ids ) < $n ) {
		$ids = array_merge( $ids, get_posts( $basis + array( 'post__not_in' => array_merge( array( $jetzt ), $ids ), 'posts_per_page' => $n - count( $ids ) ) ) );
	}
	if ( ! $ids ) {
		return '';
	}
	$blog = (int) get_option( 'page_for_posts' );
	$h    = '<section class="oq-mehr" aria-label="Weitere Beiträge"><div class="oq-mehr__kopf"><div><p class="oq-mehr__kicker">Weiterlesen</p><p class="oq-mehr__titel">' . esc_html( $atts['titel'] ) . '</p></div>'
		. ( $blog ? '<a class="oq-mehr__alle" href="' . esc_url( get_permalink( $blog ) ) . '">Alle Beiträge →</a>' : '' ) . '</div><div class="oq-blog__raster">';
	foreach ( $ids as $id ) {
		$h .= oq_blog_karte( get_post( $id ), false, 'h3' );
	}
	return $h . '</div></section>';
}

/** Überschrift für Archive: Blog-Seite, Kategorie, Schlagwort, Suche. Immer eine H1. */
function oq_archiv_titel_shortcode() {
	if ( is_home() ) {
		$blog = (int) get_option( 'page_for_posts' );
		$t    = $blog ? get_the_title( $blog ) : 'Blog';
	} elseif ( is_category() ) {
		$t = single_cat_title( '', false );
	} elseif ( is_tag() ) {
		$t = 'Schlagwort: ' . single_tag_title( '', false );
	} elseif ( is_tax() ) {
		$t = single_term_title( '', false );
	} elseif ( is_post_type_archive() ) {
		$t = post_type_archive_title( '', false );
	} elseif ( is_search() ) {
		$t = 'Suchergebnisse für „' . get_search_query() . '“';
	} else {
		$t = wp_strip_all_tags( get_the_archive_title() );
	}
	return '<h1 class="oq-archiv-titel">' . esc_html( $t ) . '</h1>';
}
