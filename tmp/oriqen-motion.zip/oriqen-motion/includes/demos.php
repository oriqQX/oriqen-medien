<?php
/**
 * Interaktive Bausteine: serverseitiges Grund-HTML je Typ. Der Text ist ohne JavaScript lesbar,
 * das zugehörige Skript macht den Baustein bedienbar. Nichts wird gespeichert.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Hülle mit Kennzeichnung. */
function oq_demo_rahmen( $type, $titel, $inhalt, $hinweis ) {
	return '<figure class="oq-demo oq-demo--' . esc_attr( $type ) . '" data-oq-demo="' . esc_attr( $type ) . '">'
		. '<p class="oq-demo__marke">Zum Ausprobieren</p>'
		. '<p class="oq-demo__titel">' . esc_html( $titel ) . '</p>'
		. $inhalt
		. '<figcaption class="oq-demo__hinweis">' . esc_html( $hinweis ) . '</figcaption></figure>';
}

/** Radio-Gruppe als Chips. */
function oq_demo_chips( $name, $legende, $werte, $aktiv ) {
	$h = '<fieldset class="oq-demo__gruppe"><legend>' . esc_html( $legende ) . '</legend><div class="oq-demo__chips">';
	foreach ( $werte as $wert => $label ) {
		$h .= '<label class="oq-demo__chip"><input type="radio" name="' . esc_attr( $name ) . '" value="' . esc_attr( $wert ) . '"' . checked( $wert, $aktiv, false ) . '><span>' . esc_html( $label ) . '</span></label>';
	}
	return $h . '</div></fieldset>';
}

/** Kleines Website-Mockup, das mehrere Bausteine nutzen. */
function oq_demo_mock( $name = 'Tischlerei Eichenwerk', $domain = 'tischlerei-eichenwerk.de' ) {
	return '<div class="oq-mock" data-stil="ruhig" data-farbe="violett">'
		. '<div class="oq-mock__leiste"><i></i><i></i><i></i><span data-oq="domain">' . esc_html( $domain ) . '</span></div>'
		. '<div class="oq-mock__seite"><div class="oq-mock__kopf"><b data-oq="name">' . esc_html( $name ) . '</b><span class="oq-mock__nav">Leistungen · Über uns · Kontakt</span><span class="oq-mock__burger" aria-hidden="true"></span></div>'
		. '<div class="oq-mock__hero"><div><p class="oq-mock__kicker" data-oq="kicker">Tischlerei in Paderborn</p><p class="oq-mock__h" data-oq="h">Möbel nach Maß, gebaut in Paderborn.</p><p class="oq-mock__p" data-oq="p">Küchen, Einbauschränke und Innenausbau aus unserer Werkstatt.</p><span class="oq-mock__knopf" data-oq="cta">Termin anfragen</span></div><div class="oq-mock__bild"></div></div>'
		. '<div class="oq-mock__karten"><span data-oq="l1">Küchen</span><span data-oq="l2">Einbaumöbel</span><span data-oq="l3">Innenausbau</span></div></div></div>';
}

function oq_demo_html_configurator( $atts ) {
	$in = '<form class="oq-demo__form" onsubmit="return false">'
		. oq_demo_chips( 'oq-typ', 'Welche Art von Website?', array( 'onepager' => 'One-Pager', 'klein' => 'Kleine Website', 'magazin' => 'Magazin oder Blog' ), 'klein' )
		. oq_demo_chips( 'oq-branche', 'Ihre Branche', array( 'handwerk' => 'Handwerk', 'gastro' => 'Gastronomie', 'praxis' => 'Praxis', 'handel' => 'Handel vor Ort' ), 'handwerk' )
		. oq_demo_chips( 'oq-stil', 'Stil', array( 'ruhig' => 'Ruhig', 'kuehn' => 'Kühn', 'klassisch' => 'Klassisch' ), 'ruhig' )
		. oq_demo_chips( 'oq-farbe', 'Farbstimmung', array( 'violett' => 'Violett', 'wald' => 'Waldgrün', 'ozean' => 'Ozean', 'terrakotta' => 'Terrakotta' ), 'violett' )
		. '</form><div class="oq-demo__vorschau">' . oq_demo_mock() . '<p class="oq-demo__ergebnis" aria-live="polite" data-oq="paket">Passender Einstieg: <strong>Starter ab 279 EUR</strong>. Bis zu fünf Seiten, für Smartphone, Tablet und Desktop gebaut.</p></div>';
	return oq_demo_rahmen( 'configurator', 'Ihre Website in vier Entscheidungen', '<div class="oq-demo__zwei">' . $in . '</div>', 'Beispielbetriebe sind erfunden. Die Vorschau zeigt die Richtung, kein fertiges Design. Preise sind Orientierungswerte, den verbindlichen Preis legen wir nach dem Erstgespräch fest.' );
}

function oq_demo_html_wireframe( $atts ) {
	$in = '<div class="oq-demo__schalter" role="group" aria-label="Ansicht wählen"><button type="button" class="oq-demo__knopf" data-oq-wire="1" aria-pressed="false">Wireframe</button><button type="button" class="oq-demo__knopf" data-oq-wire="0" aria-pressed="true">Gestaltet</button></div>' . oq_demo_mock();
	return oq_demo_rahmen( 'wireframe', 'Erst die Struktur, dann die Gestaltung', $in, 'Ein Wireframe zeigt nur, was wohin gehört: graue Kästen statt Bilder, Balken statt Text. Beispielbetrieb erfunden.' );
}

function oq_demo_html_responsive( $atts ) {
	$in = '<div class="oq-demo__schalter" role="group" aria-label="Bildschirmbreite"><button type="button" class="oq-demo__knopf" data-oq-breite="1200" aria-pressed="true">Desktop</button><button type="button" class="oq-demo__knopf" data-oq-breite="800" aria-pressed="false">Tablet</button><button type="button" class="oq-demo__knopf" data-oq-breite="390" aria-pressed="false">Smartphone</button></div>'
		. '<div class="oq-demo__buehne"><div class="oq-demo__geraet">' . oq_demo_mock() . '</div></div><p class="oq-demo__ergebnis" aria-live="polite"><span data-oq="breite">1200</span> Pixel breit</p>';
	return oq_demo_rahmen( 'responsive', 'Dieselbe Seite auf jedem Gerät', $in, 'Keine Bilder, sondern dieselbe Seite, die live umbricht: Spalten werden zu Zeilen, die Navigation wird zum Menü. Beispielbetrieb erfunden.' );
}

function oq_demo_html_speed( $atts ) {
	$handy = '<div class="oq-handy" aria-hidden="true"><div class="oq-handy__seite">'
		. '<div class="oq-handy__kopf"><i>TE</i><span>Tischlerei Eichenwerk</span><em></em></div>'
		. '<div class="oq-handy__bild"></div>'
		. '<div class="oq-handy__text"><p class="oq-handy__k">Tischlerei in Paderborn</p><p class="oq-handy__h">Möbel nach Maß, gebaut in Paderborn.</p><p class="oq-handy__p">Küchen, Einbauschränke und Innenausbau aus unserer Werkstatt. Beratung bei Ihnen vor Ort.</p><span class="oq-handy__knopf">Termin anfragen</span><span class="oq-handy__knopf oq-handy__knopf--2">05251 000 000</span></div>'
		. '</div><div class="oq-handy__lade"><span></span></div></div>';
	$bahn = function ( $name, $sub, $fcp, $lcp, $cls ) use ( $handy ) {
		return '<div class="oq-demo__bahn" data-phase="2" data-fcp="' . esc_attr( $fcp ) . '" data-lcp="' . esc_attr( $lcp ) . '" data-cls="' . esc_attr( $cls ) . '"><b>' . esc_html( $name ) . '</b><small>' . esc_html( $sub ) . '</small>' . $handy . '<p class="oq-demo__uhr"><span>' . esc_html( str_replace( '.', ',', $lcp ) ) . '</span> s<i class="oq-demo__ok" aria-hidden="true">✓</i></p></div>';
	};
	$in = '<div class="oq-demo__rennen" data-zustand="bereit">' . $bahn( 'Schwer gebaut', 'große Bilder, viele Skripte', '2.9', '5.8', '0.24' ) . $bahn( 'Schlank gebaut', 'optimierte Bilder, wenig Skripte', '0.9', '1.7', '0.02' ) . '</div>'
		. '<p><button type="button" class="oq-demo__start">Rennen starten <span class="oq-pfeil" aria-hidden="true">→</span></button></p>'
		. '<p class="oq-demo__ergebnis" aria-live="polite">Starten Sie das Rennen: Beide Fassungen derselben Seite werden gleichzeitig aufgerufen.</p>'
		. '<table class="oq-demo__tabelle"><caption class="screen-reader-text">Simulierte Messwerte der beiden Fassungen</caption><thead><tr><th scope="col">Simulierter Wert</th><th scope="col">Schwer</th><th scope="col">Schlank</th></tr></thead><tbody>'
		. '<tr><th scope="row">Erster Inhalt sichtbar</th><td>2,9 s</td><td>0,9 s</td></tr>'
		. '<tr><th scope="row">LCP, größtes Element</th><td>5,8 s <span class="oq-ampel oq-ampel--rot">schlecht</span></td><td>1,7 s <span class="oq-ampel oq-ampel--gruen">gut</span></td></tr>'
		. '<tr><th scope="row">CLS, Springen</th><td>0,24 <span class="oq-ampel oq-ampel--gelb">mittel</span></td><td>0,02 <span class="oq-ampel oq-ampel--gruen">gut</span></td></tr>'
		. '</tbody></table>';
	return oq_demo_rahmen( 'speed', 'Ladezeit-Rennen: dieselbe Seite, zweimal gebaut', $in, 'Simulation, keine Messung. Typische Größenordnungen für ein Smartphone im Mobilfunknetz, ausgerichtet an den Schwellenwerten von Google. Ihre echten Werte zeigen PageSpeed Insights und die Google Search Console.' );
}

function oq_demo_html_serp( $atts ) {
	$ohne = '<div class="oq-serp__eintrag oq-serp__eintrag--ohne"><p class="oq-serp__quelle"><span class="oq-serp__favicon" aria-hidden="true">·</span><span><b class="oq-serp__name" data-oq="domain">tischlerei-eichenwerk.de</b><span class="oq-serp__url">https://www.<span data-oq="domain2">tischlerei-eichenwerk.de</span> › <span data-oq="ohneurl">index.php?id=3</span></span></span></p>'
		. '<p class="oq-serp__titel" data-oq="ohnetitel">Startseite</p><p class="oq-serp__text" data-oq="ohnetext">Herzlich Willkommen auf unserer Homepage! Wir freuen uns über Ihren Besuch. Hier finden Sie alle Informationen rund um unser Unternehmen und unser umfangreiches …</p></div>';
	$mit = '<div class="oq-serp__eintrag oq-serp__eintrag--mit"><p class="oq-serp__quelle"><span class="oq-serp__favicon oq-serp__favicon--marke" aria-hidden="true" data-oq="ini">TE</span><span><b class="oq-serp__name" data-oq="name">Tischlerei Eichenwerk</b><span class="oq-serp__url">https://<span data-oq="domain3">tischlerei-eichenwerk.de</span> › <span data-oq="slug">leistungen</span></span></span></p>'
		. '<p class="oq-serp__titel" data-oq="titel">Tischler in Paderborn: Möbel nach Maß, Küchen, Innenausbau</p><p class="oq-serp__text" data-oq="text">Möbel und Küchen nach Maß aus unserer Werkstatt. Beratung vor Ort im Raum Paderborn, Delbrück und Salzkotten. Jetzt Termin anfragen.</p></div>';
	$fremd = '<div class="oq-serp__fremd" aria-hidden="true"><i></i><i></i><i></i></div>';
	$checks = '<ul class="oq-serp__checks" aria-live="polite">'
		. '<li data-oq-check="titel"><b>Titel</b><span>„Startseite“ sagt nichts über Leistung und Ort.</span></li>'
		. '<li data-oq-check="adresse"><b>Adresse</b><span>Eine Parameter-Adresse statt lesbarer Wörter.</span></li>'
		. '<li data-oq-check="text"><b>Beschreibung</b><span>Eine Begrüßung, die mitten im Satz abbricht.</span></li>'
		. '<li data-oq-check="marke"><b>Name und Symbol</b><span>Kein Website-Name, kein eigenes Symbol.</span></li></ul>';
	$in = oq_demo_chips( 'oq-serp-betrieb', 'Beispielbetrieb', array( 'tischlerei' => 'Tischlerei', 'physio' => 'Physiotherapie', 'steuer' => 'Steuerberatung' ), 'tischlerei' )
		. '<div class="oq-demo__schalter" role="group" aria-label="Darstellung"><button type="button" class="oq-demo__knopf" data-oq-modus="ohne" aria-pressed="true">Ohne Optimierung</button><button type="button" class="oq-demo__knopf" data-oq-modus="mit" aria-pressed="false">Mit Optimierung</button><button type="button" class="oq-demo__knopf" data-oq-modus="selbst" aria-pressed="false">Selbst schreiben</button></div>'
		. '<div class="oq-demo__zwei oq-serp__raster"><div class="oq-serp" data-modus="ohne"><p class="oq-serp__suche"><span aria-hidden="true">⌕</span> <span data-oq="such">tischler paderborn</span></p>' . $fremd . $ohne . $mit . $fremd . '</div>'
		. '<div class="oq-serp__seite"><p class="oq-serp__zustand" data-oq="zustand">Ohne Optimierung</p>' . $checks
		. '<div class="oq-serp__selbst" hidden><label for="oq-serp-titel">Ihr Seitentitel</label><input id="oq-serp-titel" type="text" maxlength="120" value="Tischler in Paderborn: Möbel nach Maß, Küchen, Innenausbau"><p class="oq-demo__info" data-oq="titelinfo" aria-live="polite"></p><label for="oq-serp-text">Ihre Beschreibung</label><textarea id="oq-serp-text" rows="3" maxlength="300">Möbel und Küchen nach Maß aus unserer Werkstatt. Beratung vor Ort im Raum Paderborn. Jetzt Termin anfragen.</textarea><p class="oq-demo__info" data-oq="textinfo" aria-live="polite"></p></div></div></div>';
	return oq_demo_rahmen( 'serp', 'Ihr Eintrag in der Ergebnisliste', $in, 'Vereinfachte Nachbildung mit erfundenen Beispielbetrieben, keine echte Google-Darstellung. Google kürzt Titel und Beschreibungen nach verfügbarer Breite und schreibt sie um, wenn sie nicht zur Suchanfrage passen. Ein guter Titel erhöht die Chance auf einen Klick, eine Position sagt er nicht voraus.' );
}

function oq_demo_html_crawler( $atts ) {
	$seiten = array(
		array( '/', 0, '' ), array( '/leistungen', 0, '' ), array( '/leistungen/kuechen', 1, '' ), array( '/leistungen/einbaumoebel', 1, '' ), array( '/leistungen/innenausbau', 1, '' ),
		array( '/ueber-uns', 0, '' ), array( '/ratgeber', 0, '' ), array( '/ratgeber/kueche-planen', 1, '' ), array( '/kontakt', 0, '' ), array( '/danke', 1, 'noindex' ), array( '/aktion-2019', 0, 'waise' ),
	);
	$baum = '<ol class="oq-crawler__baum">';
	foreach ( $seiten as $s ) {
		$zusatz = 'noindex' === $s[2] ? ' <em>noindex</em>' : ( 'waise' === $s[2] ? ' <em>nirgends verlinkt</em>' : '' );
		$baum .= '<li data-tiefe="' . (int) $s[1] . '"' . ( $s[2] ? ' data-art="' . esc_attr( $s[2] ) . '"' : '' ) . '><span class="oq-crawler__pfad">' . esc_html( $s[0] ) . $zusatz . '</span><span class="oq-crawler__status">unbekannt</span></li>';
	}
	$baum .= '</ol>';
	$in = '<div class="oq-crawler" data-p="0"><div class="oq-crawler__kopf"><span class="oq-crawler__bot" aria-hidden="true"></span><span>Crawler besucht <b>tischlerei-eichenwerk.de</b></span></div>' . $baum
		. '<div class="oq-crawler__stufen"><div class="oq-crawler__stufe" data-stufe="1"><small><b>1</b> Sammeln</small><span data-oq="gefunden">0</span></div><div class="oq-crawler__stufe" data-stufe="2"><small><b>2</b> Ordnen</small><span data-oq="index">0</span></div><div class="oq-crawler__stufe" data-stufe="3"><small><b>3</b> Ausspielen</small><span data-oq="treffer">0</span></div></div></div>'
		. '<div class="oq-crawler__steuer"><button type="button" class="oq-demo__start">Crawler starten <span class="oq-pfeil" aria-hidden="true">→</span></button><label class="oq-demo__zeile"><input type="checkbox" data-oq="sitemap"> Sitemap bei Google einreichen</label></div>'
		. '<p class="oq-demo__ergebnis" aria-live="polite" data-oq="status">Der Crawler folgt allen Links ab der Startseite. Starten Sie ihn und achten Sie auf die letzten beiden Adressen.</p>';
	return oq_demo_rahmen( 'crawler', 'So liest Google Ihre Website', $in, 'Vereinfachtes Modell mit einem erfundenen Beispielbetrieb. Echte Crawler arbeiten über Tage und Wochen und entscheiden selbst, was sie aufnehmen. Eine Aufnahme in den Index garantiert Google nicht.' );
}

function oq_demo_html_maps( $atts ) {
	$karte = '<svg class="oq-maps__karte" viewBox="0 0 400 300" role="img" aria-label="Kartenausschnitt mit der suchenden Person und vier Betrieben">'
		. '<rect width="400" height="300" rx="14" fill="#F6F1FC"/>'
		. '<path d="M-10 214C70 186 128 246 204 206S330 152 410 178" fill="none" stroke="#cfe3f7" stroke-width="16"/>'
		. '<path d="M40-10L118 310M-10 92L410 122M262-10L300 310M-10 262L410 236M150-10L180 120" fill="none" stroke="#fff" stroke-width="9"/>'
		. '<g class="oq-maps__gebiete" font-family="Arial" font-size="11" fill="#9b8fb0"><text x="150" y="176">Zentrum</text><text x="150" y="40">Nord</text><text x="350" y="86">Ost</text></g>'
		. '<circle class="oq-maps__radius" data-oq="radius" cx="200" cy="150" r="70"/>'
		. '<g data-oq="pins"></g><g data-oq="person"><circle class="oq-maps__puls" cx="200" cy="150" r="9"/><circle cx="200" cy="150" r="7" fill="#1a73e8" stroke="#fff" stroke-width="3"/></g></svg>';
	$liste = '<div class="oq-maps__pack"><p class="oq-maps__suche"><span aria-hidden="true">⌕</span> <span data-oq="such">heizungsbauer in der nähe</span></p>'
		. '<ol class="oq-maps__liste" aria-live="polite" data-oq="liste"><li class="ist-ich"><b>Ihr Betrieb (Beispiel)</b><small>4,2 ★ (12) · Heizungsbau</small></li><li><b>Mitbewerber A</b></li><li><b>Mitbewerber B</b></li></ol>'
		. '<p class="oq-maps__rest" data-oq="rest"></p></div>';
	$faktoren = '<div class="oq-maps__faktoren" aria-hidden="true"><p>So steht Ihr Betrieb in den drei Faktoren</p>'
		. '<div><span>Relevanz</span><i><b data-oq="f-rel"></b></i></div><div><span>Entfernung</span><i><b data-oq="f-ent"></b></i></div><div><span>Bekanntheit</span><i><b data-oq="f-bek"></b></i></div></div>';
	$steuer = '<div class="oq-demo__form oq-maps__steuer">'
		. oq_demo_chips( 'oq-maps-branche', 'Beispielbetrieb', array( 'heizung' => 'Heizungsbau', 'physio' => 'Physiotherapie', 'steuer' => 'Steuerberatung' ), 'heizung' )
		. oq_demo_chips( 'oq-maps-ort', 'Wo steht die suchende Person?', array( 'zentrum' => 'Zentrum', 'nord' => 'Nord', 'ost' => 'Ost' ), 'zentrum' )
		. '<label class="oq-demo__zeile"><input type="checkbox" data-oq="kategorie" checked> Hauptkategorie passt zur Suche</label>'
		. '<label class="oq-demo__zeile"><input type="checkbox" data-oq="profil"> Profil gepflegt: Fotos, Öffnungszeiten, Beiträge</label>'
		. '<label for="oq-maps-anzahl">Bewertungen: <output data-oq="anzahlwert">12</output></label><input id="oq-maps-anzahl" type="range" min="0" max="150" value="12" data-oq="anzahl">'
		. '<label for="oq-maps-schnitt">Durchschnitt: <output data-oq="schnittwert">4,2</output> Sterne</label><input id="oq-maps-schnitt" type="range" min="30" max="50" value="42" data-oq="schnitt"></div>';
	$in = '<div class="oq-maps"><div class="oq-maps__links">' . $karte . $faktoren . '</div><div class="oq-maps__rechts">' . $liste . $steuer . '</div></div>'
		. '<p class="oq-demo__ergebnis" aria-live="polite" data-oq="status">Ihr Betrieb ist der violette Pin, der blaue Punkt ist die suchende Person. Ändern Sie Standort, Kategorie oder Bewertungen und beobachten Sie die drei sichtbaren Einträge.</p>';
	return oq_demo_rahmen( 'maps', 'Die lokale Ergebnisliste: Was die Reihenfolge verschiebt', $in, 'Spielmodell mit erfundenen Betrieben. Google nennt Relevanz, Entfernung und Bekanntheit als Hauptfaktoren, veröffentlicht aber keine Gewichtung. Die Gewichtung hier ist eine eigene Annahme und sagt keine echte Position voraus.' );
}

function oq_demo_html_reviews( $atts ) {
	$in = oq_demo_chips( 'oq-rev-fall', 'Welche Bewertung?', array( 'lob' => 'Fünf Sterne', 'kritik' => 'Berechtigte Kritik', 'unfair' => 'Unfair oder falsch' ), 'kritik' )
		. '<div class="oq-demo__schalter" role="group" aria-label="Antwort"><button type="button" class="oq-demo__knopf" data-oq-antwort="schwach" aria-pressed="false">Schwache Antwort</button><button type="button" class="oq-demo__knopf" data-oq-antwort="gut" aria-pressed="true">Gute Antwort</button></div>'
		. '<div class="oq-rev"><div class="oq-rev__karte"><p class="oq-rev__kopf"><span class="oq-rev__avatar" data-oq="ini" aria-hidden="true">MK</span><span><b data-oq="autor">M. Krüger</b><small><span class="oq-rev__sterne" data-oq="sterne" role="img" aria-label="2 von 5 Sternen">★★☆☆☆</span> vor 2 Wochen</small></span></p><p class="oq-rev__text" data-oq="text">Termin wurde zweimal verschoben, ohne dass sich jemand gemeldet hat. Die Arbeit selbst war in Ordnung.</p>'
		. '<div class="oq-rev__antwort"><p class="oq-rev__von">Antwort des Inhabers</p><p data-oq="antwort">Guten Tag Herr Krüger, danke für die offenen Worte. Dass wir uns bei der zweiten Verschiebung nicht gemeldet haben, war unser Fehler. Wir haben die Terminplanung umgestellt, damit Sie und andere Kunden künftig rechtzeitig informiert werden. Gern sprechen wir persönlich: 05251 000 000.</p></div></div>'
		. '<ul class="oq-rev__punkte" aria-live="polite" data-oq="punkte"></ul></div>';
	return oq_demo_rahmen( 'reviews', 'Antworten auf Bewertungen: Wer hier mitliest', $in, 'Erfundene Beispiele. Antworten lesen vor allem spätere Interessenten. Falsche Bewertungen lassen sich bei Google melden, ob sie entfernt werden, entscheidet Google.' );
}

function oq_demo_html_care( $atts ) {
	/* Startzustand wie im Skript: Monat 12, ohne Betreuung */
	$kacheln = array(
		'updates' => array( 'Updates', 'rot', '17 Updates offen', 'Darunter mindestens ein Sicherheitsupdate' ),
		'sicher'  => array( 'Sicherheit', 'rot', 'Bekannte Lücke offen', 'Ein Plugin ist angreifbar, das Update wäre da' ),
		'backup'  => array( 'Backups', 'gelb', 'Ungeprüft', 'Seit 12 Monaten hat niemand eine Wiederherstellung versucht' ),
		'php'     => array( 'Server und PHP', 'gelb', 'Nur noch Sicherheitskorrekturen', 'Umstieg sollte geplant werden' ),
		'ssl'     => array( 'Zertifikat und Domain', 'gelb', 'Unbeobachtet', 'Hakt die Verlängerung, merkt es zuerst ein Besucher' ),
		'speed'   => array( 'Ladezeit', 'gelb', '2,8 s', 'Neue Bilder unkomprimiert, alte Skripte bremsen' ),
		'inhalt'  => array( 'Inhalte', 'rot', 'Seit 12 Monaten unverändert', 'Öffnungszeiten und Team stimmen nicht mehr' ),
		'monitor' => array( 'Überwachung', 'gelb', 'Niemand schaut zu', 'Ausfälle fallen zuerst Kunden auf' ),
	);
	$k = '';
	foreach ( $kacheln as $id => $t ) {
		$k .= '<li class="oq-cock__kachel" data-oq-kachel="' . esc_attr( $id ) . '" data-ampel="' . esc_attr( $t[1] ) . '"><span class="oq-cock__label">' . esc_html( $t[0] ) . '</span><b class="oq-cock__wert">' . esc_html( $t[2] ) . '</b><small class="oq-cock__notiz">' . esc_html( $t[3] ) . '</small><span class="oq-sr" data-oq-ampel>Status: ' . esc_html( 'gruen' === $t[1] ? 'grün' : $t[1] ) . '</span></li>';
	}
	$in = '<div class="oq-demo__schalter" role="group" aria-label="Betreuung"><button type="button" class="oq-demo__knopf" data-oq-modus="ohne" aria-pressed="true">Ohne Betreuung</button><button type="button" class="oq-demo__knopf" data-oq-modus="mit" aria-pressed="false">Mit Betreuung</button></div>'
		. '<div class="oq-demo__form"><label for="oq-care-monat">Monate nach dem Launch: <output data-oq="monatwert">12</output></label><input id="oq-care-monat" type="range" min="0" max="24" value="12" data-oq="monat"></div>'
		. '<div class="oq-cock" data-modus="ohne"><div class="oq-cock__kopf"><span class="oq-cock__punkt" aria-hidden="true"></span><b data-oq="domain">tischlerei-eichenwerk.de</b><span class="oq-cock__bilanz" data-oq="bilanz">0 grün · 5 gelb · 3 rot</span></div>'
		. '<ul class="oq-cock__raster" data-oq="raster">' . $k . '</ul>'
		. '<div class="oq-cock__log"><p class="oq-cock__logtitel">Was bis hierhin passiert ist <small>(Beispielereignisse)</small></p><ol data-oq="log"><li class="ist-nein"><b>Monat 11</b> Ein Plugin wird vom Entwickler eingestellt und bekommt keine Updates mehr.</li><li class="ist-nein"><b>Monat 8</b> Die Öffnungszeiten auf der Website stimmen nicht mehr.</li><li class="ist-nein"><b>Monat 5</b> Für ein Formular-Plugin wird eine Sicherheitslücke bekannt. Das Update wäre da.</li><li class="ist-nein"><b>Monat 2</b> Erste Plugin-Updates liegen bereit. Niemand spielt sie ein.</li></ol></div></div>'
		. '<p class="oq-demo__ergebnis" aria-live="polite" data-oq="status">Monat 12, ohne Betreuung: Jetzt sind die Baustellen auch für Besucher spürbar: alte Inhalte, langsamere Ladezeit, eine offene Lücke.</p>';
	return oq_demo_rahmen( 'care', 'Wartungs-Cockpit: Ihre Website Monat für Monat', $in, 'Vereinfachtes Modell mit erfundener Beispielwebsite und erfundenen Ereignissen. Keine Messdaten, keine Prognose. Es zeigt, wie sich typische Baustellen ohne Pflege summieren.' );
}

function oq_demo_html_notfall( $atts ) {
	$ohne = array(
		array( 'Bemerkt', 'Eine Kundin ruft an: Auf dem Smartphone sei die Seite verrutscht. Seit wann, weiß niemand.' ),
		array( 'Eingegrenzt', 'Welches Update war es? Ohne Protokoll beginnt die Suche. Die Zugänge liegen irgendwo in alten E-Mails.' ),
		array( 'Behoben', 'Ein Dienstleister muss sich erst einarbeiten. Ein Backup gibt es, ob es funktioniert, weiß niemand.' ),
		array( 'Danach', 'Aus Sorge vor dem nächsten Fehler werden Updates gar nicht mehr eingespielt. Die Lücken wachsen.' ),
	);
	$mit = array(
		array( 'Bemerkt', 'Vor dem Update sichern wir die Website, danach prüfen wir die wichtigsten Seiten. Der Fehler fällt uns auf, nicht Ihren Kunden.' ),
		array( 'Eingegrenzt', 'Das Protokoll zeigt, welches Plugin gerade aktualisiert wurde.' ),
		array( 'Behoben', 'Zurück auf den Stand vor dem Update. Die Lösung suchen wir in Ruhe, die Seite läuft weiter.' ),
		array( 'Danach', 'Das Update kommt wieder, sobald der Hersteller nachgebessert hat. Dokumentiert, nachvollziehbar.' ),
	);
	$spalte = function ( $titel, $cls, $schritte, $dauer ) {
		$h = '<div class="oq-not__spalte ' . $cls . '"><p class="oq-not__kopf">' . esc_html( $titel ) . '</p><ol class="oq-not__liste">';
		foreach ( $schritte as $i => $s ) {
			$h .= '<li class="oq-not__schritt"><span class="oq-not__nr" aria-hidden="true">' . ( $i + 1 ) . '</span><b>' . esc_html( $s[0] ) . '</b><span>' . esc_html( $s[1] ) . '</span></li>';
		}
		return $h . '</ol><p class="oq-not__dauer"><small>Typischer Verlauf</small><b>' . esc_html( $dauer ) . '</b></p></div>';
	};
	$in = oq_demo_chips( 'oq-not-fall', 'Was ist passiert?', array( 'update' => 'Update zerschießt das Layout', 'hack' => 'Website gehackt', 'ssl' => 'Zertifikat abgelaufen', 'formular' => 'Formular sendet nicht', 'offline' => 'Website nicht erreichbar' ), 'update' )
		. '<p><button type="button" class="oq-demo__start oq-magnetic" data-oq="abspielen">Ablauf abspielen <span class="oq-pfeil" aria-hidden="true">→</span></button></p>'
		. '<div class="oq-not" data-oq="buehne" aria-live="polite">' . $spalte( 'Ohne Betreuung', 'ist-ohne', $ohne, 'Tage, manchmal Wochen' ) . $spalte( 'Mit Betreuung', 'ist-mit', $mit, 'Stunden, je nach Schwere' ) . '</div>';
	return oq_demo_rahmen( 'notfall', 'Notfall-Vergleich: Wenn auf der Website etwas schiefgeht', $in, 'Beispielhafte Abläufe. Die Zeitangaben sind grobe Richtwerte, keine garantierte Reaktionszeit. Was wir zusagen, steht im Angebot.' );
}

/** Paketfinder: Daten identisch mit pricefinder.js (Startzustand: Starter). */
function oq_demo_pf_karte() {
	$inc = array( 'Individuelle Website mit bis zu fünf Seiten', 'Für Smartphone, Tablet und Desktop gebaut', 'SEO-Basis und Anbindung an die Google Search Console', 'DSGVO-Einrichtung mit Cookie-Consent', 'Übergabe mit kurzer Einweisung' );
	$li = '';
	foreach ( $inc as $i ) {
		$li .= '<li>' . esc_html( $i ) . '</li>';
	}
	return '<p class="oq-pf__label">Passender Einstieg</p><p class="oq-pf__paket">Starter</p><p class="oq-pf__preis">ab 279 EUR <small>einmalig</small></p>'
		. '<p class="oq-pf__text">Der professionelle Einstieg für kleinere Betriebe und Selbstständige, die solide auftreten wollen.</p>'
		. '<ul class="oq-pf__liste">' . $li . '</ul>'
		. '<p class="oq-pf__extra"><b>Danach optional:</b> Betreuung ab 149 EUR monatlich, monatlich kündbar.</p>'
		. '<p class="oq-pf__wege"><a class="oq-demo__start oq-magnetic" href="https://oriqen.de/kontakt/">Erstgespräch vereinbaren <span class="oq-pfeil" aria-hidden="true">→</span></a><a class="oq-pf__mehr" href="https://oriqen.de/webdesign/">Mehr zum Webdesign</a></p>';
}

function oq_demo_html_pricefinder( $atts ) {
	$in = '<form class="oq-demo__form" onsubmit="return false">'
		. oq_demo_chips( 'oq-pf-1', '1. Ihre Ausgangslage', array( 'neu' => 'Wir brauchen eine neue Website', 'besser' => 'Die Website bringt zu wenig', 'pflege' => 'Die Website steht und soll gepflegt werden' ), 'neu' )
		. oq_demo_chips( 'oq-pf-2', '2. Wie umfangreich?', array( 'klein' => 'Bis fünf Seiten', 'gross' => 'Mehrere Leistungsbereiche mit Unterseiten' ), 'klein' )
		. oq_demo_chips( 'oq-pf-3', '3. Wie wichtig ist Google?', array( 'basis' => 'Grundlagen reichen', 'strategie' => 'Sichtbarkeit ist ein Hauptziel' ), 'basis' )
		. oq_demo_chips( 'oq-pf-4', '4. Logo und Auftritt', array( 'steht' => 'Stehen und passen', 'logo' => 'Logo fehlt oder ist veraltet', 'cd' => 'Der ganze Auftritt braucht Ordnung' ), 'steht' )
		. '</form><div class="oq-pf__ergebnis" aria-live="polite" data-oq="ergebnis">' . oq_demo_pf_karte() . '</div>';
	return oq_demo_rahmen( 'pricefinder', 'Paketfinder: Welcher Einstieg passt zu Ihnen?', '<div class="oq-demo__zwei">' . $in . '</div>', 'Orientierung aus den Preisen auf oriqen.de. Den verbindlichen Preis legen wir nach dem Erstgespräch im Angebot fest. Nichts wird gespeichert oder übertragen.' );
}

/** Kostenplan: Wer bekommt welchen Euro? Startzustand identisch mit kosten.js. */
function oq_demo_html_kosten( $atts ) {
	$dritt = array(
		'hosting' => array( 'Hosting', '5 bis 15 EUR im Monat' ),
		'domain'  => array( 'Domain', '15 bis 20 EUR im Jahr' ),
		'consent' => array( 'Cookie-Consent', 'ab 49 EUR im Jahr' ),
		'recht'   => array( 'Rechtstexte mit Update-Service', 'ab 5,90 EUR im Monat' ),
	);
	$cb = '';
	foreach ( $dritt as $k => $d ) {
		$cb .= '<label class="oq-demo__zeile oq-ko__dritt"><input type="checkbox" data-oq-dritt="' . esc_attr( $k ) . '" checked> <span>' . esc_html( $d[0] ) . ' <small>' . esc_html( $d[1] ) . '</small></span></label>';
	}
	$in = '<form class="oq-demo__form" onsubmit="return false"><p class="oq-ko__kopf">An oriqen</p>'
		. oq_demo_chips( 'oq-ko-web', 'Website', array( 'keine' => 'Keine neue', 'starter' => 'Starter', 'pro' => 'Professional' ), 'starter' )
		. oq_demo_chips( 'oq-ko-pflege', 'Laufende Betreuung', array( 'ohne' => 'Ohne', 'mit' => 'Mit Betreuung' ), 'ohne' )
		. oq_demo_chips( 'oq-ko-marke', 'Markendesign', array( 'keins' => 'Keins', 'logo' => 'Logo-Projekt', 'cd' => 'Corporate Design' ), 'keins' )
		. oq_demo_chips( 'oq-ko-social', 'Social Media', array( 'nichts' => 'Nichts', 'mini' => 'Mini-Paket', 'profil' => 'Profil-Optimierung' ), 'nichts' )
		. '<fieldset class="oq-demo__gruppe"><legend>Direkt an Anbieter, auf Ihren Namen</legend>' . $cb . '</fieldset></form>'
		. '<div class="oq-ko"><div class="oq-demo__schalter" role="group" aria-label="Zeitraum"><button type="button" class="oq-demo__knopf" data-oq-jahr="1" aria-pressed="true">Erstes Jahr</button><button type="button" class="oq-demo__knopf" data-oq-jahr="2" aria-pressed="false">Ab dem zweiten Jahr</button></div>'
		. '<p class="oq-ko__summe"><small data-oq="zeitraum">Erstes Jahr, Richtwert</small><b data-oq="summe">ab 474 EUR</b></p>'
		. '<div class="oq-ko__balken" aria-hidden="true"><span class="ist-einmal" style="flex-grow:279"></span><span class="ist-lfd" style="flex-grow:0"></span><span class="ist-dritt" style="flex-grow:195"></span></div>'
		. '<ul class="oq-ko__zeilen"><li class="ist-einmal"><i aria-hidden="true"></i><span>Einmalig an oriqen</span><b data-oq="einmal">ab 279 EUR</b></li>'
		. '<li class="ist-lfd"><i aria-hidden="true"></i><span>Laufend an oriqen</span><b data-oq="lfd">0 EUR</b></li>'
		. '<li class="ist-dritt"><i aria-hidden="true"></i><span>Direkt an Hoster und Anbieter</span><b data-oq="dritt">195 bis 368 EUR</b></li></ul>'
		. '<p class="oq-demo__ergebnis" aria-live="polite" data-oq="satz">Im ersten Jahr fallen ab 474 EUR an. Davon gehen 195 bis 368 EUR direkt an Hoster und Anbieter, nicht an uns.</p></div>';
	return oq_demo_rahmen( 'kosten', 'Kostenplan: Wer bekommt welchen Euro?', '<div class="oq-demo__zwei">' . $in . '</div>', 'Richtwerte. Unsere Preise sind Untergrenzen wie auf oriqen.de, verbindlich ist das Angebot. Drittkosten sind typische Spannen je nach Tarif, teils zuzüglich Umsatzsteuer, Stand November 2026. Nichts wird gespeichert oder übertragen.' );
}

function oq_demo_html_checklist( $atts ) {
	$fragen = array( 'Ihre Website ist älter als drei Jahre.', 'Sie wissen nicht, für welche Suchbegriffe Sie gefunden werden.', 'Auf dem Smartphone wirkt die Seite eng oder lädt langsam.', 'Ihr Google-Unternehmensprofil ist unvollständig oder lange nicht gepflegt.', 'Über die Website kommen kaum Anfragen.', 'Seitentitel und Beschreibungen haben Sie nie bewusst geschrieben.', 'Mitbewerber erscheinen vor Ihnen, obwohl Sie mehr Erfahrung haben.', 'Sie haben keine Search Console eingerichtet oder schauen nie hinein.' );
	$in = '<ol class="oq-check__liste">';
	foreach ( $fragen as $i => $f ) {
		$in .= '<li><label class="oq-demo__zeile"><input type="checkbox" data-oq="frage"> ' . esc_html( $f ) . '</label></li>';
	}
	$label = $atts['label'] ? $atts['label'] : 'Kostenlose Analyse anfordern';
	$ziel = ! empty( $atts['ziel'] ) ? esc_url( home_url( $atts['ziel'] ) ) : '';
	$link = $ziel
		? '<a class="oq-demo__start oq-magnetic" href="' . $ziel . '">' . esc_html( $label ) . ' <span class="oq-pfeil" aria-hidden="true">→</span></a>'
		: '<a class="oq-demo__start oq-magnetic" href="https://oriqen.de/seo/seo-analyse/" target="_blank" rel="noopener">' . esc_html( $label ) . ' <span class="oq-pfeil" aria-hidden="true">→</span><span class="oq-sr"> (öffnet in neuem Tab)</span></a>';
	$in .= '</ol><p class="oq-demo__ergebnis" aria-live="polite" data-oq="ergebnis">Kreuzen Sie an, was auf Ihre Website zutrifft. Ab drei Treffern lohnt sich ein genauer Blick.</p><p>' . $link . '</p>';
	return oq_demo_rahmen( 'checklist', 'Selbstcheck: Lohnt sich die kostenlose Analyse?', $in, 'Ein grober Selbstcheck, keine Analyse. Nichts wird gespeichert oder übertragen.' );
}

function oq_demo_html_brand( $atts ) {
	$orte = array(
		'karte' => array( 'Visitenkarte', 'Tischlerei Eichenwerk', 'Möbel nach Maß aus Paderborn' ),
		'schild' => array( 'Schild am Eingang', 'Tischlerei Eichenwerk', 'Werkstatt und Ausstellung' ),
		'post'  => array( 'Beitrag auf Instagram', 'Neu in der Werkstatt', 'Esstisch aus Eiche' ),
		'web'   => array( 'Kopf der Website', 'Tischlerei Eichenwerk', 'Küchen · Möbel · Kontakt' ),
	);
	$li = '';
	foreach ( $orte as $k => $o ) {
		$li .= '<li class="oq-mw__ort oq-mw__ort--' . esc_attr( $k ) . '" data-oq-ort="' . esc_attr( $k ) . '"><small class="oq-mw__ortname">' . esc_html( $o[0] ) . '</small><div class="oq-mw__flaeche"><span class="oq-mw__sig" aria-hidden="true"></span><b class="oq-mw__t1">' . esc_html( $o[1] ) . '</b><span class="oq-mw__t2">' . esc_html( $o[2] ) . '</span></div></li>';
	}
	$in = oq_demo_chips( 'oq-mw-branche', 'Beispielbetrieb', array( 'handwerk' => 'Tischlerei', 'cafe' => 'Café', 'kanzlei' => 'Steuerkanzlei', 'salon' => 'Friseursalon' ), 'handwerk' )
		. '<div class="oq-mw__regler"><div class="oq-demo__form"><label for="oq-mw-name">Name des Betriebs</label><input id="oq-mw-name" type="text" maxlength="28" value="Tischlerei Eichenwerk" data-oq="name"></div>'
		. '<div class="oq-demo__form"><label for="oq-mw-tra">Charakter: <output data-oq="trawert">eher traditionell</output></label><input id="oq-mw-tra" type="range" min="0" max="4" step="1" value="1" data-oq="tra" aria-describedby="oq-mw-tra-h"><small id="oq-mw-tra-h" class="oq-mw__skala"><span>traditionell</span><span>modern</span></small></div>'
		. '<div class="oq-demo__form"><label for="oq-mw-leb">Temperament: <output data-oq="lebwert">eher ruhig</output></label><input id="oq-mw-leb" type="range" min="0" max="4" step="1" value="1" data-oq="leb" aria-describedby="oq-mw-leb-h"><small id="oq-mw-leb-h" class="oq-mw__skala"><span>ruhig</span><span>lebendig</span></small></div></div>'
		. oq_demo_chips( 'oq-mw-ton', 'Grundton', array( 'wald' => 'Waldgrün', 'ozean' => 'Ozean', 'terrakotta' => 'Terrakotta', 'violett' => 'Violett', 'anthrazit' => 'Anthrazit' ), 'wald' )
		. '<div class="oq-demo__schalter" role="group" aria-label="Markensystem"><button type="button" class="oq-demo__knopf" data-oq-sys="mit" aria-pressed="true">Mit Markensystem</button><button type="button" class="oq-demo__knopf" data-oq-sys="ohne" aria-pressed="false">Ohne Markensystem</button></div>'
		. '<div class="oq-mw" data-modus="mit"><div class="oq-mw__board">'
		. '<div class="oq-mw__logo"><span class="oq-mw__sig oq-mw__sig--gross" aria-hidden="true"></span><div><b class="oq-mw__wort" data-oq="wort">Tischlerei Eichenwerk</b><span class="oq-mw__claim" data-oq="claim">Möbel nach Maß aus Paderborn</span></div></div>'
		. '<div class="oq-mw__palette"><small>Farben</small><ul data-oq="farben"><li><i></i><span>Primär</span></li><li><i></i><span>Akzent</span></li><li><i></i><span>Hell</span></li></ul><p class="oq-mw__kontrast" data-oq="kontrast">Kontrast geprüft</p></div>'
		. '<div class="oq-mw__typo"><small>Schriften</small><p class="oq-mw__aa" aria-hidden="true">Aa</p><p data-oq="schriften">Überschrift: Georgia · Text: Arial</p></div>'
		. '</div><ul class="oq-mw__orte">' . $li . '</ul></div>'
		. '<p class="oq-demo__ergebnis" aria-live="polite" data-oq="status">Mit Markensystem: ein Zeichen, zwei Schriften, drei Farben. Jeder Kontakt zahlt auf dieselbe Marke ein.</p>';
	return oq_demo_rahmen( 'brand', 'Markenwelt: Aus einem Namen wird ein System', $in, 'Automatisch erzeugt aus Name, Charakter und Grundton, mit Schriften, die auf jedem Gerät vorhanden sind. Beispielnamen erfunden. Eine echte Marke entsteht aus Gesprächen, Skizzen und Tests, nicht per Regler.' );
}

function oq_demo_html_logotest( $atts ) {
	/* Startzustand wie im Skript: Logo „Detailverliebt“ */
	$tests = array(
		'favicon' => array( 'Browser-Tab, 16 Pixel', 'Die feinen Linien verschwimmen zu einem grauen Fleck.', false ),
		'karte'   => array( 'Visitenkarte', 'Auf der Visitenkarte wirkt es edel, der kleine Zusatz ist gerade noch lesbar.', true ),
		'fassade' => array( 'Fassade aus 20 Metern', 'Der Name ist zu dünn, der Zusatz aus der Entfernung nicht lesbar.', false ),
		'mono'    => array( 'Einfarbig: Stempel und Fax', 'Der Farbverlauf wird zu einer grauen Fläche, feine Linien laufen zu.', false ),
		'dunkel'  => array( 'Auf dunklem Grund', 'Dunkle Schrift auf dunklem Grund: Der Name verschwindet. Eine helle Fassung gibt es nicht.', false ),
		'eigen'   => array( 'Unverwechselbar', 'Eigenständig, so sieht niemand sonst aus.', true ),
	);
	$li = '';
	foreach ( $tests as $k => $t ) {
		$li .= '<li class="oq-lt__test" data-oq-test="' . esc_attr( $k ) . '" data-ok="' . ( $t[2] ? 'ja' : 'nein' ) . '"><div class="oq-lt__buehne oq-lt__buehne--' . esc_attr( $k ) . '" aria-hidden="true"></div><p class="oq-lt__name"><b>' . esc_html( $t[0] ) . '</b><span class="oq-sr" data-oq-urteil-sr>' . ( $t[2] ? 'Bestanden: ' : 'Nicht bestanden: ' ) . '</span><span class="oq-lt__urteil">' . esc_html( $t[1] ) . '</span></p></li>';
	}
	$in = oq_demo_chips( 'oq-lt-logo', 'Welches Logo soll in den Test?', array( 'detail' => 'Detailverliebt', 'generator' => 'Aus dem Logo-Generator', 'klar' => 'Klar entwickelt' ), 'detail' )
		. '<ul class="oq-lt">' . $li . '</ul>'
		. '<p class="oq-demo__ergebnis" aria-live="polite" data-oq="status">Detailverliebt: 2 von 6 Tests bestanden. Schön auf dem Bildschirm, im Alltag kaum zu gebrauchen.</p>';
	return oq_demo_rahmen( 'logotest', 'Logo-Härtetest: Funktioniert Ihr Zeichen überall?', $in, 'Drei erfundene Logos für eine erfundene Glaserei. Die Bühnen sind vereinfacht nachgestellt: kleine Größe, Entfernung, einfarbiger Druck, dunkler Grund.' );
}

function oq_demo_html_feed( $atts ) {
	$punkte = array(
		'bio'    => 'Bio sagt, was, wo und wie',
		'link'   => 'Link mit Website und Impressum',
		'high'   => 'Highlights als Wegweiser',
		'raster' => 'Raster mit System im 3:4-Format',
	);
	$schalter = '<fieldset class="oq-demo__gruppe"><legend>Was am Profil gepflegt ist</legend><div class="oq-feed__schalter">';
	foreach ( $punkte as $k => $label ) {
		$schalter .= '<label class="oq-demo__zeile"><input type="checkbox" data-oq-teil="' . esc_attr( $k ) . '"><span>' . esc_html( $label ) . '</span></label>';
	}
	$schalter .= '</div></fieldset>';
	$kacheln = '';
	for ( $i = 0; $i < 9; $i++ ) {
		$kacheln .= '<li><span></span></li>';
	}
	$in = oq_demo_chips( 'oq-feed-branche', 'Beispielbetrieb', array( 'handwerk' => 'Tischlerei', 'cafe' => 'Café', 'beratung' => 'Steuerkanzlei' ), 'handwerk' )
		. $schalter . '<div class="oq-feed__wrap"><div class="oq-feed" data-oq="profil" aria-label="Vorschau eines erfundenen Profils">'
		. '<div class="oq-feed__kopf"><span class="oq-feed__avatar" data-oq="avatar" aria-hidden="true">?</span><div class="oq-feed__name"><b data-oq="name">tischlerei.holm</b><small data-oq="zahlen">48 Beiträge</small></div></div>'
		. '<p class="oq-feed__bio" data-oq="bio">Willkommen auf unserer Seite!</p><p class="oq-feed__link" data-oq="link" hidden></p>'
		. '<ul class="oq-feed__high" data-oq="high" aria-label="Highlights"></ul>'
		. '<ol class="oq-feed__raster" data-oq="raster">' . $kacheln . '</ol></div>'
		. '<div class="oq-feed__seite"><ul class="oq-rev__punkte" aria-live="polite" data-oq="punkte"></ul><p class="oq-demo__ergebnis" aria-live="polite" data-oq="status">0 von 4 Punkten gepflegt. Ein Besucher entscheidet in Sekunden, ob er bleibt.</p></div></div>';
	return oq_demo_rahmen( 'feed', 'Ihr Profil in drei Sekunden: Was ein Besucher sieht', $in, 'Erfundene Profile. Instagram zeigt Beiträge im Profil seit 2025 im Hochformat 3:4. Impressum: Bei geschäftlichen Profilen muss es in höchstens zwei Klicks erreichbar sein.' );
}

function oq_demo_html_plan( $atts ) {
	$in = oq_demo_chips( 'oq-plan-branche', 'Beispielbetrieb', array( 'handwerk' => 'Tischlerei', 'cafe' => 'Café', 'beratung' => 'Steuerkanzlei' ), 'handwerk' )
		. oq_demo_chips( 'oq-plan-ziel', 'Was soll der Kanal leisten?', array( 'bekannt' => 'Bekannter werden', 'anfragen' => 'Mehr Anfragen', 'team' => 'Mitarbeitende finden' ), 'bekannt' )
		. '<div class="oq-demo__form"><label for="oq-plan-takt">Beiträge pro Woche: <output data-oq="taktwert">2</output></label><input id="oq-plan-takt" type="range" min="1" max="3" step="1" value="2" data-oq="takt"></div>'
		. '<div class="oq-plan__mix" data-oq="mix" aria-hidden="true"></div><ul class="oq-plan__legende" data-oq="legende"></ul>'
		. '<ol class="oq-plan" data-oq="plan" aria-live="polite">'
		. '<li class="oq-plan__woche"><b>Woche 1</b><span class="oq-plan__post" data-art="einblick"><small>Einblick · Reel</small>Ein Projekt von der Skizze bis zur Montage</span><span class="oq-plan__post" data-art="wissen"><small>Wissen · Karussell</small>Welches Holz für welchen Raum?</span></li>'
		. '<li class="oq-plan__woche"><b>Woche 2</b><span class="oq-plan__post" data-art="team"><small>Team · Bild</small>Wer bei uns was macht</span><span class="oq-plan__post" data-art="vorher"><small>Vorher und nachher · Karussell</small>Altbau-Küche, vorher und nachher</span></li>'
		. '</ol><p class="oq-demo__ergebnis" aria-live="polite" data-oq="status">Acht Beiträge im Monat, gemischt aus Einblicken, Wissen und Team.</p>';
	return oq_demo_rahmen( 'plan', 'Ihr Redaktionsplan für vier Wochen', $in, 'Erfundene Beispielthemen. Im echten Projekt entstehen die Themen aus dem, was Ihr Betrieb ohnehin erlebt. Die Gewichtung ist eine Faustregel aus unserer Planung, keine Messung.' );
}

function oq_demo_html_caption( $atts ) {
	$in = oq_demo_chips( 'oq-cap-branche', 'Beispielbetrieb', array( 'handwerk' => 'Tischlerei', 'cafe' => 'Café', 'beratung' => 'Steuerkanzlei' ), 'handwerk' )
		. '<div class="oq-demo__schalter" role="group" aria-label="Beispieltext"><button type="button" class="oq-demo__knopf" data-oq-cap="schwach" aria-pressed="true">Schwacher Text</button><button type="button" class="oq-demo__knopf" data-oq-cap="gut" aria-pressed="false">Starker Text</button></div>'
		. '<div class="oq-cap"><div class="oq-cap__post" aria-label="Vorschau des Beitrags">'
		. '<p class="oq-cap__kopf"><span class="oq-feed__avatar" data-oq="avatar" aria-hidden="true">TH</span><b data-oq="name">tischlerei.holm</b></p>'
		. '<div class="oq-cap__bild" data-oq="bild"><span data-oq="bildtext">Esstisch aus Eiche</span></div>'
		. '<p class="oq-cap__aktionen" aria-hidden="true"><span>♡</span><span>◌</span><span>➤</span></p>'
		. '<p class="oq-cap__text"><b data-oq="name2">tischlerei.holm</b> <span data-oq="sichtbar">Wieder ein tolles Projekt fertig. Danke an alle!</span><span data-oq="rest" hidden></span> <button type="button" class="oq-cap__mehr" data-oq="mehr" hidden>… mehr</button></p></div>'
		. '<div class="oq-cap__seite"><label class="oq-cap__label" for="oq-cap-text">Bildunterschrift, frei bearbeitbar</label><textarea id="oq-cap-text" rows="6" maxlength="2200" data-oq="eingabe">Wieder ein tolles Projekt fertig. Danke an alle! #tischler #holz #handwerk #handmade #interior #design #love #instagood</textarea>'
		. '<p class="oq-demo__info" data-oq="zaehler" aria-live="polite"></p><ul class="oq-rev__punkte" aria-live="polite" data-oq="punkte"></ul></div></div>';
	return oq_demo_rahmen( 'caption', 'Die ersten Zeilen entscheiden: Bildunterschrift im Feed', $in, 'Erfundene Beispiele. Im Feed zeigt Instagram nur ungefähr die ersten 125 Zeichen, der Rest liegt hinter „… mehr“. Seit Ende 2025 sind höchstens fünf Hashtags pro Beitrag möglich. Die Prüfung ist eine einfache Textregel, keine Bewertung durch Instagram.' );
}

function oq_demo_html_beforeafter( $atts ) {
	$vor = esc_url( $atts['before'] );
	$nach = esc_url( $atts['after'] );
	if ( ! $vor || ! $nach ) {
		return '';
	}
	$label = $atts['label'] ? $atts['label'] : 'Vorher und nachher';
	$in = '<div class="oq-ba" style="--oq-ba:50%"><img src="' . $nach . '" alt="' . esc_attr( $label . ': nachher' ) . '" loading="lazy"><div class="oq-ba__vorher"><img src="' . $vor . '" alt="' . esc_attr( $label . ': vorher' ) . '" loading="lazy"></div><span class="oq-ba__griff" aria-hidden="true"></span><span class="oq-ba__tag oq-ba__tag--l">Vorher</span><span class="oq-ba__tag oq-ba__tag--r">Nachher</span></div>'
		. '<label class="oq-sr" for="oq-ba-' . esc_attr( md5( $vor . $nach ) ) . '">Anteil Vorher</label><input class="oq-ba__regler" id="oq-ba-' . esc_attr( md5( $vor . $nach ) ) . '" type="range" min="0" max="100" value="50">';
	return oq_demo_rahmen( 'beforeafter', $label, $in, 'Regler ziehen oder mit den Pfeiltasten bewegen.' );
}

/**
 * Beispielauswertung einer SEO-Analyse (erfundener Betrieb). bericht.js liest die Daten aus data-json.
 * Startzustand: Grundanalyse, Bereich „Auffindbarkeit“.
 */
function oq_demo_bericht_daten() {
	return array(
		'struktur'  => array( 'Aufbau und Nutzerführung', 'gruen', 'Klarer Aufbau, die Leistungen sind gut erreichbar. Nur der Anfrage-Knopf fehlt auf dem Smartphone im sichtbaren Bereich.', 'Anfrage-Knopf nach oben holen, damit Interessenten nicht suchen müssen.', array( 'Navigation und Seitenaufbau', 'Weg vom Einstieg zur Anfrage', 'Darstellung auf dem Smartphone' ), array( 'Seitentitel und Beschreibungen aller Seiten', 'Überschriften von H1 bis H3', 'Verlinkung zwischen den Leistungen' ) ),
		'inhalte'   => array( 'Inhalte und Vertrauen', 'gelb', 'Schöne Projektbilder, aber kaum Text dazu. Bewertungen und ein Foto vom Team fehlen, Kontaktdaten stehen nur auf der Kontaktseite.', 'Zu jedem Projekt zwei, drei Sätze: was, wo, für wen. Team und Werkstatt zeigen, ausgewählte Bewertungen einbinden.', array( 'Substanz der wichtigsten Seiten', 'Sichtbare Vertrauenssignale', 'Erreichbarkeit der Kontaktdaten' ), array( 'Textqualität je Leistungsseite', 'Alternativtexte der Bilder', 'FAQ und strukturierte Daten' ) ),
		'begriffe'  => array( 'Suchbegriffe', 'rot', 'Die Website spricht von „individuellem Interior“. Gesucht wird in der Region eher nach „Tischler Paderborn“ oder „Einbauschrank nach Maß“, und genau diese Wörter kommen kaum vor.', 'Die Sprache der Kunden übernehmen: Leistung plus Ort in Seitentitel, Überschriften und Text.', array( 'Realistisch erreichbare Suchbegriffe', 'Regionale Kombinationen', 'Lücken auf der Website' ), array( 'Einschätzung der Nachfrage je Begriff', 'Zuordnung Begriff zu Seite', 'Ideen für Ratgeberbeiträge' ) ),
		'wettbewerb'=> array( 'Regionaler Wettbewerb', 'gelb', 'Drei Mitbewerber im Umkreis haben eigene Seiten je Leistung und deutlich mehr Bewertungen. Bei Altbau und Einzelanfertigung ist aber niemand klar aufgestellt.', 'Die eigene Stärke besetzen: Altbau und Maßanfertigung sichtbar nach vorn.', array( 'Wer in der Region sichtbar ist', 'Stärken und Lücken der Mitbewerber', 'Mögliche Positionierung' ), array( 'Vergleich je Mitbewerber', 'Themen, die niemand besetzt', 'Prioritäten nach Aufwand' ) ),
		'finden'    => array( 'Auffindbarkeit bei Google', 'rot', 'Im Google-Unternehmensprofil steht noch die alte Telefonnummer, in zwei Verzeichnissen eine andere Schreibweise des Namens. Die Hauptkategorie lautet „Möbelgeschäft“ statt „Tischlerei“.', 'Profil korrigieren, Kategorie anpassen und Name, Adresse, Telefon überall gleich schreiben.', array( 'Google-Unternehmensprofil', 'Name, Adresse, Telefon in Verzeichnissen', 'Fehlende Einträge' ), array( 'Kategorien und Leistungen im Profil', 'Fotos und Beiträge', 'Bewertungen und Antworten' ) ),
		'technik'   => array( 'Technik und Tempo', 'gelb', 'Auf dem Smartphone lädt die Startseite spürbar langsam, weil Projektfotos unkomprimiert sind. Zwei alte Adressen sind noch bei Google, zeigen aber nur eine Fehlerseite.', 'Bilder komprimieren, alte Adressen weiterleiten, danach erneut messen.', array(), array( 'Ladezeit auf dem Smartphone', 'Fehlerseiten und Weiterleitungen', 'Indexierung und Sitemap', 'Sichere Verbindung und Grundtechnik' ) ),
	);
}

function oq_demo_html_bericht( $atts ) {
	$d     = oq_demo_bericht_daten();
	$sr    = array( 'gruen' => 'gut', 'gelb' => 'mit Luft nach oben', 'rot' => 'größter Hebel' );
	$k     = '';
	foreach ( $d as $id => $b ) {
		$nur = empty( $b[4] );
		$k  .= '<li><button type="button" class="oq-ber__kachel" data-oq-bereich="' . esc_attr( $id ) . '" data-ampel="' . esc_attr( $nur ? 'aus' : $b[1] ) . '" aria-pressed="' . ( 'finden' === $id ? 'true' : 'false' ) . '"' . ( $nur ? ' disabled' : '' ) . '>'
			. '<span class="oq-ber__name">' . esc_html( $b[0] ) . '</span>'
			. '<small class="oq-ber__status" data-oq-status>' . esc_html( $nur ? 'nur in der erweiterten Analyse' : ucfirst( $sr[ $b[1] ] ) ) . '</small></button></li>';
	}
	$f   = $d['finden'];
	$pp  = '';
	foreach ( $f[4] as $p ) {
		$pp .= '<li>' . esc_html( $p ) . '</li>';
	}
	$in = '<div class="oq-demo__schalter" role="group" aria-label="Umfang"><button type="button" class="oq-demo__knopf" data-oq-umfang="grund" aria-pressed="true">Grundanalyse, kostenlos</button><button type="button" class="oq-demo__knopf" data-oq-umfang="erweitert" aria-pressed="false">Erweiterte Analyse, 29 EUR</button></div>'
		. '<div class="oq-ber" data-umfang="grund"><div class="oq-ber__kopf"><span class="oq-ber__doc" aria-hidden="true"></span><div><b>Auswertung: Tischlerei Eichenwerk, Paderborn</b><small data-oq="bilanz">5 Bereiche · 15 Prüfpunkte</small></div></div>'
		. '<ul class="oq-ber__raster" data-oq="raster">' . $k . '</ul>'
		. '<div class="oq-ber__detail" data-oq="detail" data-ampel="rot" aria-live="polite"><p class="oq-ber__titel"><span data-oq="titel">' . esc_html( $f[0] ) . '</span> <span class="oq-ber__badge" data-oq="badge">Größter Hebel</span></p>'
		. '<p><b>Befund</b> <span data-oq="befund">' . esc_html( $f[2] ) . '</span></p>'
		. '<p><b>Unsere Empfehlung</b> <span data-oq="empfehlung">' . esc_html( $f[3] ) . '</span></p>'
		. '<p class="oq-ber__pp-titel">Geprüft in diesem Bereich</p><ul class="oq-ber__pp" data-oq="pp">' . $pp . '</ul></div>'
		. '<div class="oq-ber__plan"><p class="oq-ber__pp-titel">Wo wir anfangen würden</p><ol data-oq="plan"><li>Auffindbarkeit bei Google</li><li>Suchbegriffe</li><li>Inhalte und Vertrauen</li></ol></div></div>'
		. '<div hidden data-oq="daten" data-json="' . esc_attr( wp_json_encode( $d ) ) . '"></div>'
		. '<p class="oq-demo__ergebnis" aria-live="polite" data-oq="satz">Grundanalyse: ein ehrlicher Überblick über fünf Bereiche mit den wichtigsten Hebeln und einer klaren Reihenfolge.</p>';
	return oq_demo_rahmen( 'bericht', 'Beispielauswertung: So sieht Ihre SEO-Analyse aus', $in, 'Erfundener Beispielbetrieb mit erfundenen Befunden. Die Prüfpunkte zeigen den typischen Umfang, was die erweiterte Analyse im Einzelnen umfasst, besprechen wir individuell. Nichts wird gespeichert oder übertragen.' );
}
